#include "libSystem.h"
#include <stdio.h>

int main()
{
	//Create a VTEXSystem pointer
	LibSystem *pSystem;
	
  /*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if the driver is not found in the COM registry*/

	try
	{
		pSystem = LibSystem::Create();

		/*We want to do the Initialization a try/catch block so that our test code
		doesn't run if we fail to initialize.*/
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pSystem->Initialize("TCPIP::10.1.4.55::INSTR",true,true, "");

			/* The Event Log keeps track of received LXI LAN Event Packets for us. It is enabled in circular-buffer mode by default,
			but also has a fifo-mode which stops when it is full. */
			
			//The event log can be disabled if the user doesn't want to spend system resources logging packets. 
			pSystem->EventLog->Enabled = false;

			//However, leaving the log enabled can be helpful if using LAN triggers, to help debug issues with a test system
			pSystem->EventLog->Enabled = true;

			//We can also change the system so that it stops recording events when the log is full.
			pSystem->InstrumentSpecific->EventLogOverflowMode = VTEXSystemEventLogOverflowStop;

			//We can also retrieve current entries in the event log, if there are any
			if(pSystem->EventLog->EntryCount > 0)
			{
				std::string entry = pSystem->EventLog->GetNextEntry();
			}

			//Or, we can clear the entire log
			pSystem->EventLog->Clear();

			//Close the initialized session
			pSystem->Close();
		}
    catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
