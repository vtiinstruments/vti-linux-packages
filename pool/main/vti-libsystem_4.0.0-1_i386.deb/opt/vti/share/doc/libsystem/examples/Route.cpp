#include "libSystem.h"
#include <stdio.h>
#ifndef _WIN32
#include <unistd.h>
#endif

int main()
{
	//Create a VTEXSystem pointer
	LibSystem *pSystem;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created System pointer
		pSystem = LibSystem::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pSystem->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			//The first Event example using the routing interface
			pSystem->InstrumentSpecific->Route->Destinations->Item["LXI2"]->SourcesList = "LAN3";
			pSystem->InstrumentSpecific->Route->Destinations->Item["LXI2"]->DriveMode = VTEXSystemEventDriveModeDriven;

			/*That example was more work to do in Route than in Event. Let's try the second Event
			example. Note that we have to clear the SourcesList since LXI does not support multiple
			sources.*/
			pSystem->InstrumentSpecific->Route->Destinations->Item["LXI2"]->SourcesList = "";
			pSystem->InstrumentSpecific->Route->Destinations->Item["LXI2"]->InvertedSourcesList = "LAN3";
			pSystem->InstrumentSpecific->Route->Destinations->Item["LXI2"]->DriveMode = VTEXSystemEventDriveModeDriven;

			/*The next thing we're going to do is impossible in the Events interface. We're going to 
			toggle DIO3 for 5 seconds. Note that the SourcesList and InvertedSourcesList must be
			empty for software control to work.*/
			//If the line is undriven, changing its state will have no effect.
			pSystem->InstrumentSpecific->Route->Destinations->Item["DIO3"]->DriveMode = VTEXSystemEventDriveModeDriven;
			pSystem->InstrumentSpecific->Route->Destinations->Item["DIO3"]->SoftwareState = 1;
			usleep(5000000);
			pSystem->InstrumentSpecific->Route->Destinations->Item["DIO3"]->SoftwareState = 0;

			/*What happens if we assign multiple source to a line? By default they're logical-ANDed
			together, just like Arm sources. Note that we can have multiple sources in each 
			SourcesList if we want to.*/
			pSystem->InstrumentSpecific->Route->Destinations->Item["BPL2"]->SourcesList = "LXI2,DIO3";
			pSystem->InstrumentSpecific->Route->Destinations->Item["BPL2"]->InvertedSourcesList = "LAN3";
			//We can change it to Logical-OR as well
			pSystem->InstrumentSpecific->Route->Destinations->Item["BPL2"]->OrEnabled = true;
			
			//Close the initialized session
			pSystem->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
