#include "libSystem.h"
#include <stdio.h>

int main()
{
	//Create a VTEXSystem pointer
	LibSystem *pSystem;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created System pointer
		pSystem = LibSystem::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pSystem->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			//In the first example, I want an arm source of DIO3
			pSystem->Arm->Sources->Item["DIO3"]->Enabled = true;

			//Now I want to use either DIO3 or LXI2
			pSystem->Arm->Sources->Item["DIO3"]->Enabled = true;
			pSystem->Arm->Sources->Item["LXI2"]->Enabled = true;

			//If we didn't perform the next command, it is unlikely we would never arm the device
			pSystem->Arm->Sources->OrEnabled = true;

			/* In this scenario, all the DIO lines must have gone high and we got a rising edge on 
			LAN 4*/
			pSystem->Arm->Sources->Item["DIO0"]->Enabled = true;
			pSystem->Arm->Sources->Item["DIO1"]->Enabled = true;
			pSystem->Arm->Sources->Item["DIO2"]->Enabled = true;
			pSystem->Arm->Sources->Item["DIO3"]->Enabled = true;
			pSystem->Arm->Sources->Item["DIO4"]->Enabled = true;
			pSystem->Arm->Sources->Item["DIO5"]->Enabled = true;
			pSystem->Arm->Sources->Item["DIO6"]->Enabled = true;
			pSystem->Arm->Sources->Item["DIO7"]->Enabled = true;

			pSystem->Arm->Sources->Item["DIO0"]->Detection = VTEXSystemArmSourceDetectionHigh;
			pSystem->Arm->Sources->Item["DIO1"]->Detection = VTEXSystemArmSourceDetectionHigh;
			pSystem->Arm->Sources->Item["DIO2"]->Detection = VTEXSystemArmSourceDetectionHigh;
			pSystem->Arm->Sources->Item["DIO3"]->Detection = VTEXSystemArmSourceDetectionHigh;
			pSystem->Arm->Sources->Item["DIO4"]->Detection = VTEXSystemArmSourceDetectionHigh;
			pSystem->Arm->Sources->Item["DIO5"]->Detection = VTEXSystemArmSourceDetectionHigh;
			pSystem->Arm->Sources->Item["DIO6"]->Detection = VTEXSystemArmSourceDetectionHigh;
			pSystem->Arm->Sources->Item["DIO7"]->Detection = VTEXSystemArmSourceDetectionHigh;
			pSystem->Arm->Sources->Item["LAN4"]->Enabled = true;
			
			//Close the initialized session
			pSystem->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
