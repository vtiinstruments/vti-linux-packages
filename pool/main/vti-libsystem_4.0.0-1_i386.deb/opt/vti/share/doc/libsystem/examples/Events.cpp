#include "libSystem.h"
#include <stdio.h>

int main()
{
	//Create a VTEXSystem pointer
	LibSystem *pSystem;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created System pointer
		pSystem = LibSystem::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pSystem->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			//Route all signals from LAN3 to LXI2
			pSystem->Events->Item["LXI2"]->Source = "LAN3";
			pSystem->Events->Item["LXI2"]->DriveMode = VTEXSystemEventDriveModeDriven;

			//Route & invert all signals from LAN3 to LXI2
			pSystem->Events->Item["LXI2"]->Source = "LAN3";
			pSystem->Events->Item["LXI2"]->Slope = VTEXSystemSourceSlopeFall;
			pSystem->Events->Item["LXI2"]->DriveMode = VTEXSystemEventDriveModeDriven;
			
			//Close the initialized session
			pSystem->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
