#include "libSystem.h"
#include <stdio.h>

//The failsafe signal on the backplane, called BPL_INSFAIL, is an active low signal available to plugin modules in an EX1200 chassis. 
//When the signal is asserted low, plugin modules will revert to a safe state. In the case of switch modules, relays will open. 
//Plugin modules will also block any commands and indicate an error to software. 
//Modules will remain in this state until they are reset, either through the driver, web interface, or rear panel reset button.

//The BPL_INSFAIL signal is controlled through the VTEXSystem driver. External triggers, such as the rear panel DIO triggers, can be routed to BPL_INSFAIL. 
//The following is an example of routing the rear panel DIO7 trigger to BPL_INSFAIL

int main()
{
  //Create a VTEXSystem pointer
  LibSystem *pSystem;
  try
  {
    /*We want to instantiate a pointer to the driver in a try/catch block so that we fail
      properly if there is an error*/
    pSystem = LibSystem::Create();
    
    try
    {
			pSystem->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");
      /*************************************************************************************************************
       * Example 1: Make sure 5V is connected to DIO7. If not, Fail safe condition will ne asserted once the DIO channel is routed.
       * Refer to the connection diagram(1) on how to make connections
       **************************************************************************************************************/
      //Configure the DIO7
      pSystem->InstrumentSpecific->Route->Destinations->Item["DIO7"]->DriveMode = VTEXSystemEventDriveModeOff;

      //Route the DIO to BPL Failsafe line. Whenever DIO goes low the BPL Fail safe condition will be activated 
      pSystem->InstrumentSpecific->Route->Destinations->Item["BPL_INSFAIL"]->SourcesList = "DIO7";// drive BPL_INSFAIL with an external trigger
      pSystem->InstrumentSpecific->Route->Destinations->Item["BPL_INSFAIL"]->DriveMode = VTEXSystemEventDriveModeDriven;

      //Note: Fail safe condition can also be driven by LXI events or LAN events

      /***********************************************************************************************************************
       * Example2: In this DIO6 is used to upply 5V to DIO7. Whenever the 5V is pulled low, failsafe condition will be asserted. 
       * Refer to the connection diagram(2) on how to make connections
       ************************************************************************************************************************/
      pSystem->Utility->Reset();

      //Configure the DIO7
      pSystem->InstrumentSpecific->Route->Destinations->Item["DIO7"]->DriveMode = VTEXSystemEventDriveModeOff;
      //Configure the DIO6 and switch it to high state
      pSystem->InstrumentSpecific->Route->Destinations->Item["DIO6"]->DriveMode = VTEXSystemEventDriveModeDriven;
      pSystem->InstrumentSpecific->Route->Destinations->Item["DIO6"]->SoftwareState = 1;

      //Route the DIO to BPL Failsafe line. Whenever DIO goes low the BPL Fail safe condition will be activated 
      pSystem->InstrumentSpecific->Route->Destinations->Item["BPL_INSFAIL"]->SourcesList = "DIO7";// drive BPL_INSFAIL with an external trigger
      pSystem->InstrumentSpecific->Route->Destinations->Item["BPL_INSFAIL"]->DriveMode = VTEXSystemEventDriveModeDriven;

      //Close the initialized session
      pSystem->Close();
    }
    catch(VTEXException e)
    {
      printf("Error code: %d", e.errorCode);
      printf("Error Message: %s", e.errorMessage.c_str());
    }
  }
  catch(...)
  {
    /*We put this here to catch any error the program generates.*/
    //Do something to intelligently deal with errors
  }
}

