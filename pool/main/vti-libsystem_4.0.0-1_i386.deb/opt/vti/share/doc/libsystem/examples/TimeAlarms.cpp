#include "libSystem.h"
#include <stdio.h>

int main()
{
	//Create a VTEXSystem pointer
	LibSystem *pSystem;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created System pointer
		pSystem = LibSystem::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pSystem->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			/*Set an Arm alarm to go off at Fri Feb 13 2009 18:31:30.0503 EST and fire exactly once.
			Note that Arm Alarms have an Enabled property in their Configure call which also adds the 
			Alarm to the enabled Arm sources.*/
			//An alarm should not be set unless the device is synchronized to IEEE 1588
			if(pSystem->Time->IsSynchronized)
			{
				//Note that 0 is a special case for Period and RepeatCount
				pSystem->Arm->Alarms->Item["ALARM0"]->Configure(true, 1234567890.0, 0.0503 ,0 ,0);
			}

			/*Set a Route alarm to go off 10 seconds from the current time and fire 10 times with a
			period of one second. Note that the start time won't be exactly 10 seconds from now due
			to network delays. Also note that the Route Alarms have an Enabled property which only
			enables the alarm, but does nothing else.*/

			//Firt, again don't do this unless we're synchronized
			if(pSystem->Time->IsSynchronized)
			{
				double seconds;
				double fraction;
				pSystem->Time->GetSystemTime(&seconds, &fraction); //Get the current time
				pSystem->InstrumentSpecific->Route->Alarms->Item["ALARM0"]->Configure(true, seconds + 10.0, fraction, 1.0, 10);
				pSystem->InstrumentSpecific->Route->Alarms->Item["ALARM0"]->Enabled = true;
			}
			
			//Close the initialized session
			pSystem->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
