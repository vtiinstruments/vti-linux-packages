#include "libSystem.h"
#include <stdio.h>

int main()
{
	//Create a VTEXSystem pointer
	LibSystem *pSystem;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created System pointer
		pSystem = LibSystem::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pSystem->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			//Set an LXI line as the trigger source
			pSystem->Trigger->TriggerSource = "LXI1";

			/*Set an alarm as the trigger source - How to configure alarms is covered later in the
			"Time & Alarms" section */
			pSystem->Trigger->TriggerSource = "ALARM0";

			/*Configure a LAN trigger source - see the LXI Specification for more on how to set LAN
			Event Filters*/
			//Incoming events required to have eventId "Test" to be accepted
			pSystem->Trigger->Sources->Item["LAN0"]->EventId = "Test";
			//Incoming events must come from IP 1.2.3.4 on port 5678 to be accepted
			pSystem->Trigger->Sources->Item["LAN0"]->Filter = "1.2.3.4:5678";
			/*Trigger will now happen when a falling-edge event comes in rather than a rising-edge
			event*/
			pSystem->Trigger->Sources->Item["LAN0"]->Detection = VTEXSystemTriggerSourceDetectionFall;
			
			//Close the initialized session
			pSystem->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
