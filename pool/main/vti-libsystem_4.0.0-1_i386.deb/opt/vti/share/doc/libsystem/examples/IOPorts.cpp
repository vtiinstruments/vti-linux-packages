#include "libSystem.h"
#include <stdio.h>

int main()
{
	//Create a VTEXSystem pointer
	LibSystem *pSystem;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created System pointer
		pSystem = LibSystem::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pSystem->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			/*The IOPorts interface allows us to check the current state of the device's hardware and LAN lines.
			These states are presented as 8-bit bitmasks, indicating the states of lines 0-7. Using this interface
			we can either check the DrivenState, meaning the state that we attempt to drive onto the line if the DriveMode
			is enabled, or the InputState, meaning the state that the hardware itself reads, regardless of what
			we are attempting to drive. The InputState and DrivenState can be different if the line is not being
			driven, if the line is in WiredOr mode and a different device is pulling it high, or if there is an
			electrical fault on the line where one device is attempting to drive the line high, and another is
			attempting to drive the line low. */

			//This is the current state of the 8 Backplane lines.
			int state = pSystem->InstrumentSpecific->IOPorts->Item["BPL"]->InputState;
			int bpl0state = state & 0x1; //Select the first bit of the bitmask to check the state of BPL0.

			//Change the DrivenState for BPL0 by altering the software state
			//Note that this has no impact on the state of the line since the DriveMode should still be Off.
			pSystem->InstrumentSpecific->Route->Destinations->Item["BPL0"]->SoftwareState=1;

			//Retrieve the driven state
			state = pSystem->InstrumentSpecific->IOPorts->Item["BPL"]->DrivenState;
			
			//We would expect the two states to not match, due to the change in SoftwareState
			state = bpl0state != (state & 0x1); //should be true

			//Now we can enable the DriveMode and change the InputState as well, since we will now be driving the line
			pSystem->InstrumentSpecific->Route->Destinations->Item["BPL0"]->DriveMode = VTEXSystemEventDriveModeDriven;

			//Retrieve the InputState again
			state = pSystem->InstrumentSpecific->IOPorts->Item["BPL"]->InputState;

			//And now we can confirm that the input state no longer matches the original input state, since we are driving the line
			state = bpl0state != (state & 0x1); //should be true

			//One note about this functionality - since the BPL_INSFAIL line is not exactly a backplane line, it has its own entry in the IOPorts capability.
			//It is also only a single bit wide.
			state = pSystem->InstrumentSpecific->IOPorts->Item["BPL_INSFAIL"]->InputState;

			//Close the initialized session
			pSystem->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
