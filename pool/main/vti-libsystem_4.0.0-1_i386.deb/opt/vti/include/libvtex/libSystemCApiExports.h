#pragma once
#include "vtexVisaTypes.h"

#ifdef _WIN32
#ifdef VTEXSYETEM_EXPORTS
#define VTEXSYETEM_API __declspec(dllexport)
#elif defined(VTEX_DLL)
#define VTEXSYETEM_API __declspec(dllimport)
#else
#define VTEXSYETEM_API
#endif
#else
#define VTEXSYETEM_API __attribute__((visibility("default")))
#endif
#define VTEXSYETEM_CALL
