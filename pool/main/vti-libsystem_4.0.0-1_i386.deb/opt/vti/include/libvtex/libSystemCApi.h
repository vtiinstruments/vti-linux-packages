/******************************************************************************
 *                                                                         
 * Copyright 2009 VTI Instruments Corporation
 *
 *****************************************************************************/

#ifndef __VTEXSYSTEM_HEADER
#define __VTEXSYSTEM_HEADER

#include "libSystemCApiExports.h"

#if defined(__cplusplus) || defined(__cplusplus__)
extern "C" {
#endif

/**************************************************************************** 
 *---------------------------- Attribute Defines ---------------------------* 
 ****************************************************************************/
#ifndef IVI_ATTR_BASE
#define IVI_ATTR_BASE                 1000000
#endif

#ifndef IVI_INHERENT_ATTR_BASE		        
#define IVI_INHERENT_ATTR_BASE        (IVI_ATTR_BASE +  50000)   /* base for inherent capability attributes */
#endif

#ifndef IVI_CLASS_ATTR_BASE           
#define IVI_CLASS_ATTR_BASE           (IVI_ATTR_BASE + 250000)   /* base for IVI-defined class attributes */
#endif

#ifndef IVI_LXISYNC_ATTR_BASE         
#define IVI_LXISYNC_ATTR_BASE         (IVI_ATTR_BASE + 950000)   /* base for IviLxiSync attributes */
#endif

#ifndef IVI_SPECIFIC_ATTR_BASE        
#define IVI_SPECIFIC_ATTR_BASE        (IVI_ATTR_BASE + 150000)   /* base for attributes of specific drivers */
#endif


/*===== IVI Inherent Instrument Attributes ==============================*/    

/*- Driver Identification */

#define VTEXSYSTEM_ATTR_SPECIFIC_DRIVER_DESCRIPTION              (IVI_INHERENT_ATTR_BASE + 514L)  /* ViString, read-only */
#define VTEXSYSTEM_ATTR_SPECIFIC_DRIVER_PREFIX                   (IVI_INHERENT_ATTR_BASE + 302L)  /* ViString, read-only */
#define VTEXSYSTEM_ATTR_SPECIFIC_DRIVER_VENDOR                   (IVI_INHERENT_ATTR_BASE + 513L)  /* ViString, read-only */
#define VTEXSYSTEM_ATTR_SPECIFIC_DRIVER_REVISION                 (IVI_INHERENT_ATTR_BASE + 551L)  /* ViString, read-only */
#define VTEXSYSTEM_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MAJOR_VERSION (IVI_INHERENT_ATTR_BASE + 515L)  /* ViInt32, read-only */
#define VTEXSYSTEM_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MINOR_VERSION (IVI_INHERENT_ATTR_BASE + 516L)  /* ViInt32, read-only */

/*- User Options */

#define VTEXSYSTEM_ATTR_RANGE_CHECK                         (IVI_INHERENT_ATTR_BASE + 2L)  /* ViBoolean, read-write */
#define VTEXSYSTEM_ATTR_QUERY_INSTRUMENT_STATUS             (IVI_INHERENT_ATTR_BASE + 3L)  /* ViBoolean, read-write */
#define VTEXSYSTEM_ATTR_CACHE                               (IVI_INHERENT_ATTR_BASE + 4L)  /* ViBoolean, read-write */
#define VTEXSYSTEM_ATTR_SIMULATE                            (IVI_INHERENT_ATTR_BASE + 5L)  /* ViBoolean, read-write */
#define VTEXSYSTEM_ATTR_RECORD_COERCIONS                    (IVI_INHERENT_ATTR_BASE + 6L)  /* ViBoolean, read-write */
#define VTEXSYSTEM_ATTR_INTERCHANGE_CHECK                   (IVI_INHERENT_ATTR_BASE + 21L)  /* ViBoolean, read-write */

/*- Advanced Session Information */

#define VTEXSYSTEM_ATTR_LOGICAL_NAME                        (IVI_INHERENT_ATTR_BASE + 305L)  /* ViString, read-only */
#define VTEXSYSTEM_ATTR_IO_RESOURCE_DESCRIPTOR              (IVI_INHERENT_ATTR_BASE + 304L)  /* ViString, read-only */
#define VTEXSYSTEM_ATTR_DRIVER_SETUP                        (IVI_INHERENT_ATTR_BASE + 7L)  /* ViString, read-only */

/*- Driver Capabilities */

#define VTEXSYSTEM_ATTR_GROUP_CAPABILITIES                  (IVI_INHERENT_ATTR_BASE + 401L)  /* ViString, read-only */
#define VTEXSYSTEM_ATTR_SUPPORTED_INSTRUMENT_MODELS         (IVI_INHERENT_ATTR_BASE + 327L)  /* ViString, read-only */

/*- Instrument Identification */

#define VTEXSYSTEM_ATTR_INSTRUMENT_FIRMWARE_REVISION        (IVI_INHERENT_ATTR_BASE + 510L)  /* ViString, read-only */
#define VTEXSYSTEM_ATTR_INSTRUMENT_MANUFACTURER             (IVI_INHERENT_ATTR_BASE + 511L)  /* ViString, read-only */
#define VTEXSYSTEM_ATTR_INSTRUMENT_MODEL                    (IVI_INHERENT_ATTR_BASE + 512L)  /* ViString, read-only */


/*===== Instrument-Specific Attributes =====================================*/

/*- Event Log */

#define VTEXSYSTEM_ATTR_IVILXISYNC_EVENT_LOG_ENABLED        (IVI_LXISYNC_ATTR_BASE + 34L)  /* ViBoolean, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_EVENT_LOG_ENTRY_COUNT    (IVI_LXISYNC_ATTR_BASE + 35L)  /* ViInt32, read-only */

/*- Time */

#define VTEXSYSTEM_ATTR_IVILXISYNC_IS_TIME_MASTER           (IVI_LXISYNC_ATTR_BASE + 36L)  /* ViBoolean, read-only */
#define VTEXSYSTEM_ATTR_IVILXISYNC_IS_TIME_SYNCHRONIZED     (IVI_LXISYNC_ATTR_BASE + 37L)  /* ViBoolean, read-only */

/*- Arm */

#define VTEXSYSTEM_ATTR_IVILXISYNC_ARM_COUNT                (IVI_LXISYNC_ATTR_BASE + 7L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_ARM_DELAY                (IVI_LXISYNC_ATTR_BASE + 8L)  /* ViReal64, read-write */

/*- Alarm */

#define VTEXSYSTEM_ATTR_IVILXISYNC_ARM_ALARM_ENABLED        (IVI_LXISYNC_ATTR_BASE + 2L)  /* ViBoolean, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_ARM_ALARM_PERIOD         (IVI_LXISYNC_ATTR_BASE + 3L)  /* ViReal64, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_ARM_ALARM_REPEAT_COUNT   (IVI_LXISYNC_ATTR_BASE + 4L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_ARM_ALARM_TIME_FRACTION  (IVI_LXISYNC_ATTR_BASE + 5L)  /* ViReal64, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_ARM_ALARM_TIME_SECONDS   (IVI_LXISYNC_ATTR_BASE + 6L)  /* ViReal64, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_ARM_ALARM_COUNT          (IVI_LXISYNC_ATTR_BASE + 1L)  /* ViInt32, read-only */

/*- Source */

#define VTEXSYSTEM_ATTR_IVILXISYNC_ARM_SOURCE_ENABLED       (IVI_LXISYNC_ATTR_BASE + 11L)  /* ViBoolean, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_ARM_SOURCE_DETECTION     (IVI_LXISYNC_ATTR_BASE + 10L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_ARM_SOURCE_EVENTID       (IVI_LXISYNC_ATTR_BASE + 12L)  /* ViString, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_ARM_SOURCE_FILTER        (IVI_LXISYNC_ATTR_BASE + 13L)  /* ViString, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_ARM_SOURCE_COUNT         (IVI_LXISYNC_ATTR_BASE + 9L)  /* ViInt32, read-only */
#define VTEXSYSTEM_ATTR_IVILXISYNC_ARM_SOURCE_OR_ENABLED    (IVI_LXISYNC_ATTR_BASE + 14L)  /* ViBoolean, read-write */

/*- Event */

#define VTEXSYSTEM_ATTR_IVILXISYNC_EVENT_DESTINATION_PATH   (IVI_LXISYNC_ATTR_BASE + 29L)  /* ViString, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_EVENT_DRIVE_MODE         (IVI_LXISYNC_ATTR_BASE + 30L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_EVENT_SLOPE              (IVI_LXISYNC_ATTR_BASE + 31L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_EVENT_SOURCE             (IVI_LXISYNC_ATTR_BASE + 32L)  /* ViString, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_EVENT_COUNT              (IVI_LXISYNC_ATTR_BASE + 28L)  /* ViInt32, read-only */
#define VTEXSYSTEM_ATTR_IVILXISYNC_EVENT_WIRED_OR_BIAS_MODE (IVI_LXISYNC_ATTR_BASE + 33L)  /* ViInt32, read-write */

/*- Trigger */

#define VTEXSYSTEM_ATTR_IVILXISYNC_TRIGGER_COUNT            (IVI_LXISYNC_ATTR_BASE + 21L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_TRIGGER_SOURCE           (IVI_LXISYNC_ATTR_BASE + 22L)  /* ViString, read-write */

/*- Alarm */

#define VTEXSYSTEM_ATTR_IVILXISYNC_TRIGGER_ALARM_ENABLED       (IVI_LXISYNC_ATTR_BASE + 16L)  /* ViBoolean, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_TRIGGER_ALARM_PERIOD        (IVI_LXISYNC_ATTR_BASE + 17L)  /* ViReal64, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_TRIGGER_ALARM_REPEAT_COUNT  (IVI_LXISYNC_ATTR_BASE + 18L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_TRIGGER_ALARM_TIME_FRACTION (IVI_LXISYNC_ATTR_BASE + 19L)  /* ViReal64, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_TRIGGER_ALARM_TIME_SECONDS  (IVI_LXISYNC_ATTR_BASE + 20L)  /* ViReal64, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_TRIGGER_ALARM_COUNT         (IVI_LXISYNC_ATTR_BASE + 15L)  /* ViInt32, read-only */

/*- Source */

#define VTEXSYSTEM_ATTR_IVILXISYNC_TRIGGER_SOURCE_DELAY     (IVI_LXISYNC_ATTR_BASE + 24L)  /* ViReal64, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_TRIGGER_SOURCE_DETECTION (IVI_LXISYNC_ATTR_BASE + 25L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_TRIGGER_SOURCE_EVENTID   (IVI_LXISYNC_ATTR_BASE + 26L)  /* ViString, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_TRIGGER_SOURCE_FILTER    (IVI_LXISYNC_ATTR_BASE + 27L)  /* ViString, read-write */
#define VTEXSYSTEM_ATTR_IVILXISYNC_TRIGGER_SOURCE_COUNT     (IVI_LXISYNC_ATTR_BASE + 23L)  /* ViInt32, read-only */

/*- InstrumentSpecific */

#define VTEXSYSTEM_ATTR_SYSTEM_INVENTORY                    (IVI_SPECIFIC_ATTR_BASE + 69L)  /* ViString, read-only */
#define VTEXSYSTEM_ATTR_SERIAL_NUMBER                       (IVI_SPECIFIC_ATTR_BASE + 41L)  /* ViString, read-only */
#define VTEXSYSTEM_ATTR_LXI_DOMAIN                          (IVI_SPECIFIC_ATTR_BASE + 63L)  /* ViInt32, read-write */

/*- Sources */

#define VTEXSYSTEM_ATTR_ROUTE_SOURCES_COUNT                 (IVI_SPECIFIC_ATTR_BASE + 1000L)  /* ViInt32, read-only */
#define VTEXSYSTEM_ATTR_ROUTE_SOURCES_LIST                  (IVI_SPECIFIC_ATTR_BASE + 59L)  /* ViString, read-only */

/*- Destination */

#define VTEXSYSTEM_ATTR_ROUTE_DESTINATION_INVERTED_SOURCES_LIST (IVI_SPECIFIC_ATTR_BASE + 49L)  /* ViString, read-write */
#define VTEXSYSTEM_ATTR_ROUTE_DESTINATION_SOFTWARE_STATE        (IVI_SPECIFIC_ATTR_BASE + 60L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_ROUTE_DESTINATION_PATH                  (IVI_SPECIFIC_ATTR_BASE + 51L)  /* ViString, read-write */
#define VTEXSYSTEM_ATTR_ROUTE_DESTINATION_DRIVE_MODE            (IVI_SPECIFIC_ATTR_BASE + 52L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_ROUTE_DESTINATION_OR_ENABLED            (IVI_SPECIFIC_ATTR_BASE + 53L)  /* ViBoolean, read-write */
#define VTEXSYSTEM_ATTR_ROUTE_DESTINATION_SOURCES_LIST          (IVI_SPECIFIC_ATTR_BASE + 54L)  /* ViString, read-write */

/*- Destinations */

#define VTEXSYSTEM_ATTR_ROUTE_DESTINATIONS_COUNT            (IVI_SPECIFIC_ATTR_BASE + 1001L)  /* ViInt32, read-only */
#define VTEXSYSTEM_ATTR_ROUTE_DESTINATIONS_LIST             (IVI_SPECIFIC_ATTR_BASE + 50L)  /* ViString, read-only */

/*- Alarm */

#define VTEXSYSTEM_ATTR_ROUTE_ALARM_ENABLED                 (IVI_SPECIFIC_ATTR_BASE + 44L)  /* ViBoolean, read-write */
#define VTEXSYSTEM_ATTR_ROUTE_ALARM_TIME_SECONDS            (IVI_SPECIFIC_ATTR_BASE + 45L)  /* ViReal64, read-write */
#define VTEXSYSTEM_ATTR_ROUTE_ALARM_TIME_FRACTION           (IVI_SPECIFIC_ATTR_BASE + 46L)  /* ViReal64, read-write */
#define VTEXSYSTEM_ATTR_ROUTE_ALARM_PERIOD                  (IVI_SPECIFIC_ATTR_BASE + 47L)  /* ViReal64, read-write */
#define VTEXSYSTEM_ATTR_ROUTE_ALARM_REPEAT_COUNT            (IVI_SPECIFIC_ATTR_BASE + 48L)  /* ViInt32, read-write */

/*- Alarms */

#define VTEXSYSTEM_ATTR_ROUTE_ALARMS_COUNT                  (IVI_SPECIFIC_ATTR_BASE + 1002L)  /* ViInt32, read-only */
#define VTEXSYSTEM_ATTR_ROUTE_ALARMS_LIST                   (IVI_SPECIFIC_ATTR_BASE + 57L)  /* ViString, read-only */

/*- Source */

#define VTEXSYSTEM_ATTR_ROUTE_SOURCE_EVENT_ID               (IVI_SPECIFIC_ATTR_BASE + 42L)  /* ViString, read-write */
#define VTEXSYSTEM_ATTR_ROUTE_SOURCE_FILTER                 (IVI_SPECIFIC_ATTR_BASE + 43L)  /* ViString, read-write */

/*- IOPort */

#define VTEXSYSTEM_ATTR_IOPORT_INPUT_STATE                  (IVI_SPECIFIC_ATTR_BASE + 61L)  /* ViInt32, read-only */
#define VTEXSYSTEM_ATTR_IOPORT_DRIVEN_STATE                 (IVI_SPECIFIC_ATTR_BASE + 62L)  /* ViInt32, read-only */

/*- IOPorts */

#define VTEXSYSTEM_ATTR_IOPORTS_COUNT                       (IVI_SPECIFIC_ATTR_BASE + 1003L)  /* ViInt32, read-only */
#define VTEXSYSTEM_ATTR_IOPORTS_LIST                        (IVI_SPECIFIC_ATTR_BASE + 58L)  /* ViString, read-only */

/*- Time */

#define VTEXSYSTEM_ATTR_TIME_IS_MASTER                      (IVI_SPECIFIC_ATTR_BASE + 70L)  /* ViBoolean, read-only */
#define VTEXSYSTEM_ATTR_TIME_IS_SYNCHRONIZED                (IVI_SPECIFIC_ATTR_BASE + 71L)  /* ViBoolean, read-only */

/*- Trigger */

#define VTEXSYSTEM_ATTR_TRIGGER_SOURCE                      (IVI_SPECIFIC_ATTR_BASE + 72L)  /* ViString, read-write */
#define VTEXSYSTEM_ATTR_TRIGGER_COUNT                       (IVI_SPECIFIC_ATTR_BASE + 73L)  /* ViInt32, read-write */

/*- Source */

#define VTEXSYSTEM_ATTR_TRIGGER_SOURCE_DELAY                (IVI_SPECIFIC_ATTR_BASE + 74L)  /* ViReal64, read-write */
#define VTEXSYSTEM_ATTR_TRIGGER_SOURCE_DETECTION            (IVI_SPECIFIC_ATTR_BASE + 75L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_TRIGGER_SOURCE_EVENT_ID             (IVI_SPECIFIC_ATTR_BASE + 76L)  /* ViString, read-write */
#define VTEXSYSTEM_ATTR_TRIGGER_SOURCE_FILTER               (IVI_SPECIFIC_ATTR_BASE + 77L)  /* ViString, read-write */

/*- Sources */

#define VTEXSYSTEM_ATTR_TRIGGER_SOURCES_COUNT               (IVI_SPECIFIC_ATTR_BASE + 1004L)  /* ViInt32, read-only */
#define VTEXSYSTEM_ATTR_TRIGGER_SOURCES_LIST                (IVI_SPECIFIC_ATTR_BASE + 64L)  /* ViString, read-only */

/*- Alarm */

#define VTEXSYSTEM_ATTR_TRIGGER_ALARM_ENABLED               (IVI_SPECIFIC_ATTR_BASE + 78L)  /* ViBoolean, read-write */
#define VTEXSYSTEM_ATTR_TRIGGER_ALARM_PERIOD                (IVI_SPECIFIC_ATTR_BASE + 79L)  /* ViReal64, read-write */
#define VTEXSYSTEM_ATTR_TRIGGER_ALARM_REPEAT_COUNT          (IVI_SPECIFIC_ATTR_BASE + 80L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_TRIGGER_ALARM_TIME_FRACTION         (IVI_SPECIFIC_ATTR_BASE + 81L)  /* ViReal64, read-write */
#define VTEXSYSTEM_ATTR_TRIGGER_ALARM_TIME_SECONDS          (IVI_SPECIFIC_ATTR_BASE + 82L)  /* ViReal64, read-write */

/*- Alarms */

#define VTEXSYSTEM_ATTR_TRIGGER_ALARMS_COUNT                (IVI_SPECIFIC_ATTR_BASE + 1005L)  /* ViInt32, read-only */
#define VTEXSYSTEM_ATTR_TRIGGER_ALARMS_LIST                 (IVI_SPECIFIC_ATTR_BASE + 68L)  /* ViString, read-only */

/*- EventLog */

#define VTEXSYSTEM_ATTR_EVENT_LOG_ENABLED                   (IVI_SPECIFIC_ATTR_BASE + 83L)  /* ViBoolean, read-write */
#define VTEXSYSTEM_ATTR_EVENT_LOG_ENTRY_COUNT               (IVI_SPECIFIC_ATTR_BASE + 84L)  /* ViInt32, read-only */
#define VTEXSYSTEM_ATTR_EVENT_LOG_OVERFLOW_MODE             (IVI_SPECIFIC_ATTR_BASE + 56L)  /* ViInt32, read-write */

/*- Events */

#define VTEXSYSTEM_ATTR_EVENTS_COUNT                        (IVI_SPECIFIC_ATTR_BASE + 1006L)  /* ViInt32, read-only */
#define VTEXSYSTEM_ATTR_EVENTS_LIST                         (IVI_SPECIFIC_ATTR_BASE + 67L)  /* ViString, read-only */
#define VTEXSYSTEM_ATTR_EVENTS_WIRED_OR_BIAS_MODE           (IVI_SPECIFIC_ATTR_BASE + 85L)  /* ViInt32, read-write */

/*- Event */

#define VTEXSYSTEM_ATTR_EVENT_DESTINATION_PATH              (IVI_SPECIFIC_ATTR_BASE + 86L)  /* ViString, read-write */
#define VTEXSYSTEM_ATTR_EVENT_DRIVE_MODE                    (IVI_SPECIFIC_ATTR_BASE + 87L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_EVENT_SLOPE                         (IVI_SPECIFIC_ATTR_BASE + 88L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_EVENT_SOURCE                        (IVI_SPECIFIC_ATTR_BASE + 89L)  /* ViString, read-write */

/*- Arm */

#define VTEXSYSTEM_ATTR_ARM_COUNT                           (IVI_SPECIFIC_ATTR_BASE + 90L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_ARM_DELAY                           (IVI_SPECIFIC_ATTR_BASE + 91L)  /* ViReal64, read-write */

/*- Alarms */

#define VTEXSYSTEM_ATTR_ARM_ALARMS_COUNT                    (IVI_SPECIFIC_ATTR_BASE + 1007L)  /* ViInt32, read-only */
#define VTEXSYSTEM_ATTR_ARM_ALARMS_LIST                     (IVI_SPECIFIC_ATTR_BASE + 65L)  /* ViString, read-only */

/*- Alarm */

#define VTEXSYSTEM_ATTR_ARM_ALARM_ENABLED                   (IVI_SPECIFIC_ATTR_BASE + 92L)  /* ViBoolean, read-write */
#define VTEXSYSTEM_ATTR_ARM_ALARM_PERIOD                    (IVI_SPECIFIC_ATTR_BASE + 93L)  /* ViReal64, read-write */
#define VTEXSYSTEM_ATTR_ARM_ALARM_REPEAT_COUNT              (IVI_SPECIFIC_ATTR_BASE + 94L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_ARM_ALARM_TIME_FRACTION             (IVI_SPECIFIC_ATTR_BASE + 95L)  /* ViReal64, read-write */
#define VTEXSYSTEM_ATTR_ARM_ALARM_TIME_SECONDS              (IVI_SPECIFIC_ATTR_BASE + 96L)  /* ViReal64, read-write */

/*- Sources */

#define VTEXSYSTEM_ATTR_ARM_SOURCES_COUNT                   (IVI_SPECIFIC_ATTR_BASE + 1008L)  /* ViInt32, read-only */
#define VTEXSYSTEM_ATTR_ARM_SOURCES_LIST                    (IVI_SPECIFIC_ATTR_BASE + 66L)  /* ViString, read-only */
#define VTEXSYSTEM_ATTR_ARM_SOURCES_OR_ENABLED              (IVI_SPECIFIC_ATTR_BASE + 97L)  /* ViBoolean, read-write */

/*- Source */

#define VTEXSYSTEM_ATTR_ARM_SOURCE_DETECTION                (IVI_SPECIFIC_ATTR_BASE + 98L)  /* ViInt32, read-write */
#define VTEXSYSTEM_ATTR_ARM_SOURCE_ENABLED                  (IVI_SPECIFIC_ATTR_BASE + 99L)  /* ViBoolean, read-write */
#define VTEXSYSTEM_ATTR_ARM_SOURCE_EVENT_ID                 (IVI_SPECIFIC_ATTR_BASE + 100L)  /* ViString, read-write */
#define VTEXSYSTEM_ATTR_ARM_SOURCE_FILTER                   (IVI_SPECIFIC_ATTR_BASE + 101L)  /* ViString, read-write */

/*- Configuration */

#define VTEXSYSTEM_ATTR_CURRENT_CONFIGURATION_DIGEST        (IVI_SPECIFIC_ATTR_BASE + 1009L)  /* ViString, read-only */
#define VTEXSYSTEM_ATTR_SAVED_CONFIGURATION_DIGEST          (IVI_SPECIFIC_ATTR_BASE + 1010L)  /* ViString, read-only */


/**************************************************************************** 
 *------------------------ Attribute Value Defines -------------------------* 
 ****************************************************************************/

/*- Defined values for 
	attribute VTEXSYSTEM_ATTR_IVILXISYNC_ARM_SOURCE_DETECTION
	attribute VTEXSYSTEM_ATTR_IVILXISYNC_TRIGGER_SOURCE_DETECTION
	parameter Detection in function VTEXSystem_IviLxiSync_ConfigureArmSource
	parameter Detection in function VTEXSystem_IviLxiSync_ConfigureTriggerSource */

#define VTEXSYSTEM_VAL_IVILXISYNC_DETECTION_RISE            0
#define VTEXSYSTEM_VAL_IVILXISYNC_DETECTION_FALL            1
#define VTEXSYSTEM_VAL_IVILXISYNC_DETECTION_HIGH            2
#define VTEXSYSTEM_VAL_IVILXISYNC_DETECTION_LOW             3

/*- Defined values for 
	attribute VTEXSYSTEM_ATTR_IVILXISYNC_EVENT_DRIVE_MODE
	parameter DriveMode in function VTEXSystem_IviLxiSync_ConfigureEvent */

#define VTEXSYSTEM_VAL_IVILXISYNC_EVENT_DRIVEN              0
#define VTEXSYSTEM_VAL_IVILXISYNC_EVENT_OFF                 1
#define VTEXSYSTEM_VAL_IVILXISYNC_EVENT_WIREDOR             2

/*- Defined values for 
	attribute VTEXSYSTEM_ATTR_IVILXISYNC_EVENT_SLOPE
	parameter Slope in function VTEXSystem_IviLxiSync_ConfigureEvent */

#define VTEXSYSTEM_VAL_IVILXISYNC_SLOPE_RISE                0
#define VTEXSYSTEM_VAL_IVILXISYNC_SLOPE_FALL                1

/*- Defined values for */

#define VTEXSYSTEM_VAL_IVILXISYNC_SLOPE_RISE                0
#define VTEXSYSTEM_VAL_IVILXISYNC_SLOPE_FALL                1

/*- Defined values for 
	attribute VTEXSYSTEM_ATTR_ARM_SOURCE_DETECTION
	parameter Detection in function VTEXSystem_ArmSourceConfigure */

#define VTEXSYSTEM_VAL_ARM_SOURCE_DETECTION_RISE            0
#define VTEXSYSTEM_VAL_ARM_SOURCE_DETECTION_FALL            1
#define VTEXSYSTEM_VAL_ARM_SOURCE_DETECTION_HIGH            2
#define VTEXSYSTEM_VAL_ARM_SOURCE_DETECTION_LOW             3

/*- Defined values for 
	attribute VTEXSYSTEM_ATTR_ROUTE_DESTINATION_DRIVE_MODE
	attribute VTEXSYSTEM_ATTR_EVENT_DRIVE_MODE
	parameter DriveMode in function VTEXSystem_RouteDestinationConfigure
	parameter DriveMode in function VTEXSystem_EventConfigure */

#define VTEXSYSTEM_VAL_EVENT_DRIVE_MODE_DRIVEN              0
#define VTEXSYSTEM_VAL_EVENT_DRIVE_MODE_OFF                 1
#define VTEXSYSTEM_VAL_EVENT_DRIVE_MODE_WIRED_OR            2

/*- Defined values for 
	attribute VTEXSYSTEM_ATTR_EVENT_SLOPE
	parameter Slope in function VTEXSystem_EventConfigure */

#define VTEXSYSTEM_VAL_SOURCE_SLOPE_RISE                    0
#define VTEXSYSTEM_VAL_SOURCE_SLOPE_FALL                    1

/*- Defined values for 
	attribute VTEXSYSTEM_ATTR_TRIGGER_SOURCE_DETECTION
	parameter Detection in function VTEXSystem_TriggerSourceConfigure */

#define VTEXSYSTEM_VAL_TRIGGER_SOURCE_DETECTION_RISE        0
#define VTEXSYSTEM_VAL_TRIGGER_SOURCE_DETECTION_FALL        1

/*- Defined values for 
	attribute VTEXSYSTEM_ATTR_EVENT_LOG_OVERFLOW_MODE */

#define VTEXSYSTEM_VAL_EVENT_LOG_OVERFLOW_STOP              1000
#define VTEXSYSTEM_VAL_EVENT_LOG_OVERFLOW_OVERRIDE          1001


/**************************************************************************** 
 *---------------- Instrument Driver Function Declarations -----------------* 
 ****************************************************************************/

/*- VTEXSystem */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_init ( ViRsrc ResourceName, ViBoolean IdQuery, ViBoolean Reset, ViSession* Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_close ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_InitWithOptions ( ViRsrc ResourceName, ViBoolean IdQuery, ViBoolean Reset, ViConstString OptionsString, ViSession* Vi );

/*- Utility */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_revision_query ( ViSession Vi, ViChar DriverRev[], ViChar InstrRev[] );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_error_message ( ViSession Vi, ViStatus ErrorCode, ViChar ErrorMessage[] );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetError ( ViSession Vi, ViStatus* ErrorCode, ViInt32 ErrorDescriptionBufferSize, ViChar ErrorDescription[] );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_ClearError ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_ClearInterchangeWarnings ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetNextCoercionRecord ( ViSession Vi, ViInt32 CoercionRecordBufferSize, ViChar CoercionRecord[] );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetNextInterchangeWarning ( ViSession Vi, ViInt32 InterchangeWarningBufferSize, ViChar InterchangeWarning[] );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_InvalidateAllAttributes ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_ResetInterchangeCheck ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_Disable ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_error_query ( ViSession Vi, ViInt32* ErrorCode, ViChar ErrorMessage[] );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_LockSession ( ViSession Vi, ViBoolean* CallerHasLock );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_reset ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_ResetWithDefaults ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_self_test ( ViSession Vi, ViInt16* TestResult, ViChar TestMessage[] );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_UnlockSession ( ViSession Vi, ViBoolean* CallerHasLock );

/*- Attribute Accessors */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetAttributeViInt32 ( ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViInt32* AttributeValue );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetAttributeViInt64 ( ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViInt64* AttributeValue );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetAttributeViReal64 ( ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViReal64* AttributeValue );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetAttributeViBoolean ( ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViBoolean* AttributeValue );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetAttributeViSession ( ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViSession* AttributeValue );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetAttributeViString ( ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViInt32 AttributeValueBufferSize, ViChar AttributeValue[] );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_SetAttributeViInt32 ( ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViInt32 AttributeValue );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_SetAttributeViInt64 ( ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViInt64 AttributeValue );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_SetAttributeViReal64 ( ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViReal64 AttributeValue );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_SetAttributeViBoolean ( ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViBoolean AttributeValue );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_SetAttributeViSession ( ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViSession AttributeValue );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_SetAttributeViString ( ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViConstString AttributeValue );

/*- Alarm */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_GetArmAlarmName ( ViSession Vi, ViInt32 AlarmIndex, ViInt32 AlarmNameBufferSize, ViChar AlarmName[] );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_ConfigureArmAlarm ( ViSession Vi, ViConstString AlarmName, ViBoolean Enabled, ViReal64 TimeSeconds, ViReal64 TimeFraction, ViReal64 Period, ViInt32 RepeatCount );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_AddArmAlarm ( ViSession Vi, ViConstString AlarmName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_DisableAllArmAlarms ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_RemoveArmAlarm ( ViSession Vi, ViConstString AlarmName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_RemoveAllCustomArmAlarms ( ViSession Vi );

/*- Source */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_GetArmSourceName ( ViSession Vi, ViInt32 SourceIndex, ViInt32 SourceNameBufferSize, ViChar SourceName[] );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_ConfigureArmSource ( ViSession Vi, ViConstString SourceName, ViBoolean Enabled, ViInt32 Detection );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_AddArmSource ( ViSession Vi, ViConstString SourceName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_DisableAllArmSources ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_RemoveArmSource ( ViSession Vi, ViConstString SourceName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_RemoveAllCustomArmSources ( ViSession Vi );

/*- Alarm */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_GetTriggerAlarmName ( ViSession Vi, ViInt32 AlarmIndex, ViInt32 AlarmNameBufferSize, ViChar AlarmName[] );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_ConfigureTriggerAlarm ( ViSession Vi, ViConstString AlarmName, ViReal64 TimeSeconds, ViReal64 TimeFraction, ViReal64 Period, ViInt32 RepeatCount );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_AddTriggerAlarm ( ViSession Vi, ViConstString AlarmName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_DisableAllTriggerAlarms ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_RemoveTriggerAlarm ( ViSession Vi, ViConstString AlarmName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_RemoveAllTriggerAlarms ( ViSession Vi );

/*- Source */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_GetTriggerSourceName ( ViSession Vi, ViInt32 SourceIndex, ViInt32 SourceNameBufferSize, ViChar SourceName[] );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_ConfigureTriggerSource ( ViSession Vi, ViConstString SourceName, ViReal64 Delay, ViInt32 Detection );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_AddTriggerSource ( ViSession Vi, ViConstString SourceName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_RemoveTriggerSource ( ViSession Vi, ViConstString SourceName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_RemoveAllCustomTriggerSources ( ViSession Vi );

/*- Event */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_GetEventName ( ViSession Vi, ViInt32 EventIndex, ViInt32 EventNameBufferSize, ViChar EventName[] );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_ConfigureEvent ( ViSession Vi, ViConstString EventName, ViInt32 DriveMode, ViConstString Source, ViConstString DestinationPath, ViInt32 Slope );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_AddEvent ( ViSession Vi, ViConstString EventName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_DisableAllEvents ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_RemoveEvent ( ViSession Vi, ViConstString EventName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_RemoveAllCustomEvents ( ViSession Vi );

/*- Event Log */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_ClearEventLog ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_GetNextEventLogEntry ( ViSession Vi, ViInt32 LogEntryBufferSize, ViChar LogEntry[] );

/*- Time */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_IviLxiSync_GetSystemTime ( ViSession Vi, ViReal64* TimeSeconds, ViReal64* TimeFractional );

/*- InstrumentSpecific */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RetrieveFile ( ViSession Vi, ViConstString FileName, ViInt32 RetValBufferSize, ViChar RetVal[], ViInt32* RetValActualSize );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_Display ( ViSession Vi, ViConstString Text, ViInt32 FontSize, ViInt32 ScrollSpeed );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetResourceState ( ViSession Vi, ViInt32 SlotsBufferSize, ViInt32 Slots[], ViInt32* SlotsActualSize, ViInt32 LockedBufferSize, ViBoolean Locked[], ViInt32* LockedActualSize );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_FindInstruments ( ViSession Vi, ViConstString Models, ViInt32 Timeout, ViInt32 RetValBufferSize, ViChar RetVal[] );

/*- Sources */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RouteSourcesAdd ( ViSession Vi, ViConstString SourceName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RouteSourcesRemove ( ViSession Vi, ViConstString SourceName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RouteSourcesRemoveAllCustom ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetRouteSourceName ( ViSession Vi, ViInt32 Index, ViInt32 NameBufferSize, ViChar Name[] );

/*- Destination */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RouteDestinationPulse ( ViSession Vi, ViConstString RepCapIdentifier );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RouteDestinationConfigure ( ViSession Vi, ViConstString RepCapIdentifier, ViConstString SourcesList, ViConstString InvertedSourcesList, ViBoolean OrEnabled, ViInt32 DriveMode, ViConstString DestinationPath );

/*- Destinations */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RouteDestinationsAdd ( ViSession Vi, ViConstString DestinationName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RouteDestinationsDisableAll ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RouteDestinationsRemove ( ViSession Vi, ViConstString DestinationName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RouteDestinationsRemoveAllCustom ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetRouteDestinationName ( ViSession Vi, ViInt32 Index, ViInt32 NameBufferSize, ViChar Name[] );

/*- Alarm */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RouteAlarmConfigure ( ViSession Vi, ViConstString RepCapIdentifier, ViBoolean Enabled, ViReal64 TimeSeconds, ViReal64 TimeFraction, ViReal64 Period, ViInt32 RepeatCount );

/*- Alarms */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RouteAlarmsAdd ( ViSession Vi, ViConstString AlarmName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RouteAlarmsDisableAll ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RouteAlarmsRemove ( ViSession Vi, ViConstString AlarmName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RouteAlarmsRemoveAllCustom ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetRouteAlarmName ( ViSession Vi, ViInt32 Index, ViInt32 NameBufferSize, ViChar Name[] );

/*- IOPorts */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetIOPortName ( ViSession Vi, ViInt32 Index, ViInt32 NameBufferSize, ViChar Name[] );

/*- Time */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetSystemTime ( ViSession Vi, ViReal64* TimeSeconds, ViReal64* TimeFractional );

/*- Source */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_TriggerSourceConfigure ( ViSession Vi, ViConstString TriggerSource, ViReal64 Delay, ViInt32 Detection );

/*- Sources */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_TriggerSourcesAdd ( ViSession Vi, ViConstString SourceName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_TriggerSourcesRemove ( ViSession Vi, ViConstString SourceName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_TriggerSourcesRemoveAllCustom ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetTriggerSourceName ( ViSession Vi, ViInt32 Index, ViInt32 NameBufferSize, ViChar Name[] );

/*- Alarm */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_TriggerAlarmConfigure ( ViSession Vi, ViConstString TriggerAlarm, ViReal64 TimeSeconds, ViReal64 TimeFraction, ViReal64 Period, ViInt32 RepeatCount );

/*- Alarms */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_TriggerAlarmsAdd ( ViSession Vi, ViConstString AlarmName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_TriggerAlarmsDisableAll ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_TriggerAlarmsRemove ( ViSession Vi, ViConstString AlarmName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_TriggerAlarmsRemoveAll ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetTriggerAlarmName ( ViSession Vi, ViInt32 Index, ViInt32 NameBufferSize, ViChar Name[] );

/*- EventLog */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_EventLogClear ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_EventLogGetNextEntry ( ViSession Vi, ViInt32 ValBufferSize, ViChar Val[] );

/*- Events */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_EventsAdd ( ViSession Vi, ViConstString EventName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_EventsRemove ( ViSession Vi, ViConstString EventName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_EventsRemoveAllCustom ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_DisableAll ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetEventName ( ViSession Vi, ViInt32 Index, ViInt32 NameBufferSize, ViChar Name[] );

/*- Event */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_EventConfigure ( ViSession Vi, ViConstString Event, ViInt32 DriveMode, ViConstString Source, ViConstString DestinationPath, ViInt32 Slope );

/*- Alarms */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_ArmAlarmsAdd ( ViSession Vi, ViConstString AlarmName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_ArmAlarmsDisableAll ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_ArmAlarmsRemove ( ViSession Vi, ViConstString AlarmName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_RemoveAllCustomArmAlarms ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetArmAlarmName ( ViSession Vi, ViInt32 Index, ViInt32 NameBufferSize, ViChar Name[] );

/*- Alarm */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_ArmAlarmConfigure ( ViSession Vi, ViConstString ArmAlarm, ViBoolean Enabled, ViReal64 TimeSeconds, ViReal64 TimeFraction, ViReal64 Period, ViInt32 RepeatCount );

/*- Sources */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_ArmSourcesAdd ( ViSession Vi, ViConstString SourceName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_ArmSourcesDisableAll ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_ArmSourcesRemove ( ViSession Vi, ViConstString SourceName );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_ArmSourcesRemoveAllCustom ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_GetArmSourceName ( ViSession Vi, ViInt32 Index, ViInt32 NameBufferSize, ViChar Name[] );

/*- Source */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_ArmSourceConfigure ( ViSession Vi, ViConstString ArmSource, ViBoolean Enabled, ViInt32 Detection );

/*- Configuration */

VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_SaveConfiguration ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_ClearSavedConfiguration ( ViSession Vi );
VTEXSYETEM_API ViStatus VTEXSYETEM_CALL VTEXSystem_LoadSavedConfiguration ( ViSession Vi );


/**************************************************************************** 
 *----------------- Instrument Error And Completion Codes ------------------* 
 ****************************************************************************/
#ifndef _IVIC_ERROR_BASE_DEFINES_
#define _IVIC_ERROR_BASE_DEFINES_

#define IVIC_WARN_BASE                           (0x3FFA0000L)
#define IVIC_CROSS_CLASS_WARN_BASE               (IVIC_WARN_BASE + 0x1000)
#define IVIC_CLASS_WARN_BASE                     (IVIC_WARN_BASE + 0x2000)
#define IVIC_SPECIFIC_WARN_BASE                  (IVIC_WARN_BASE + 0x4000)

#define IVIC_ERROR_BASE                          (-1074135040L)
#define IVIC_CROSS_CLASS_ERROR_BASE              (IVIC_ERROR_BASE + 0x1000)
#define IVIC_CLASS_ERROR_BASE                    (IVIC_ERROR_BASE + 0x2000)
#define IVIC_SPECIFIC_ERROR_BASE                 (IVIC_ERROR_BASE + 0x4000)
#define IVIC_LXISYNC_ERROR_BASE                  (IVIC_ERROR_BASE + 0x2000)

#define IVIC_ERROR_INVALID_ATTRIBUTE             (IVIC_ERROR_BASE + 0x000C)
#define IVIC_ERROR_TYPES_DO_NOT_MATCH            (IVIC_ERROR_BASE + 0x0015)
#define IVIC_ERROR_IVI_ATTR_NOT_WRITABLE         (IVIC_ERROR_BASE + 0x000D)
#define IVIC_ERROR_IVI_ATTR_NOT_READABLE         (IVIC_ERROR_BASE + 0x000E)
#define IVIC_ERROR_INVALID_SESSION_HANDLE        (IVIC_ERROR_BASE + 0x1190)

#endif


#define VTEXSYSTEM_ERROR_CANNOT_RECOVER                       ((ViStatus)(IVIC_ERROR_BASE + 0x0000))
#define VTEXSYSTEM_ERROR_INSTRUMENT_STATUS                    ((ViStatus)(IVIC_ERROR_BASE + 0x0001))
#define VTEXSYSTEM_ERROR_CANNOT_OPEN_FILE                     ((ViStatus)(IVIC_ERROR_BASE + 0x0002))
#define VTEXSYSTEM_ERROR_READING_FILE                         ((ViStatus)(IVIC_ERROR_BASE + 0x0003))
#define VTEXSYSTEM_ERROR_WRITING_FILE                         ((ViStatus)(IVIC_ERROR_BASE + 0x0004))
#define VTEXSYSTEM_ERROR_INVALID_PATHNAME                     ((ViStatus)(IVIC_ERROR_BASE + 0x000B))
#define VTEXSYSTEM_ERROR_INVALID_VALUE                        ((ViStatus)(IVIC_ERROR_BASE + 0x0010))
#define VTEXSYSTEM_ERROR_FUNCTION_NOT_SUPPORTED               ((ViStatus)(IVIC_ERROR_BASE + 0x0011))
#define VTEXSYSTEM_ERROR_ATTRIBUTE_NOT_SUPPORTED              ((ViStatus)(IVIC_ERROR_BASE + 0x0012))
#define VTEXSYSTEM_ERROR_VALUE_NOT_SUPPORTED                  ((ViStatus)(IVIC_ERROR_BASE + 0x0013))
#define VTEXSYSTEM_ERROR_NOT_INITIALIZED                      ((ViStatus)(IVIC_ERROR_BASE + 0x001D))
#define VTEXSYSTEM_ERROR_UNKNOWN_CHANNEL_NAME                 ((ViStatus)(IVIC_ERROR_BASE + 0x0020))
#define VTEXSYSTEM_ERROR_TOO_MANY_OPEN_FILES                  ((ViStatus)(IVIC_ERROR_BASE + 0x0023))
#define VTEXSYSTEM_ERROR_CHANNEL_NAME_REQUIRED                ((ViStatus)(IVIC_ERROR_BASE + 0x0044))
#define VTEXSYSTEM_ERROR_MISSING_OPTION_NAME                  ((ViStatus)(IVIC_ERROR_BASE + 0x0049))
#define VTEXSYSTEM_ERROR_MISSING_OPTION_VALUE                 ((ViStatus)(IVIC_ERROR_BASE + 0x004A))
#define VTEXSYSTEM_ERROR_BAD_OPTION_NAME                      ((ViStatus)(IVIC_ERROR_BASE + 0x004B))
#define VTEXSYSTEM_ERROR_BAD_OPTION_VALUE                     ((ViStatus)(IVIC_ERROR_BASE + 0x004C))
#define VTEXSYSTEM_ERROR_OUT_OF_MEMORY                        ((ViStatus)(IVIC_ERROR_BASE + 0x0056))
#define VTEXSYSTEM_ERROR_OPERATION_PENDING                    ((ViStatus)(IVIC_ERROR_BASE + 0x0057))
#define VTEXSYSTEM_ERROR_NULL_POINTER                         ((ViStatus)(IVIC_ERROR_BASE + 0x0058))
#define VTEXSYSTEM_ERROR_UNEXPECTED_RESPONSE                  ((ViStatus)(IVIC_ERROR_BASE + 0x0059))
#define VTEXSYSTEM_ERROR_FILE_NOT_FOUND                       ((ViStatus)(IVIC_ERROR_BASE + 0x005B))
#define VTEXSYSTEM_ERROR_INVALID_FILE_FORMAT                  ((ViStatus)(IVIC_ERROR_BASE + 0x005C))
#define VTEXSYSTEM_ERROR_STATUS_NOT_AVAILABLE                 ((ViStatus)(IVIC_ERROR_BASE + 0x005D))
#define VTEXSYSTEM_ERROR_ID_QUERY_FAILED                      ((ViStatus)(IVIC_ERROR_BASE + 0x005E))
#define VTEXSYSTEM_ERROR_RESET_FAILED                         ((ViStatus)(IVIC_ERROR_BASE + 0x005F))
#define VTEXSYSTEM_ERROR_RESOURCE_UNKNOWN                     ((ViStatus)(IVIC_ERROR_BASE + 0x0060))
#define VTEXSYSTEM_ERROR_ALREADY_INITIALIZED                  ((ViStatus)(IVIC_ERROR_BASE + 0x0061))
#define VTEXSYSTEM_ERROR_CANNOT_CHANGE_SIMULATION_STATE       ((ViStatus)(IVIC_ERROR_BASE + 0x0062))
#define VTEXSYSTEM_ERROR_INVALID_NUMBER_OF_LEVELS_IN_SELECTOR ((ViStatus)(IVIC_ERROR_BASE + 0x0063))
#define VTEXSYSTEM_ERROR_INVALID_RANGE_IN_SELECTOR            ((ViStatus)(IVIC_ERROR_BASE + 0x0064))
#define VTEXSYSTEM_ERROR_UNKOWN_NAME_IN_SELECTOR              ((ViStatus)(IVIC_ERROR_BASE + 0x0065))
#define VTEXSYSTEM_ERROR_BADLY_FORMED_SELECTOR                ((ViStatus)(IVIC_ERROR_BASE + 0x0066))
#define VTEXSYSTEM_ERROR_UNKNOWN_PHYSICAL_IDENTIFIER          ((ViStatus)(IVIC_ERROR_BASE + 0x0067))



#define VTEXSYSTEM_SUCCESS                                  0
#define VTEXSYSTEM_WARN_NSUP_ID_QUERY                       (IVIC_WARN_BASE + 0x0065)
#define VTEXSYSTEM_WARN_NSUP_RESET                          (IVIC_WARN_BASE + 0x0066)
#define VTEXSYSTEM_WARN_NSUP_SELF_TEST                      (IVIC_WARN_BASE + 0x0067)
#define VTEXSYSTEM_WARN_NSUP_ERROR_QUERY                    (IVIC_WARN_BASE + 0x0068)
#define VTEXSYSTEM_WARN_NSUP_REV_QUERY                      (IVIC_WARN_BASE + 0x0069)



#define VTEXSYSTEM_ERROR_ALARM_TIME_INVALID                       ((ViStatus)(IVIC_LXISYNC_ERROR_BASE + 0x0001))
#define VTEXSYSTEM_ERROR_EVENT_SOURCE_EXISTS                      ((ViStatus)(IVIC_LXISYNC_ERROR_BASE + 0x0002))
#define VTEXSYSTEM_ERROR_OUT_OF_EVENT_RESOURCES                   ((ViStatus)(IVIC_LXISYNC_ERROR_BASE + 0x0003))
#define VTEXSYSTEM_ERROR_EVENT_SOURCE_DOES_NOT_EXIST              ((ViStatus)(IVIC_LXISYNC_ERROR_BASE + 0x0004))
#define VTEXSYSTEM_ERROR_EVENT_SOURCE_NOT_SET                     ((ViStatus)(IVIC_LXISYNC_ERROR_BASE + 0x0005))
#define VTEXSYSTEM_ERROR_INVALID_EVENT_SOURCE                     ((ViStatus)(IVIC_LXISYNC_ERROR_BASE + 0x0006))
#define VTEXSYSTEM_ERROR_ALARM_EXISTS                             ((ViStatus)(IVIC_LXISYNC_ERROR_BASE + 0x0007))
#define VTEXSYSTEM_ERROR_ALARM_DOES_NOT_EXIST                     ((ViStatus)(IVIC_LXISYNC_ERROR_BASE + 0x0008))
#define VTEXSYSTEM_ERROR_WIRED_OR_MODE_INVALID                    ((ViStatus)(IVIC_LXISYNC_ERROR_BASE + 0x0009))
#define VTEXSYSTEM_ERROR_CANT_REMOVE_RESERVED_REPEATED_CAPABILITY ((ViStatus)(IVIC_LXISYNC_ERROR_BASE + 0x0010))
#define VTEXSYSTEM_ERROR_PERSONALITY_NOT_ACTIVE                   ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0211))
#define VTEXSYSTEM_ERROR_PERSONALITY_NOT_INSTALLED                ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0212))
#define VTEXSYSTEM_ERROR_PERSONALITY_NOT_LICENSED                 ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0213))
#define VTEXSYSTEM_ERROR_IO_GENERAL                               ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0214))
#define VTEXSYSTEM_ERROR_IO_TIMEOUT                               ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0215))
#define VTEXSYSTEM_ERROR_MODEL_NOT_SUPPORTED                      ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0216))
#define VTEXSYSTEM_ERROR_WRAPPED_DRIVER_ERROR                     ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0218))
#define VTEXSYSTEM_ERROR_NO_IVI_REPRESENTATION                    ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0001))
#define VTEXSYSTEM_ERROR_SPECIFIC_DRIVER_EXCEPTION                ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0002))




/**************************************************************************** 
 *---------------------------- End Include File ----------------------------* 
 ****************************************************************************/
#if defined(__cplusplus) || defined(__cplusplus__)
}
#endif
#endif // __VTEXSYSTEM_HEADER
