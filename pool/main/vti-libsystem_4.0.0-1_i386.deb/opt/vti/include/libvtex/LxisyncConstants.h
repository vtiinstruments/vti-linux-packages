#include "exErrors.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#if defined(_WIN32) && !defined(_CVI_)
#define INLINE __inline
#else
#define INLINE inline
#endif

#ifdef __cplusplus
extern "C" {
#endif

 //!
 //! @file
 //!
 //! LXI Sync constants.
 //!

#ifndef _LxisyncConstants_H
#define _LxisyncConstants_H


#define VTEX_LAN0 "LAN0"
#define VTEX_LAN1 "LAN1"
#define VTEX_LAN2 "LAN2"
#define VTEX_LAN3 "LAN3"
#define VTEX_LAN4 "LAN4"
#define VTEX_LAN5 "LAN5"
#define VTEX_LAN6 "LAN6"
#define VTEX_LAN7 "LAN7"

#define VTEX_LXI0 "LXI0"
#define VTEX_LXI1 "LXI1"
#define VTEX_LXI2 "LXI2"
#define VTEX_LXI3 "LXI3"
#define VTEX_LXI4 "LXI4"
#define VTEX_LXI5 "LXI5"
#define VTEX_LXI6 "LXI6"
#define VTEX_LXI7 "LXI7"

#define VTEX_DIO0 "DIO0"
#define VTEX_DIO1 "DIO1"
#define VTEX_DIO2 "DIO2"
#define VTEX_DIO3 "DIO3"
#define VTEX_DIO4 "DIO4"
#define VTEX_DIO5 "DIO5"
#define VTEX_DIO6 "DIO6"
#define VTEX_DIO7 "DIO7"

#define VTEX_BPL0 "BPL0"
#define VTEX_BPL1 "BPL1"
#define VTEX_BPL2 "BPL2"
#define VTEX_BPL3 "BPL3"
#define VTEX_BPL4 "BPL4"
#define VTEX_BPL5 "BPL5"
#define VTEX_BPL6 "BPL6"
#define VTEX_BPL7 "BPL7"

#define VTEX_BPL_INSFAIL "BPL_INSFAIL"

#define VTEX_ALARM0 "ALARM0"
#define VTEX_ALARM1 "ALARM1"
#define VTEX_ALARM2 "ALARM2"
#define VTEX_ALARM3 "ALARM3"
#define VTEX_ALARM4 "ALARM4"
#define VTEX_ALARM5 "ALARM5"
#define VTEX_ALARM6 "ALARM6"
#define VTEX_ALARM7 "ALARM7"

 //
 // VTEXSystem equivalent of LxiSync enums.
 //
enum VTEXSystemArmSourceDetectionEnum
{
  VTEXSystemArmSourceDetectionRise = 0,
  VTEXSystemArmSourceDetectionFall = 1,
  VTEXSystemArmSourceDetectionHigh = 2,
  VTEXSystemArmSourceDetectionLow = 3
};

enum VTEXSystemEventDriveModeEnum
{
  VTEXSystemEventDriveModeDriven = 0,
  VTEXSystemEventDriveModeOff = 1,
  VTEXSystemEventDriveModeWiredOr = 2
};

enum VTEXSystemSourceSlopeEnum
{
  VTEXSystemSourceSlopeRise = 0,
  VTEXSystemSourceSlopeFall = 1
};

enum VTEXSystemTriggerSourceDetectionEnum
{
  VTEXSystemTriggerSourceDetectionRise = 0,
  VTEXSystemTriggerSourceDetectionFall = 1
};

enum VTEXSystemEventLogOverflowEnum
{
  VTEXSystemEventLogOverflowStop = 1000,
  VTEXSystemEventLogOverflowOverride = 1001
};
#endif /* ! _LxisyncConstants_H */

#ifdef  __cplusplus
}
#endif

