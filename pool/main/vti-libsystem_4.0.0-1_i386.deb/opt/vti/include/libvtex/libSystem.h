/******************************************************************************
 *
 *  .----------------------.	
 *  |==     ==  ======  == |	$Author$
 *  | ==   ==   ======  == |	$Revision$ 
 *  |  == ==      ==    == |	$Date$ 
 *  |   ===       ==    == |	$HeadURL$
 *  |    =        ==    == |	
 *  `----------------------' 
 *
 * Copyright 2006 VTI Instruments Corp. as an unpublished work.
 * All rights reserved. The information contained herein is confidential
 * property of VTI Instruments Corp. Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement
 * with VXI Technology, Inc.
 *
 * PURPOSE:
 *   System classes external definition.
 *
 * Note:
 *   A class definition equivalent to IVI System interface.
 *
 * First Written By: Yuji Kobayshi On Jan-2007
 ******************************************************************************/
#ifndef _LIB_SYSTEM_H
#define _LIB_SYSTEM_H

/*******************
 * System header
 *******************/

/*******************
 * Library header
 *******************/

/*******************
 * Macros
 ******************/




/*******************
 * Local header
 *******************/
#include "vtexapi.h"
#ifndef _ATL_ATTRIBUTES
#include "LxisyncConstants.h"
#endif
#include "CommonErrors.h"
#include "property.h"
#include "array.h"
#include "exTypes.h"
#include "libInherent.h"
#include <vector>
#include "vtexException.h"
#include "LxisyncErrors.h"

/***********************
 * Forward Declarations
 ***********************/

class VTEX_API LibSystemEventLog
{
	public:
		virtual ~LibSystemEventLog();

		//Datamembers
		property <LibSystemEventLog, int32_t, READ_ONLY> EntryCount;
		property <LibSystemEventLog, bool, READ_WRITE> Enabled;

		//Methods
		virtual VTEXString GetNextEntry() = 0;
		virtual VTEXResult Clear() = 0;

		virtual VTEXResult get_EntryCount(int32_t* count) = 0;
		virtual VTEXResult get_Enabled(bool* enabled) = 0;
		virtual VTEXResult put_Enabled(bool enabled) = 0;
};


class VTEX_API LibSystemTime
{
	public:
		virtual ~LibSystemTime();

		//Datamembers
		property <LibSystemTime, bool, READ_ONLY> IsMaster;
		property <LibSystemTime, bool, READ_ONLY> IsSynchronized;

		//Methods
		virtual VTEXResult GetSystemTime(double* seconds, double* nanoseconds) = 0;

		virtual VTEXResult get_IsMaster(bool* master) = 0;
		virtual VTEXResult get_IsSynchronized(bool* sync) = 0;
};


class VTEX_API LibSystemArmAlarm
{
	public:
		virtual ~LibSystemArmAlarm();

		//Datamembers
		property <LibSystemArmAlarm, double, READ_WRITE> TimeSeconds;
		property <LibSystemArmAlarm, double, READ_WRITE> TimeFraction;
		property <LibSystemArmAlarm, double, READ_WRITE> Period;
		property <LibSystemArmAlarm, int32_t, READ_WRITE> RepeatCount;
		property <LibSystemArmAlarm, bool, READ_WRITE> Enabled;

		//Methods
		virtual VTEXResult Configure(bool enabled, double seconds, double fractionalSeconds, double period, int32_t repeatCount)=0;
		virtual VTEXResult get_TimeSeconds(double* seconds) = 0;
		virtual VTEXResult put_TimeSeconds(double seconds) = 0;
		virtual VTEXResult get_TimeFraction(double* fraction) = 0;
		virtual VTEXResult put_TimeFraction(double fraction) = 0;
		virtual VTEXResult get_Period(double* period) = 0;
		virtual VTEXResult put_Period(double period) = 0;
		virtual VTEXResult get_RepeatCount(int32_t* count) = 0;
		virtual VTEXResult put_RepeatCount(int32_t count) = 0;
		virtual VTEXResult get_Enabled(bool* enabled) = 0;
		virtual VTEXResult put_Enabled(bool enabled) = 0;


};


class VTEX_API LibSystemArmSource
{
	public:

		virtual ~LibSystemArmSource();

		//Datamembers
		property <LibSystemArmSource, bool, READ_WRITE> Enabled;
		property <LibSystemArmSource, enum VTEXSystemArmSourceDetectionEnum, READ_WRITE> Detection;
		property <LibSystemArmSource, VTEXString, READ_WRITE> Filter;
		property <LibSystemArmSource, VTEXString, READ_WRITE> EventId;

		//Methods
		virtual VTEXResult Configure(bool enabled, enum VTEXSystemArmSourceDetectionEnum detection) = 0;

		virtual VTEXResult get_Enabled(bool* enabled) = 0;
		virtual VTEXResult put_Enabled(bool enabled) = 0;
		virtual VTEXResult get_Detection(enum VTEXSystemArmSourceDetectionEnum* detection) = 0;
		virtual VTEXResult put_Detection(enum VTEXSystemArmSourceDetectionEnum detection) = 0;
		virtual VTEXResult get_Filter(VTEXString* filter) = 0;
		virtual VTEXResult put_Filter(const VTEXString &filter) = 0;
		virtual VTEXResult get_EventId(VTEXString* eventID) = 0;
		virtual VTEXResult put_EventId(const VTEXString &eventID) = 0;
};


class VTEX_API LibSystemEvent
{
	public:
		virtual ~LibSystemEvent();

		//Datamembers
		property <LibSystemEvent, VTEXString, READ_WRITE> Source;
		property <LibSystemEvent, VTEXString, READ_WRITE> DestinationPath;
		property <LibSystemEvent, enum VTEXSystemSourceSlopeEnum, READ_WRITE> Slope;
		property <LibSystemEvent, enum VTEXSystemEventDriveModeEnum, READ_WRITE> DriveMode;

		//Methods
		virtual VTEXResult Configure(	enum VTEXSystemEventDriveModeEnum mode, 
				VTEXString source, 
				VTEXString path, 
				enum VTEXSystemSourceSlopeEnum slope) = 0;

		virtual VTEXResult get_Source(VTEXString* source) = 0;
		virtual VTEXResult put_Source(const VTEXString &source) = 0;
		virtual VTEXResult get_DestinationPath(VTEXString* path) = 0;
		virtual VTEXResult put_DestinationPath(const VTEXString &path) = 0;
		virtual VTEXResult get_Slope(enum VTEXSystemSourceSlopeEnum* slope) = 0;
		virtual VTEXResult put_Slope(enum VTEXSystemSourceSlopeEnum slope) = 0;
		virtual VTEXResult get_DriveMode(enum VTEXSystemEventDriveModeEnum* mode) = 0;
		virtual VTEXResult put_DriveMode(enum VTEXSystemEventDriveModeEnum mode) = 0;
};


class VTEX_API LibSystemTriggerAlarm
{
	public:
		virtual ~LibSystemTriggerAlarm();

		//Datamembers
		property <LibSystemTriggerAlarm, bool, READ_WRITE> Enabled;
		property <LibSystemTriggerAlarm, double, READ_WRITE> TimeSeconds;
		property <LibSystemTriggerAlarm, double, READ_WRITE> TimeFraction;
		property <LibSystemTriggerAlarm, double, READ_WRITE> Period;
		property <LibSystemTriggerAlarm, int32_t, READ_WRITE> RepeatCount;

		//Methods
		virtual VTEXResult Configure(double, double, double, int32_t) = 0;

		virtual VTEXResult get_Period(double* period) = 0;
		virtual VTEXResult put_Period(double period) = 0;
		virtual VTEXResult get_TimeSeconds(double* seconds) = 0;
		virtual VTEXResult put_TimeSeconds(double seconds) = 0;
		virtual VTEXResult get_TimeFraction(double* fraction) = 0;
		virtual VTEXResult put_TimeFraction(double fraction) = 0;
		virtual VTEXResult get_RepeatCount(int32_t* count) = 0;
		virtual VTEXResult put_RepeatCount(int32_t count) = 0;
		virtual VTEXResult get_Enabled(bool* enabled) = 0;
		virtual VTEXResult put_Enabled(bool enabled) = 0;
};


class VTEX_API LibSystemTriggerSource
{
	public:
		virtual ~LibSystemTriggerSource();

		//Datamembers
		property <LibSystemTriggerSource, double, READ_WRITE> Delay;
		property <LibSystemTriggerSource, enum VTEXSystemTriggerSourceDetectionEnum, READ_WRITE> Detection;
		property <LibSystemTriggerSource, VTEXString, READ_WRITE> Filter;
		property <LibSystemTriggerSource, VTEXString, READ_WRITE> EventId;

		//Methods
		virtual VTEXResult Configure(double delay, enum VTEXSystemTriggerSourceDetectionEnum detection) = 0;

		virtual VTEXResult get_Delay(double* delay) = 0;
		virtual VTEXResult put_Delay(double delay) = 0;
		virtual VTEXResult get_Detection(enum VTEXSystemTriggerSourceDetectionEnum* detection) = 0;
		virtual VTEXResult put_Detection(enum VTEXSystemTriggerSourceDetectionEnum detection) = 0;
		virtual VTEXResult get_Filter(VTEXString* filter) = 0;
		virtual VTEXResult put_Filter(const VTEXString &filter) = 0;
		virtual VTEXResult get_EventId(VTEXString* eventID) = 0;
		virtual VTEXResult put_EventId(const VTEXString &eventID) = 0;
};


class VTEX_API LibSystemTriggerAlarms
{
	public:
		virtual ~LibSystemTriggerAlarms();

		//Datamembers
		property <LibSystemTriggerAlarms, int32_t, READ_ONLY> Count;
		property <LibSystemTriggerAlarms, VTEXString, READ_ONLY> ListOfTriggerAlarms;
		arrayizer <LibSystemTriggerAlarms, LibSystemTriggerAlarm*, VTEXString>Item;
		arrayizer <LibSystemTriggerAlarms, VTEXString, int32_t>Name;

		//Methods
		virtual VTEXResult RemoveAllTriggerAlarms(void) = 0;
		virtual VTEXResult Remove(VTEXString name) = 0;
		virtual VTEXResult DisableAll(void) = 0;
		virtual VTEXResult Add(VTEXString name) = 0;
		virtual LibSystemTriggerAlarm *get_Item(VTEXString name) = 0;
		virtual VTEXString get_Name(int32_t index) = 0;

		virtual VTEXResult get_Count(int32_t* val) = 0;

		virtual VTEXResult get_ListOfTriggerAlarms(VTEXString* list) = 0;
};


class VTEX_API LibSystemArmSources
{
	public:
		virtual ~LibSystemArmSources();

		//Datamembers
		property <LibSystemArmSources, int32_t, READ_ONLY> Count;
		property <LibSystemArmSources, bool, READ_WRITE> OrEnabled;
		property <LibSystemArmSources, VTEXString, READ_ONLY> ListOfArmSources;
		arrayizer <LibSystemArmSources, LibSystemArmSource*, VTEXString>Item;
		arrayizer <LibSystemArmSources, VTEXString, int32_t>Name;

		//Methods
		virtual VTEXResult Add(VTEXString name) = 0;
		virtual VTEXResult DisableAll(void) = 0;
		virtual VTEXResult Remove(VTEXString name) = 0;
		virtual VTEXResult RemoveAllCustomArmSources(void) = 0;
		virtual LibSystemArmSource *get_Item(VTEXString name) = 0;
		virtual VTEXString get_Name(int32_t index) = 0;

		virtual VTEXResult get_Count(int32_t* count) = 0;
		virtual VTEXResult get_OrEnabled(bool* enabled) = 0;
		virtual VTEXResult put_OrEnabled(bool enabled) = 0;

		virtual VTEXResult get_ListOfArmSources(VTEXString* list) = 0;
};


class VTEX_API LibSystemTriggerSources
{
	public:
		virtual ~LibSystemTriggerSources();

		//Datamembers
		property <LibSystemTriggerSources, int32_t, READ_ONLY> Count;
		property <LibSystemTriggerSources, VTEXString, READ_ONLY> ListOfTriggerSources;
		arrayizer <LibSystemTriggerSources, LibSystemTriggerSource*, VTEXString>Item;
		arrayizer <LibSystemTriggerSources, VTEXString, int32_t>Name;

		//Methods
		virtual VTEXResult Add(VTEXString name) = 0;
		virtual VTEXResult Remove(VTEXString name) = 0;
		virtual VTEXResult RemoveAllCustomTriggerSources(void) = 0;
		virtual LibSystemTriggerSource *get_Item(VTEXString name) = 0;
		virtual VTEXString get_Name(int32_t index) = 0;

		virtual VTEXResult get_Count(int32_t* count) = 0;

		virtual VTEXResult get_ListOfTriggerSources(VTEXString* list) = 0;
};



class VTEX_API LibSystemArmAlarms
{
	public:
		virtual ~LibSystemArmAlarms();

		//Datamembers
		property <LibSystemArmAlarms, int32_t, READ_ONLY> Count;
		property <LibSystemArmAlarms, VTEXString, READ_ONLY> ListOfArmAlarms;
		arrayizer <LibSystemArmAlarms, LibSystemArmAlarm*, VTEXString>Item;
		arrayizer <LibSystemArmAlarms, VTEXString, int32_t>Name;

		//Methods
		virtual VTEXResult RemoveAllCustomArmAlarms(void) = 0;
		virtual VTEXResult Remove(VTEXString name) = 0;
		virtual VTEXResult Add(VTEXString name) = 0;
		virtual VTEXResult DisableAll(void) = 0;
		virtual LibSystemArmAlarm *get_Item(VTEXString name) = 0;
		virtual VTEXString get_Name(int32_t index) = 0;

		virtual VTEXResult get_Count(int32_t* count) = 0;
		virtual VTEXResult get_ListOfArmAlarms(VTEXString* list) = 0;
};


class VTEX_API LibSystemArm
{
	public:
		virtual ~LibSystemArm();

		//Datamembers
		LibSystemArmSources *Sources;
		LibSystemArmAlarms *Alarms;

		property <LibSystemArm, int32_t, READ_WRITE> ArmCount;
		property <LibSystemArm, double, READ_WRITE> Delay;

		//Methods
		virtual VTEXResult get_ArmCount(int32_t* count) = 0;
		virtual VTEXResult put_ArmCount(int32_t count) = 0;
		virtual VTEXResult get_Delay(double* delay) = 0;
		virtual VTEXResult put_Delay(double delay) = 0;
};


class VTEX_API LibSystemTrigger
{
	public:
		virtual ~LibSystemTrigger();

		//Datamembers
		LibSystemTriggerSources *Sources;
		LibSystemTriggerAlarms *Alarms;

		property <LibSystemTrigger, int32_t, READ_WRITE> TriggerCount;
		property <LibSystemTrigger, VTEXString, READ_WRITE> TriggerSource;

		//Methods
		virtual VTEXResult get_TriggerCount(int32_t* count) = 0;
		virtual VTEXResult put_TriggerCount(int32_t count) = 0;
		virtual VTEXResult get_TriggerSource(VTEXString* source) = 0;
		virtual VTEXResult put_TriggerSource(const VTEXString &source) = 0;
};


class VTEX_API LibSystemEvents
{
	public:
		virtual ~LibSystemEvents();

		//Datamembers
		property <LibSystemEvents, int32_t, READ_ONLY> Count;
		property <LibSystemEvents, int32_t, READ_WRITE> WiredOrBiasMode;
		property <LibSystemEvents, VTEXString, READ_ONLY> ListOfEvents;
		arrayizer <LibSystemEvents, LibSystemEvent*, VTEXString>Item;
		arrayizer <LibSystemEvents, VTEXString, int32_t>Name;

		//Methods
		virtual VTEXResult RemoveAllCustomEvents(void) = 0;
		virtual VTEXResult Remove(VTEXString name) = 0;
		virtual VTEXResult Add(VTEXString name) = 0;
		virtual VTEXResult DisableAll(void) = 0;
		virtual LibSystemEvent *get_Item(VTEXString name) = 0;
		virtual VTEXString get_Name(int32_t index) = 0;

		virtual VTEXResult get_Count(int32_t* count) = 0;
		virtual VTEXResult get_WiredOrBiasMode(int32_t* bias) = 0;
		virtual VTEXResult put_WiredOrBiasMode(int32_t bias) = 0;
		virtual VTEXResult get_ListOfEvents(VTEXString* list) = 0;
};

class VTEX_API LibSystemInstrumentSpecificRouteDestination
{
	public:
		virtual ~LibSystemInstrumentSpecificRouteDestination();

		property <LibSystemInstrumentSpecificRouteDestination, VTEXString, READ_WRITE> SourcesList;
		property <LibSystemInstrumentSpecificRouteDestination, VTEXString, READ_WRITE> InvertedSourcesList;
		property <LibSystemInstrumentSpecificRouteDestination, VTEXString, READ_WRITE> DestinationPath;
		property <LibSystemInstrumentSpecificRouteDestination, enum VTEXSystemEventDriveModeEnum, READ_WRITE> DriveMode;
		property <LibSystemInstrumentSpecificRouteDestination, bool, READ_WRITE> OrEnabled;
		property <LibSystemInstrumentSpecificRouteDestination, int32_t, READ_WRITE> SoftwareState;

		virtual VTEXResult Pulse(void) = 0;
		virtual VTEXResult Configure(VTEXString sourcesList, VTEXString invertedSourcesList, bool orEnabled, VTEXSystemEventDriveModeEnum mode, VTEXString destinationPath)=0;

		virtual VTEXResult get_SourcesList(VTEXString* sources) = 0;
		virtual VTEXResult put_SourcesList(const VTEXString &sources) = 0;
		virtual VTEXResult get_InvertedSourcesList(VTEXString* invSources) = 0;
		virtual VTEXResult put_InvertedSourcesList(const VTEXString &invSources) = 0;
		virtual VTEXResult get_DestinationPath(VTEXString* destPath) = 0;
		virtual VTEXResult put_DestinationPath(const VTEXString &destPath) = 0;
		virtual VTEXResult get_DriveMode(enum VTEXSystemEventDriveModeEnum* mode) = 0;
		virtual VTEXResult put_DriveMode(enum VTEXSystemEventDriveModeEnum mode) = 0;
		virtual VTEXResult get_OrEnabled(bool* enabled) = 0;
		virtual VTEXResult put_OrEnabled(bool enabled) = 0;
		virtual VTEXResult get_SoftwareState(int32_t* state) = 0;
		virtual VTEXResult put_SoftwareState(int32_t state) = 0;
};



class VTEX_API LibSystemInstrumentSpecificRouteDestinations
{
	public:
		virtual ~LibSystemInstrumentSpecificRouteDestinations();
		property <LibSystemInstrumentSpecificRouteDestinations, int32_t, READ_ONLY> Count;
		property <LibSystemInstrumentSpecificRouteDestinations, VTEXString, READ_ONLY> ListOfRouteDestinations;
		arrayizer <LibSystemInstrumentSpecificRouteDestinations, LibSystemInstrumentSpecificRouteDestination*, VTEXString>Item;
		arrayizer <LibSystemInstrumentSpecificRouteDestinations, VTEXString, int32_t>Name;

		virtual LibSystemInstrumentSpecificRouteDestination *get_Item(VTEXString name)=0;
		virtual VTEXString get_Name(int32_t index) = 0;
		virtual VTEXResult get_Count(int32_t* count) = 0;
		virtual VTEXResult get_ListOfRouteDestinations(VTEXString* list) = 0;
		virtual VTEXResult Add(VTEXString name) = 0;
		virtual VTEXResult Remove(VTEXString name) = 0;
		virtual VTEXResult RemoveAllCustomRouteDestinations(void) = 0;
		virtual VTEXResult DisableAll(void) = 0;	
};

class VTEX_API LibSystemInstrumentSpecificRouteSource
{
	public:
		virtual ~LibSystemInstrumentSpecificRouteSource();

		property <LibSystemInstrumentSpecificRouteSource, VTEXString, READ_WRITE> Filter;
		property <LibSystemInstrumentSpecificRouteSource, VTEXString, READ_WRITE> EventId;

		virtual VTEXResult get_Filter(VTEXString* filter) =0 ;
		virtual VTEXResult put_Filter(const VTEXString &filter) =0 ;
		virtual VTEXResult get_EventId(VTEXString* eventID) =0 ;
		virtual VTEXResult put_EventId(const VTEXString &eventID) =0 ;

};

class VTEX_API LibSystemInstrumentSpecificRouteSources
{
	public:
		virtual ~LibSystemInstrumentSpecificRouteSources();
		property <LibSystemInstrumentSpecificRouteSources, int32_t, READ_ONLY> Count;
		property <LibSystemInstrumentSpecificRouteSources, VTEXString, READ_ONLY> ListOfRouteSources;
		arrayizer <LibSystemInstrumentSpecificRouteSources, LibSystemInstrumentSpecificRouteSource*, VTEXString>Item;
		arrayizer <LibSystemInstrumentSpecificRouteSources, VTEXString, int32_t>Name;

		virtual LibSystemInstrumentSpecificRouteSource *get_Item(VTEXString name)=0;
		virtual VTEXString get_Name(int32_t index) = 0;
		virtual VTEXResult get_Count(int32_t* count)=0;
		virtual VTEXResult get_ListOfRouteSources(VTEXString* list) = 0;
		virtual VTEXResult Add(VTEXString name) = 0;
		virtual VTEXResult Remove(VTEXString name) = 0;
		virtual VTEXResult RemoveAllCustomRouteSources(void) = 0;
};

class VTEX_API LibSystemInstrumentSpecificRouteAlarm
{
	public:
		virtual ~LibSystemInstrumentSpecificRouteAlarm();
		property <LibSystemInstrumentSpecificRouteAlarm, bool, READ_WRITE> Enabled;
		property <LibSystemInstrumentSpecificRouteAlarm, double, READ_WRITE> TimeSeconds;
		property <LibSystemInstrumentSpecificRouteAlarm, double, READ_WRITE> TimeFraction;
		property <LibSystemInstrumentSpecificRouteAlarm, double, READ_WRITE> Period;
		property <LibSystemInstrumentSpecificRouteAlarm, int32_t, READ_WRITE> RepeatCount;

		virtual VTEXResult Configure(bool enabled, double seconds, double fractionalSeconds, double period, int32_t repeatCount)=0;
		virtual VTEXResult get_Enabled(bool* enabled) =0 ;
		virtual VTEXResult put_Enabled(bool enabled) =0 ;
		virtual VTEXResult get_TimeSeconds(double* timeSeconds) =0 ;
		virtual VTEXResult put_TimeSeconds(double timeSeconds) =0 ;
		virtual VTEXResult get_TimeFraction(double* timeFraction) =0 ;
		virtual VTEXResult put_TimeFraction(double timeFraction) =0 ;
		virtual VTEXResult get_Period(double* period) =0 ;
		virtual VTEXResult put_Period(double period) =0 ;
		virtual VTEXResult get_RepeatCount(int32_t* repeatCount) =0 ;
		virtual VTEXResult put_RepeatCount(int32_t repeatCount) =0 ;
};

class VTEX_API LibSystemInstrumentSpecificRouteAlarms
{
	public:
		virtual ~LibSystemInstrumentSpecificRouteAlarms();

		property <LibSystemInstrumentSpecificRouteAlarms, int32_t, READ_ONLY> Count;
		property <LibSystemInstrumentSpecificRouteAlarms, VTEXString, READ_ONLY> ListOfRouteAlarms;
		arrayizer <LibSystemInstrumentSpecificRouteAlarms, LibSystemInstrumentSpecificRouteAlarm*, VTEXString>Item;
		arrayizer <LibSystemInstrumentSpecificRouteAlarms, VTEXString, int32_t>Name;
		virtual LibSystemInstrumentSpecificRouteAlarm* get_Item(VTEXString name)=0;
		virtual VTEXString get_Name(int32_t index) = 0;
		virtual VTEXResult get_Count(int32_t* count) =0;
		virtual VTEXResult get_ListOfRouteAlarms(VTEXString* list) = 0;
		virtual VTEXResult Add(VTEXString name) = 0;
		virtual VTEXResult Remove(VTEXString name) = 0;
		virtual VTEXResult RemoveAllCustomRouteAlarms(void) = 0;
		virtual VTEXResult DisableAll(void) = 0;
};

class VTEX_API LibSystemInstrumentSpecificRoute
{
	public:
		LibSystemInstrumentSpecificRouteSources* Sources;
		LibSystemInstrumentSpecificRouteDestinations* Destinations;
		LibSystemInstrumentSpecificRouteAlarms* Alarms;
};

class VTEX_API LibSystemInstrumentSpecificIOPort
{
	public:
		virtual ~LibSystemInstrumentSpecificIOPort(); 
		property <LibSystemInstrumentSpecificIOPort, int32_t, READ_ONLY> InputState;
		property <LibSystemInstrumentSpecificIOPort, int32_t, READ_ONLY> DrivenState;

		virtual VTEXResult get_InputState(int32_t* state) = 0;
		virtual VTEXResult get_DrivenState(int32_t* state) = 0;
};

class VTEX_API LibSystemInstrumentSpecificIOPorts
{
	public:

		property <LibSystemInstrumentSpecificIOPorts, int32_t, READ_ONLY> Count;
		property <LibSystemInstrumentSpecificIOPorts, VTEXString, READ_ONLY> ListOfIOPorts;
		arrayizer <LibSystemInstrumentSpecificIOPorts, LibSystemInstrumentSpecificIOPort*, VTEXString>Item;
		arrayizer <LibSystemInstrumentSpecificIOPorts, VTEXString, int32_t>Name;
		
		virtual ~LibSystemInstrumentSpecificIOPorts();

		virtual VTEXResult get_ListOfIOPorts(VTEXString* list) = 0;
		virtual VTEXResult get_Count(int32_t* count) = 0;
		virtual VTEXString get_Name(int32_t index) = 0;
		virtual LibSystemInstrumentSpecificIOPort* get_Item(VTEXString name) = 0;

};

class VTEX_API LibSystemInstrumentSpecific
{
	public:
		virtual ~LibSystemInstrumentSpecific();

		LibSystemInstrumentSpecificRoute* Route;
		LibSystemInstrumentSpecificIOPorts* IOPorts;

		//Datamembers
		/// <summary> This platform's serial number </summary>
		property <LibSystemInstrumentSpecific, VTEXString, READ_ONLY> SerialNumber;
		property <LibSystemInstrumentSpecific, enum VTEXSystemEventLogOverflowEnum, READ_WRITE> EventLogOverflowMode;
		property <LibSystemInstrumentSpecific, VTEXString, READ_ONLY> SystemInventory;

		//Methods
		virtual VTEXResult get_SerialNumber(VTEXString* serial) = 0;
		virtual VTEXResult get_EventLogOverflowMode(enum VTEXSystemEventLogOverflowEnum* mode) = 0;
		virtual VTEXResult put_EventLogOverflowMode(enum VTEXSystemEventLogOverflowEnum mode) = 0;
		virtual VTEXResult Display(VTEXString text, int32_t fontSize, int32_t scrollSpeed) = 0;
		virtual VTEXResult get_SystemInventory(VTEXString* inventory) = 0;
        virtual std::vector<unsigned char> RetrieveFile(VTEXString filename) = 0;

		virtual VTEXResult GetResourceState(VTEXIntVector& slots, VTEXBoolVector& locked) = 0; 

		virtual VTEXString FindInstruments(VTEXString models, int32_t timeout) = 0; 
        virtual VTEXResult SetTimeout(uint32_t timeout) = 0;
};

class VTEX_API LibSystemConfiguration
{
	public:
		virtual ~LibSystemConfiguration();

		//Datamembers
		property <LibSystemConfiguration, VTEXString, READ_ONLY> SavedConfigurationDigest;
		property <LibSystemConfiguration, VTEXString, READ_ONLY> CurrentConfigurationDigest;

		//Methods
		virtual VTEXResult ClearSavedConfiguration() = 0;
		virtual VTEXResult LoadSavedConfiguration() = 0;
		virtual VTEXResult SaveConfiguration() = 0;
        virtual VTEXResult get_SavedConfigurationDigest(VTEXString* val) = 0;
        virtual VTEXResult get_CurrentConfigurationDigest(VTEXString* val) = 0;
};


//class LibSystem
class VTEX_API LibSystem
{
	public:
		virtual ~LibSystem();
		static LibSystem* Create();

		//Datamembers
		//Inherent capabilitites
		property <LibSystem, bool, READ_ONLY> Initialized;
		property <LibSystem, int32_t, READ_WRITE> LXIDomain;

		/// <summary>Pointer to Utility interface</summary>
		LibInherentCapabilityUtility* Utility;

		/// <summary>Pointer to DriverOperation interface</summary>
		LibInherentCapabilityDriverOperation* DriverOperation;

		/// <summary>Pointer to Identity interface</summary>
		LibInherentCapabilityIdentity* Identity;


		/// <summary>Pointer to Arm interface</summary>
		LibSystemArm *Arm;

		/// <summary>Pointer to Configuration interface</summary>
		LibSystemConfiguration *Configuration;

		/// <summary>Pointer to EventLog interface</summary>
		LibSystemEventLog *EventLog;

		/// <summary>Pointer to Events interface</summary>
		LibSystemEvents *Events;

		/// <summary>Pointer to Time interface</summary>
		LibSystemTime *Time;

		/// <summary>Pointer to Trigger interface</summary>
		LibSystemTrigger *Trigger;

		/// <summary>Pointer to InstrumentSpecific interface</summary>
		LibSystemInstrumentSpecific* InstrumentSpecific;


		//Methods
		virtual VTEXResult Close() = 0;

		virtual VTEXResult Initialize(const VTEXString& resourceName,
				bool idQuery,
				bool reset,
				const VTEXString& optionString) = 0;

		virtual VTEXResult Initialize(const VTEXString& resourceName,
				bool idQuery,
				bool reset) = 0;

		virtual VTEXResult get_Initialized (bool *val) = 0;
		virtual VTEXResult get_LXIDomain(int32_t* domain) = 0;
		virtual VTEXResult put_LXIDomain(int32_t domain) = 0;
};

#endif  // _LIB_SYSTEM_H
