#include "libPlatform.h"
#include <stdio.h>

int main()
{
    //Create a libPlatform pointer
    LibPlatform *pPlatform;

    /*We want to instantiate a pointer to the driver in a try/catch block so that we fail
    properly if there is an error*/
    try
    {
        //Instantiate the created Platform pointer
        pPlatform = LibPlatform::Create();
        /*We want to do the initialization in a try/catch block so that our test code
        doesn't run if we fail to initialize.*/

        try
        {
            /*We chose to give the driver an empty options string. You may want to
            give your driver options - check the manual to see the available settings.
            Note that we also set the Reset bit so that we get a clean state to work
            from.*/
            pPlatform->Initialize("TCPIP::10.1.4.55::INSTR", true, true, "");

            // Route all signals from PXI3 to LAN2
            pPlatform->Events->Item["LAN2"]->Source = "PXI3";
            pPlatform->Events->Item["LAN2"]->DriveMode = VTEXPlatformEventDriveModeWiredOr;

            // Route & invert all signals from PXI3 to LAN2
            pPlatform->Events->Item["LAN2"]->Source = "PXI3";
            pPlatform->Events->Item["LAN2"]->Slope = VTEXPlatformSourceSlopeFall;
            pPlatform->Events->Item["LAN2"]->DriveMode = VTEXPlatformEventDriveModeWiredOr;

            // Toggle PXI3
            pPlatform->Events->Item["PXI3"]->DriveMode = VTEXPlatformEventDriveModeDriven;
            pPlatform->Events->Item["PXI3"]->Source = "1";
            pPlatform->Events->Item["PXI3"]->Source = "0";

            // Disable all events that were previously in use
            pPlatform->Events->DisableAll();

            // Route PXI0 to EXT, for use when synchronizing two chassis
            pPlatform->Events->Item["EXT"]->Source = "PXI0";
            pPlatform->Events->Item["EXT"]->DriveMode = VTEXPlatformEventDriveModeDriven;

            // Route EXT to PXI0, for use when synchronizing two chassis
            pPlatform->Events->Item["PXI0"]->Source = "EXT";
            pPlatform->Events->Item["PXI0"]->DriveMode = VTEXPlatformEventDriveModeDriven;

            //Close the initialized session
            pPlatform->Close();
        }
        catch(VTEXException e)
        {
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS) // If the error is IVI_E_INSTRUMENT_STATUS, we need to check the error queue
            {
                if(pPlatform->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    pPlatform->Utility->ErrorQuery(error_code, error);

                    fprintf(stderr, "Error code: 0x%X\n", error_code);
                    fprintf(stderr, "Error Message: %s\n", error.c_str());
                }
                else
                {
                    fprintf(stderr, "Error code: 0x%X\n", e.errorCode);
                    fprintf(stderr, "Error Message: %s\n", e.errorMessage.c_str());
                }
            }
            else
            {
                fprintf(stderr, "Error code: 0x%X\n", e.errorCode);
                fprintf(stderr, "Error Message: %s\n", e.errorMessage.c_str());
            }
            if(pPlatform->Initialized)
            {
                // If an exception occurs, try to close the driver session gracefully if possible
                pPlatform->Close();
            }
        }

        //Clean up when we're done
        delete pPlatform;
        pPlatform = nullptr;
    }
    catch(...)
    {
        /*We put this here to catch any error the program generates.*/
        //Do something to intelligently deal with errors
    }
}
