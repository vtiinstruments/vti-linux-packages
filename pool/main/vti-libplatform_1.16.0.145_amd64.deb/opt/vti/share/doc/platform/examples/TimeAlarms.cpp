#include "libPlatform.h"
#include <stdio.h>

int main()
{
    //Create a libPlatform pointer
    LibPlatform *pPlatform;

    /*We want to instantiate a pointer to the driver in a try/catch block so that we fail
    properly if there is an error*/
    try
    {
        //Instantiate the created Platform pointer
        pPlatform = LibPlatform::Create();
        /*We want to do the initialization in a try/catch block so that our test code
        doesn't run if we fail to initialize.*/

        try
        {
            /*We chose to give the driver an empty options string. You may want to
            give your driver options - check the manual to see the available settings.
            Note that we also set the Reset bit so that we get a clean state to work
            from.*/
            pPlatform->Initialize("TCPIP::10.1.4.55::INSTR", true, true, "");

            /*Set an Alarm to go off at Fri Feb 13 2009 18:31:30.0503 EST and fire exactly once.
            Note that attempting to enable an alarm with the time set in the past will cause an error.*/
            //An alarm should not be set unless the device is synchronized to IEEE 1588
            if(pPlatform->Time->IsSynchronized)
            {
                //Note that 0 is a special case for Period and RepeatCount
                pPlatform->Alarm->Configure(false, 1234567890.0, 0.0503, 0, 0);
            }

            /*Set a Alarm to go off 10 seconds from the current time and fire 10 times with a
            period of one second. Note that the start time won't be exactly 10 seconds from now due
            to network delays.*/

            //Again, don't do this unless we're synchronized
            if(pPlatform->Time->IsSynchronized)
            {
                double seconds;
                double fraction;
                pPlatform->Time->GetSystemTime(seconds, fraction); //Get the current time
                pPlatform->Alarm->Configure(true, seconds + 10.0, fraction, 1.0, 10);
            }

            //Close the initialized session
            pPlatform->Close();
        }
        catch(VTEXException e)
        {
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS) // If the error is IVI_E_INSTRUMENT_STATUS, we need to check the error queue
            {
                if(pPlatform->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    pPlatform->Utility->ErrorQuery(error_code, error);

                    fprintf(stderr, "Error code: 0x%X\n", error_code);
                    fprintf(stderr, "Error Message: %s\n", error.c_str());
                }
                else
                {
                    fprintf(stderr, "Error code: 0x%X\n", e.errorCode);
                    fprintf(stderr, "Error Message: %s\n", e.errorMessage.c_str());
                }
            }
            else
            {
                fprintf(stderr, "Error code: 0x%X\n", e.errorCode);
                fprintf(stderr, "Error Message: %s\n", e.errorMessage.c_str());
            }
            if(pPlatform->Initialized)
            {
                // If an exception occurs, try to close the driver session gracefully if possible
                pPlatform->Close();
            }
        }

        //Clean up when we're done
        delete pPlatform;
        pPlatform = nullptr;
    }
    catch(...)
    {
        /*We put this here to catch any error the program generates.*/
        //Do something to intelligently deal with errors
    }
}
