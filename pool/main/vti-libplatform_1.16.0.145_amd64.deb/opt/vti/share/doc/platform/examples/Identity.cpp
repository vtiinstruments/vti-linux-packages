#include <iostream>
#include "libPlatform.h"

int main(int argc, char **argv)
{
    LibPlatform *platform;
    try {
        // Create a new instance of the Platform driver
        platform = LibPlatform::Create();
        try
        {
            // The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_1::INSTR
            if (argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // Initialize the Platform driver
            platform->Initialize(resource_string, true, true);
            std::cout << "Initialized to " << resource_string << std::endl;

            // Query the instrument for different properties: Model Number, Firmware Revision, Manufacturer

            std::string model = platform->Identity->InstrumentModel;
            std::cout << "Model: " << model << std::endl;

            std::string firmware_rev = platform->Identity->InstrumentFirmwareRevision;
            std::cout << "Firmware Revision: " << firmware_rev << std::endl;

            std::string manufacturer = platform->Identity->InstrumentManufacturer;
            std::cout << "Manufacturer: " << manufacturer << std::endl;
            
            std::string serial = platform->SerialNumber;
            std::cout << "Controller Serial Number: " << serial << std::endl;

            int chassis_count = platform->Chassiss->Count;
            for(int i = 0; i < chassis_count; i++)
            {
                std::cout << "Chassis #" << i + 1 << ": ";
                std::string name = platform->Chassiss->Name[i + 1];

                std::string chassis_model = platform->Chassiss->Item[name]->Model;
                std::string chassis_serial = platform->Chassiss->Item[name]->SerialNumber;
                std::cout << chassis_model << " Serial Number: " << chassis_serial << std::endl;
            }

            platform->Close(); // Make sure to close the driver session when you are finished
        }
        catch(VTEXException e)
        {
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS) // If the error is IVI_E_INSTRUMENT_STATUS, we need to check the error queue
            {
                if(platform->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    platform->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(platform->Initialized)
            {
                // If an exception occurs, try to close the driver session gracefully if possible
                platform->Close();
            }
        }

        //Clean up when we're done
        delete platform;
        platform = nullptr;
    }
    catch(...)
    {
        // Handle any non VTEX exceptions here
    }
}
