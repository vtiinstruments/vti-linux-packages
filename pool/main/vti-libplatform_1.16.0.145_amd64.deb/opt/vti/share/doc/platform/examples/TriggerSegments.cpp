#include "libPlatform.h"
#include <stdio.h>

int main()
{
    //Create a libPlatform pointer
    LibPlatform *pPlatform;

    /*We want to instantiate a pointer to the driver in a try/catch block so that we fail
    properly if there is an error*/
    try
    {
        //Instantiate the created Platform pointer
        pPlatform = LibPlatform::Create();
        /*We want to do the initialization in a try/catch block so that our test code
        doesn't run if we fail to initialize.*/

        try
        {
            /*We chose to give the driver an empty options string. You may want to
            give your driver options - check the manual to see the available settings.
            Note that we also set the Reset bit so that we get a clean state to work
            from.*/
            pPlatform->Initialize("TCPIP::10.1.4.55::INSTR", true, true, "");

            std::string chassis = pPlatform->Chassiss->Name[1]; // The EMX-2500 only supports one chassis

            // Reserve the lines you want to bridge
            // Bridging between two segments must be on the same line. Here, we bridging PXI3 from BUS1 to BUS2, and PXI4 from BUS2 to BUS1
            bool reserved = pPlatform->Chassiss->Item[chassis]->Buss->Item["BUS1"]->Lines->Item["PXI3"]->Reserved;
            if(!reserved)
            {
                pPlatform->Chassiss->Item[chassis]->Buss->Item["BUS1"]->Lines->Item["PXI3"]->Reserved = true;
            }
            reserved = pPlatform->Chassiss->Item[chassis]->Buss->Item["BUS2"]->Lines->Item["PXI3"]->Reserved;
            if(!reserved)
            {
                pPlatform->Chassiss->Item[chassis]->Buss->Item["BUS2"]->Lines->Item["PXI3"]->Reserved = true;
            }
            
            reserved = pPlatform->Chassiss->Item[chassis]->Buss->Item["BUS1"]->Lines->Item["PXI4"]->Reserved;
            if(!reserved)
            {
                pPlatform->Chassiss->Item[chassis]->Buss->Item["BUS1"]->Lines->Item["PXI4"]->Reserved = true;
            }
            reserved = pPlatform->Chassiss->Item[chassis]->Buss->Item["BUS2"]->Lines->Item["PXI4"]->Reserved;
            if(!reserved)
            {
                pPlatform->Chassiss->Item[chassis]->Buss->Item["BUS2"]->Lines->Item["PXI4"]->Reserved = true;
            }

            // Now, add the routes. 
            // Note: Routes are directional, so if you want the route to work in both directions, you'll need to add a separate route for each direction
            pPlatform->Chassiss->Item[chassis]->Routes->Add("BUS1_to_BUS2", "BUS1", "BUS2", "PXI3", "PXI3");
            pPlatform->Chassiss->Item[chassis]->Routes->Add("BUS2_to_BUS1", "BUS2", "BUS1", "PXI4", "PXI4");

            // Do some work, take some measurements, etc.

            // If you're done with the route, you can remove it
            pPlatform->Chassiss->Item[chassis]->Routes->Remove("BUS1_to_BUS2");
            pPlatform->Chassiss->Item[chassis]->Routes->Remove("BUS2_to_BUS1");


            // If you are not using the lines anymore, and if they are not in use by another route, you can clear the reservation
            pPlatform->Chassiss->Item[chassis]->Buss->Item["BUS1"]->Lines->Item["PXI3"]->Reserved = false;
            pPlatform->Chassiss->Item[chassis]->Buss->Item["BUS2"]->Lines->Item["PXI3"]->Reserved = false;

            pPlatform->Chassiss->Item[chassis]->Buss->Item["BUS1"]->Lines->Item["PXI4"]->Reserved = false;
            pPlatform->Chassiss->Item[chassis]->Buss->Item["BUS2"]->Lines->Item["PXI4"]->Reserved = false;

            //Close the initialized session
            pPlatform->Close();
        }
        catch(VTEXException e)
        {
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS) // If the error is IVI_E_INSTRUMENT_STATUS, we need to check the error queue
            {
                if(pPlatform->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    pPlatform->Utility->ErrorQuery(error_code, error);

                    fprintf(stderr, "Error code: 0x%X\n", error_code);
                    fprintf(stderr, "Error Message: %s\n", error.c_str());
                }
                else
                {
                    fprintf(stderr, "Error code: 0x%X\n", e.errorCode);
                    fprintf(stderr, "Error Message: %s\n", e.errorMessage.c_str());
                }
            }
            else
            {
                fprintf(stderr, "Error code: 0x%X\n", e.errorCode);
                fprintf(stderr, "Error Message: %s\n", e.errorMessage.c_str());
            }
            if(pPlatform->Initialized)
            {
                // If an exception occurs, try to close the driver session gracefully if possible
                pPlatform->Close();
            }
        }

        //Clean up when we're done
        delete pPlatform;
        pPlatform = nullptr;
    }
    catch(...)
    {
        /*We put this here to catch any error the program generates.*/
        //Do something to intelligently deal with errors
    }
}