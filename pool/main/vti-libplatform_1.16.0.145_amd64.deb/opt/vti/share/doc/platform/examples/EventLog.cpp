#include "libPlatform.h"
#include <stdio.h>

int main()
{
    //Create a libPlatform pointer
    LibPlatform *pPlatform;

    /*We want to instantiate a pointer to the driver in a try/catch block so that we fail
    properly if there is an error*/
    try
    {
        pPlatform = LibPlatform::Create();

        /*We want to do the Initialization a try/catch block so that our test code
        doesn't run if we fail to initialize.*/
        try
        {
            /*We chose to give the driver an empty options string. You may want to
            give your driver options - check the manual to see the available settings.
            Note that we also set the Reset bit so that we get a clean state to work
            from.*/
            pPlatform->Initialize("TCPIP::10.1.4.55::INSTR", true, true, "");

            /* The Event Log keeps track of received LXI LAN Event Packets for us. It is enabled in circular-buffer mode by default,
            but also has a fifo-mode which stops when it is full. */

            //The event log can be disabled if the user doesn't want to spend system resources logging packets.
            pPlatform->EventLog->Enabled = false;

            //However, leaving the log enabled can be helpful if using LAN triggers, to help debug issues with a test system
            pPlatform->EventLog->Enabled = true;

            //We can also change the system so that it stops recording events when the log is full.
            pPlatform->EventLog->OverflowMode = VTEXPlatformEventLogOverflowModeStop;

            //We can also retrieve current entries in the event log, if there are any
            printf("Event log entry count: %d\n", pPlatform->EventLog->EntryCount);
            if(pPlatform->EventLog->EntryCount > 0)
            {
                std::string entry = pPlatform->EventLog->GetNextEntry();
                printf("%s\n", entry.c_str());
            }

            //Or, we can clear the entire log
            pPlatform->EventLog->Clear();

            //Close the initialized session
            pPlatform->Close();
        }
        catch(VTEXException e)
        {
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS) // If the error is IVI_E_INSTRUMENT_STATUS, we need to check the error queue
            {
                if(pPlatform->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    pPlatform->Utility->ErrorQuery(error_code, error);

                    fprintf(stderr, "Error code: 0x%X\n", error_code);
                    fprintf(stderr, "Error Message: %s\n", error.c_str());
                }
                else
                {
                    fprintf(stderr, "Error code: 0x%X\n", e.errorCode);
                    fprintf(stderr, "Error Message: %s\n", e.errorMessage.c_str());
                }
            }
            else
            {
                fprintf(stderr, "Error code: 0x%X\n", e.errorCode);
                fprintf(stderr, "Error Message: %s\n", e.errorMessage.c_str());
            }
            if(pPlatform->Initialized)
            {
                // If an exception occurs, try to close the driver session gracefully if possible
                pPlatform->Close();
            }
        }

        //Clean up when we're done
        delete pPlatform;
        pPlatform = nullptr;
    }
    catch(...)
    {
        /*We put this here to catch any error the program generates.*/
        //Do something to intelligently deal with errors
    }
}
