#ifndef _PLATFORM_ENUMS_
#define _PLATFORM_ENUMS_

#ifndef ___VTEXPlatform_h__

typedef enum
{
    VTEXPlatformArmSourceDetectionRise = 0,
    VTEXPlatformArmSourceDetectionFall = 1,
    VTEXPlatformArmSourceDetectionHigh = 2,
    VTEXPlatformArmSourceDetectionLow = 3,
} VTEXPlatformArmSourceDetectionEnum;

typedef enum
{
    VTEXPlatformEventDriveModeDriven = 0,
    VTEXPlatformEventDriveModeOff = 1,
    VTEXPlatformEventDriveModeWiredOr = 2,
} VTEXPlatformEventDriveModeEnum;

typedef enum
{
    VTEXPlatformSourceSlopeRise = 0,
    VTEXPlatformSourceSlopeFall = 1,
} VTEXPlatformSourceSlopeEnum;

typedef enum
{
    VTEXPlatformTriggerSourceDetectionRise = 0,
    VTEXPlatformTriggerSourceDetectionFall = 1,
} VTEXPlatformTriggerSourceDetectionEnum;

typedef enum
{
    VTEXPlatformEventLogOverflowModeStop = 1000,
    VTEXPlatformEventLogOverflowModeOverwrite = 1001,
} VTEXPlatformEventLogOverflowModeEnum;

typedef enum
{
    VTEXPlatformFanSpeedModeAuto = 1000,
    VTEXPlatformFanSpeedModeHigh = 1001,
    VTEXPlatformFanSpeedModeLow = 1002,
    VTEXPlatformFanSpeedModeOff = 1003,
} VTEXPlatformFanSpeedModeEnum;

typedef enum
{
    VTEXPlatformLinkConfiguration4Links = 1000,
    VTEXPlatformLinkConfiguration2Links = 1001,
    VTEXPlatformLinkConfiguration1Link = 1002,
} VTEXPlatformLinkConfigurationEnum;

typedef enum
{
    VTEXPlatformSlotTypePXI = 1000,
    VTEXPlatformSlotTypeSystem = 1001,
    VTEXPlatformSlotTypeHybrid = 1002,
    VTEXPlatformSlotTypeTiming = 1003,
} VTEXPlatformSlotTypeEnum;

typedef enum
{
    VTEXPlatformSMBusProtocolQuickCommand = 1000,
    VTEXPlatformSMBusProtocolSendByte = 1001,
    VTEXPlatformSMBusProtocolReceiveByte = 1002,
    VTEXPlatformSMBusProtocolWriteByte = 1003,
    VTEXPlatformSMBusProtocolReadByte = 1004,
    VTEXPlatformSMBusProtocolWriteWord = 1005,
    VTEXPlatformSMBusProtocolReadWord = 1006,
    VTEXPlatformSMBusProtocolProcessCall = 1007,
    VTEXPlatformSMBusProtocolWriteBlock = 1008,
    VTEXPlatformSMBusProtocolReadBlock = 1009,
} VTEXPlatformSMBusProtocolEnum;

typedef enum
{
    VTEXPlatformTemperatureUnitsCelsius = 1000,
    VTEXPlatformTemperatureUnitsFahrenheit = 1001,
    VTEXPlatformTemperatureUnitsKelvin = 1002,
} VTEXPlatformTemperatureUnitsEnum;

typedef enum
{
    VTEXPlatformSystemTimeSourceManual = 1000,
    VTEXPlatformSystemTimeSourceNTP = 1001,
    VTEXPlatformSystemTimeSourcePTP = 1002,
} VTEXPlatformSystemTimeSourceEnum;

#endif // ___VTEXPlatform_h__
#endif // _PLATFORM_ENUMS_
