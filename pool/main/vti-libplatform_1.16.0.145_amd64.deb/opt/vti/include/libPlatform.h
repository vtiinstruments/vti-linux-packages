/******************************************************************************
*  .----------------------.
*  |==     ==  ======  == |    $Author$
*  | ==   ==   ======  == |    $Revision$
*  |  == ==      ==    == |    $Date$
*  |   ===       ==    == |    $HeadURL$
*  |    =        ==    == |
*  `----------------------'
*
* Copyright 2010 VTI Instruments Corp. as an unpublished work.
* All rights reserved. The information contained herein is confidential
* property of VTI Instruments Corp. Use, copy, transfer or disclosure
* of such information is prohibited except by express written agreement
* with VTI Instruments Corp.
*
* PURPOSE:
*   Main public interface file for the Platform library
******************************************************************************/

#ifndef _libPlatform_H
#define _libPlatform_H

/**************************
 *       Includes         *
 **************************/
#include <string>
#include <vector>

#include "vtexInherent.h"
#include "libVtexException.h"

#include "libPlatformErrors.h"
#include "libPlatformEnums.h"

/*************************
 *      Classes          *
 *************************/

class LibPlatformAlarm
{
public:
    virtual ~LibPlatformAlarm() {};

    virtual VTEXResult Configure(bool enabled, double time_seconds, double time_fraction, double period, int32_t repeat_count) = 0;

    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Period(double &val) = 0;
    virtual VTEXResult put_Period(double val) = 0;
    virtual VTEXResult get_RepeatCount(int32_t &val) = 0;
    virtual VTEXResult put_RepeatCount(int32_t val) = 0;
    virtual VTEXResult get_TimeSeconds(double &val) = 0;
    virtual VTEXResult put_TimeSeconds(double val) = 0;
    virtual VTEXResult get_TimeFraction(double &val) = 0;
    virtual VTEXResult put_TimeFraction(double val) = 0;

    vtexProperty <LibPlatformAlarm, bool, READ_WRITE> Enabled;
    vtexProperty <LibPlatformAlarm, double, READ_WRITE> Period;
    vtexProperty <LibPlatformAlarm, int32_t, READ_WRITE> RepeatCount;
    vtexProperty <LibPlatformAlarm, double, READ_WRITE> TimeSeconds;
    vtexProperty <LibPlatformAlarm, double, READ_WRITE> TimeFraction;
};

class LibPlatformArmSource
{
public:
    virtual ~LibPlatformArmSource() {};

    virtual VTEXResult Configure(bool enabled, VTEXPlatformArmSourceDetectionEnum detection) = 0;

    virtual VTEXResult get_Detection(VTEXPlatformArmSourceDetectionEnum &val) = 0;
    virtual VTEXResult put_Detection(VTEXPlatformArmSourceDetectionEnum val) = 0;
    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Filter(std::string &val) = 0;
    virtual VTEXResult put_Filter(std::string val) = 0;
    virtual VTEXResult get_EventId(std::string &val) = 0;
    virtual VTEXResult put_EventId(std::string val) = 0;

    vtexProperty <LibPlatformArmSource, VTEXPlatformArmSourceDetectionEnum, READ_WRITE> Detection;
    vtexProperty <LibPlatformArmSource, bool, READ_WRITE> Enabled;
    vtexProperty <LibPlatformArmSource, std::string, READ_WRITE> EventId;
    vtexProperty <LibPlatformArmSource, std::string, READ_WRITE> Filter;
};

class LibPlatformArmSources
{
public:
    virtual ~LibPlatformArmSources() {};

    virtual VTEXResult DisableAll() = 0;

    virtual LibPlatformArmSource* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibPlatformArmSources, int32_t, READ_ONLY> Count;
    arrayizer <LibPlatformArmSources, LibPlatformArmSource*, std::string> Item;
    arrayizer <LibPlatformArmSources, std::string, int32_t> Name;
};

class LibPlatformArm
{
public:
    virtual ~LibPlatformArm() {};

    LibPlatformArmSources* Sources;

    virtual VTEXResult SendSoftwareArm() = 0;

    virtual VTEXResult get_Lines(std::string &val) = 0;
    virtual VTEXResult put_Lines(std::string val) = 0;

    vtexProperty <LibPlatformArm, std::string, READ_WRITE> Lines;
};

class LibPlatformLine
{
public:
    virtual ~LibPlatformLine() {};

    virtual VTEXResult get_Reserved(bool &val) = 0;
    virtual VTEXResult put_Reserved(bool val) = 0;

    vtexProperty <LibPlatformLine, bool, READ_WRITE> Reserved;
};

class LibPlatformLines
{
public:
    virtual ~LibPlatformLines() {};

    virtual LibPlatformLine* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibPlatformLines, int32_t, READ_ONLY> Count;
    arrayizer <LibPlatformLines, LibPlatformLine*, std::string> Item;
    arrayizer <LibPlatformLines, std::string, int32_t> Name;
};

class LibPlatformBus
{
public:
    virtual ~LibPlatformBus() {};

    LibPlatformLines* Lines;
};

class LibPlatformBuss
{
public:
    virtual ~LibPlatformBuss() {};

    virtual LibPlatformBus* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibPlatformBuss, int32_t, READ_ONLY> Count;
    arrayizer <LibPlatformBuss, LibPlatformBus*, std::string> Item;
    arrayizer <LibPlatformBuss, std::string, int32_t> Name;
};

class LibPlatformFan
{
public:
    virtual ~LibPlatformFan() {};

    virtual VTEXResult get_MaxPWMDutyCycle(double &val) = 0;
    virtual VTEXResult put_MaxPWMDutyCycle(double val) = 0;
    virtual VTEXResult get_MinPWMDutyCycle(double &val) = 0;
    virtual VTEXResult put_MinPWMDutyCycle(double val) = 0;
    virtual VTEXResult get_Speed(double &val) = 0;
    virtual VTEXResult get_SpeedLimit(double &val) = 0;
    virtual VTEXResult put_SpeedLimit(double val) = 0;
    virtual VTEXResult get_SpeedMode(VTEXPlatformFanSpeedModeEnum &val) = 0;
    virtual VTEXResult put_SpeedMode(VTEXPlatformFanSpeedModeEnum val) = 0;
    virtual VTEXResult get_SpeedTarget(double &val) = 0;
    virtual VTEXResult put_SpeedTarget(double val) = 0;

    vtexProperty <LibPlatformFan, double, READ_WRITE> MaxPWMDutyCycle;
    vtexProperty <LibPlatformFan, double, READ_WRITE> MinPWMDutyCycle;
    vtexProperty <LibPlatformFan, double, READ_ONLY> Speed;
    vtexProperty <LibPlatformFan, double, READ_WRITE> SpeedLimit;
    vtexProperty <LibPlatformFan, VTEXPlatformFanSpeedModeEnum, READ_WRITE> SpeedMode;
    vtexProperty <LibPlatformFan, double, READ_WRITE> SpeedTarget;
};

class LibPlatformFans
{
public:
    virtual ~LibPlatformFans() {};

    virtual LibPlatformFan* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibPlatformFans, int32_t, READ_ONLY> Count;
    arrayizer <LibPlatformFans, LibPlatformFan*, std::string> Item;
    arrayizer <LibPlatformFans, std::string, int32_t> Name;
};

class LibPlatformPowerLine
{
public:
    virtual ~LibPlatformPowerLine() {};

    virtual VTEXResult get_Voltage(double &val) = 0;
    virtual VTEXResult get_VoltageLimit(double &val) = 0;
    virtual VTEXResult put_VoltageLimit(double val) = 0;
    virtual VTEXResult get_VoltageTarget(double &val) = 0;
    virtual VTEXResult put_VoltageTarget(double val) = 0;
    virtual VTEXResult get_Current(double &val) = 0;

    vtexProperty <LibPlatformPowerLine, double, READ_ONLY> Voltage;
    vtexProperty <LibPlatformPowerLine, double, READ_WRITE> VoltageLimit;
    vtexProperty <LibPlatformPowerLine, double, READ_WRITE> VoltageTarget;
    vtexProperty <LibPlatformPowerLine, double, READ_ONLY> Current;
};

class LibPlatformPowerLines
{
public:
    virtual ~LibPlatformPowerLines() {};

    virtual LibPlatformPowerLine* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibPlatformPowerLines, int32_t, READ_ONLY> Count;
    arrayizer <LibPlatformPowerLines, LibPlatformPowerLine*, std::string> Item;
    arrayizer <LibPlatformPowerLines, std::string, int32_t> Name;
};

class LibPlatformRoute
{
public:
    virtual ~LibPlatformRoute() {};

    virtual VTEXResult get_DestinationBus(std::string &val) = 0;
    virtual VTEXResult get_DestinationLine(std::string &val) = 0;
    virtual VTEXResult get_SourceBus(std::string &val) = 0;
    virtual VTEXResult get_SourceLine(std::string &val) = 0;

    vtexProperty <LibPlatformRoute, std::string, READ_ONLY> DestinationBus;
    vtexProperty <LibPlatformRoute, std::string, READ_ONLY> DestinationLine;
    vtexProperty <LibPlatformRoute, std::string, READ_ONLY> SourceBus;
    vtexProperty <LibPlatformRoute, std::string, READ_ONLY> SourceLine;
};

class LibPlatformRoutes
{
public:
    virtual ~LibPlatformRoutes() {};

    virtual VTEXResult Add(std::string route_name,
        std::string source_bus, std::string destination_bus,
        std::string source_line, std::string destination_line) = 0;
    virtual VTEXResult Remove(std::string route_name) = 0;
    virtual VTEXResult RemoveAll() = 0;

    virtual LibPlatformRoute* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibPlatformRoutes, int32_t, READ_ONLY> Count;
    arrayizer <LibPlatformRoutes, LibPlatformRoute*, std::string> Item;
    arrayizer <LibPlatformRoutes, std::string, int32_t> Name;
};

class LibPlatformSlot
{
public:
    virtual ~LibPlatformSlot() {};

    virtual VTEXResult get_FirmwareRevision(std::string &val) = 0;
    virtual VTEXResult get_Model(std::string &val) = 0;
    virtual VTEXResult get_SerialNumber(std::string &val) = 0;
    virtual VTEXResult get_Type(VTEXPlatformSlotTypeEnum &val) = 0;
    virtual VTEXResult get_Vendor(std::string &val) = 0;

    vtexProperty <LibPlatformSlot, std::string, READ_ONLY> FirmwareRevision;
    vtexProperty <LibPlatformSlot, std::string, READ_ONLY> Model;
    vtexProperty <LibPlatformSlot, std::string, READ_ONLY> SerialNumber;
    vtexProperty <LibPlatformSlot, VTEXPlatformSlotTypeEnum, READ_ONLY> Type;
    vtexProperty <LibPlatformSlot, std::string, READ_ONLY> Vendor;
};

class LibPlatformSlots
{
public:
    virtual ~LibPlatformSlots() {};

    virtual LibPlatformSlot* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibPlatformSlots, int32_t, READ_ONLY> Count;
    arrayizer <LibPlatformSlots, LibPlatformSlot*, std::string> Item;
    arrayizer <LibPlatformSlots, std::string, int32_t> Name;
};

class LibPlatformTemperature
{
public:
    virtual ~LibPlatformTemperature() {};

    virtual VTEXResult get_Limit(double &val) = 0;
    virtual VTEXResult put_Limit(double val) = 0;
    virtual VTEXResult get_Target(double &val) = 0;
    virtual VTEXResult put_Target(double val) = 0;
    virtual VTEXResult get_Temperature(double &val) = 0;

    vtexProperty <LibPlatformTemperature, double, READ_WRITE> Limit;
    vtexProperty <LibPlatformTemperature, double, READ_WRITE> Target;
    vtexProperty <LibPlatformTemperature, double, READ_ONLY> Temperature;
};

class LibPlatformTemperatures
{
public:
    virtual ~LibPlatformTemperatures() {};

    virtual LibPlatformTemperature* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibPlatformTemperatures, int32_t, READ_ONLY> Count;
    arrayizer <LibPlatformTemperatures, LibPlatformTemperature*, std::string> Item;
    arrayizer <LibPlatformTemperatures, std::string, int32_t> Name;
};

class LibPlatformChassis
{
public:
    virtual ~LibPlatformChassis() {};

    LibPlatformBuss* Buss;
    LibPlatformFans* Fans;
    LibPlatformPowerLines* PowerLines;
    LibPlatformRoutes* Routes;
    LibPlatformSlots* Slots;
    LibPlatformTemperatures* Temperatures;

    virtual VTEXResult SMBusOperation(std::string name, std::string address_info,
        VTEXPlatformSMBusProtocolEnum protocol, int32_t address, int32_t command,
        bool packet_error_code, std::string write_buffer, std::string &read_buffer) = 0;
    virtual VTEXResult GetEeprom(std::string name, std::string address_info, std::string &eeprom) = 0;

    virtual VTEXResult get_BackplaneSerialNumber(std::string &val) = 0;
    virtual VTEXResult get_CoolingAirDetected(bool &val) = 0;
    virtual VTEXResult get_FirmwareRevision(std::string &val) = 0;
    virtual VTEXResult get_LinkConfiguration(VTEXPlatformLinkConfigurationEnum &val) = 0;
    virtual VTEXResult put_LinkConfiguration(VTEXPlatformLinkConfigurationEnum val) = 0;
    virtual VTEXResult get_Model(std::string &val) = 0;
    virtual VTEXResult get_RemoteInhibit(bool &val) = 0;
    virtual VTEXResult put_RemoteInhibit(bool val) = 0;
    virtual VTEXResult get_Revision(std::string &val) = 0;
    virtual VTEXResult get_SerialNumber(std::string &val) = 0;
    virtual VTEXResult get_Vendor(std::string &val) = 0;

    vtexProperty <LibPlatformChassis, std::string, READ_ONLY> BackplaneSerialNumber;
    vtexProperty <LibPlatformChassis, bool, READ_ONLY> CoolingAirDetected;
    vtexProperty <LibPlatformChassis, std::string, READ_ONLY> FirmwareRevision;
    vtexProperty <LibPlatformChassis, VTEXPlatformLinkConfigurationEnum, READ_WRITE> LinkConfiguration;
    vtexProperty <LibPlatformChassis, std::string, READ_ONLY> Model;
    vtexProperty <LibPlatformChassis, bool, READ_WRITE> RemoteInhibit;
    vtexProperty <LibPlatformChassis, std::string, READ_ONLY> Revision;
    vtexProperty <LibPlatformChassis, std::string, READ_ONLY> SerialNumber;
    vtexProperty <LibPlatformChassis, std::string, READ_ONLY> Vendor;
};

class LibPlatformChassiss
{
public:
    virtual ~LibPlatformChassiss() {};

    virtual LibPlatformChassis* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibPlatformChassiss, int32_t, READ_ONLY> Count;
    arrayizer <LibPlatformChassiss, LibPlatformChassis*, std::string> Item;
    arrayizer <LibPlatformChassiss, std::string, int32_t> Name;
};

class LibPlatformEventLog
{
public:
    virtual ~LibPlatformEventLog() {};

    virtual VTEXResult Clear() = 0;
    virtual std::string GetNextEntry() = 0;

    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_EntryCount(int32_t &val) = 0;
    virtual VTEXResult get_OverflowMode(VTEXPlatformEventLogOverflowModeEnum &val) = 0;
    virtual VTEXResult put_OverflowMode(VTEXPlatformEventLogOverflowModeEnum val) = 0;

    vtexProperty <LibPlatformEventLog, bool, READ_WRITE> Enabled;
    vtexProperty <LibPlatformEventLog, int32_t, READ_ONLY> EntryCount;
    vtexProperty <LibPlatformEventLog, VTEXPlatformEventLogOverflowModeEnum, READ_WRITE> OverflowMode;
};

class LibPlatformEvent
{
public:
    virtual ~LibPlatformEvent() {};

    virtual VTEXResult Configure(VTEXPlatformEventDriveModeEnum drive_mode,
                                 std::string source,
                                 std::string destination_path,
                                 VTEXPlatformSourceSlopeEnum slope) = 0;

    virtual VTEXResult get_DestinationPath(std::string &val) = 0;
    virtual VTEXResult put_DestinationPath(std::string val) = 0;
    virtual VTEXResult get_DriveMode(VTEXPlatformEventDriveModeEnum &val) = 0;
    virtual VTEXResult put_DriveMode(VTEXPlatformEventDriveModeEnum val) = 0;
    virtual VTEXResult get_Slope(VTEXPlatformSourceSlopeEnum &val) = 0;
    virtual VTEXResult put_Slope(VTEXPlatformSourceSlopeEnum val) = 0;
    virtual VTEXResult get_Source(std::string &val) = 0;
    virtual VTEXResult put_Source(std::string val) = 0;

    vtexProperty <LibPlatformEvent, std::string, READ_WRITE> DestinationPath;
    vtexProperty <LibPlatformEvent, VTEXPlatformEventDriveModeEnum, READ_WRITE> DriveMode;
    vtexProperty <LibPlatformEvent, VTEXPlatformSourceSlopeEnum, READ_WRITE> Slope;
    vtexProperty <LibPlatformEvent, std::string, READ_WRITE> Source;
};

class LibPlatformEvents
{
public:
    virtual ~LibPlatformEvents() {};

    virtual VTEXResult DisableAll() = 0;

    virtual LibPlatformEvent* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;
    
    virtual VTEXResult get_ListOfSources(std::string &val) = 0;
    virtual VTEXResult get_WiredOrBiasMode(int32_t &val) = 0;
    virtual VTEXResult put_WiredOrBiasMode(int32_t val) = 0;
    virtual VTEXResult SendSoftwareEvent(std::string DestinationPath, VTEXPlatformSourceSlopeEnum Slope, double TimeSeconds, double TimeFraction) = 0;

    vtexProperty <LibPlatformEvents, int32_t, READ_ONLY> Count;
    arrayizer <LibPlatformEvents, LibPlatformEvent*, std::string>Item;
    arrayizer <LibPlatformEvents, std::string, int32_t>Name;

    vtexProperty <LibPlatformEvents, std::string, READ_ONLY> ListOfSources;
    vtexProperty <LibPlatformEvents, int32_t, READ_WRITE> WiredOrBiasMode;
};

class LibPlatformTime
{
public:
    virtual ~LibPlatformTime() {};

    virtual VTEXResult GetSystemTime(double &seconds, double &fraction) = 0;
    virtual VTEXResult SetSystemTime(double seconds, double fraction) = 0;

    virtual VTEXResult get_AverageOffsetFromMaster(double &val) = 0;
    virtual VTEXResult get_IsMaster(bool &val) = 0;
    virtual VTEXResult get_IsSynchronized(bool &val) = 0;
    virtual VTEXResult get_OffsetFromMaster(double &val) = 0;
    virtual VTEXResult get_PTPDomain(int32_t &val) = 0;
    virtual VTEXResult put_PTPDomain(int32_t val) = 0;
    virtual VTEXResult get_SyncThreshold(int32_t &val) = 0;
    virtual VTEXResult put_SyncThreshold(int32_t val) = 0;
    virtual VTEXResult get_SystemTimeSource(VTEXPlatformSystemTimeSourceEnum &val) = 0;
    virtual VTEXResult get_UTCOffset(int32_t &val) = 0;

    vtexProperty <LibPlatformTime, double, READ_ONLY> AverageOffsetFromMaster;
    vtexProperty <LibPlatformTime, bool, READ_ONLY> IsMaster;
    vtexProperty <LibPlatformTime, bool, READ_ONLY> IsSynchronized;
    vtexProperty <LibPlatformTime, double, READ_ONLY> OffsetFromMaster;
    vtexProperty <LibPlatformTime, int32_t, READ_WRITE> PTPDomain;
    vtexProperty <LibPlatformTime, int32_t, READ_WRITE> SyncThreshold;
    vtexProperty <LibPlatformTime, VTEXPlatformSystemTimeSourceEnum, READ_ONLY> SystemTimeSource;
    vtexProperty <LibPlatformTime, int32_t, READ_ONLY> UTCOffset;
};

class LibPlatformTriggerSource
{
public:
    virtual ~LibPlatformTriggerSource() {};

    virtual VTEXResult Configure(double delay, VTEXPlatformTriggerSourceDetectionEnum detection) = 0;

    virtual VTEXResult get_Delay(double &val) = 0;
    virtual VTEXResult put_Delay(double val) = 0;
    virtual VTEXResult get_Detection(VTEXPlatformTriggerSourceDetectionEnum &val) = 0;
    virtual VTEXResult put_Detection(VTEXPlatformTriggerSourceDetectionEnum val) = 0;
    virtual VTEXResult get_EventId(std::string &val) = 0;
    virtual VTEXResult put_EventId(std::string val) = 0;
    virtual VTEXResult get_Filter(std::string &val) = 0;
    virtual VTEXResult put_Filter(std::string val) = 0;

    vtexProperty <LibPlatformTriggerSource, double, READ_WRITE> Delay;
    vtexProperty <LibPlatformTriggerSource, VTEXPlatformTriggerSourceDetectionEnum, READ_WRITE> Detection;
    vtexProperty <LibPlatformTriggerSource, std::string, READ_WRITE> EventId;
    vtexProperty <LibPlatformTriggerSource, std::string, READ_WRITE> Filter;
};

class LibPlatformTriggerSources
{
public:
    virtual ~LibPlatformTriggerSources() {};

    virtual LibPlatformTriggerSource* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibPlatformTriggerSources, int32_t, READ_ONLY> Count;
    arrayizer <LibPlatformTriggerSources, LibPlatformTriggerSource*, std::string>Item;
    arrayizer <LibPlatformTriggerSources, std::string, int32_t>Name;
};

class LibPlatformTrigger
{
public:
    virtual ~LibPlatformTrigger() {};

    LibPlatformTriggerSources* Sources;

    virtual VTEXResult SendSoftwareTrigger() = 0;

    virtual VTEXResult get_Lines(std::string &val) = 0;
    virtual VTEXResult put_Lines(std::string val) = 0;
    virtual VTEXResult get_TriggerSource(std::string &val) = 0;
    virtual VTEXResult put_TriggerSource(std::string val) = 0;

    vtexProperty <LibPlatformTrigger, std::string, READ_WRITE> Lines;
    vtexProperty <LibPlatformTrigger, std::string, READ_WRITE> TriggerSource;
};

class LibPlatformBoardTemperature
{
public:
    virtual ~LibPlatformBoardTemperature() {};

    virtual VTEXResult get_BoardTemperature(double &val) = 0;
    virtual VTEXResult get_Units(VTEXPlatformTemperatureUnitsEnum &val) = 0;
    virtual VTEXResult put_Units(VTEXPlatformTemperatureUnitsEnum val) = 0;

    vtexProperty <LibPlatformBoardTemperature, double, READ_ONLY> BoardTemperature;
    vtexProperty <LibPlatformBoardTemperature, VTEXPlatformTemperatureUnitsEnum, READ_WRITE> Units;
};

class LibPlatform : public vtexInherent
{
public:
    static LibPlatform* Create();
    virtual ~LibPlatform() {};

    // Inherent
    vtexInherentCapabilityDriverOperation* DriverOperation;
    vtexInherentCapabilityIdentity* Identity;
    vtexInherentCapabilityUtility* Utility;

    vtexProperty <LibPlatform, bool, READ_ONLY> Initialized;

    LibPlatformAlarm* Alarm;
    LibPlatformArm* Arm;
    LibPlatformChassiss* Chassiss;
    LibPlatformEventLog* EventLog;
    LibPlatformEvents* Events;
    LibPlatformBoardTemperature* Temperature;
    LibPlatformTime* Time;
    LibPlatformTrigger* Trigger;

    virtual VTEXResult get_LXIDomain(int32_t &val) = 0;
    virtual VTEXResult put_LXIDomain(int32_t val) = 0;
    virtual VTEXResult get_SerialNumber(std::string &val) = 0;

    vtexProperty <LibPlatform, int32_t, READ_WRITE> LXIDomain;
    vtexProperty <LibPlatform, std::string, READ_ONLY> SerialNumber;
};

#endif    /* _libPlatform_H */
