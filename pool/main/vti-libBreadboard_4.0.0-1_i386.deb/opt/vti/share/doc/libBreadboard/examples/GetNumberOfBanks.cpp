//This example is get the number of banks in the board

#include <iostream>
#include <vector>
#include "libBreadboard.h"

using namespace std;

int main(int argc, char* argv[])
{
    try
    {
        LibBreadboard* breadboard = NULL;
        /*We want to do the Initialization in a try/catch block so that our test code
        doesn't run if we fail to create.*/
        breadboard = LibBreadboard::Create();

        try
        {
            /*We chose to give the driver an empty options string. You may want to 
            give your driver options - check the manual to see the available settings.
            Note that we also set the Reset bit so that we get a clean start to work 
            from.*/
            breadboard->Initialize("TCPIP::10.30.1.109::INSTR", true, true, "");

            // Get the number of banks available in the board
            int32_t numBanks = breadboard->IO->Banks->Count;
            cout<<"Number of Banks: "<<numBanks<<endl;

            //Close the initialized session
            breadboard->Close();
        }
        catch (VTEXException e)
        {
            cout<<"Error code: \t"<<e.errorCode<<endl;
            cout<<"Error message: \n"<<e.errorMessage.c_str()<<endl;
        }
    }
    catch (...)
    {
        /*We put this here to catch any error the program generates.*/
        //Do something to intelligently deal with errors
    }

    return 0;
}
