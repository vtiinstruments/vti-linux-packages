#include "exErrors.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#if defined(_WIN32) && !defined(_CVI_)
#define INLINE __inline
#else
#define INLINE inline
#endif

#ifdef __cplusplus
extern "C" {
#endif

 //!
 //! @file
 //!
 //! Breadboard constants
 //!
#ifndef _BreadboardConstants_H
#define _BreadboardConstants_H

enum VTEXBreadboardIOBankDirectionEnum
{
  VTEXBreadboardIOBankDirectionInput = 1000,
  VTEXBreadboardIOBankDirectionOutput = 1001
};

enum VTEXBreadboardIOBankPolarityEnum
{
  VTEXBreadboardIOBankPolarityNormal = 1000,
  VTEXBreadboardIOBankPolarityInverse = 1001
};

enum VTEXBreadboardDmmMeasurementModeEnum
{
  VTEXBreadboardDmmMeasurementModeNone = 1000,
  VTEXBreadboardDmmMeasurementModeVoltage = 1001,
  VTEXBreadboardDmmMeasurementModeCurrent = 1002,
  VTEXBreadboardDmmMeasurementMode4WResistance = 1003
};

enum VTEXBreadboardTriggerInputEnum
{
  VTEXBreadboardTriggerInputNone = 1000,
  VTEXBreadboardTriggerInputBPL0 = 1001,
  VTEXBreadboardTriggerInputBPL1 = 1002,
  VTEXBreadboardTriggerInputBPL2 = 1003,
  VTEXBreadboardTriggerInputBPL3 = 1004,
  VTEXBreadboardTriggerInputBPL4 = 1005,
  VTEXBreadboardTriggerInputBPL5 = 1006,
  VTEXBreadboardTriggerInputBPL6 = 1007,
  VTEXBreadboardTriggerInputBPL7 = 1008
};

enum VTEXBreadboardTriggerOutputEnum
{
  VTEXBreadboardTriggerOutputNone = 1000,
  VTEXBreadboardTriggerOutputSoftware = 1001,
  VTEXBreadboardTriggerOutputBPL0 = 1002,
  VTEXBreadboardTriggerOutputBPL1 = 1003,
  VTEXBreadboardTriggerOutputBPL2 = 1004,
  VTEXBreadboardTriggerOutputBPL3 = 1005,
  VTEXBreadboardTriggerOutputBPL4 = 1006,
  VTEXBreadboardTriggerOutputBPL5 = 1007,
  VTEXBreadboardTriggerOutputBPL6 = 1008,
  VTEXBreadboardTriggerOutputBPL7 = 1009
};
#endif /* ! _BreadboardConstants_H */

#ifdef  __cplusplus
}
#endif

