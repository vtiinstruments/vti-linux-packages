/******************************************************************************
 *
 *  .----------------------.    
 *  |==     ==  ======  == |    $Author$
 *  | ==   ==   ======  == |    $Revision$ 
 *  |  == ==      ==    == |    $Date$ 
 *  |   ===       ==    == |    $HeadURL$
 *  |    =        ==    == |    
 *  `----------------------'
 *
 * Copyright 2006 VXI Technology Inc. as an unpublished work. 
 * All rights reserved. The information contained herein is confidential
 * property of VXI Technology, Inc. Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement 
 * with VXI Technology, Inc.
 *
 * PURPOSE: 
 *   Class definition of the LibBreadboard class
 *
 ******************************************************************************/

#ifndef _LIB_BB_H
#define _LIB_BB_H

/* System Header */
#include <vector>

/* Local Header */
#include "vtexapi.h"
#include "vtexException.h"
#include "libInherent.h"
#include "CommonErrors.h"
#include "BreadboardErrors.h"

#ifndef _ATL_ATTRIBUTES
#include "BreadboardConstants.h"
#endif

class VTEX_API LibBreadboardIOBank
{
    public:
        virtual ~LibBreadboardIOBank() {};

        // Properties
        property <LibBreadboardIOBank, bool, READ_WRITE> Enabled;
        property <LibBreadboardIOBank, int32_t, READ_WRITE> Data;
        property <LibBreadboardIOBank, int32_t, READ_WRITE> ResetData;
        property <LibBreadboardIOBank, VTEXBreadboardIOBankDirectionEnum, READ_WRITE> Direction;
        property <LibBreadboardIOBank, VTEXBreadboardIOBankPolarityEnum, READ_WRITE> Polarity;

        // Property methods
        virtual VTEXResult put_Enabled(bool enable) = 0;
        virtual VTEXResult get_Enabled(bool* enable) = 0;
        virtual VTEXResult put_Data(int32_t data) = 0;
        virtual VTEXResult get_Data(int32_t* data) = 0;
        virtual VTEXResult put_ResetData(int32_t data) = 0;
        virtual VTEXResult get_ResetData(int32_t* data) = 0;
        virtual VTEXResult put_Direction(VTEXBreadboardIOBankDirectionEnum direction) = 0;
        virtual VTEXResult get_Direction(VTEXBreadboardIOBankDirectionEnum* direction) = 0;
        virtual VTEXResult put_Polarity(VTEXBreadboardIOBankPolarityEnum polarity) = 0;
        virtual VTEXResult get_Polarity(VTEXBreadboardIOBankPolarityEnum* polarity) = 0;

        virtual VTEXResult ConfigureBank(bool enabled,VTEXBreadboardIOBankDirectionEnum direction,
                                        VTEXBreadboardIOBankPolarityEnum polarity) = 0;
};

class VTEX_API LibBreadboardIOBanks
{
    public:
        virtual ~LibBreadboardIOBanks() {};

        // Properties
        property <LibBreadboardIOBanks, int32_t, READ_ONLY> Count;
        arrayizer <LibBreadboardIOBanks, LibBreadboardIOBank*, const std::string&> Item;
        arrayizer <LibBreadboardIOBanks, std::string, int32_t> Name;

        // Property methods
        virtual LibBreadboardIOBank *get_Item(const std::string& Name) = 0;
        virtual std::string get_Name(int32_t Index) = 0;
        virtual VTEXResult get_Count(int32_t* count) = 0;
};

class VTEX_API LibBreadboardIO
{
    public:
        virtual ~LibBreadboardIO() {};

        LibBreadboardIOBanks * Banks;

        // Properties
        property <LibBreadboardIO, bool, READ_WRITE> ClockOutputEnabled;
        property <LibBreadboardIO, bool, READ_WRITE> DmmConnectionEnabled;
        property <LibBreadboardIO, VTEXBreadboardDmmMeasurementModeEnum, READ_WRITE> DmmMeasurementMode;

        // Property methods
        virtual VTEXResult put_ClockOutputEnabled(bool clockEnable) = 0;
        virtual VTEXResult get_ClockOutputEnabled(bool* clockEnable) = 0;
        virtual VTEXResult put_DmmConnectionEnabled(bool dmmConnectionEnable) = 0;
        virtual VTEXResult get_DmmConnectionEnabled(bool* dmmConnectionEnable) = 0;
        virtual VTEXResult put_DmmMeasurementMode(VTEXBreadboardDmmMeasurementModeEnum dmmMeasurementMode) = 0;
        virtual VTEXResult get_DmmMeasurementMode(VTEXBreadboardDmmMeasurementModeEnum* dmmMeasurementMode) = 0;
        virtual VTEXResult ConfigureDmm(bool dmmConnectionEnabled, VTEXBreadboardDmmMeasurementModeEnum dmmMeasurementMode) = 0;
        virtual VTEXResult SaveResetData() = 0;
};

class VTEX_API LibBreadboardTrigger
{
    public:
        virtual ~LibBreadboardTrigger() {};

        // Methods
        virtual VTEXResult SendSoftwareTrigger(void) = 0;

        // Properties
        property <LibBreadboardTrigger, VTEXBreadboardTriggerInputEnum, READ_WRITE> Input;
        property <LibBreadboardTrigger, VTEXBreadboardTriggerOutputEnum, READ_WRITE> Output;

        // Property methods
        virtual VTEXResult put_Input(VTEXBreadboardTriggerInputEnum input) = 0;
        virtual VTEXResult get_Input(VTEXBreadboardTriggerInputEnum* input) = 0;
        virtual VTEXResult put_Output(VTEXBreadboardTriggerOutputEnum output) = 0;
        virtual VTEXResult get_Output(VTEXBreadboardTriggerOutputEnum* output) = 0;
};

class VTEX_API LibBreadboardPlatform
{
    public:
        virtual ~LibBreadboardPlatform() {};

        // Properties
        property <LibBreadboardPlatform, VTEXString, READ_ONLY> SerialNumber;
        property <LibBreadboardPlatform, VTEXString, READ_WRITE> ModelSuffix;

        // Property methods
        virtual VTEXResult get_SerialNumber(VTEXString *serial) = 0;
        virtual VTEXResult put_ModelSuffix(const VTEXString &model) = 0;
        virtual VTEXResult get_ModelSuffix(VTEXString *model) = 0;
        virtual VTEXResult CloseLogFile() = 0;
        virtual VTEXResult OpenLogFile(const VTEXString& fileName, const VTEXString& accessMode) = 0;
};

class VTEX_API LibBreadboard : public LibInherent
{
    public:
        static LibBreadboard* Create();
        virtual ~LibBreadboard();

        property <LibBreadboard, bool, READ_ONLY> Initialized;
        LibInherentCapabilityUtility *Utility;
        LibInherentCapabilityDriverOperation *DriverOperation;
        LibInherentCapabilityIdentity *Identity;

        LibBreadboardIO *IO;
        LibBreadboardTrigger *Trigger;
        LibBreadboardPlatform *Platform;
};


#endif