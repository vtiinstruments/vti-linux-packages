#include "exErrors.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#if defined(_WIN32) && !defined(_CVI_)
#define INLINE __inline
#else
#define INLINE inline
#endif

#ifdef __cplusplus
extern "C" {
#endif

 //!
 //! @file
 //!
 //! Breadboard Error Codes
 //!

#ifndef _BreadboardErrors_H
#define _BreadboardErrors_H

 //! IVI Breadboard errors.
#define IVIBREADBOARD_E_BASE 0x800a0000

 //! IVI Breadboard warnings.
#define IVIBREADBOARD_W_BASE 0xa0000

 //! Driver errors.
#define VTEXBREADBOARD_E_BASE 0x800a4000
#define VTEXBREADBOARD_E_UNKNOWN_BANK_NAME 0x800a4001

 //! Driver warnings.
#define VTEXBREADBOARD_W_BASE 0xa4000

 //! Device errors.
#define FWBREADBOARD_E_BASE 0x800a8000
#define FWBREADBOARD_E_NULL_POINTER_ARGUMENT 0x800a8001
#define FWBREADBOARD_E_INVALID_BANK_NUMBER 0x800a8002
#define FWBREADBOARD_E_INTERNAL_ERROR 0x800a8003
#define FWBREADBOARD_E_BAD_DCF 0x800a8004
#define FWBREADBOARD_E_BAD_RESET_FILE 0x800a8005
#define FWBREADBOARD_E_INVALID_TRIGGER_ASSIGNMENT 0x800a8006
#define FWBREADBOARD_E_TRIGGER_OUTPUT_NOT_SOFTWARE 0x800a8007
#define FWBREADBOARD_E_MEM_ALLOC_FAILED 0x800a8008

 //! Device warnings.
#define FWBREADBOARD_W_BASE 0xa8000



#endif /* ! _BreadboardErrors_H */

#ifdef  __cplusplus
}
#endif

