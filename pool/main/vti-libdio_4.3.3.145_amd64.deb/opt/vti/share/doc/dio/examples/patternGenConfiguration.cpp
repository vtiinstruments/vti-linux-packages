// Recommended Previous Example: PortConfiguration
#include "libDio.h"
#include "stdlib.h"
#include <stdio.h>

int main()
{
  //Linux driver pointer
  LibDio* Dio;
  try
  {
     Dio = LibDio::Create();

    /*We chose to give this driver an empty options string. If you have more than one DIO card in 
      your chassis, you will have to give it options such as a slot number. This is because the DIO
      driver does not support more than one card per driver instance. Note also that we set the reset
      flag so that we can get a clean start with the unit */
    Dio->Initialize("TCPIP::10.20.1.5::INSTR", true, true, "");

	/* Now we need to switch the card into Pattern mode */

	Dio->Mode = VTEXDioModePattern;

	/*Now that the card is in pattern mode we can change the common settings, including the PatternMode
	property. Changing this property to Pattern Generation only doubles the size of each pattern we can
	store, since we will not be sharing the memory with the Pattern Acquisition fifo. We can also change
	the pattern clock source and frequency. Note that the pattern clock is also shared with Pattern 
	Acquisition. */

	Dio->Pattern->PatternMode = VTEXDioPatternModeGeneration;
	//After we change the clock mode to external below, changing the frequency will have no effect.
	Dio->Pattern->ClockSource = VTEXDioClockSourceExternal;
    
	/* Now we can change the settings for Pattern Generation, including the standard voltage settings that 
	   we have seen in Normal mode. Pattern Generation mode supports only the 3.3 and 5V TTL emulation modes,
	   but because using the enum values -1.0 and -2.0 is unintuitive, the values 3.3 and 5.0 will produce
	   the same effect. */
	Dio->Pattern->Output->VoltageRange = 5.0;
	Dio->Pattern->Output->Polarity = VTEXDioPolarityInverse;

	/* Since we're not just passively taking data in Pattern Generation, we must set up the pattern we want
	   to output before we Initiate. To do this, we use a property called MaxPatterns, which describes how
	   many patterns we would like to keep in memory at once, and a function called CreatePattern, which
	   allows us to submit patterns to the device. Once we set MaxPatterns and the card's PatternMode 
	   properties correctly, a convenience property called MaxPatternLength will tell us how many integers
	   long a pattern can be. The utility of this will become clearer as we go along. */

	/*MaxPatterns is the divisor for memory size. It can be between 1-512. It is also a power of 2, and will
	  be coerced to the next highest power of 2 if a power of 2 is not chosen. */
	Dio->Pattern->Output->MaxPatterns = 128;

	/* The maximum size of each pattern is now ((2MB / 4 bytes per 32bit integer) / MaxPatterns). Because this
	   is difficult to calculate, and may be different for different cards, we have this convenience property */

	int maxsize = Dio->Pattern->Output->MaxPatternLength;
	
	std::vector<int32_t> Data;
	/*Here we are creating a maximum size pattern. Our pattern could consist of any number of states up to
	  maxsize, but for a quick example we are going to make one of full length */
	for(long i=0; i<maxsize; i++)
	{
		/* To create a pattern, we're simply going to use random numbers. In reality, pattern data is a 
		binary representation of the state of the 4 ports (on a 1200-7500), so the full range of positive 
		and negative numbers in a 32-bit integer is used to express the port state. */
		Data.push_back(random());
	}
	
	//Now that we have created a pattern, let's send it to the unit. This pattern will be pattern 42.
	Dio->Pattern->Output->CreatePattern(42, Data);

	/*Once we have created a pattern, we should select it so that the card is set to output it. */
	Dio->Pattern->Output->CurrentPattern = 42;

	/*Now that we have selected our pattern we can enter the trigger model and output it. As in the Pattern
	Acquisition example code, we will not deal with the complexities of the trigger model as those are dealt
	with in other examples. */

	Dio->Pattern->Output->TriggerSource = VTEXDioTriggerSourceBPL0;
	Dio->Pattern->Output->Initiate();
	
    //Now, some other test device must cause BPL0 to go high, or we will not start outputting.

	/* Here we actually have two options. We can call Abort, or we can wait for the entire pattern to be
	   output. If Loopback is set to Stop, the pattern will stop outputting and the device will transition
	   to the End State. If the Loopback is set to Overwrite, the pattern will repeat from the beginning 
	   whenever it ends, and Abort must be called. Calling Abort also sends the device to the End State. */

	Dio->Pattern->Output->Abort();
	
	/* Now that we have aborted, we can add more patterns or reconfigure the ports. */

	Dio->Close();

	delete Dio;
    Dio = nullptr;
  }
  catch(...)
  {
	  //Error handling goes here
  }
  return 0;
}
