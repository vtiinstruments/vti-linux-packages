#include "libDio.h"
#include <stdio.h>

int main()
{
  //Linux driver pointer creation
  LibDio* Dio;
  try
  {
          //Linux driver instantiation
	  Dio = LibDio::Create();

    /*We chose to give this driver an empty options string. If you have more than one DIO card in 
      your chassis, you will have to give it options such as a slot number. This is because the DIO
      driver does not support more than one card per driver instance. Note also that we set the reset
      flag so that we can get a clean start witht he unit */
    Dio->Initialize("TCPIP::10.20.1.5::INSTR", true, true, ""); 

	/*First we need to change the mode of the card to Pattern mode */

	Dio->Mode = VTEXDioModePattern;

	/*Now that we're in pattern mode, we can change the common pattern settings, including the pattern clock
	  and also the PatternMode property. We're going to set the latter to Pattern Acquisition only, so that
	  we don't have to share the Pattern Acquisition memory with Pattern Generation. */

	Dio->Pattern->PatternMode = VTEXDioPatternModeAcquisition;
	Dio->Pattern->ClockSource = VTEXDioClockSourceInternal;
	Dio->Pattern->InternalClockFrequency = 1.0; //This will be coerced to the lowest frequency we support

	/* Now that we have set up the common Pattern Mode settings, we can set up Pattern Acquisition. As with
       the Normal mode settings, we can change several settings including Polarity and VoltageRange. Unlike
	   Normal mode, if we change these settings they apply to all ports, not only one port. */

	//The Pattern Acquisition functionality only supports 3.3V and 5V non-TTL ranges, and the special value 0.
	Dio->Pattern->Input->VoltageRange = 5.0; 
	//A backplane line, the front panel pin, or software can be the trigger source
	Dio->Pattern->Input->TriggerSource = VTEXDioTriggerSourceBPL0;
	//This setting will stop the fifo from taking more data when it is full.
	Dio->Pattern->Input->LoopBack = VTEXDioFifoStop;
	
	/* Now that we have configured the Acquisition functionality, we need to enable it. The Initiate
	   function causes the card to enter the trigger model, and Abort forces an exit. For now, we will
	   ignore the Gate and Software Trigger functionalities as there are separate examples for these */

	Dio->Pattern->Input->Initiate();

	// Here is where another test device must cause the BPL0 line to go high - this will trigger our card.
    //After the line goes high, insert a sleep to allow us to accumulate some samples.

	Dio->Pattern->Input->Abort();

	/* Now we've taken some data, we need to read it back from the device. In Linux, we can do this with an
	   ordinary std::vector type. We don't need to include the header for this type because it's included in
	   libDio.h. We will give the Read function arguments to get back 100 pages of data with a timeout of 60 seconds*/

	std::vector<int32_t> Data; //Note that we expect this array to be empty when it is passed to Read.
	Dio->Pattern->Input->Read(100, 60000, Data);

	Dio->Close();

    delete Dio;
    Dio = nullptr;
  }
  catch(...)
  {
	  //Error handling here
  }
  return 0;
}
