//Recommended previous examples: PortConfiguration, PatternAcq/GenConfiguration, PatternModeGateConfiguration
#include "libDio.h"
#include <stdio.h>

int main()
{
  //Linux driver pointer
  LibDio* Dio;
  try
  {
       Dio = LibDio::Create();

    /*We chose to give this driver an empty options string. If you have more than one DIO card in 
      your chassis, you will have to give it options such as a slot number. This is because the DIO
      driver does not support more than one card per driver instance. Note also that we set the reset
      flag so that we can get a clean start with the unit */
    Dio->Initialize("TCPIP::10.20.1.5::INSTR", true, true, "");

	/* Here, we'll go ahead and set up the card so both Pattern Acquisition and Pattern Generation are
	   running at once. */

	Dio->Mode = VTEXDioModePattern;
	//Common pattern mode settings
	Dio->Pattern->PatternMode = VTEXDioPatternModeBoth;
	Dio->Pattern->ClockSource = VTEXDioClockSourceInternal;
	Dio->Pattern->InternalClockFrequency = 1.0; //This will be coerced to the lowest frequency we support
	//Pattern Input
	Dio->Pattern->Input->TriggerSource = VTEXDioTriggerSourceSwTrigFunc;
	Dio->Pattern->Input->VoltageRange = 5.0;
	Dio->Pattern->Input->LoopBack = VTEXDioFifoStop;
	//Pattern Output
	Dio->Pattern->Output->VoltageRange = 3.3;
	Dio->Pattern->Output->TriggerSource = VTEXDioTriggerSourceSwTrigFunc;
	Dio->Pattern->Output->MaxPatterns = 32;
	//Creating a pattern for Pattern Output
        std::vector<int32_t> PatternData;
	long data = 128;
        PatternData.push_back(data); //Single-element pattern	
	Dio->Pattern->Output->CreatePattern(0, PatternData);

	/* Now that we're configured, we can go ahead and call Initiate. Note that in the Software Trigger case,
	   we do not wait for a GATE signal - we use the software trigger to immediately start acquiring or 
	   outputting. */
	Dio->Pattern->Output->Initiate();
	Dio->Pattern->Input->Initiate();

	/* Now we need to send the software trigger signal. There are several ways we can do this. First, we
	   will trigger Output and Input separately. This may be desired if only one of the two is operating,
	   or if some event needs to happen to cause a side to trigger. */

	Dio->Pattern->SendSoftwareTrigger(VTEXDioSoftwareTriggerGeneration);
	//Some event, etc
	Dio->Pattern->SendSoftwareTrigger(VTEXDioSoftwareTriggerAcquisition);
	
	Dio->Pattern->Input->Abort();
	Dio->Pattern->Output->Abort();

	/* Another way of doing this is to software trigger both at the same time. While due to hardware
	   constraints the timing cannot be guaranteed, this mode is still much more accurate than calling 
	   the two one after the other as shown above */

	Dio->Pattern->Input->Initiate();
	Dio->Pattern->Output->Initiate();

	Dio->Pattern->SendSoftwareTrigger(VTEXDioSoftwareTriggerBoth);

	Dio->Pattern->Input->Abort();
	Dio->Pattern->Output->Abort();

	Dio->Close();

	delete Dio;
    Dio = nullptr;
  }
  catch(...)
  {
	  //Error Handling
  }
  return 0;
}
