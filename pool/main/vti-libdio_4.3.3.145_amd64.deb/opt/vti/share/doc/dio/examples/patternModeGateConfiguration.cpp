// Recommended previous examples: PortConfiguration, PatternGen or PatternAcq Configuration
#include "libDio.h"
#include <stdio.h>

int main()
{
  //Linux driver pointer
  LibDio* Dio;
  try
  {
	     Dio = LibDio::Create();

    /*We chose to give this driver an empty options string. If you have more than one DIO card in 
      your chassis, you will have to give it options such as a slot number. Note that in this case we
	  did not give the device the reset flag
	  
	  IN THIS EXAMPLE WE ASSUME THAT PATTERN GENERATION AND PATTERN ACQUISITION ARE ALREADY SET UP
	  EXCEPT FOR THE TRIGGER MODEL SETTINGS WE ARE ABOUT TO CONFIGURE
	  
	  This is very important because it allows us to avoid having to show the configuration process, which 
	  is covered in other examples, while still allowing the example code to work properly.*/
    Dio->Initialize("TCPIP::10.20.1.5::INSTR", false, false, "");
    
	/* Since Pattern Acq/Gen are already set up, we will now configure their trigger settings. We've already
	covered the Trigger Source settings in other examples, but just for clarity here we will set both of
	the Pattern Mode trigger models to use the front-panel input.*/
	Dio->Pattern->Output->TriggerSource = VTEXDioTriggerSourceExternal;
	Dio->Pattern->Input->TriggerSource = VTEXDioTriggerSourceExternal;

	/* One thing we have avoided talking about so far is the GATE signal. The GATE signal regulates when
	  data is taken or output. There is a selector that determines whether the GATE signal is active when
	  the value is high or low. By default, the GATE signal floats to high. The default selection of the
	  Gate Polarity signal is Active High, so by default no action needs to be taken. The Gate Polarity can
	  be different between Pattern Acquisition and Pattern Generation. The GATE signal is only used after
	  a trigger has been received and the device is ready to begin output or input. */

	Dio->Pattern->Output->GatePolarity = VTEXDioGatePolarityActiveHigh; //The Default
	Dio->Pattern->Input->GatePolarity = VTEXDioGatePolarityActiveLow; 

	/* Now, when we call Initiate, both of the trigger models will wait for a front-panel input signal.
	   However, the Input model will look for a low GATE signal, while the Output model will look for a
	   high GATE signal. Both of them will wait until they have received a trigger before acting. */

	Dio->Pattern->Output->Initiate();
	Dio->Pattern->Input->Initiate();

	//Front panel signal causes waiting for GATE
	//GATE proper position causes data input/output.

	/* Next we can call Abort to return the trigger models to the Idle state. */

	Dio->Pattern->Input->Abort();
	Dio->Pattern->Output->Abort();

	Dio->Close();

	delete Dio;
    Dio = nullptr;
  }
  catch(...)
  {
	  //Error handling
  }
  return 0;
}
