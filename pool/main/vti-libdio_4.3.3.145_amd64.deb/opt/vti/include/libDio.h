/******************************************************************************
 *
 *  .----------------------.    File Name: libDio.h
 *  |==     ==  ======  == |    Project : EMX Platform
 *  | ==   ==   ======  == |    $Author$
 *  |  == ==      ==    == |    $Revision$
 *  |   ===       ==    == |    $Date$
 *  |    =        ==    == |    $HeadURL$
 *  `----------------------'
 *
 * Copyright 2010 VTI Instruments Inc. as an unpublished work.
 * All rights reserved. The information contained herein is confidential
 * vtexProperty of VTI Instruments, Inc. Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement
 * with VTI Instruments, Inc.
 *
 * PURPOSE:
 *   Class definition of the main LibDio class
 *
 * First Written By: Abdul Latif Curtay On Nov-2016
******************************************************************************/

#ifndef _libDio_H
#define _libDio_H

/**************************
 *       Includes         *
 **************************/
#include <string>
#include <vector>

#include "vtexInherent.h"
#include "libVtexException.h"

#include "libDioEnums.h"
#include "libDioErrors.h"


/*************************
 *      Classes          *
 *************************/

class LibDioPortClock
{
public:
    virtual ~LibDioPortClock() { }

    //Datamembers
    vtexProperty <LibDioPortClock, VTEXDioDirectionEnum, READ_WRITE> Direction;
    vtexProperty <LibDioPortClock, VTEXDioPolarityEnum, READ_WRITE> Polarity;
    vtexProperty <LibDioPortClock, VTEXDioDataClockSourceEnum, READ_WRITE> Source;

    vtexProperty <LibDioPortClock, VTEXDioPolarityEnum, READ_WRITE> InputDataClockPolarity;
    vtexProperty <LibDioPortClock, VTEXDioDataClockSourceEnum, READ_WRITE> InputDataClockSource;
    vtexProperty <LibDioPortClock, VTEXDioPolarityEnum, READ_WRITE> OutputDataClockPolarity;
    vtexProperty <LibDioPortClock, VTEXDioDataClockSourceEnum, READ_WRITE> OutputDataClockSource;

    //Property Methods
    virtual VTEXResult put_Direction(VTEXDioDirectionEnum direction) = 0;
    virtual VTEXResult get_Direction(VTEXDioDirectionEnum& direction) = 0;
    virtual VTEXResult put_Polarity(VTEXDioPolarityEnum polarity) = 0;
    virtual VTEXResult get_Polarity(VTEXDioPolarityEnum& polarity) = 0;
    virtual VTEXResult put_Source(VTEXDioDataClockSourceEnum source) = 0;
    virtual VTEXResult get_Source(VTEXDioDataClockSourceEnum& source) = 0;

    virtual VTEXResult put_InputDataClockPolarity(VTEXDioPolarityEnum polarity) = 0;
    virtual VTEXResult get_InputDataClockPolarity(VTEXDioPolarityEnum& polarity) = 0;
    virtual VTEXResult put_InputDataClockSource(VTEXDioDataClockSourceEnum source) = 0;
    virtual VTEXResult get_InputDataClockSource(VTEXDioDataClockSourceEnum& source) = 0;
    virtual VTEXResult put_OutputDataClockPolarity(VTEXDioPolarityEnum polarity) = 0;
    virtual VTEXResult get_OutputDataClockPolarity(VTEXDioPolarityEnum& polarity) = 0;
    virtual VTEXResult put_OutputDataClockSource(VTEXDioDataClockSourceEnum source) = 0;
    virtual VTEXResult get_OutputDataClockSource(VTEXDioDataClockSourceEnum& source) = 0;
};

class LibDioPort
{
public:
    virtual ~LibDioPort() { }

    LibDioPortClock* Clock;

    //Datamembers
    vtexProperty <LibDioPort, int32_t, READ_WRITE> Data;
    vtexProperty <LibDioPort, VTEXDioDirectionEnum, READ_WRITE> Direction;
    vtexProperty <LibDioPort, VTEXDioPullupEnum, READ_WRITE> Pullup;
    vtexProperty <LibDioPort, VTEXDioPolarityEnum, READ_WRITE> Polarity;
    vtexProperty <LibDioPort, bool, READ_ONLY> OverCurrent;
    vtexProperty <LibDioPort, bool, READ_ONLY> LatchedOverCurrent;
    vtexProperty <LibDioPort, VTEXDioVoltageSourceEnum, READ_WRITE> VoltageSource;
    vtexProperty <LibDioPort, double, READ_WRITE> VoltageRange;

    //Methods
    virtual VTEXResult Configure(VTEXDioDirectionEnum direction, VTEXDioPolarityEnum polarity,
                                VTEXDioVoltageSourceEnum voltageSource, double voltageRange) = 0;
    virtual VTEXResult ConfigureData(int32_t data, VTEXDioDirectionEnum direction, VTEXDioPolarityEnum polarity,
        VTEXDioVoltageSourceEnum voltageSource, double voltageRange) = 0;
    virtual VTEXResult ResetOverCurrent() = 0;

    //Property Methods
    virtual VTEXResult put_Data(int32_t data) = 0;
    virtual VTEXResult get_Data(int32_t& data) = 0;
    virtual VTEXResult put_Direction(VTEXDioDirectionEnum direction) = 0;
    virtual VTEXResult get_Direction(VTEXDioDirectionEnum& direction) = 0;
    virtual VTEXResult put_Pullup(VTEXDioPullupEnum pullup) = 0;
    virtual VTEXResult get_Pullup(VTEXDioPullupEnum& pullup) = 0;
    virtual VTEXResult put_Polarity(VTEXDioPolarityEnum polarity) = 0;
    virtual VTEXResult get_Polarity(VTEXDioPolarityEnum& polarity) = 0;
    virtual VTEXResult get_LatchedOverCurrent(bool& overCurrent) = 0;
    virtual VTEXResult get_OverCurrent(bool& overCurrent) = 0;
    virtual VTEXResult put_VoltageSource(VTEXDioVoltageSourceEnum source) = 0;
    virtual VTEXResult get_VoltageSource(VTEXDioVoltageSourceEnum& source) = 0;
    virtual VTEXResult put_VoltageRange(double range) = 0;
    virtual VTEXResult get_VoltageRange(double& range) = 0;
};

class LibDioPorts
{
public:
    virtual ~LibDioPorts() { }

    //Attributes
    vtexProperty <LibDioPorts, int32_t, READ_ONLY> Count;
    arrayizer <LibDioPorts, LibDioPort*, std::string> Item;
    arrayizer <LibDioPorts, std::string, int32_t> Name;

    vtexProperty <LibDioPorts, std::string, READ_ONLY> ListOfPorts;

    //Property Methods
    virtual LibDioPort* get_Item(std::string portName) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t& count) = 0;
    virtual VTEXResult get_ListOfPorts(std::string& val) = 0;
};

class LibDioInputTrigger
{
public:
    virtual ~LibDioInputTrigger() { }

    vtexProperty <LibDioInputTrigger, bool, READ_WRITE> Enabled;
    vtexProperty <LibDioInputTrigger, VTEXDioTriggerLineEnum, READ_WRITE> Source;

    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Enabled(bool& val) = 0;
    virtual VTEXResult put_Source(VTEXDioTriggerLineEnum source) = 0;
    virtual VTEXResult get_Source(VTEXDioTriggerLineEnum& source) = 0;
};

class LibDioOutputTrigger
{
public:
    virtual ~LibDioOutputTrigger() { }

    vtexProperty <LibDioOutputTrigger, bool, READ_WRITE> Enabled;
    vtexProperty <LibDioOutputTrigger, VTEXDioOutputTriggerSourceEnum, READ_WRITE> Source;
    vtexProperty <LibDioOutputTrigger, VTEXDioTriggerLineEnum, READ_WRITE> Destination;
    vtexProperty <LibDioOutputTrigger, VTEXDioPolarityEnum, READ_WRITE> Polarity;

    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Enabled(bool& val) = 0;
    virtual VTEXResult put_Source(VTEXDioOutputTriggerSourceEnum source) = 0;
    virtual VTEXResult get_Source(VTEXDioOutputTriggerSourceEnum& source) = 0;
    virtual VTEXResult put_Destination(VTEXDioTriggerLineEnum destination) = 0;
    virtual VTEXResult get_Destination(VTEXDioTriggerLineEnum& destination) = 0;
    virtual VTEXResult put_Polarity(VTEXDioPolarityEnum polarity) = 0;
    virtual VTEXResult get_Polarity(VTEXDioPolarityEnum& polarity) = 0;
};

class LibDioNormalLatched
{
public:
    virtual ~LibDioNormalLatched() { }

    LibDioInputTrigger* InputTrigger;
    LibDioOutputTrigger* OutputTrigger;
    vtexProperty <LibDioNormalLatched, int32_t, READ_ONLY> ExternalClockLineStatus;
    vtexProperty <LibDioNormalLatched, int32_t, READ_ONLY> IOControlLineStatus;

    virtual VTEXResult SendSoftwareTrigger() = 0;
    virtual VTEXResult get_ExternalClockLineStatus(int32_t& val) = 0;
    virtual VTEXResult get_IOControlLineStatus(int32_t& val) = 0;
};

class LibDioImmediateAsynchronous
{
public:
    virtual ~LibDioImmediateAsynchronous() { }

    //Datamembers
    LibDioPorts* Ports;
    LibDioNormalLatched* Latched;
    vtexProperty <LibDioImmediateAsynchronous, int32_t, READ_ONLY> AsyncFifoCount;
    vtexProperty <LibDioImmediateAsynchronous, VTEXDioFifoLoopbackEnum, READ_WRITE> AsyncFifoLoopBack;
    vtexProperty <LibDioImmediateAsynchronous, VTEXDioTriggerSourceEnum, READ_WRITE> AsyncTriggerSource;

    virtual VTEXResult ReadPorts(VTEXDioDataWidthEnum dataWidth, int32_t portNumber, std::vector<int32_t>& data) = 0;
    virtual VTEXResult WritePorts(VTEXDioDataWidthEnum dataWidth, int32_t portNumber, int32_t data) = 0;
    virtual VTEXResult ReadAsync(int32_t sampleCount, int32_t MaxTimeMilliseconds,
                                std::vector<int32_t>& Data, std::vector<double>& TimeSeconds,
                                std::vector<double>& TimeFraction, std::vector<double>& PortVoltage,
                                std::vector<VTEXDioVoltageSourceEnum>& VoltageSource, std::vector<VTEXDioPolarityEnum>& Polarity,
                                std::vector<VTEXDioDirectionEnum>& Direction, std::vector<int32_t>& OverCurrent,
                                std::vector<VTEXDioPullupEnum>& Pullup) = 0;
    //These commands start or stop the asynchronous fifo. Immediate reads/writes can still be done.
    virtual VTEXResult ClearAsyncFifo() = 0;
    virtual VTEXResult AbortAsync() = 0;
    virtual VTEXResult InitiateAsync() = 0;
    virtual VTEXResult AsyncSoftwareTrigger() = 0;

    //Property Methods
    virtual VTEXResult get_AsyncFifoCount(int32_t& count) = 0;
    virtual VTEXResult put_AsyncFifoLoopBack(VTEXDioFifoLoopbackEnum loopback) = 0;
    virtual VTEXResult get_AsyncFifoLoopBack(VTEXDioFifoLoopbackEnum& loopback) = 0;
    virtual VTEXResult put_AsyncTriggerSource(VTEXDioTriggerSourceEnum source) = 0;
    virtual VTEXResult get_AsyncTriggerSource(VTEXDioTriggerSourceEnum& source) = 0;
};

class LibDioPlatform
{
public:
    virtual ~LibDioPlatform() { }

    vtexProperty <LibDioPlatform, std::string, READ_ONLY> SerialNumber;

    // Property methods
    virtual VTEXResult get_SerialNumber(std::string& value) = 0;

    virtual VTEXResult OpenLogFile(std::string FileName, std::string AccessMode) = 0;
    virtual VTEXResult CloseLogFile() = 0;
};

/*
* Dio Self-Test Interface
*/

class LibDioSelfTest
{
public:
    virtual ~LibDioSelfTest() {}

    virtual VTEXResult Initiate() = 0;
    virtual VTEXResult GetStatus(int32_t &status, std::string &message) = 0;
    virtual VTEXResult get_Report(std::string &val) = 0;

    vtexProperty <LibDioSelfTest, std::string, READ_ONLY> Report;
};




//Measurement  3.5.7
/**
 * Dio.Measurement.Sampling
 */

#if 0
class LibDioMeasurementSampling
{
public:
    virtual ~LibDioMeasurementSampling() {}

    virtual VTEXResult Configure(int64_t record_size, double sample_rate, bool oversample) = 0;

    virtual VTEXResult GetFilterCoefficients(std::vector<double> &coeffs) = 0;
    virtual VTEXResult SetFilterCoefficients(std::vector<double> coeffs) = 0;
    virtual VTEXResult get_ClockFrequency(double &val) = 0;
    virtual VTEXResult put_ClockFrequency(double val) = 0;
    virtual VTEXResult get_RecordSize(int64_t &val) = 0;
    virtual VTEXResult put_RecordSize(int64_t val) = 0;
    virtual VTEXResult get_SampleRate(double &val) = 0;
    virtual VTEXResult put_SampleRate(double val) = 0;
    virtual VTEXResult get_Span(double &val) = 0;
    virtual VTEXResult put_Span(double val) = 0;
    virtual VTEXResult get_Oversample(bool &val) = 0;
    virtual VTEXResult put_Oversample(bool val) = 0;
    virtual VTEXResult get_Prescaler(int32_t &val) = 0;
    virtual VTEXResult put_Prescaler(int32_t val) = 0;
    virtual VTEXResult get_Multipass(bool &val) = 0;
    virtual VTEXResult put_Multipass(bool val) = 0;
    virtual VTEXResult get_DownsamplingFactor(int32_t &val) = 0;
    virtual VTEXResult put_DownsamplingFactor(int32_t val) = 0;
    virtual VTEXResult get_FilterType(VTEXDioDecimationFilterEnum &val) = 0;
    virtual VTEXResult put_FilterType(VTEXDioDecimationFilterEnum val) = 0;
    virtual VTEXResult get_GroupDelay(double &val) = 0;
    virtual VTEXResult put_GroupDelay(double val) = 0;

    vtexProperty <LibDioMeasurementSampling, double, READ_WRITE> ClockFrequency;
    vtexProperty <LibDioMeasurementSampling, int64_t, READ_WRITE> RecordSize;
    vtexProperty <LibDioMeasurementSampling, double, READ_WRITE> SampleRate;
    vtexProperty <LibDioMeasurementSampling, double, READ_WRITE> Span;
    vtexProperty <LibDioMeasurementSampling, bool, READ_WRITE> Oversample;
    vtexProperty <LibDioMeasurementSampling, int32_t, READ_WRITE> Prescaler;
    vtexProperty <LibDioMeasurementSampling, bool, READ_WRITE> Multipass;
    vtexProperty <LibDioMeasurementSampling, int32_t, READ_WRITE> DownsamplingFactor;
    vtexProperty <LibDioMeasurementSampling, VTEXDioDecimationFilterEnum, READ_WRITE> FilterType;
    vtexProperty <LibDioMeasurementSampling, double, READ_WRITE> GroupDelay;
};


class LibDioMeasurement
{
public:
    virtual ~LibDioMeasurement() {}

    LibDioMeasurementSampling* Sampling;

    virtual VTEXResult Abort() = 0;
    virtual VTEXResult Initiate() = 0;
    virtual VTEXResult get_NumAcquiredRecords(int64_t &val) = 0;
    virtual VTEXResult get_NumFIFORecords(int64_t &val) = 0;
    virtual VTEXResult get_FIFOMode(VTEXDioFifoModeEnum &val) = 0;
    virtual VTEXResult put_FIFOMode(VTEXDioFifoModeEnum val) = 0;
    virtual VTEXResult get_NumRecordsPerTrigger(int64_t &val) = 0;
    virtual VTEXResult put_NumRecordsPerTrigger(int64_t val) = 0;
    virtual VTEXResult Read(int32_t max_time_ms, int32_t num_records,
                            int32_t& actual_records, std::string &channel,
                            std::vector<double> &data, std::vector<double> &ts_sec,
                            std::vector<double> &ts_frac, std::string &addl_data) = 0;
    virtual VTEXResult get_State(VTEXDioMeasurementStateEnum &val) = 0;
    virtual VTEXResult WaitForMeasurementComplete(int32_t max_time_milliseconds) = 0;

    vtexProperty <LibDioMeasurement, int64_t, READ_ONLY> NumAcquiredRecords;
    vtexProperty <LibDioMeasurement, int64_t, READ_ONLY> NumFIFORecords;
    vtexProperty <LibDioMeasurement, int64_t, READ_WRITE> NumRecordsPerTrigger;
    vtexProperty <LibDioMeasurement, VTEXDioFifoModeEnum, READ_WRITE> FIFOMode;
    vtexProperty <LibDioMeasurement, VTEXDioMeasurementStateEnum, READ_ONLY> State;
};
#endif

class LibDioPatternInput
{
public:
virtual ~LibDioPatternInput() { }

    //Attributes
    vtexProperty <LibDioPatternInput, int32_t, READ_ONLY> FifoCount;
    vtexProperty <LibDioPatternInput, VTEXDioTriggerSourceEnum, READ_WRITE> TriggerSource;
    vtexProperty <LibDioPatternInput, VTEXDioGatePolarityEnum, READ_WRITE> GatePolarity;
    vtexProperty <LibDioPatternInput, bool, READ_ONLY> Triggered;
    vtexProperty <LibDioPatternInput, int64_t, READ_ONLY> RecordLength;
    vtexProperty <LibDioPatternInput, VTEXDioFifoLoopbackEnum, READ_WRITE> LoopBack;
    vtexProperty <LibDioPatternInput, VTEXDioPolarityEnum, READ_WRITE> Polarity;
    vtexProperty <LibDioPatternInput, double, READ_WRITE> VoltageRange;
    //Measurement  3.5.7
    //LibDioMeasurement*          Measurement;

    //Methods
    virtual VTEXResult Initiate() = 0;
    virtual VTEXResult Abort() = 0;
    virtual VTEXResult FifoClear() = 0;
    virtual VTEXResult Read(int32_t sampleCount, int32_t MaxTimeMilliseconds, std::vector<int32_t>& Data) = 0;
    virtual VTEXResult ConfigurePorts(VTEXDioPolarityEnum polarity, VTEXDioGatePolarityEnum gatePolarity, double voltageRange) = 0;
    //Property Methods
    virtual VTEXResult get_FifoCount(int32_t& count) = 0;
    virtual VTEXResult put_GatePolarity(VTEXDioGatePolarityEnum polarity) = 0;
    virtual VTEXResult get_GatePolarity(VTEXDioGatePolarityEnum& polarity) = 0;
    virtual VTEXResult put_LoopBack(VTEXDioFifoLoopbackEnum loopback) = 0;
    virtual VTEXResult get_LoopBack(VTEXDioFifoLoopbackEnum& loopback) = 0;
    virtual VTEXResult put_TriggerSource(VTEXDioTriggerSourceEnum source) = 0;
    virtual VTEXResult get_TriggerSource(VTEXDioTriggerSourceEnum& source) = 0;
    virtual VTEXResult get_Triggered(bool& triggered) = 0;
    virtual VTEXResult put_Polarity(VTEXDioPolarityEnum polarity) = 0;
    virtual VTEXResult get_Polarity(VTEXDioPolarityEnum& polarity) = 0;
    virtual VTEXResult put_VoltageRange(double range) = 0;
    virtual VTEXResult get_VoltageRange(double& range) = 0;
    //virtual VTEXResult get_RecordLength(int64_t& RecordLength) = 0;
};

class LibDioPatternOutput
{
public:
    virtual ~LibDioPatternOutput() { }

    //Attributes
    vtexProperty <LibDioPatternOutput, bool, READ_ONLY> Triggered;
    vtexProperty <LibDioPatternOutput, VTEXDioTriggerSourceEnum, READ_WRITE> TriggerSource;
    vtexProperty <LibDioPatternOutput, VTEXDioGatePolarityEnum, READ_WRITE> GatePolarity;
    //vtexProperty <LibDioPatternOutput, VTEXDioFifoModeEnum, READ_WRITE> FIFOMode;
    //vtexProperty <LibDioPatternOutput, int32_t, READ_ONLY> RepeatCount;
    vtexProperty <LibDioPatternOutput, VTEXDioFifoLoopbackEnum, READ_WRITE> LoopBack;
    vtexProperty <LibDioPatternOutput, int32_t, READ_WRITE> MaxPatterns;
    vtexProperty <LibDioPatternOutput, int32_t, READ_ONLY> PatternCount;
    vtexProperty <LibDioPatternOutput, VTEXDioPolarityEnum, READ_WRITE> Polarity;
    vtexProperty <LibDioPatternOutput, double, READ_WRITE> VoltageRange;
    vtexProperty <LibDioPatternOutput, int32_t, READ_WRITE> CurrentPattern;
    vtexProperty <LibDioPatternOutput, int32_t, READ_ONLY> MaxPatternLength;

    //Methods
    virtual VTEXResult Initiate() = 0;
    virtual VTEXResult Abort() = 0;
    virtual VTEXResult CreatePattern(int32_t PatternId, const std::vector<int32_t> &PatternData) = 0;
    virtual VTEXResult RetrievePattern(int32_t PatternId, std::vector<int32_t>& PatternData) = 0;
    virtual VTEXResult SetEndState(std::vector<int32_t> Data) = 0;
    virtual VTEXResult GetEndState(std::vector<int32_t>& Data) = 0;
    virtual VTEXResult ConfigurePorts(VTEXDioPolarityEnum polarity, VTEXDioGatePolarityEnum gatePolarity, double voltageRange) = 0;

    //Property Methods
    virtual VTEXResult put_MaxPatterns(int32_t patterns) = 0;
    virtual VTEXResult get_MaxPatterns(int32_t& patterns) = 0;
    virtual VTEXResult get_PatternCount(int32_t& count) = 0;
    virtual VTEXResult put_GatePolarity(VTEXDioGatePolarityEnum polarity) = 0;
    virtual VTEXResult get_GatePolarity(VTEXDioGatePolarityEnum& polarity) = 0;
    virtual VTEXResult put_LoopBack(VTEXDioFifoLoopbackEnum loopback) = 0;
    virtual VTEXResult get_LoopBack(VTEXDioFifoLoopbackEnum& loopback) = 0;
    virtual VTEXResult put_TriggerSource(VTEXDioTriggerSourceEnum source) = 0;
    virtual VTEXResult get_TriggerSource(VTEXDioTriggerSourceEnum& source) = 0;
    virtual VTEXResult get_Triggered(bool& triggered) = 0;
    virtual VTEXResult put_CurrentPattern(int32_t patternId) = 0;
    virtual VTEXResult get_CurrentPattern(int32_t& patternId) = 0;
    virtual VTEXResult put_Polarity(VTEXDioPolarityEnum polarity) = 0;
    virtual VTEXResult get_Polarity(VTEXDioPolarityEnum& polarity) = 0;
    virtual VTEXResult put_VoltageRange(double range) = 0;
    virtual VTEXResult get_VoltageRange(double& range) = 0;
    virtual VTEXResult get_MaxPatternLength(int32_t& patternLen) = 0;
#if 0
    //Confirm With Barbara if below 6 functions are required.
    virtual VTEXResult get_FIFOMode(VTEXDioFifoModeEnum &val) = 0;
    virtual VTEXResult put_FIFOMode(VTEXDioFifoModeEnum val) = 0;
    virtual VTEXResult get_RepeatCount(int32_t& count) = 0;
    //this may have a list of data rather than single int32.
    virtual VTEXResult get_RemaningMem(int32_t& Memory) = 0;

    virtual VTEXResult ClearMemory() = 0;
    virtual VTEXResult WriteData(VTEXDioDataWidthEnum dataWidth, int32_t portNumber, int32_t data) = 0;
#endif
};

class LibDioPattern
{
public:
    virtual ~LibDioPattern() { }

    LibDioPatternInput* Input;
    LibDioPatternOutput* Output;

    //Attributes
    vtexProperty <LibDioPattern, VTEXDioPatternModeEnum, READ_WRITE> PatternMode;
    vtexProperty <LibDioPattern, double, READ_WRITE> InternalClockFrequency;
    vtexProperty <LibDioPattern, VTEXDioClockSourceEnum, READ_WRITE> ClockSource;
    vtexProperty <LibDioPattern, bool, READ_WRITE> ClockOutputEnabled;

    //Property Methods
    virtual VTEXResult put_PatternMode(VTEXDioPatternModeEnum mode) = 0;
    virtual VTEXResult get_PatternMode(VTEXDioPatternModeEnum& mode) = 0;
    virtual VTEXResult put_InternalClockFrequency(double frequency) = 0;
    virtual VTEXResult get_InternalClockFrequency(double& frequency) = 0;
    virtual VTEXResult put_ClockSource(VTEXDioClockSourceEnum source) = 0;
    virtual VTEXResult get_ClockSource(VTEXDioClockSourceEnum& source) = 0;
    virtual VTEXResult put_ClockOutputEnabled(bool enabled) = 0;
    virtual VTEXResult get_ClockOutputEnabled(bool& enabled) = 0;
    virtual VTEXResult SendSoftwareTrigger(VTEXDioSoftwareTriggerEnum trigger) = 0;
};

#if 0
//Dio Streaming Interface  4
//=============================================================================

//User-overridable class implementing the callback
class LibDioStreamingCallback
{
public:
    virtual ~LibDioStreamingCallback() {}
    virtual void StreamingCallback(int32_t num_records,
        std::string& channel, std::vector<double>& data, std::vector<double>& ts_sec, std::vector<double>& ts_frac, std::string& additional_data) = 0;
};

//=============================================================================

class LibDioStreamingData
{
public:
    virtual ~LibDioStreamingData() {}

    virtual VTEXResult AddAttribute(std::string name, std::string value) = 0;
    virtual VTEXResult DisableStreaming() = 0;
    virtual VTEXResult EnableStreaming() = 0;
    virtual VTEXResult get_Filename(std::string& filename) = 0;
    virtual VTEXResult put_Filename(std::string filename) = 0;
    virtual VTEXResult MemoryRead(int32_t num_records, int32_t& actual_records, std::string& channel, std::vector<double>& data,
                                    std::vector<double>& ts_sec, std::vector<double>& ts_frac, std::string& additional_data) = 0;
    virtual VTEXResult get_NumMemoryRecords(int64_t &val) = 0;
    virtual VTEXResult get_NumStreamedRecords(int64_t &val) = 0;
    virtual VTEXResult RegisterStreamingCallback(LibDioStreamingCallback& callback, std::string channel_list) = 0;
    virtual VTEXResult UnregisterStreamingCallback(LibDioStreamingCallback& callback) = 0;

    vtexProperty <LibDioStreamingData, std::string, READ_WRITE> Filename;
    vtexProperty <LibDioStreamingData, int64_t, READ_ONLY> NumMemoryRecords;
    vtexProperty <LibDioStreamingData, int64_t, READ_ONLY> NumStreamedRecords;
};

//Dio.ReferenceOscillator  5
class LibDioReferenceOscillator
{
public:
    virtual ~LibDioReferenceOscillator() {}

    virtual VTEXResult Configure(VTEXDioReferenceOscillatorSourceEnum source, double frequency) = 0;
    virtual VTEXResult get_ExternalFrequency(double &val) = 0;
    virtual VTEXResult put_ExternalFrequency(double val) = 0;
    virtual VTEXResult get_OutputEnabled(bool &val) = 0;
    virtual VTEXResult put_OutputEnabled(bool val) = 0;
    virtual VTEXResult get_Source(VTEXDioReferenceOscillatorSourceEnum &val) = 0;
    virtual VTEXResult put_Source(VTEXDioReferenceOscillatorSourceEnum val) = 0;
    virtual VTEXResult get_TimestampSource(VTEXDioReferenceOscillatorTimestampSourceEnum &val) = 0;
    virtual VTEXResult put_TimestampSource(VTEXDioReferenceOscillatorTimestampSourceEnum val) = 0;

    vtexProperty <LibDioReferenceOscillator, double, READ_WRITE> ExternalFrequency;
    vtexProperty <LibDioReferenceOscillator, bool, READ_WRITE> OutputEnabled;
    vtexProperty <LibDioReferenceOscillator, VTEXDioReferenceOscillatorSourceEnum, READ_WRITE> Source;
    vtexProperty <LibDioReferenceOscillator, VTEXDioReferenceOscillatorTimestampSourceEnum, READ_WRITE> TimestampSource;
};

#endif


class LibDio : public vtexInherent
{
  public:
    virtual ~LibDio() { }
    static LibDio* Create();

    //Inherent capabilitites
    vtexProperty <LibDio, bool, READ_ONLY> Initialized;
    vtexProperty <LibDio, VTEXDioModeEnum, READ_WRITE> Mode;

    vtexInherentCapabilityUtility* Utility;
    vtexInherentCapabilityDriverOperation* DriverOperation;
    vtexInherentCapabilityIdentity* Identity;
    LibDioPlatform* Platform;
    LibDioImmediateAsynchronous* Normal;
    LibDioPattern* Pattern;
    //LibDioStreamingData* StreamingData;
    //LibDioReferenceOscillator* ReferenceOscillator;
    LibDioSelfTest* SelfTest;

    //Property Methods
    virtual VTEXResult put_Mode(VTEXDioModeEnum mode) = 0;
    virtual VTEXResult get_Mode(VTEXDioModeEnum& mode) = 0;
};

#endif  //_LIB_DIO_H
