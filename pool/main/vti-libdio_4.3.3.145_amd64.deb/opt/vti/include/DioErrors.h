#include "exErrors.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#if defined(_WIN32) && !defined(_CVI_)
#define INLINE __inline
#else
#define INLINE inline
#endif

#ifdef __cplusplus
extern "C" {
#endif

 //!
 //! @file
 //!
 //! Dio error codes.
 //!

#ifndef _DioErrors_H
#define _DioErrors_H

 //! IVI dio errors.
#define IVIDIO_E_BASE 0x80080000


 //! IVI dio warnings.
#define IVIDIO_W_BASE 0x80000


 // 
 // Do not edit IVI class compliant errors.  Add custom errors below.
 //

 //! Driver errors.
#define VTEXDIO_E_BASE 0x80084000

#define VTEXDIO_E_INVALID_PORT_NUMBER 0x80084001
#define VTEXDIO_E_INVALID_DATA_WIDTH 0x80084002
#define VTEXDIO_E_DATA_INCONSISTENT 0x80084003
#define VTEXDIO_E_WRONG_LENGTH 0x80084004

 //! Driver warnings.
#define VTEXDIO_W_BASE 0x84000


 //! Device errors.
#define FWDIO_E_BASE 0x80088000

#define FWDIO_E_NULL_POINTER_ARGUMENT 0x80088001
#define FWDIO_E_MEM_ALLOC_FAILED 0x80088002
#define FWDIO_E_NOT_IMPLEMENTED 0x80088003
#define FWDIO_E_FPGA_INTERNAL_ERROR 0x80088004
#define FWDIO_E_INVALID_PORT 0x80088005
#define FWDIO_E_DEVICE_IS_ARMED 0x80088006
#define FWDIO_E_INVALID_PATTERN 0x80088007
#define FWDIO_E_PATTERN_TOO_LONG 0x80088008
#define FWDIO_E_INVALID_MODE 0x80088009
#define FWDIO_E_ASYNC_NOT_ENABLED 0x8008800a
#define FWDIO_E_TRIGGER_SOURCE_NOT_SOFTWARE 0x8008800b
#define FWDIO_E_TOO_MANY_PATTERNS 0x8008800c
#define FWDIO_E_VOLTAGE_NOT_SET 0x8008800d
#define FWDIO_E_PATTERN_BEING_LOADED 0x8008800e
#define FWDIO_E_MAX_TIME_EXCEEDED 0x8008800f
#define FWDIO_E_INVALID_TIMEOUT_VALUE 0x80088010
#define FWDIO_E_BAD_DCF 0x80088011
#define FWDIO_E_INTERNAL_ERROR 0x80088012
#define FWDIO_E_NOT_ARMED 0x80088013
#define FWDIO_E_INCONSISTENT_STATE 0x80088014

 //! Device warnings.
#define FWDIO_W_BASE 0x88000




#endif /* ! _DioErrors_H */

#ifdef  __cplusplus
}
#endif

