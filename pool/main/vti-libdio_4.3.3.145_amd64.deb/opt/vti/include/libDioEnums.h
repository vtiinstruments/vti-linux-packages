#ifndef _DIO_ENUMS_
#define _DIO_ENUMS_

#ifndef ___VTEXDio_h__


typedef enum
{
    VTEXDioClockSourceExternal = 1000,
    VTEXDioClockSourceInternal = 1001
}VTEXDioClockSourceEnum;

typedef enum
{
    VTEXDioDataWidth8 = 1000,
    VTEXDioDataWidth16 = 1001,
    VTEXDioDataWidth32 = 1002,
    VTEXDioDataWidth64 = 1003
}VTEXDioDataWidthEnum;

typedef enum
{
    VTEXDioDirectionInput = 1000,
    VTEXDioDirectionOutput = 1001
}VTEXDioDirectionEnum;

typedef enum
{
    VTEXDioPullupDisable = 1000,
    VTEXDioPullupEnable = 1001
}VTEXDioPullupEnum;

// Note that this enum and ONLY this enum works like the DMM Autorange enums
typedef enum
{
    VTEXDioTTLEmulation = -1,
    VTEXDioLVEmulation = -2
}VTEXDioVoltageRangeEnum;

typedef enum
{
    VTEXDioVoltageSourceInternal = 1000,
    VTEXDioVoltageSourceUser = 1001
}VTEXDioVoltageSourceEnum;

typedef enum
{
    VTEXDioGatePolarityActiveHigh = 1000,
    VTEXDioGatePolarityActiveLow = 1001
}VTEXDioGatePolarityEnum;

typedef enum
{
    VTEXDioModeNormal = 1000,
    VTEXDioModePattern = 1001,
    VTEXDioModeScanlist = 1002
}VTEXDioModeEnum;

// Note that this is actually part of the mode register too and MUST match up with the Immediate/ImmAsync selector there
typedef enum
{
    VTEXDioAsyncDisabled = 1000,
    VTEXDioAsyncEnabled = 1001
}VTEXDioAsyncEnum;

typedef enum
{
    VTEXDioPatternModeBoth = 1000,
    VTEXDioPatternModeGeneration = 1001,
    VTEXDioPatternModeAcquisition = 1002
}VTEXDioPatternModeEnum;

typedef enum
{
    VTEXDioPolarityNormal = 1000,
    VTEXDioPolarityInverse = 1001
}VTEXDioPolarityEnum;

typedef enum
{
    VTEXDioSoftwareTriggerBoth = 1000,
    VTEXDioSoftwareTriggerGeneration = 1001,
    VTEXDioSoftwareTriggerAcquisition = 1002
}VTEXDioSoftwareTriggerEnum;

typedef enum
{
    VTEXDioFifoStop = 1000,
    VTEXDioFifoOverwrite = 1001
}VTEXDioFifoLoopbackEnum;

typedef enum
{
    VTEXDioTriggerSourceNone = 0,
    VTEXDioTriggerSourceExternal = 2,
    VTEXDioTriggerSourceSwTrigFunc = 3,
    VTEXDioTriggerSourceBPL0 = 1000,
    VTEXDioTriggerSourceBPL1 = 1001,
    VTEXDioTriggerSourceBPL2 = 1002,
    VTEXDioTriggerSourceBPL3 = 1003,
    VTEXDioTriggerSourceBPL4 = 1004,
    VTEXDioTriggerSourceBPL5 = 1005,
    VTEXDioTriggerSourceBPL6 = 1006,
    VTEXDioTriggerSourceBPL7 = 1007
}VTEXDioTriggerSourceEnum;

typedef enum
{
    VTEXDioDataClockSourceNone = 1000,
    VTEXDioDataClockSourceTriggerLine = 1001,
    VTEXDioDataClockSourceExt = 1002,
    VTEXDioDataClockSourceSoftware = 1003,
    VTEXDioDataClockSourceGlobal = 1004,
}VTEXDioDataClockSourceEnum; // input data clock source & output data clock source

typedef enum
{
    VTEXDioOutputTriggerSourceNone = 1000,
    VTEXDioOutputTriggerSourceSoftware = 1001,
    VTEXDioOutputTriggerSourceExt1 = 1002,
    VTEXDioOutputTriggerSourceExt2 = 1003,
    VTEXDioOutputTriggerSourceExt3 = 1004,
    VTEXDioOutputTriggerSourceExt4 = 1005,
    VTEXDioOutputTriggerSourceExt5 = 1006,
    VTEXDioOutputTriggerSourceExt6 = 1007,
    VTEXDioOutputTriggerSourceExt7 = 1008,
    VTEXDioOutputTriggerSourceExt8 = 1009,
    VTEXDioOutputTriggerSourceExt9 = 1010,
    VTEXDioOutputTriggerSourceExt10 = 1011,
    VTEXDioOutputTriggerSourceExt11 = 1012,
    VTEXDioOutputTriggerSourceExt12 = 1013,
    VTEXDioOutputTriggerSourceExt13 = 1014,
    VTEXDioOutputTriggerSourceExt14 = 1015,
    VTEXDioOutputTriggerSourceExt15 = 1016,
    VTEXDioOutputTriggerSourceExt16 = 1017,
    VTEXDioOutputTriggerSourceExt17 = 1018,
    VTEXDioOutputTriggerSourceExt18 = 1019,
    VTEXDioOutputTriggerSourceExt19 = 1020,
    VTEXDioOutputTriggerSourceExt20 = 1021,
    VTEXDioOutputTriggerSourceExt21 = 1022,
    VTEXDioOutputTriggerSourceExt22 = 1023,
    VTEXDioOutputTriggerSourceExt23 = 1024,
    VTEXDioOutputTriggerSourceExt24 = 1025,
}VTEXDioOutputTriggerSourceEnum; // output trigger source

typedef enum
{
    VTEXDioTriggerLine0 = 1000,
    VTEXDioTriggerLine1 = 1001,
    VTEXDioTriggerLine2 = 1002,
    VTEXDioTriggerLine3 = 1003,
    VTEXDioTriggerLine4 = 1004,
    VTEXDioTriggerLine5 = 1005,
    VTEXDioTriggerLine6 = 1006,
    VTEXDioTriggerLine7 = 1007,
}VTEXDioTriggerLineEnum; // input trigger source & output destination

typedef enum
{
    VTEXDioFifoModeWait = 1000,
    VTEXDioFifoModeOverwrite = 1001,
    VTEXDioFifoModeStop = 1002,
}VTEXDioFifoModeEnum;

typedef enum
{
    VTEXDioDataFormatEUFixedPoint32 = 1000,
    VTEXDioDataFormatEUReal64 = 1001,
    VTEXDioDataFormatEUReal32 = 1002,
    VTEXDioDataFormatRawInt32 = 1100,
    VTEXDioDataFormatRawInt16 = 1101,
    VTEXDioDataFormatVReal64 = 1102,
    VTEXDioDataFormatVReal32 = 1103,
}VTEXDioDataFormatEnum;

typedef enum
{
    VTEXDigitizerDecimationFilterNone = 1000,
    VTEXDigitizerDecimationFilterLowLatency = 1001,
    VTEXDigitizerDecimationFilterMedLatency = 1002,
    VTEXDigitizerDecimationFilterHighPerformance = 1003,
} VTEXDioDecimationFilterEnum;

typedef enum
{
    VTEXDioMeasurementStateIdle = 1000,
    VTEXDioMeasurementStateSettling = 1001,
    VTEXDioMeasurementStateWaitingForStart = 1002,
    VTEXDioMeasurementStateWaitingForArm = 1003,
    VTEXDioMeasurementStateWaitingForTrigger = 1004,
    VTEXDioMeasurementStatePretriggerSamples = 1005,
    VTEXDioMeasurementStateMeasuring = 1006,
    VTEXDioMeasurementStateTriggerHoldoff = 1007,
    VTEXDioMeasurementStateMixed = 1008,
}VTEXDioMeasurementStateEnum;

typedef enum
{
    VTEXDioReferenceOscillatorSourceInternal = 0,
    VTEXDioReferenceOscillatorSourceExternal = 1,
    VTEXDioReferenceOscillatorSourcePXIClk10 = 2,
    VTEXDioReferenceOscillatorSourcePXIeClk100 = 3,
    VTEXDioReferenceOscillatorSourcePXIeDSTARA = 4,
    VTEXDioReferenceOscillatorSourcePXIeDSTARB = 5,
    VTEXDioReferenceOscillatorSourcePXIeDSTARC = 6,
    VTEXDioReferenceOscillatorSourceSystem = 1002,
}VTEXDioReferenceOscillatorSourceEnum;

typedef enum
{
    VTEXDioReferenceOscillatorTimestampSourceInternal = 0,
    VTEXDioReferenceOscillatorTimestampSourceExternal = 1,      //This is used in Pattern Mode on the application side only not FPGA
    VTEXDioReferenceOscillatorTimestampSourcePXIClk10 = 2,
    VTEXDioReferenceOscillatorTimestampSourcePXIeClk100 = 3,
    VTEXDioReferenceOscillatorTimestampSourcePXIeDSTARA = 4,
    VTEXDioReferenceOscillatorTimestampSourcePXIeDSTARB = 5,
    VTEXDioReferenceOscillatorTimestampSourcePXIeDSTARC = 6,
    VTEXDioReferenceOscillatorTimestampSourceSystem = 1002,
}VTEXDioReferenceOscillatorTimestampSourceEnum;

// The maximum size of pattern we allow in one transfer. Bigger transfers are chunked
#define MAX_PATTERN_TRANSMISSION_WORDS 4096

// 60 second fifo timeout max
#define DIO_MAX_TIMEOUT_MSEC 60000

// Fifo pagecount maximums
#define DIO_MAX_ASYNC_FIFO_RESPONSE 150
#define DIO_MAX_PATTERN_FIFO_RESPONSE 200

#endif /* ___VTEXDio_h__ */
#endif /* _DIO_ENUMS_ */
