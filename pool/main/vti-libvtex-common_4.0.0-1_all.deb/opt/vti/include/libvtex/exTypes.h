#ifndef _EXTYPES_H
#define _EXTYPES_H

#include <stdint.h>

#define IVI_SUCCESS 0

typedef int32_t VTEXResult;

#ifdef __cplusplus

#ifdef _WIN32
#ifdef DLL_EXPORTS
/* Win32 dynamic link library export */
#include <comdef.h>
#define	VTEXString	BSTR
#define VTEXIntVector	SAFEARRAY*
#define VTEXBoolVector	SAFEARRAY*
#define VTEXDoubleVector	SAFEARRAY*
#define VTEXEnumVector(type)	SAFEARRAY*

#else // DLL_EXPORTS
#ifdef VTEX_DLL
/* Win32 dynamic link library import */
#include <comdef.h>
#define	VTEXString	BSTR
#define VTEXIntVector	SAFEARRAY*
#define VTEXBoolVector	SAFEARRAY*
#define VTEXDoubleVector	SAFEARRAY*
#define VTEXEnumVector(type)	SAFEARRAY*

#else // VTEX_DLL
/* Win32 static library */
#include <string>
#include <vector>
#define VTEX_API
#define	VTEXString	std::string
#define VTEXIntVector	std::vector<int>
#define VTEXBoolVector	std::vector<bool>
#define VTEXDoubleVector	std::vector<double>
#define VTEXEnumVector(type)	std::vector<int>

#endif // VTEX_DLL
#endif // DLL_EXPORTS

#else // _WIN32
/* Linux, Unix,...etc */
#include <string>
#include <vector>
#define	VTEXString	std::string
#define VTEXIntVector	std::vector<int>
#define VTEXBoolVector	std::vector<bool>
#define VTEXDoubleVector	std::vector<double>
#define VTEXEnumVector(type)	std::vector<int>

#endif // _WIN32

#endif // __cplusplus

#endif // _EXTYPES_H
