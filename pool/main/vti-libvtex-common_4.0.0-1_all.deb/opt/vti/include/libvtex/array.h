/******************************************************************************
 *
 *  .----------------------.	
 *  |==     ==  ======  == |	$Author$
 *  | ==   ==   ======  == |	$Revision$ 
 *  |  == ==      ==    == |	$Date$ 
 *  |   ===       ==    == |	$HeadURL$
 *  |    =        ==    == |	
 *  `----------------------'
 *
 * Copyright 2006 VXI Technology Inc. as an unpublished work. 
 * All rights reserved. The information contained herein is confidential
 * property of VXI Technology, Inc. Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement 
 * with VXI Technology, Inc.
 *
 * PURPOSE: 
 *   Template class for various IVI properties
 *
 * First Written By: David Sigler On Jan-2007
 ******************************************************************************/
 
#ifndef _ARRAY_TEMPLATE_
#define _ARRAY_TEMPLATE_

template <typename Container, typename ValueType, typename IndexType>
class VTEX_API arrayizer
{
public:
    arrayizer()
    {
        m_container = NULL;
        m_get = NULL;
    }
    
    void SetAttributes(Container *container,
      ValueType (Container::*get)(IndexType value))
    {
        m_container = container;
        m_get = get;
    }
    
    ValueType operator [](IndexType index)
    {
        return (m_container->*m_get)(index);
    }

private:
    Container *m_container;
    ValueType (Container::*m_get)(IndexType value);
};

#endif //_ARRAY_TEMPLATE_

