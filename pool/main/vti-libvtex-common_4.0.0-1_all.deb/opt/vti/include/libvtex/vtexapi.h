
/******************************************************************************
 *
 *  .----------------------.	File Name: vtexapi.h
 *  |==     ==  ======  == |	Project : EX Platform
 *  | ==   ==   ======  == |	$Author: yujik $
 *  |  == ==      ==    == |	$Revision:$
 *  |   ===       ==    == |	$Date: 2009-06-04 08:56:47 -0700 (Thu, 04 Jun 2009) $
 *  |    =        ==    == |
 *  `----------------------'
 *
 * Copyright 2008 VTI Instruments Corporation.
 * All rights reserved. The information contained herein is confidential
 * property of VTI Instruments. Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement
 * with VTI Instruments.
 *
 * PURPOSE:
 *   Export libVTEX APIs in Win32 DLL.
 *
 * First Written By: Yuji Kobayashi On Jun-2009
 ******************************************************************************/
#ifndef __INCLUDE_VTEX_API__
#define __INCLUDE_VTEX_API__

/*
 * All libVTEX APIs that are exported from Win32 DLL must be defined as VTEX_API.
 * Define DLL_EXPORTS to build libVTEX Win32 DLL.
 * Define VTEX_DLL to link with libVTEX DLL import libraries.
 */
#ifdef _WIN32

#ifdef DLL_EXPORTS
/* Win32 dynamic link library export */
#define VTEX_API __declspec(dllexport)
#else 
#ifdef VTEX_DLL
/* Win32 dynamic link library import */
#define VTEX_API __declspec(dllimport)

#else
/* Win32 static library */
#define VTEX_API

#endif
#endif

#else
/* Linux, Unix,...etc */

#if __GNUC__ >= 3 && !defined(VTEX_HIDDEN)
#define VTEX_API __attribute__ ((visibility("default")))
#else
#define VTEX_API
#endif

#endif

#endif
