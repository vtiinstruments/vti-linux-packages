/******************************************************************************
 *
 *  .----------------------.	
 *  |==     ==  ======  == |	$Author$
 *  | ==   ==   ======  == |	$Revision$ 
 *  |  == ==      ==    == |	$Date$ 
 *  |   ===       ==    == |	$HeadURL$
 *  |    =        ==    == |	
 *  `----------------------'
 *
 * Copyright 2006 VXI Technology Inc. as an unpublished work. 
 * All rights reserved. The information contained herein is confidential
 * property of VXI Technology, Inc. Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement 
 * with VXI Technology, Inc.
 *
 * PURPOSE: 
 *   Template class for various IVI properties
 *
 * First Written By: David Sigler On Jan-2007
 ******************************************************************************/

#ifndef _PROPERTY_TEMPLATE_
#define _PROPERTY_TEMPLATE_

#include "exTypes.h"

#define READ_ONLY   1
#define WRITE_ONLY  2
#define READ_WRITE  3

template<typename ValueType>
class PropertyArg
{
public:
    typedef ValueType Type;
};

template<>
class PropertyArg<VTEXString>
{
public:
    typedef const VTEXString &Type;
};

//#if defined(_WIN32) && _MSC_VER <= 1200  // MSVC6 workaround
#if defined(_WIN32) && (defined(DLL_EXPORTS) || defined(VTEX_DLL))  // MSVC6 DLL client workaround.
template<typename Container, typename ValueType, int access>
class VTEX_API property
{
public:
    property()
    {
        m_container = NULL;
        m_get = NULL;
        m_set = NULL;
    }

    void SetAttributes(Container *container,
        VTEXResult (Container::*get)(ValueType *value) = NULL,
        VTEXResult (Container::*set)(typename PropertyArg<ValueType>::Type value) = NULL)
    {
        m_container = container;
        m_get = get;
        m_set = set;
    }

    operator ValueType()
    {
        ValueType value;

        (m_container->*m_get)(&value);

        return value;
    }

    const ValueType &operator =(const ValueType &value)
    {
        (m_container->*m_set)(value);

        return value;
    }

private:
    Container *m_container;
    VTEXResult (Container::*m_get)(ValueType *value);
    VTEXResult (Container::*m_set)(typename PropertyArg<ValueType>::Type value);
};

#else // MSVC6 workaround
template<typename Container, typename ValueType, int access>
class VTEX_API property {};

template<typename Container, typename ValueType>
class VTEX_API property<Container, ValueType, READ_ONLY>
{
public:
    property()
    {
        m_container = NULL;
        m_get = NULL;
    }

    void SetAttributes(Container *container,
        VTEXResult (Container::*get)(ValueType *value))
    {
        m_container = container;
        m_get = get;
    }

    operator ValueType()
    {
        ValueType value;

        (m_container->*m_get)(&value);

        return value;
    }

private:
    Container *m_container;
    VTEXResult (Container::*m_get)(ValueType *value);
};

template<typename Container, typename ValueType>
class VTEX_API property<Container, ValueType, WRITE_ONLY>
{
public:
    property()
    {
        m_container = NULL;
        m_set = NULL;
    }

    void SetAttributes(Container *container,
        VTEXResult (Container::*set)(typename PropertyArg<ValueType>::Type value))
    {
        m_container = container;
        m_set = set;
    }

    const ValueType &operator =(const ValueType &value)
    {
        (m_container->*m_set)(value);

        return value;
    }

private:
    Container *m_container;
    VTEXResult (Container::*m_set)(typename PropertyArg<ValueType>::Type value);
};

template<typename Container, typename ValueType>
class VTEX_API property<Container, ValueType, READ_WRITE>
{
public:
    property()
    {
        m_container = NULL;
        m_get = NULL;
        m_set = NULL;
    }

    void SetAttributes(Container *container,
        VTEXResult (Container::*get)(ValueType *value),
        VTEXResult (Container::*set)(typename PropertyArg<ValueType>::Type value))
    {
        m_container = container;
        m_get = get;
        m_set = set;
    }

    operator ValueType()
    {
        ValueType value;

        (m_container->*m_get)(&value);

        return value;
    }

    const ValueType &operator =(const ValueType &value)
    {
        (m_container->*m_set)(value);

        return value;
    }

private:
    Container *m_container;
    VTEXResult (Container::*m_get)(ValueType *value);
    VTEXResult (Container::*m_set)(typename PropertyArg<ValueType>::Type value);
};
#endif // MSVC6 workaround

#endif //_PROPERTY_TEMPLATE_

