#ifndef VTEX_VISA_TYPES_H
#define VTEX_VISA_TYPES_H

#include <stdint.h>

/* Use installed SDK types without requiring the VISA runtime. */
#if defined(__has_include)
#if __has_include(<visatype.h>)
#include <visatype.h>
#endif
#endif

/* Standalone builds use the same fixed-width ABI, not the SDK's header guard. */
#ifndef __VISATYPE_HEADER__
typedef int16_t ViInt16;
typedef int32_t ViInt32;
typedef int64_t ViInt64;
typedef uint16_t ViBoolean;
typedef uint32_t ViUInt32;
typedef uint32_t ViSession;
typedef uint32_t ViAttr;
typedef int32_t ViStatus;
typedef double ViReal64;
typedef char ViChar;
typedef char *ViString;
typedef char *ViRsrc;
typedef const char *ViConstString;
#define VI_TRUE 1
#define VI_FALSE 0
#define VI_NULL 0
#define VI_SUCCESS 0
#endif

typedef char VtexVisaAbiWidths[
    sizeof(ViInt16) == 2 && sizeof(ViInt32) == 4 && sizeof(ViInt64) == 8 &&
    sizeof(ViBoolean) == 2 && sizeof(ViSession) == 4 && sizeof(ViAttr) == 4 &&
    sizeof(ViStatus) == 4 && sizeof(ViReal64) == 8 ? 1 : -1];

#endif
