//This example simulates the temperature output on channel 1

#include <iostream>
#ifndef _WIN32
#include <unistd.h>
#endif
#include <vector>
#include "libRTDSimulator.h"

using namespace std;

#define MAXCOUNT 10
int main(int argc, char* argv[])
{
  try
  {
    LibRTDSimulator* rtdSimulator = NULL;
    /*We want to do the Initialization in a try/catch block so that our test code
    doesn't run if we fail to create.*/
    rtdSimulator = LibRTDSimulator::Create();

    try
    {
      /*We chose to give the driver an empty options string. You may want to 
      give your driver options - check the manual to see the available settings.
      Note that we also set the Reset bit so that we get a clean start to work 
      from.*/
      rtdSimulator->Initialize("TCPIP::10.30.1.54::INSTR", true, true, "");

      //Configure mode to temperature
      rtdSimulator->Mode = VTEXRTDSimulatorModeTemperature;

      //Set one of the standard RTD type, should be Platinum or Copper 
      //EUConversion => engineering convesion unit. 
      //User can set one of the supported conversion units VTEXRTDSimulatorEUConversionDegreeC,
      //                                                   VTEXRTDSimulatorEUConversionKelvin,
      //                                                   VTEXRTDSimulatorEUConversionDegreeF
      rtdSimulator->Channels->Item["CH1"]->RTDType = VTEXRTDSimulatorRTDTypePT100_385;
      rtdSimulator->Channels->Item["CH1"]->EUConversion = VTEXRTDSimulatorEUConversionDegreeC;

      //Set the temperature output on channel 1.
      rtdSimulator->Channels->Item["CH1"]->Output = 100;

      //Enable channel 1.
      rtdSimulator->Channels->Item["CH1"]->Enabled = true;

      cout<<"Simulated Output on Channel: 1 "<<rtdSimulator->Channels->Item["CH1"]->Output<<endl;

      cout<<"\nCurrent Measured on Channel: 1\n"<<endl;
      //Get the exitation Current on channel 1
      //User can enter the MAXCOUNT number to get the measured current
      for(int i=0; i< MAXCOUNT; i++)
      {
        //Measuring current on channel 1
        cout<<"Current on Channel: 1 is\t"<<rtdSimulator->Channels->Item["CH1"]->MeasuredCurrent<<endl; 
        sleep(1);
      }

      //Close the initialized session
      rtdSimulator->Close();
    }
    catch (VTEXException e)
    {
      cout<<"Error code: \t"<<e.errorCode<<endl;
      cout<<"Error message: \n"<<e.errorMessage.c_str()<<endl;
    }
  }

  catch (...)
  {
    /*We put this here to catch any error the program generates.*/
    //Do something to intelligently deal with errors
  }

  cout<<"\nDone - Press Enter to Exit"<<endl;
  getchar();

  return 0;
}
