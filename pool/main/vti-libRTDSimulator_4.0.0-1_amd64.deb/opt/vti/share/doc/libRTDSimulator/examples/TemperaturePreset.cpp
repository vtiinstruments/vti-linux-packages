//This example simulates the temperature preset points on channel 1

#include <iostream>
#ifndef _WIN32
#include <unistd.h>
#endif
#include <vector>
#include "libRTDSimulator.h"

using namespace std;

#define MAXCOUNT 10
int main(int argc, char* argv[])
{
  try
  {
    LibRTDSimulator* rtdSimulator = NULL;
    /*We want to do the Initialization in a try/catch block so that our test code
    doesn't run if we fail to create.*/
    rtdSimulator = LibRTDSimulator::Create();

    try
    {
      /*We chose to give the driver an empty options string. You may want to 
      give your driver options - check the manual to see the available settings.
      Note that we also set the Reset bit so that we get a clean start to work 
      from.*/
      rtdSimulator->Initialize("TCPIP::10.30.1.54::INSTR", true, true, "");

      //Set mode to temperature preset
      rtdSimulator->Mode = VTEXRTDSimulatorModeTemperaturePreset;

      //Set one of the standard RTD type, should be Platinum or Copper 
      //EUConversion => engineering convesion unit. 
      //User can set one of the supported conversion units VTEXRTDSimulatorEUConversionDegreeC,
      //                                                   VTEXRTDSimulatorEUConversionKelvin,
      //                                                   VTEXRTDSimulatorEUConversionDegreeF
      rtdSimulator->Channels->Item["CH1"]->RTDType = VTEXRTDSimulatorRTDTypePT100_385;
      rtdSimulator->Channels->Item["CH1"]->EUConversion = VTEXRTDSimulatorEUConversionDegreeC;

      //Set Preset mode to cyclic
      //Cyclic Mode => keeps cycling through the set preset temperature points 
      //End Mode    => Keeps sending the last preset temperature point as trigger continues
      rtdSimulator->Channels->Item["CH1"]->Preset->Mode = VTEXRTDSimulatorPresetModeCyclic;

      //Set the TriggerIntput property to software
      //User needs to send the software trigger to update the next value
      rtdSimulator->Trigger->TriggerInput = VTEXRTDSimulatorTriggerInputSoftware;

      //User should specify the maximum values that needs to be created.
      //Valid preset points should contain at least 2 and goes up to maximum of 10.
      std::vector<double>presetPoints;
      presetPoints.push_back(50.2);
      presetPoints.push_back(120.0);
      presetPoints.push_back(200.0);

      //Sets the preset temperature points on channel 1
      rtdSimulator->Channels->Item["CH1"]->Preset->PutPresetPoints(presetPoints);

      //Enable the channel 1
      rtdSimulator->Channels->Item["CH1"]->Enabled = true;

      sleep(2);        //Added delay required for the DMM to update.
      //Initiate the card
      rtdSimulator->Initiate();

      int count  = 10; //Specifies the number for temperature output.
      for(int i = 0;  i < count;  i++)
      {
        //SendSoftwareTrigger, keeps sending the temperature data on the Front panel for the specified count
        //Minimum update rate is 10 milli seconds. 
        //User has to give at the time interval which should be > 10 milli seconds between two triggers
        sleep(1);
        rtdSimulator->Trigger->SendSoftwareTrigger();
        cout<<"Output on Channel: 1 is\t"<<rtdSimulator->Channels->Item["CH1"]->MeasuredResistance<<endl;
      }

      cout<<"\nCurrent Measured on Channel: 1\n"<<endl;
      //User can enter the MAXCOUNT number to get the measured current
      for(int i=0; i< MAXCOUNT; i++)
      {
        //Measuring current on channel 1
        cout<<"Current on Channel: 1 is\t"<<rtdSimulator->Channels->Item["CH1"]->MeasuredCurrent<<endl; 
        sleep(1);
      }

      //Aborts the initilized card
      rtdSimulator->Abort();
      //Close the initialized session
      rtdSimulator->Close();

    }
    catch (VTEXException e)
    {
      cout<<"Error code: \t"<<e.errorCode<<endl;
      cout<<"Error message: \n"<<e.errorMessage.c_str()<<endl;
    }
  }
  catch (...)
  {
    /*We put this here to catch any error the program generates.*/
    //Do something to intelligently deal with errors
  }

  cout<<"\nDone - Press Enter to Exit"<<endl;
  getchar();

  return 0;
}
