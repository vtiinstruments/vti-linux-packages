//This example simulates the resistance ramp on channel 1

#include <iostream>
#ifndef _WIN32
#include <unistd.h>
#endif
#include <vector>
#include "libRTDSimulator.h"

using namespace std;

#define MAXCOUNT 10
int main(int argc, char* argv[])
{
  try
  {
    LibRTDSimulator* rtdSimulator = NULL;
    /*We want to do the Initialization in a try/catch block so that our test code
    doesn't run if we fail to create.*/
    rtdSimulator = LibRTDSimulator::Create();

    try
    {
      /*We chose to give the driver an empty options string. You may want to 
      give your driver options - check the manual to see the available settings.
      Note that we also set the Reset bit so that we get a clean start to work 
      from.*/
      rtdSimulator->Initialize("TCPIP::10.30.1.54::INSTR", true, true, "");

      //Set mode to resistance Ramp
      rtdSimulator->Mode = VTEXRTDSimulatorModeResistanceRamp;

      //For ramp function we need to set the start and end resistance
      //Property Output is used to set the start resistance and property EndResistance is for setting the end resistance.
      rtdSimulator->Channels->Item["CH1"]->Output = 200.0;
      rtdSimulator->Channels->Item["CH1"]->Ramp->EndResistance = 2000.0;

      //Sets the time to ramp from start to end resistance
      rtdSimulator->Channels->Item["CH1"]->Ramp->RampTime = 10;

      //User can set this property for trigger output
      //The card starts ramping from start resistamce towards end. Upon reaching the trigger level,
      //marker output trigger pulse will be sent out of the card. User needs to make sure that the trigger level will be set between start and end resistance.
      // ( Start resistance < Triggerlevel  < End resistance )
      rtdSimulator->Channels->Item["CH1"]->Ramp->TriggerOutputLevel = 1000;

      //Set the TriggerIntput property to software and TriggerOutput property to BPL0
      //User needs to send the software trigger to get the resistance output on front panel
      //Set the output reference channel to identify channel referred for trigger output
      rtdSimulator->Trigger->TriggerInput = VTEXRTDSimulatorTriggerInputSoftware;
      rtdSimulator->Trigger->TriggerOutput = VTEXRTDSimulatorTriggerOutputFrontpanel;
      rtdSimulator->Trigger->TriggerOutputReferenceChannel = "CH1";

      //Enable the channel 1
      rtdSimulator->Channels->Item["CH1"]->Enabled = true;

      sleep(2);         //Added delay required for the DMM to update.
      //Initiate the card
      rtdSimulator->Initiate();

      sleep(2);            //Added delay required for the DMM to update.
      //SendSoftwareTrigger should be send to start ramp
      rtdSimulator->Trigger->SendSoftwareTrigger();

      cout<<"\nCurrent and Resistance Measured on Channel: 1\n"<<endl;
      //Get the exitation Current on channel 1
      //User can enter the MAXCOUNT number to get the measured current
      for(int i=0; i< MAXCOUNT; i++)
      {
        //Measuring current on channel 1
        //Get the resistance output at that instance of call on Channel 1
        cout<<"Current on Channel: 1  is\t"<<rtdSimulator->Channels->Item["CH1"]->MeasuredCurrent<<endl; 
        cout<<"Resistance on Channel: 1 is\t"<<rtdSimulator->Channels->Item["CH1"]->MeasuredResistance<<endl;
        sleep(1);
      }

      //Aborts the initilized card
      rtdSimulator->Abort();
      //Close the initialized session
      rtdSimulator->Close();

    }
    catch (VTEXException e)
    {
      cout<<"Error code: \t"<<e.errorCode<<endl;
      cout<<"Error message: \n"<<e.errorMessage.c_str()<<endl;
    }
  }

  catch (...)
  {
    /*We put this here to catch any error the program generates.*/
    //Do something to intelligently deal with errors
  }

  cout<<"\nDone - Press Enter to Exit"<<endl;
  getchar();

  return 0;
}
