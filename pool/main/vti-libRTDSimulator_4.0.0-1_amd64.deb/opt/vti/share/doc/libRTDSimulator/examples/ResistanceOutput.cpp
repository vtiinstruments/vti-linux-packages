//This example simulates the resistance Output on channel 1 and channel 2

#include <iostream>
#include <vector>
#ifndef _WIN32
#include <unistd.h>
#endif
#include "libRTDSimulator.h"

using namespace std;

#define MAXCOUNT 10
int main(int argc, char* argv[])
{
  try
  {
    LibRTDSimulator* rtdSimulator = NULL;
    /*We want to do the Initialization in a try/catch block so that our test code
    doesn't run if we fail to create.*/
    rtdSimulator = LibRTDSimulator::Create();

    try
    {
      /*We chose to give the driver an empty options string. You may want to 
      give your driver options - check the manual to see the available settings.
      Note that we also set the Reset bit so that we get a clean start to work 
      from.*/      
      rtdSimulator->Initialize("TCPIP::10.30.1.54::INSTR", true, true, "");

      //Configure mode to resistance
      rtdSimulator->Mode = VTEXRTDSimulatorModeResistance;

      //Set the resistance output on channel 1 and enable the channel. 
      rtdSimulator->Channels->Item["CH1"]->Output = 2000;               //Resistance input in Ohm
      rtdSimulator->Channels->Item["CH1"]->Enabled = true;

      //Set the resistance output on channel 2 and enable the channel.
      rtdSimulator->Channels->Item["CH2"]->Output = 3000;               //Resistance input in Ohm
      rtdSimulator->Channels->Item["CH2"]->Enabled = true;


      cout<<"Simulated output on channel: 1 "<<rtdSimulator->Channels->Item["CH1"]->Output<<endl;
      cout<<"Simulated output on channel: 2 "<<rtdSimulator->Channels->Item["CH2"]->Output<<endl;

      cout<<"\nCurrent Measured on Channel's\n"<<endl;
      //Get the exitation Current on channel 1 and channel 2
      //User can enter the MAXCOUNT number to get the measured current
      for(int i=0; i< MAXCOUNT; i++)
      {
        //Measuring current on channel 1 and channel 2
        cout<<"Current on Channel: 1 is\t"<<rtdSimulator->Channels->Item["CH1"]->MeasuredCurrent<<endl; 
        cout<<"Current on Channel: 2 is\t"<<rtdSimulator->Channels->Item["CH2"]->MeasuredCurrent<<endl;
        sleep(1);
      }

      //Close the initialized session
      rtdSimulator->Close();
    }
    catch (VTEXException e)
    {
      cout<<"Error code: \t"<<e.errorCode<<endl;
      cout<<"Error message: \n"<<e.errorMessage.c_str()<<endl;
    }
  }

  catch (...)
  {
    /*We put this here to catch any error the program generates.*/
    //Do something to intelligently deal with errors
  }

  cout<<"\nDone - Press Enter to Exit"<<endl;
  getchar();

  return 0;
}

