#include "exErrors.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#if defined(_WIN32) && !defined(_CVI_)
#define INLINE __inline
#else
#define INLINE inline
#endif

#ifdef __cplusplus
extern "C" {
#endif

 //!
 //! @file
 //!
 //! RTDSimulator constants
 //!
#ifndef _RTDSimulatorConstants_H
#define _RTDSimulatorConstants_H

 // IVI compliant constants for this driver

enum VTEXRTDSimulatorModeEnum
{
  VTEXRTDSimulatorModeOpen = 1000,
  VTEXRTDSimulatorModeShort = 1001,
  VTEXRTDSimulatorModeResistance = 1002,
  VTEXRTDSimulatorModeResistanceRamp = 1003,
  VTEXRTDSimulatorModeResistancePreset = 1004,
  VTEXRTDSimulatorModeTemperature = 1005,
  VTEXRTDSimulatorModeTemperaturePreset = 1006
};


enum VTEXRTDSimulatorEUConversionEnum
{
  VTEXRTDSimulatorEUConversionDegreeC = 1000,
  VTEXRTDSimulatorEUConversionKelvin = 1001,
  VTEXRTDSimulatorEUConversionDegreeF = 1002
};

enum VTEXRTDSimulatorRTDTypeEnum
{
  VTEXRTDSimulatorRTDTypePT100_385 = 1000,
  VTEXRTDSimulatorRTDTypePT200_385 = 1001,
  VTEXRTDSimulatorRTDTypePT500_385 = 1002,
  VTEXRTDSimulatorRTDTypePT1000_385 = 1003,
  VTEXRTDSimulatorRTDTypePT100_392 = 1004,
  VTEXRTDSimulatorRTDTypePT200_392 = 1005,
  VTEXRTDSimulatorRTDTypePT500_392 = 1006,
  VTEXRTDSimulatorRTDTypeCU10 = 1007,
  VTEXRTDSimulatorRTDTypeCU100 = 1008
};

enum VTEXRTDSimulatorPresetModeEnum
{
  VTEXRTDSimulatorPresetModeCyclic = 1000,
  VTEXRTDSimulatorPresetModeEnd = 1001
};


enum VTEXRTDSimulatorTriggerInputEnum
{
  VTEXRTDSimulatorTriggerInputSoftware = 1000,
  VTEXRTDSimulatorTriggerInputFrontpanel = 1001,
  VTEXRTDSimulatorTriggerInputBPL0 = 1002,
  VTEXRTDSimulatorTriggerInputBPL1 = 1003,
  VTEXRTDSimulatorTriggerInputBPL2 = 1004,
  VTEXRTDSimulatorTriggerInputBPL3 = 1005,
  VTEXRTDSimulatorTriggerInputBPL4 = 1006,
  VTEXRTDSimulatorTriggerInputBPL5 = 1007,
  VTEXRTDSimulatorTriggerInputBPL6 = 1008,
  VTEXRTDSimulatorTriggerInputBPL7 = 1009
};

enum VTEXRTDSimulatorTriggerOutputEnum
{
  VTEXRTDSimulatorTriggerOutputNone = 1000,
  VTEXRTDSimulatorTriggerOutputFrontpanel = 1001,
  VTEXRTDSimulatorTriggerOutputBPL0 = 1002,
  VTEXRTDSimulatorTriggerOutputBPL1 = 1003,
  VTEXRTDSimulatorTriggerOutputBPL2 = 1004,
  VTEXRTDSimulatorTriggerOutputBPL3 = 1005,
  VTEXRTDSimulatorTriggerOutputBPL4 = 1006,
  VTEXRTDSimulatorTriggerOutputBPL5 = 1007,
  VTEXRTDSimulatorTriggerOutputBPL6 = 1008,
  VTEXRTDSimulatorTriggerOutputBPL7 = 1009
};

enum VTEXRTDSimulatorCalibrationGainEnum
{
  VTEXRTDSimulatorCalibrationGainx1 = 1000,
  VTEXRTDSimulatorCalibrationGainx10 = 1001
};

enum VTEXRTDSimulatorCalibrationConstantEnum
{
  VTEXRTDSimulatorCalibrationConstantCurrentADCGain1x = 1000,
  VTEXRTDSimulatorCalibrationConstantCurrentADCOffset1x = 1001,
  VTEXRTDSimulatorCalibrationConstantCurrentADCGain10x = 1002,
  VTEXRTDSimulatorCalibrationConstantCurrentADCOffset10X = 1003,
  VTEXRTDSimulatorCalibrationConstantVoltageADCGain1x = 1004,
  VTEXRTDSimulatorCalibrationConstantVoltageADCOffset1x = 1005,
  VTEXRTDSimulatorCalibrationConstantVoltageADCGain10x = 1006,
  VTEXRTDSimulatorCalibrationConstantVoltageADCOffset10X = 1007,
  VTEXRTDSimulatorCalibrationConstantProportionalGain = 1008,
  VTEXRTDSimulatorCalibrationConstantDate = 1009,
  VTEXRTDSimulatorCalibrationConstantDueDate = 1010
};
#endif /* ! _RTDSimulatorConstants_H */

#ifdef  __cplusplus
}
#endif

