/******************************************************************************
*
*  .----------------------.
*  |==     ==  ======  == | $Author$
*  | ==   ==   ======  == | $Revision$ 
*  |  == ==      ==    == | $Date$ 
*  |   ===       ==    == | $HeadURL: http://10.1.0.10/svn/nextgen/trunk/software/Instrument_drivers/libVTEX/libRTDSimulator/libRTDSimulator.h$
*  |    =        ==    == |
*  `----------------------'
*
* Copyright 2010 VTI Instruments Inc. as an unpublished work.
* All rights reserved. The information contained herein is confidential
* property of VTI Instruments, Inc. Use, copy, transfer or disclosure
* of such information is prohibited except by express written agreement
* with VTI Instruments, Inc.
*
* PURPOSE: 
*   Class definition of the libRTDSimulator class
*
******************************************************************************/

#ifndef _LIB_RTDSIM_H
#define _LIB_RTDSIM_H

/* System Header */
#include <vector>

/* Local Header */
#include "vtexapi.h"
#include "vtexException.h"
#include "libInherent.h"

#ifndef _ATL_ATTRIBUTES
#include "RTDSimulatorConstants.h"
#endif

#include "CommonErrors.h"
#include "RTDSimulatorErrors.h"

//=============================================================================

/**
 * RTDSimulator.Channels.Item.Ramp
 *
 */

class VTEX_API LibRTDSimulatorRamp
{
public:
  virtual ~LibRTDSimulatorRamp() { };

  //properties
  property <LibRTDSimulatorRamp, double, READ_WRITE> EndResistance;
  property <LibRTDSimulatorRamp, double, READ_WRITE> RampTime;
  property <LibRTDSimulatorRamp, double, READ_WRITE> TriggerOutputLevel;

  //properties methods
  virtual VTEXResult put_EndResistance(double value)      = 0;
  virtual VTEXResult get_EndResistance(double* value)     = 0;
  virtual VTEXResult put_RampTime(double value)           = 0;
  virtual VTEXResult get_RampTime(double* value)          = 0;
  virtual VTEXResult put_TriggerOutputLevel(double value) = 0;
  virtual VTEXResult get_TriggerOutputLevel(double* value)= 0;

  // methods
  virtual VTEXResult Configure(double endResistance, double rampTime, double triggerOutputLevel ) = 0;
};

//=============================================================================

/**
 * RTDSimulator.Channels.Item.Preset
 * 
 */

class LibRTDSimulatorPreset
{
public:
  virtual ~LibRTDSimulatorPreset() { };

  //properties
  property <LibRTDSimulatorPreset, VTEXRTDSimulatorPresetModeEnum, READ_WRITE> Mode;

  //properties methods
  virtual VTEXResult put_Mode(VTEXRTDSimulatorPresetModeEnum value)  = 0;
  virtual VTEXResult get_Mode(VTEXRTDSimulatorPresetModeEnum* value) = 0;

  // methods
  virtual VTEXResult PutPresetPoints(std::vector<double> PresetPoints)   = 0;
  virtual VTEXResult GetPresetPoints(std::vector<double> &PresetPoints)  = 0;
};

//=============================================================================

/**
 * RTDSimulator.Channels.Item
 *
 */

class VTEX_API LibRTDSimulatorChannel
{
public:
  virtual ~LibRTDSimulatorChannel() { };

  // Ramp and Preset Interfaces
  LibRTDSimulatorRamp      *Ramp;
  LibRTDSimulatorPreset    *Preset;

  //Datamembers
  property <LibRTDSimulatorChannel, bool, READ_WRITE> Enabled;
  property <LibRTDSimulatorChannel, double, READ_WRITE> Output;
  property <LibRTDSimulatorChannel, bool, READ_ONLY> LatchedOverCurrent;
  property <LibRTDSimulatorChannel, bool, READ_ONLY> OverCurrent;
  property <LibRTDSimulatorChannel, VTEXRTDSimulatorEUConversionEnum, READ_WRITE> EUConversion;
  property <LibRTDSimulatorChannel, VTEXRTDSimulatorRTDTypeEnum, READ_WRITE> RTDType;
  property <LibRTDSimulatorChannel, double, READ_ONLY> MeasuredCurrent;
  property <LibRTDSimulatorChannel, double, READ_ONLY> MeasuredResistance;

  // Property methods
  virtual VTEXResult put_Enabled(bool value)    = 0;
  virtual VTEXResult get_Enabled(bool* value)   = 0;
  virtual VTEXResult put_Output(double value)   = 0;
  virtual VTEXResult get_Output(double* value)  = 0;
  virtual VTEXResult get_LatchedOverCurrent(bool* value) = 0;
  virtual VTEXResult get_OverCurrent(bool* value) = 0;
  virtual VTEXResult put_EUConversion(VTEXRTDSimulatorEUConversionEnum value) = 0;
  virtual VTEXResult get_EUConversion(VTEXRTDSimulatorEUConversionEnum* value) = 0;
  virtual VTEXResult put_RTDType(VTEXRTDSimulatorRTDTypeEnum  value)    = 0;
  virtual VTEXResult get_RTDType(VTEXRTDSimulatorRTDTypeEnum* value)    = 0;
  virtual VTEXResult get_MeasuredCurrent(double* value)     = 0;
  virtual VTEXResult get_MeasuredResistance(double* value)  = 0;

  // methods
  virtual VTEXResult ConfigureTemperature(VTEXRTDSimulatorRTDTypeEnum RTD_Type,VTEXRTDSimulatorEUConversionEnum EU_Conversion) = 0;
  virtual VTEXResult GetCoefficients(std::vector<double> &RTD)    = 0;
  virtual VTEXResult ResetOverCurrent(void)                               = 0;
};

//=============================================================================

/**
 * RTDSimulator.Channels
 *
 */

class VTEX_API LibRTDSimulatorChannels
{
public:
  virtual ~LibRTDSimulatorChannels() { };

  //Properties
  property <LibRTDSimulatorChannels, int32_t, READ_ONLY> Count;
  arrayizer <LibRTDSimulatorChannels, LibRTDSimulatorChannel*, const VTEXString&> Item;
  arrayizer <LibRTDSimulatorChannels, VTEXString, int32_t> Name;

  //Methods
  virtual VTEXResult get_Count(int32_t* count)                    = 0;
  virtual LibRTDSimulatorChannel* get_Item(const VTEXString& channelName)     = 0;
  virtual VTEXString get_Name(int32_t repCapIndex)                = 0;
};

//=============================================================================
/**
 * RTDSimulator.Platform
 *
 */

class VTEX_API LibRTDSimulatorPlatform
{
public:
  virtual ~LibRTDSimulatorPlatform() {};

  // Properties
  property <LibRTDSimulatorPlatform, VTEXString, READ_ONLY> SerialNumber;

  // Property methods
  virtual VTEXResult get_SerialNumber(VTEXString *value)    = 0;

  // Methods
  virtual VTEXResult CloseLogFile(void)                     = 0;
  virtual VTEXResult OpenLogFile(VTEXString FileName, VTEXString AccessMode)= 0;
};

//=============================================================================
/**
 * RTDSimulator.Trigger
 *
 */

class VTEX_API LibRTDSimulatorTrigger
{
public:
  virtual ~LibRTDSimulatorTrigger() { };

  // Properties
  property <LibRTDSimulatorTrigger, VTEXRTDSimulatorTriggerInputEnum , READ_WRITE> TriggerInput;
  property <LibRTDSimulatorTrigger, VTEXString , READ_WRITE> TriggerOutputReferenceChannel;
  property <LibRTDSimulatorTrigger, VTEXRTDSimulatorTriggerOutputEnum , READ_WRITE> TriggerOutput;

  // Properties methods
  virtual VTEXResult put_TriggerInput(VTEXRTDSimulatorTriggerInputEnum value)   = 0;
  virtual VTEXResult get_TriggerInput(VTEXRTDSimulatorTriggerInputEnum* value)  = 0;
  virtual VTEXResult put_TriggerOutputReferenceChannel(const VTEXString& value) = 0;
  virtual VTEXResult get_TriggerOutputReferenceChannel(VTEXString* value)       = 0;
  virtual VTEXResult put_TriggerOutput(VTEXRTDSimulatorTriggerOutputEnum value) = 0;
  virtual VTEXResult get_TriggerOutput(VTEXRTDSimulatorTriggerOutputEnum* value)= 0;

  // methods
  virtual VTEXResult SendSoftwareTrigger(void) = 0;
};

//=============================================================================
/**
 * RTDSimulator.Calibration.Card
 *
 */

class LibRTDSimulatorCalibrationCard
{
public:
  virtual ~LibRTDSimulatorCalibrationCard(){};

  property <LibRTDSimulatorCalibrationCard, bool, READ_WRITE> BackplaneConnectionEnabled;
  property <LibRTDSimulatorCalibrationCard, VTEXString, READ_WRITE> BackplaneConnectionChannel;

  virtual VTEXResult put_BackplaneConnectionEnabled(bool enable)              = 0;
  virtual VTEXResult get_BackplaneConnectionEnabled(bool* enable)             = 0;
  virtual VTEXResult put_BackplaneConnectionChannel(const VTEXString& channel)= 0;
  virtual VTEXResult get_BackplaneConnectionChannel(VTEXString* channel)      = 0;

  virtual VTEXResult put_RawDac(VTEXString channel, int32_t data)         = 0;
  virtual VTEXResult get_RawDac(VTEXString channel, int32_t *data)        = 0;
  virtual VTEXResult put_RawDigipot(VTEXString channel, int32_t data)     = 0;
  virtual VTEXResult get_RawDigipot(VTEXString channel, int32_t *data)    = 0;
  virtual VTEXResult put_VoltageGain(VTEXString channel, VTEXRTDSimulatorCalibrationGainEnum gain)    = 0;
  virtual VTEXResult get_VoltageGain(VTEXString channel, VTEXRTDSimulatorCalibrationGainEnum* gain)   = 0;
  virtual VTEXResult put_CurrentGain(VTEXString channel, VTEXRTDSimulatorCalibrationGainEnum gain)    = 0;
  virtual VTEXResult get_CurrentGain(VTEXString channel, VTEXRTDSimulatorCalibrationGainEnum* gain)   = 0;

  virtual VTEXResult get_RawVoltage(VTEXString channel, int32_t *data)    = 0;
  virtual VTEXResult get_RawCurrent(VTEXString channel, int32_t *data)    = 0;
};

//=============================================================================
/**
 * RTDSimulator.Calibration
 *
 */

class VTEX_API LibRTDSimulatorCalibration
{
public:
  virtual ~LibRTDSimulatorCalibration() {};

  LibRTDSimulatorCalibrationCard  *Card;

  property <LibRTDSimulatorCalibration, bool, READ_WRITE> CalMode;

  virtual VTEXResult put_CalMode(bool mode)   = 0;
  virtual VTEXResult get_CalMode(bool* mode)  = 0;

  virtual VTEXResult Load(int32_t CalibrationSet)                     = 0;
  virtual VTEXResult Save(int32_t CalibrationSet, int32_t Password)   = 0;
  virtual VTEXResult Read(VTEXString ChannelName, VTEXRTDSimulatorCalibrationConstantEnum  Type,
    double *Value)                            = 0;
  virtual VTEXResult Write(VTEXString ChannelName, VTEXRTDSimulatorCalibrationConstantEnum Type,
    double Value)                                           = 0;
  virtual VTEXResult ReadFile(int32_t CalibrationSet, VTEXString &String) = 0;
  virtual VTEXResult WriteFile(int32_t CalibrationSet, int32_t Password, VTEXString Data)    = 0;
};

//=============================================================================
/**
 * RTDSimulator.base class
 *
 */

class VTEX_API LibRTDSimulator : public LibInherent
{
public:
  static LibRTDSimulator* Create();
  virtual ~LibRTDSimulator() { };

  //Inherent capability
  property <LibRTDSimulator, bool, READ_ONLY> Initialized;
  LibInherentCapabilityUtility*          Utility;
  LibInherentCapabilityDriverOperation*  DriverOperation;
  LibInherentCapabilityIdentity*         Identity;

  // Properties
  property <LibRTDSimulator, bool, READ_ONLY> BackplaneFailsafe;
  property <LibRTDSimulator, VTEXRTDSimulatorModeEnum, READ_WRITE> Mode;

  // Property methods
  virtual VTEXResult get_BackplaneFailsafe(bool* value)=0;
  virtual VTEXResult put_Mode(VTEXRTDSimulatorModeEnum  value)    = 0;
  virtual VTEXResult get_Mode(VTEXRTDSimulatorModeEnum* value)    = 0;
  virtual VTEXResult put_Delay(int32_t  value)    = 0;
  virtual VTEXResult get_Delay(int32_t* value)    = 0;
  virtual VTEXResult Initiate(void)                               = 0;
  virtual VTEXResult Abort(void)                                  = 0;

  LibRTDSimulatorChannels*    Channels;
  LibRTDSimulatorTrigger*     Trigger;
  LibRTDSimulatorPlatform*    Platform;
  LibRTDSimulatorCalibration* Calibration;
};
#endif
