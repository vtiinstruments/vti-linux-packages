#include <iostream>
#include "libDigitizer.h"

// Forward declaration for a utility function
void print_channel_strain_configuration(LibDigitizer *driver, std::string ch);

int main(int argc, char **argv)
{
    // NOTE: This example program is written specifically for the EX1403A.
    // The configuration is similar for other strain instruments, but the supported features may be different.
    // Refer to the instrument's user's manual for additional information.

    // This example demonstrates how to configure channels for standard bridge types and includes a short data acquisition.
    // It also includes information on how to maximize measurement accuracy.
    // The acquired data is not displayed.

    // We will use the following channel configurations:
    // CH1: quarter-bridge strain gauge (with 350 ohm completion, measuring axial or bending strain)
    // CH2: half-bridge strain gauge (measuring bending strain only, with one gauge measuring tensile strain and the other measuring compressive strain)
    // CH3: full-bridge strain gauge (measuring bending strain only, with one gauge each measuring tensile strain, compressive strain, tensile Poisson effect, and compressive Poisson effect)

    // Refer to the "Bridge Configurations" section in the EX1403A user's manual for detailed wiring diagrams. A summary is provided here.
    // The EX1403A uses the industry-standard RJ-45 input connector.
    // Pin 1: Excitation +
    // Pin 2: Excitation -
    // Pin 3: Sense -
    // Pin 4: RCal + (shunt calibration)
    // Pin 5: RCal - (shunt calibration)
    // Pin 6: Sense +
    // Pin 7: Excitation Sense -
    // Pin 8: Excitation Sense +

    // Quarter-bridge wiring
    // For a standard 3-wire configuration, connect Excitation + and Excitation - to the strain gauge.
    // Sense - should also be connected to the gauge on the same side as Excitation -
    // The Excitation Sense lines are not used and must be left open, as opposed to being grounded or tied together.
    // The shunt calibration lines are not used in this configuration, but can be connected (as described in the user's manual) for remote shunt calibration.

    // Half-bridge wiring
    // Connect the gauge in tension to pin 1 (excitation +) and pin 3 (sense -).
    // Connect the gauge in compression to pin 2 (excitation -) and pin 3 (sense -).
    // The excitation sense lines should be connected to the bridge at the same points as the excitation lines.
    // The shunt calibration lines should also be connected on both sides of any one gauge (as described in the user's manual) to maximize measurement accuracy.

    // Full-bridge wiring
    // Connect the gauges in tension from pin 1 (excitation +) to pin 6 (sense +) and from pin 2 (excitation -) to pin 3 (sense -).
    // Connect the gauges in compression from pin 2 (excitation -) to pin 6 (sense +) and from pin 1 (excitation +) to pin 3 (sense -).
    // The excitation sense lines should be connected to the bridge at the same points as the excitation lines.
    // The shunt calibration lines should also be connected on both sides of any one gauge (as described in the user's manual) to maximize measurement accuracy.

    LibDigitizer *driver;
    try
    {
        // Create a new instance of the Digitizer driver
        driver = LibDigitizer::Create();
        try
        {
            // The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::INSTR
            if (argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // Initialize the Digitizer driver
            driver->Initialize(resource_string, true, true);
            std::cout << "Initialized to " << resource_string << std::endl;

            // Keeping all channels on the 10V range while configuring channels will improve measurement accuracy
            driver->Channels->Item["ALL"]->Range = 10.0;

            // We'll also disable all channels and then enable the channels we actually care about (only those that have a strain gauge connected)
            driver->Channels->Item["ALL"]->Enabled = false;

            // Channel groups make it much easier to set several channels to the same property values at the same time
            std::string ch_qtr = "CH1";
            std::string ch_half = "CH2";
            std::string ch_full = "CH3";
            std::string strain_group = "StrainChannels";
            std::string strain_channels = "CH1,CH2,CH3";
            driver->Channels->AddChannelGroup(strain_group, strain_channels);

            // Use the channel group to enable the channels with strain gauges connected and set the function to Strain
            driver->Channels->Item[strain_group]->Enabled = true;
            driver->Channels->Item[strain_group]->Function = VTEXDigitizerChannelFunctionStrain;

            // Quarter-bridge configuration
            driver->Channels->Item[ch_qtr]->Strain->BridgeType = VTEXDigitizerBridgeTypeQuarter350;
            // All of the strain gauges require voltage excitation - we'll use a nominal excitation level of 5 volts
            driver->Channels->Item[ch_qtr]->Strain->ExcitationType = VTEXDigitizerExcitationTypeVoltage;
            driver->Channels->Item[ch_qtr]->Strain->ExcitationLevel = 5.0;
            // The manufacturer prints the exact gauge factor on the packaging (typical value is 2.0)
            driver->Channels->Item[ch_qtr]->Strain->GaugeFactor = 2.04;
            // The nominal (unstrained) resistance of the strain gauge is 350 ohms, but setting the exact value improves accuracy.
            // Use an ohmmeter to measure the total network resistance of the bridge between the positive and negative Excitation connection points.
            driver->Channels->Item[ch_qtr]->Strain->OhmGaugeResistance = 350.16;

            // Half-bridge configuration
            driver->Channels->Item[ch_half]->Strain->BridgeType = VTEXDigitizerBridgeTypeHalfBending;
            // All of the strain gauges require voltage excitation - we'll use a nominal excitation level of 5 volts
            driver->Channels->Item[ch_half]->Strain->ExcitationType = VTEXDigitizerExcitationTypeVoltage;
            driver->Channels->Item[ch_half]->Strain->ExcitationLevel = 5.0;
            // The manufacturer prints the exact gauge factor on the packaging (typical value is 2.0)
            driver->Channels->Item[ch_half]->Strain->GaugeFactor = 2.02;
            // Use an ohmmeter to measure the total network resistance of the bridge between the positive and negative Excitation connection points.
            driver->Channels->Item[ch_half]->Strain->OhmGaugeResistance = 700.03;

            // Full-bridge poisson configuration
            driver->Channels->Item[ch_full]->Strain->BridgeType = VTEXDigitizerBridgeTypeFullPoissonBending;
            // All of the strain gauges require voltage excitation - we'll use a nominal excitation level of 5 volts
            driver->Channels->Item[ch_full]->Strain->ExcitationType = VTEXDigitizerExcitationTypeVoltage;
            driver->Channels->Item[ch_full]->Strain->ExcitationLevel = 5.0;
            // The manufacturer prints the exact gauge factor on the packaging (typical value is 2.0)
            driver->Channels->Item[ch_full]->Strain->GaugeFactor = 1.99;
            // Use an ohmmeter to measure the total network resistance of the bridge between the positive and negative Excitation connection points.
            driver->Channels->Item[ch_full]->Strain->OhmGaugeResistance = 349.98;
            // Poisson Ratio is the Poisson's ratio (ν) of the strain gauge elements in use. It's used in the EU conversion for this type of strain gauge.
            driver->Channels->Item[ch_full]->Strain->PoissonRatio = 0.3;

            // Now set the strain channels to use the 100mV range - this needs to be done after configuring the strain properties to improve accuracy
            driver->Channels->Item[strain_group]->Range = 0.1;

            // Strain accuracy is improved by measuring the unstrained voltage and performing a shunt calibration
            // We can throw away the measured values, since performing the measurement updates the corresponding properties
            double unstrained_volts, shunt_gain;

            driver->Channels->Item[ch_qtr]->Strain->MeasureUnstrainedVoltage(unstrained_volts);
            // For quarter bridge, we set RemoteShuntEnabled to false since we're using a 3-wire connection.
            // If we also connected Rcal+/Rcal- to the quarter bridge, we could set RemoteShuntEnabled to true.
            driver->Channels->Item[ch_qtr]->Strain->RemoteShuntEnabled = false;
            driver->Channels->Item[ch_qtr]->Strain->MeasureShuntCalibrationGain(shunt_gain);

            driver->Channels->Item[ch_half]->Strain->MeasureUnstrainedVoltage(unstrained_volts);
            // RemoteShuntEnabled has to be true for half-bridge configurations.
            driver->Channels->Item[ch_half]->Strain->RemoteShuntEnabled = true;
            driver->Channels->Item[ch_half]->Strain->MeasureShuntCalibrationGain(shunt_gain);

            driver->Channels->Item[ch_full]->Strain->MeasureUnstrainedVoltage(unstrained_volts);
            // RemoteShuntEnabled has to be true for full-bridge configurations.
            driver->Channels->Item[ch_full]->Strain->RemoteShuntEnabled = true;
            driver->Channels->Item[ch_full]->Strain->MeasureShuntCalibrationGain(shunt_gain);

            // As the last step before performing the measurement, we'll query some strain properties that were measured or are calibrated
            print_channel_strain_configuration(driver, ch_qtr);
            print_channel_strain_configuration(driver, ch_half);
            print_channel_strain_configuration(driver, ch_full);

            // Set appropriate parameters for the measurement - each block of data will be 1 second long (100 samples per enabled channel, sampling at 100 Hz)
            double sample_rate = 100;
            int record_size = 100;
            // The clock frequency needs to be set to 102400 Hz to be able to set the sample rate to exactly 100 Hz
            // See the user's manual for more information about the sampling properties and how they interact
            driver->Measurement->Sampling->ClockFrequency = 102400;
            driver->Measurement->Sampling->SampleRate = sample_rate;
            driver->Measurement->Sampling->RecordSize = record_size;

            // We want to acquire 10 seconds of data
            int num_records = 10;
            driver->Measurement->NumRecordsPerTrigger = num_records;

            // Initiate the acquisition, wait for it to complete, and then read the data
            int meas_timeout_ms = num_records * 1000;
            driver->Measurement->Initiate();
            driver->Measurement->WaitForMeasurementComplete(meas_timeout_ms);

            // Read acquired Data
            int actual_recs;
            std::string channel;
            std::vector<double> data;
            std::vector<double> ts_sec;
            std::vector<double> ts_frac;
            std::string addl_data;
            int read_timeout_ms = num_records * 1000;
            driver->Measurement->Read(num_records, -1, actual_recs, channel, data,
                    ts_sec, ts_frac, addl_data);

            driver->Measurement->Abort();
            driver->Close();
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(driver->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    driver->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(driver->Initialized)
            {
                driver->Close();
            }
        }

        //Clean up when we're done
        delete driver;
        driver = nullptr;
    }
    catch(...)
    {
        // Handle non VTEX errors in an intelligent manner
    }
}

void print_channel_strain_configuration(LibDigitizer *driver, std::string ch)
{
    std::cout << "Channel: " << ch << std::endl;

    LibDigitizerChannel* pChan = driver->Channels->Item[ch];

    double exc_level = pChan->Strain->ExcitationLevel;
    std::cout << "Calibrated Excitation Level: " << exc_level << " (volts)" << std::endl;

    VTEXDigitizerBridgeTypeEnum bridge_type = pChan->Strain->BridgeType;
    if (bridge_type == VTEXDigitizerBridgeTypeQuarter120 ||
        bridge_type == VTEXDigitizerBridgeTypeQuarter350 ||
        bridge_type == VTEXDigitizerBridgeTypeQuarter1000)
    {
        double completion = pChan->Strain->CompletionResistance;
        std::cout << "Calibrated Completion Resistance: " << completion << " (ohms)" << std::endl;
    }

    double unstrained_volts = pChan->Strain->UnstrainedVoltage;
    std::cout << "Unstrained Voltage: " << unstrained_volts << std::endl;

    double shunt_cal_gain = pChan->Strain->ShuntCalibrationGain;
    std::cout << "Shunt Calibration Gain: " << shunt_cal_gain << std::endl;

    std::cout << std::endl;
}
