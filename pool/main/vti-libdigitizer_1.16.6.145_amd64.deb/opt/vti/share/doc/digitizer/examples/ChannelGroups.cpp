#include <iostream>
#include "libDigitizer.h"

int main(int argc, char **argv)
{
    LibDigitizer *digitizer;
    try {
        // Create a new instance of the Digitizer driver
        digitizer = LibDigitizer::Create();
        try{
            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             * The pipe character (|) is used to separate hostnames for multiple devices, e.g., hostname1|hostname2
             */
            if (argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // connect to both EMX-4250 and RX0124 devices - at least one of each
            digitizer->Initialize(resource_string, true, true, "");
            std::cout << "Initialized to " << resource_string << std::endl;

            std::string models = digitizer->Platform->InstrumentModel;
            std::cout << "Models: " << models << std::endl;

            // set the clock frequency to a value supported by all devices
            digitizer->Measurement->Sampling->ClockFrequency = 102400;

            // set all channels to use the 2.0 volt range, which is supported by all devices
            digitizer->Channels->Item["ALL"]->Range = 2.0;

            // create a new channel group containing the first 3 channels and set those to use the 10.0 volt range
            std::string group_name = "Channels10V";
            std::string name1 = digitizer->Channels->Name[1];
            std::string name2 = digitizer->Channels->Name[2];
            std::string name3 = digitizer->Channels->Name[3];
            std::string channel_list = name1 + "," + name2 + "," + name3;
            digitizer->Channels->AddChannelGroup(group_name, channel_list);

            std::string group_members = digitizer->Channels->Item[group_name]->Members;
            std::cout << "Channel Group Members: " << group_members << std::endl;

            digitizer->Channels->Item[group_name]->Range = 10.0;

            // use the EMX-4250 channel group to set a sample rate of 102400 Hz and a record size of 4096 on all EMX-4250 devices
            // each record will take 40 milliseconds to acquire
            digitizer->Channels->Item["EMX-4250"]->Sampling->SampleRate = 102400;
            digitizer->Channels->Item["EMX-4250"]->Sampling->RecordSize = 4096;

            // use the RX0124 channel group to set a sample rate of 51200 Hz and a record size of 2048
            // each record will also take 40 milliseconds to acquire, but it will have half the samples as the records from EMX-4250
            digitizer->Channels->Item["RX0124"]->Sampling->SampleRate = 51200;
            digitizer->Channels->Item["RX0124"]->Sampling->RecordSize = 2048;

            // set up to use LAN coordination
            digitizer->ReferenceOscillator->Source = VTEXDigitizerReferenceOscillatorSourceSystem;
            digitizer->ReferenceOscillator->TimestampSource = VTEXDigitizerReferenceOscillatorTimestampSourceSystem;
            digitizer->Sync->CoordinationLine = "LAN,PXI0";
            digitizer->Sync->SendSoftwareSync();

            // Initiate measurement
            digitizer->Measurement->Initiate();

            // Wait for the measurement to complete
            digitizer->Measurement->WaitForMeasurementComplete(5000); // 5 seconds

            // Read acquired Data
            int actual_recs;
            std::string channel;
            std::vector<double> data;
            std::vector<double> ts_sec;
            std::vector<double> ts_frac;
            std::string addl_data;
            digitizer->Measurement->Read(5000, -1, actual_recs, channel, data,
                    ts_sec, ts_frac, addl_data);

            // The channel string indicates how the data is arranged in the vector
            // Remember, the number of samples for each channel will depend on the record size
            // That value can be queried for a specific channel via digitizer->Channels->Item[name]->Sampling->RecordSize
            std::cout << "Channels: " << channel << std::endl;

            digitizer->Measurement->Abort();
            digitizer->Close();
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(digitizer->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    digitizer->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(digitizer->Initialized)
            {
                digitizer->Close();
            }
        }
    }
    catch(...)
    {
        // Handle non VTEX errors in an intelligent manner
    }
}

