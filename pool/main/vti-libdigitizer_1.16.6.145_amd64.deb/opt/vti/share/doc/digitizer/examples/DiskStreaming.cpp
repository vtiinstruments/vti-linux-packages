#include <iostream>
#include <unistd.h>
#include "libDigitizer.h"

int main(int argc, char **argv)
{
    LibDigitizer *driver;
    try {
        // Create a new instance of the Digitizer driver
        driver = LibDigitizer::Create();
        try{
            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             */
            if (argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // Initialize the driver
            driver->Initialize(resource_string, true, true);
            std::cout << "Initialized to " << resource_string << std::endl;

            // Set the name of the file to use for disk streaming
            driver->StreamingData->Filename = "basic_disk_streaming.h5";

            // Add some custom attributes to describe the data in the files
            driver->StreamingData->SetCustomAttribute("Tester Name", "George");
            driver->StreamingData->SetCustomAttribute("Test Location", "Room 14");

            // Review the attributes we just set, before we start the acquisition
            std::string attrs;
            driver->StreamingData->GetCustomAttributes(attrs);
            std::cout << "Acquisition Attributes: " << attrs << std::endl;

            // Oops! We make a mistake in one of the attributes. Better fix that and review again.
            driver->StreamingData->SetCustomAttribute("Test Location", "Room 12");
            driver->StreamingData->GetCustomAttributes(attrs);
            std::cout << "Acquisition Attributes: " << attrs << std::endl;

            // Configure the acquisition
            int64_t num_records_per_trigger = 2;
            int32_t trigger_count = 3;
            int64_t expected_records = num_records_per_trigger * trigger_count;

            driver->Measurement->NumRecordsPerTrigger = num_records_per_trigger;
            driver->Trigger->TriggerCount = trigger_count;

            // Now we can enable streaming and start the acquisition
            driver->StreamingData->EnableStreaming();
            driver->Measurement->Initiate();

            // Wait for the acquisition to complete
            driver->Measurement->WaitForMeasurementComplete(10 * 1000);

            // Make sure all of the data has arrived
            for(int i = 0; i < 10; i++)
            {
                int64_t num_recs = driver->StreamingData->NumStreamedRecords;
                std::cout << "NumStreamedRecords: " << num_recs << std::endl;
                if(num_recs == expected_records)
                {
                    break;
                }
                usleep(250 * 1000);
            }

            driver->StreamingData->DisableStreaming();
            driver->Close();
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(driver->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    driver->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(driver->Initialized)
            {
                driver->Close();
            }
        }
    }
    catch(...)
    {
        // Handle non VTEX errors in an intelligent manner
    }
}
