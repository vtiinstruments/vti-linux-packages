#include "libDigitizer.h"
#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <map>
#include "json.h"

struct Record
{
    std::vector<double> data;
    double ts_seconds;
    double ts_fractions;
    double trigger_timestamp;
    bool overrange;
    bool valid;
};

std::vector<std::string> &split(const std::string &s, char delim, std::vector<std::string> &elems);
std::vector<std::string> split(const std::string &s, char delim);

int main(int argc, char* argv[])
{
    LibDigitizer *driver;
    try
    {
        // Create a new instance of the driver
        driver = LibDigitizer::Create();
        try
        {
            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             */
            if(argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                std::cout << "Ex: " << argv[0] << "TCPIP::192.168.0.1::INSTR" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // Initialize the driver
            driver->Initialize(resource_string, false, true, "");

            // "ALL" is a channel group which allows you to modify all of the channels at once
            driver->Channels->Item["ALL"]->Enabled = true; // Enable the channels
            driver->Channels->Item["ALL"]->AutoRangeMode = VTEXDigitizerAutoRangeModeOff;
            driver->Channels->Item["ALL"]->Range = 10;
            driver->Channels->Item["ALL"]->Function = VTEXDigitizerChannelFunctionVoltage; // Set the channels to measure voltage

            // Setup sample rate, record size and number record per trigger on all channels
            double sample_rate = 4096;
            int record_size = 128;
            int num_rec_per_trigger = 2;
            driver->Measurement->Sampling->SampleRate = sample_rate;
            driver->Measurement->Sampling->RecordSize = record_size;
            driver->Measurement->NumRecordsPerTrigger = num_rec_per_trigger;

            //Initiate the measurement
            driver->Measurement->Initiate();
            driver->Measurement->WaitForMeasurementComplete(5000); // Wait up to 5 seconds for the measurement to finish.

            int actual_records = 0;
            std::vector<double> data;
            std::vector<double> ts_sec;
            std::vector<double> ts_frac;
            std::string addl_data;
            std::string channel;

            int64_t count = driver->Measurement->NumFIFORecords;
            std::cout << "Count: " << count << std::endl;

            if(count > 0) // Make sure there is data in the FIFO
            {
                /* Read out all of the data from the FIFO with a timeout of 1000ms
                 * Set the number of records to read to -1, which indicates that all records should be read
                 */
                driver->Measurement->Read(1000, -1, actual_records, channel, data, ts_sec, ts_frac, addl_data);
                Json::Value addl;
                Json::Reader reader;
                reader.parse(addl_data, addl);
                std::vector<std::string> channels = split(channel, ',');
                
                std::map<std::string, std::vector<Record> > records;
                for(int i = 0; i < (int)channels.size(); i++)
                {
                    Record r;
                    // The Trigger Timestamp data will be in the first element of the array for each record, and the overrange data will be in the second
                    r.trigger_timestamp = addl[i][0]["Trigger Timestamp Seconds"].asDouble() + addl[i][0]["Trigger Timestamp Fraction"].asDouble();
                    r.overrange = addl[i][1]["Over-Range"].asBool();
                    r.valid = addl[i][1]["Valid Data"].asBool();

                    r.ts_seconds = ts_sec[i];
                    r.ts_fractions = ts_frac[i];
                    r.data = std::vector<double>(data.begin() + (i*record_size), data.begin() + ((i+1)*record_size));
                    
                    records[channels[i]].push_back(r);
                }
            }
            driver->Close();
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(driver->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    driver->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(driver->Initialized)
            {
                driver->Close();
            }
        }

        //Clean up when we're done
        delete driver;
        driver = nullptr;
    }
    catch(...)
    {
        //Do something to intelligently deal with any other non-VTEX errors.
    }

    return 0;
}


std::vector<std::string> &split(const std::string &s, char delim, std::vector<std::string> &elems) {
    std::stringstream ss(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        elems.push_back(item);
    }
    return elems;
}


std::vector<std::string> split(const std::string &s, char delim) {
    std::vector<std::string> elems;
    split(s, delim, elems);
    return elems;
}
