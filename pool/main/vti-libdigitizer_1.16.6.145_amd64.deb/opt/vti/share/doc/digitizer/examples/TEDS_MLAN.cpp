/* The MicroLAN (MLAN) specification details five major functions that are the centerpiece of any operations involving TEDS devices.
 * These five functions are:
 *  - Read serial/URN from device (GET_URN)
 *  - Write to volatile memory scratchpad (READ_SCRATCHPAD)
 *  - Read from volatile memory scratchpad (WRITE_SCRATCHPAD)
 *  - Copy volatile scratchpad to nonvolatile memory (COPY_SCRATCHPAD)
 *  - Read from non-volatile memory (READ_MEMORY)
 *
 * This program demonstrates how to use all five of these functions.
 * See the discussion in TEDS_MLAN_Readme.txt for more information.
 */

#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>

#include "libDigitizer.h"

// MLAN commands
#define CMD_RESET 0x84
#define DATA_SEARCH_STATE 0x01
#define DATA_SEARCH_CMD 0x02
#define CMD_ML_DATA 0x0A
#define CMD_ML_RESET 0x80
#define CMD_ML_SEARCH 0x81
#define DATA_ID 0x00
#define CMD_GETBUF 0x85
#define CMD_ML_ACCESS 0x82
#define CMD_DELAY 0x0B
#define CMD_ML_BIT 0x09
#define DELAY_128 0x02
#define DELAY_MS 0x80

// Functions that modify TEDS data
#define WRITE_SCRATCHPAD 0x0F
#define READ_SCRATCHPAD 0xAA
#define COPY_SCRATCHPAD 0x55
#define READ_MEMORY 0xF0

// Device-specific values
#define DS2430_SCRATCHPAD_LEN 32
#define DS2430_MEMORY_LEN 32
#define DS2431_SCRATCHPAD_LEN 8
#define DS2431_MEMORY_LEN 128

// Global buffers for storing the sent & received packets
std::vector<int16_t> WriteBuf, ReadBuf;

// Global driver pointer
LibDigitizer* driver;

// We have code for using both the DS2430 and the DS2431
// Define one of these flags to run the code required to communicate with the appropriate type of device
//#define USE_DS2430
#define USE_DS2431

// Methods for working with TEDS devices
int write_scratchpad_2430(std::string name, const char* data);
int read_scratchpad_2430(std::string name);
int copy_scratchpad_2430(std::string name);
int read_memory_2430(std::string name);
int write_and_copy_scratchpad_2430(std::string name, const char* data);

int write_scratchpad_2431(std::string name, const char* data, int address);
int read_scratchpad_2431(std::string name);
int copy_scratchpad_2431(std::string name, int address);
int read_memory_2431(std::string name);
int write_and_copy_scratchpad_2431(std::string name, const char* data, int address);

// Utility methods for working with TEDS devices, see the implementation for discussion
void PrintPacket(std::vector<int16_t> buf);
unsigned int CRCcalc(std::vector<int16_t> buf, int offset, int len);

int main(int argc, char* argv[])
{
    try
    {
        // Create a new instance of the driver
        driver = LibDigitizer::Create();
        try
        {
            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             */
            if(argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                std::cout << "Ex: " << argv[0] << "TCPIP::192.168.0.1::INSTR" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // Initialize the driver
            std::cout << "Initializing" << std::endl;
            driver->Initialize(resource_string, false, true, "");
            
            // We'll assume that we have a TEDS device connected to CH1 of the card
            std::string chan = "CH1";

            // The channel must be disabled before we can enable TEDS
            driver->Channels->Item[chan]->Enabled = false;
            driver->Channels->Item[chan]->TEDS->Enabled = true;
            std::cout << "TEDS enabled on " << chan << std::endl << std::endl;

            /* Reading the URN is one of the simplest examples of MLAN programming.
             *
             * First, an MLAN Bus Master Reset is performed. This ceases compunction with any other
             * MLAN devices that were previously addressed, and uses the new one. The CMD_ML_SEARCH
             * and DATA_ID commands tell the controller to find the next device and obtain its ID, respectively.
             * If multiple CMD_ML_SEARCH and DATA_ID pairs were sent, it would be possible to determine
             * how many devices were on this channel. CMD_ML_SEARCH returns 0x01 when no more
             * devices are found.
             */
            ReadBuf.clear();
            WriteBuf.clear();

            WriteBuf.push_back(0); // reserve first byte for length
            // clear the search state so we find the 'first' device
            WriteBuf.push_back(CMD_RESET);
            // do a reset, search and then read results
            WriteBuf.push_back(CMD_ML_RESET);
            WriteBuf.push_back(CMD_ML_SEARCH);
            WriteBuf.push_back(DATA_ID);
            WriteBuf.push_back(0);
            // request the result buffer as the last command
            WriteBuf.push_back(CMD_GETBUF);
            // set the length
            WriteBuf[0] = (int)WriteBuf.size() - 1;

            // send the commands
            driver->Channels->Item[chan]->TEDS->WriteTEDS(WriteBuf);
            std::cout << "Read URN (WriteData)" << std::endl;
            PrintPacket(WriteBuf);

            // retrieve the response for each command
            driver->Channels->Item[chan]->TEDS->ReadTEDS(ReadBuf);
            std::cout << "Read URN (ReadData)" << std::endl;
            PrintPacket(ReadBuf);

            // The above code is equivalent to the VTEXDigitizer ReadUrn method
            // ReadUrn returns only the URN. The responses for each command are omitted.
            ReadBuf.clear();
            driver->Channels->Item[chan]->TEDS->ReadURN(ReadBuf);
            std::cout << "ReadURN" << std::endl;
            PrintPacket(ReadBuf);
            std::cout << std::endl;

#ifdef USE_DS2430
            // using the DS2430
            write_scratchpad_2430(chan, "01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F 10 11 12 13 14 15 16 17 18 19 1A 1B 1C 1D 1F 20 21");
            std::cout << std::endl;
            
            read_scratchpad_2430(chan);
            std::cout << std::endl;
            
            copy_scratchpad_2430(chan);
            std::cout << std::endl;
            
            read_memory_2430(chan);
            std::cout << std::endl;
            
            write_and_copy_scratchpad_2430(chan, "01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F 10 11 12 13 14 15 16 17 18 19 1A 1B 1C 1D 1F 20 21");
#endif // USE_DS2430

#ifdef USE_DS2431
            // using the DS2431
            write_scratchpad_2431(chan, "01 02 03 04 05 06 07 08", 0);
            std::cout << std::endl;

            read_scratchpad_2431(chan);
            std::cout << std::endl;

            copy_scratchpad_2431(chan, 0);
            std::cout << std::endl;

            read_memory_2431(chan);
            std::cout << std::endl;

            write_and_copy_scratchpad_2431(chan, "01 02 03 04 05 06 07 08", 0);
#endif // USE_DS2431

            // Always close the driver when finished
            driver->Close();
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(driver->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    driver->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(driver->Initialized)
            {
                driver->Close();
            }
        }

        //Clean up when we're done
        delete driver;
        driver = nullptr;
    }
    catch(...)
    {
        // Do something to intelligently deal with any other non-VTEX errors.
    }

    return 0;
}

int write_scratchpad_2430(std::string name, const char* data)
{
    int recLen = 0;
    ReadBuf.clear();
    WriteBuf.clear();

    if(strlen(data) != ((DS2430_SCRATCHPAD_LEN * 2) + (DS2430_SCRATCHPAD_LEN-1)))
    {
        //(SCRATCHPAD_LEN*2)+(SCRATCHPAD_LEN-1) = 95
        printf("Data was not the right length (wanted 95, got %i)\n", (int)strlen(data));
        return -1;
    }

    WriteBuf.push_back(0); // reserve first byte for length
    // access the current device with address in DATA_ID
    WriteBuf.push_back(CMD_ML_ACCESS);
    // construct a block of communication to MicroLAN
    WriteBuf.push_back(CMD_ML_DATA);
    WriteBuf.push_back(3+DS2430_SCRATCHPAD_LEN); // block length
    WriteBuf.push_back(2+DS2430_SCRATCHPAD_LEN); // data length
    // send the write scratchpad command
    WriteBuf.push_back(WRITE_SCRATCHPAD);
    // send the address byte
    WriteBuf.push_back(0);
    // the bytes of data to write
    char byte[3];
    for(int i = 0; i < ((2*DS2430_SCRATCHPAD_LEN) + (DS2430_SCRATCHPAD_LEN-1)); i+=3)
    {
        strncpy(byte, &data[i], 2);
        byte[2]='\0';
        WriteBuf.push_back((uint8_t)strtoul(byte, nullptr, 16)); //convert to hex
    }
    // request the result buffer as the last command
    WriteBuf.push_back(CMD_GETBUF);
    // set the length
    WriteBuf[0] = (int)WriteBuf.size() - 1;

    // send the commands
    driver->Channels->Item[name]->TEDS->WriteTEDS(WriteBuf);
    std::cout << "DS2430 Write Scratchpad (WriteData)" << std::endl;
    PrintPacket(WriteBuf);

    // retrieve the response
    driver->Channels->Item[name]->TEDS->ReadTEDS(ReadBuf);
    std::cout << "DS2430 Write Scratchpad (ReadData)" << std::endl;
    PrintPacket(ReadBuf);

    recLen = (int)ReadBuf.size();
    return recLen;
}

int read_scratchpad_2430(std::string name)
{
    int recLen = 0;
    ReadBuf.clear();
    WriteBuf.clear();

    WriteBuf.push_back(0); // reserve first byte for length
    // access the current device with address in DATA_ID
    WriteBuf.push_back(CMD_ML_ACCESS);
    // construct a block of communication to MicroLAN
    WriteBuf.push_back(CMD_ML_DATA);
    WriteBuf.push_back(3); // block length
    WriteBuf.push_back(2+DS2430_SCRATCHPAD_LEN); // data length of read
    // send the read scratchpad command
    WriteBuf.push_back(READ_SCRATCHPAD);
    // send the address byte
    WriteBuf.push_back(0);
    // request the result buffer as the last command
    WriteBuf.push_back(CMD_GETBUF);
    // set the length
    WriteBuf[0] = (int)WriteBuf.size() - 1;

    // send the commands
    driver->Channels->Item[name]->TEDS->WriteTEDS(WriteBuf);
    std::cout << "DS2430 Read Scratchpad (WriteData)" << std::endl;
    PrintPacket(WriteBuf);

    // retrieve the response
    driver->Channels->Item[name]->TEDS->ReadTEDS(ReadBuf);
    std::cout << "DS2430 Read Scratchpad (ReadData)" << std::endl;
    PrintPacket(ReadBuf);

    recLen = (int)ReadBuf.size();
    return recLen;
}

int copy_scratchpad_2430(std::string name)
{
    int recLen = 0;
    ReadBuf.clear();
    WriteBuf.clear();

    WriteBuf.push_back(0); // reserve first byte for length
    // access the current device with address in DATA_ID
    WriteBuf.push_back(CMD_ML_ACCESS);
    // construct a block of communication to MicroLAN
    WriteBuf.push_back(CMD_ML_DATA);
    WriteBuf.push_back(3); // block length
    WriteBuf.push_back(2); // data length
    // send the copy scratchpad command
    WriteBuf.push_back(COPY_SCRATCHPAD);
    // send the validation key
    WriteBuf.push_back(0xA5);
    // delay for 128ms
    WriteBuf.push_back(CMD_DELAY);
    WriteBuf.push_back(1);
    WriteBuf.push_back(DELAY_128 | DELAY_MS);
    // request the result buffer as the last command
    WriteBuf.push_back(CMD_GETBUF);
    // set the length
    WriteBuf[0] = (int)WriteBuf.size() - 1;

    // send the commands
    driver->Channels->Item[name]->TEDS->WriteTEDS(WriteBuf);
    std::cout << "DS2430 Copy Scratchpad (WriteData)" << std::endl;
    PrintPacket(WriteBuf);

    // retrieve the response
    driver->Channels->Item[name]->TEDS->ReadTEDS(ReadBuf);
    std::cout << "DS2430 Copy Scratchpad (ReadData)" << std::endl;
    PrintPacket(ReadBuf);

    recLen = (int)ReadBuf.size();
    return recLen;
}

int read_memory_2430(std::string name)
{
    int recLen = 0;
    ReadBuf.clear();
    WriteBuf.clear();

    WriteBuf.push_back(0); // reserve first byte for length
    // access the current device with address in DATA_ID
    WriteBuf.push_back(CMD_ML_ACCESS);
    // construct a block of communication to MicroLAN
    WriteBuf.push_back(CMD_ML_DATA);
    WriteBuf.push_back(3); // block length
    WriteBuf.push_back(2+DS2430_MEMORY_LEN); // data length with 32 bytes of reads
    // send the read memory command
    WriteBuf.push_back(READ_MEMORY);
    // send the address byte
    WriteBuf.push_back(0);
    // request the result buffer as the last command
    WriteBuf.push_back(CMD_GETBUF);
    // set the length
    WriteBuf[0] = (int)WriteBuf.size() - 1;

    // send the commands
    driver->Channels->Item[name]->TEDS->WriteTEDS(WriteBuf);
    std::cout << "DS2430 Read Memory (WriteData)" << std::endl;
    PrintPacket(WriteBuf);

    // retrieve the response
    driver->Channels->Item[name]->TEDS->ReadTEDS(ReadBuf);
    std::cout << "DS2430 Read Memory (ReadData)" << std::endl;
    PrintPacket(ReadBuf);

    recLen = (int)ReadBuf.size();
    return recLen;
}

int write_and_copy_scratchpad_2430(std::string name, const char* data)
{
    int recLen = 0;
    ReadBuf.clear();
    WriteBuf.clear();

    if(strlen(data) != ((DS2430_SCRATCHPAD_LEN * 2) + (DS2430_SCRATCHPAD_LEN-1)))
    {
        printf("Data was not the right length (wanted 95, got %i)\n", (int)strlen(data));
        return -1;
    }

    WriteBuf.push_back(0); // reserve first byte for length
    // access the current device with address in DATA_ID
    WriteBuf.push_back(CMD_ML_ACCESS);
    // construct a block of communication to MicroLAN
    WriteBuf.push_back(CMD_ML_DATA);
    WriteBuf.push_back(3+DS2430_SCRATCHPAD_LEN); // block length
    WriteBuf.push_back(4+DS2430_SCRATCHPAD_LEN); // data length
    // send the write scratchpad command
    WriteBuf.push_back(WRITE_SCRATCHPAD);
    // send the address byte
    WriteBuf.push_back(0);
    // the 5 bytes of data to write
    char byte[3];
    for(int i = 0; i < ((2*DS2430_SCRATCHPAD_LEN) + (DS2430_SCRATCHPAD_LEN-1)); i+=3)
    {
        strncpy(byte, &data[i], 2);
        byte[2]='\0';
        WriteBuf.push_back((uint8_t)strtoul(byte, nullptr, 16)); //convert to hex
    }

    // the copy command
    // access the current device with address in DATA_ID
    WriteBuf.push_back(CMD_ML_ACCESS);
    // construct a block of communication to MicroLAN
    WriteBuf.push_back(CMD_ML_DATA);
    WriteBuf.push_back(3); // block length
    WriteBuf.push_back(2); // data length
    // send the copy scratchpad command
    WriteBuf.push_back(COPY_SCRATCHPAD);
    // send the validation key
    WriteBuf.push_back(0xA5);
    // delay for 128ms
    WriteBuf.push_back(CMD_DELAY);
    WriteBuf.push_back(1);
    WriteBuf.push_back(DELAY_128 | DELAY_MS);
    // request the result buffer as the last command
    WriteBuf.push_back(CMD_GETBUF);

    // set the length
    WriteBuf[0] = (int)WriteBuf.size() - 1;

    // send the commands
    driver->Channels->Item[name]->TEDS->WriteTEDS(WriteBuf);
    std::cout << "DS2430 Write & Copy Scratchpad (WriteData)" << std::endl;
    PrintPacket(WriteBuf);

    // retrieve the response
    driver->Channels->Item[name]->TEDS->ReadTEDS(ReadBuf);
    std::cout << "DS2430 Write & Copy Scratchpad (ReadData)" << std::endl;
    PrintPacket(ReadBuf);

    recLen = (int)ReadBuf.size();
    return recLen;
}

int write_scratchpad_2431(std::string name, const char* data, int address)
{
    int recLen = 0;
    ReadBuf.clear();
    WriteBuf.clear();

    if(strlen(data) != ((DS2431_SCRATCHPAD_LEN * 2) + (DS2431_SCRATCHPAD_LEN-1)))
    {
        printf("Data was not the right length (wanted 23, got %i)\n", (int)strlen(data));
        return -1;
    }

    WriteBuf.push_back(0); // reserve first byte for length
    // access the current device with address in DATA_ID
    WriteBuf.push_back(CMD_ML_ACCESS);
    // construct a block of communication to MicroLAN
    WriteBuf.push_back(CMD_ML_DATA);
    WriteBuf.push_back(4+DS2431_SCRATCHPAD_LEN); // block length
    WriteBuf.push_back(5+DS2431_SCRATCHPAD_LEN); // data length
    // send the write scratchpad command
    WriteBuf.push_back(WRITE_SCRATCHPAD);
    // send the address byte
    if (address > (DS2431_MEMORY_LEN-DS2431_SCRATCHPAD_LEN) || address < 0)
    {
        printf("Invalid scratchpad address, must be between 0 and 88 hex\n");
        return -1;
    }
    WriteBuf.push_back(address);
    WriteBuf.push_back(0);
    // the 5 bytes of data to write
    char byte[3];
    for(int i = 0; i < ((2*DS2431_SCRATCHPAD_LEN) + (DS2431_SCRATCHPAD_LEN-1)); i+=3)
    {
        strncpy(byte, &data[i], 2);
        byte[2]='\0';
        WriteBuf.push_back((uint8_t)strtoul(byte, nullptr, 16)); //convert to hex
    }
    // request the result buffer as the last command
    WriteBuf.push_back(CMD_GETBUF);
    // set the length
    WriteBuf[0] = (int)WriteBuf.size() - 1;

    // send the commands
    driver->Channels->Item[name]->TEDS->WriteTEDS(WriteBuf);
    std::cout << "DS2431 Write Scratchpad (WriteData)" << std::endl;
    PrintPacket(WriteBuf);
    CRCcalc(WriteBuf, 6, 11);

    // retrieve the response
    driver->Channels->Item[name]->TEDS->ReadTEDS(ReadBuf);
    std::cout << "DS2431 Write Scratchpad (ReadData)" << std::endl;
    PrintPacket(ReadBuf);

    recLen = (int)ReadBuf.size();
    return recLen;
}

int read_scratchpad_2431(std::string name)
{
    int recLen = 0;
    ReadBuf.clear();
    WriteBuf.clear();

    WriteBuf.push_back(0); // reserve first byte for length
    // access the current device with address in DATA_ID
    WriteBuf.push_back(CMD_ML_ACCESS);
    // construct a block of communication to MicroLAN
    WriteBuf.push_back(CMD_ML_DATA);
    WriteBuf.push_back(3); // block length
    WriteBuf.push_back(6+DS2431_SCRATCHPAD_LEN); // data length of read
    // send the read scratchpad command
    WriteBuf.push_back(READ_SCRATCHPAD);
    // send the address byte
    WriteBuf.push_back(0);
    // request the result buffer as the last command
    WriteBuf.push_back(CMD_GETBUF);
    // set the length
    WriteBuf[0] = (int)WriteBuf.size() - 1;

    // send the commands
    driver->Channels->Item[name]->TEDS->WriteTEDS(WriteBuf);
    std::cout << "DS2431 Read Scratchpad (WriteData)" << std::endl;
    PrintPacket(WriteBuf);

    // retrieve the response
    driver->Channels->Item[name]->TEDS->ReadTEDS(ReadBuf);
    std::cout << "DS2431 Read Scratchpad (ReadData)" << std::endl;
    PrintPacket(ReadBuf);
    CRCcalc(ReadBuf, 6, 12);

    recLen = (int)ReadBuf.size();
    return recLen;
}

int copy_scratchpad_2431(std::string name, int address)
{
    int recLen = 0;
    ReadBuf.clear();
    WriteBuf.clear();

    WriteBuf.push_back(0); // reserve first byte for length
    // access the current device with address in DATA_ID
    WriteBuf.push_back(CMD_ML_ACCESS);
    // construct a block of communication to MicroLAN
    WriteBuf.push_back(CMD_ML_DATA);
    WriteBuf.push_back(5); // block length
    WriteBuf.push_back(4); // data length
    // send the copy scratchpad command
    WriteBuf.push_back(COPY_SCRATCHPAD);
    // send the address validation key
    if (address > (DS2431_MEMORY_LEN-DS2431_SCRATCHPAD_LEN) || address < 0)
    {
        printf("Invalid scratchpad address, must be between 0 and 88 hex\n");
        return -1;
    }
    WriteBuf.push_back(address);
    WriteBuf.push_back(0);
    WriteBuf.push_back(0x07); // ES register
    // delay for 128ms
    WriteBuf.push_back(CMD_DELAY);
    WriteBuf.push_back(1);
    WriteBuf.push_back(DELAY_128 | DELAY_MS);
    // request the result buffer as the last command
    WriteBuf.push_back(CMD_GETBUF);
    // set the length
    WriteBuf[0] = (int)WriteBuf.size() - 1;

    // send the commands
    driver->Channels->Item[name]->TEDS->WriteTEDS(WriteBuf);
    std::cout << "DS2431 Copy Scratchpad (WriteData)" << std::endl;
    PrintPacket(WriteBuf);

    // retrieve the response
    driver->Channels->Item[name]->TEDS->ReadTEDS(ReadBuf);
    std::cout << "DS2431 Copy Scratchpad (ReadData)" << std::endl;
    PrintPacket(ReadBuf);

    recLen = (int)ReadBuf.size();
    return recLen;
}

int read_memory_2431(std::string name)
{
    int recLen = 0;
    ReadBuf.clear();
    WriteBuf.clear();

    WriteBuf.push_back(0); // reserve first byte for length
    // access the current device with address in DATA_ID
    WriteBuf.push_back(CMD_ML_ACCESS);
    // construct a block of communication to MicroLAN
    WriteBuf.push_back(CMD_ML_DATA);
    WriteBuf.push_back(4); // block length
    WriteBuf.push_back(3+DS2431_MEMORY_LEN); // data length with 144 bytes of reads
    // send the read memory command
    WriteBuf.push_back(READ_MEMORY);
    // send the address bytes
    WriteBuf.push_back(0);
    WriteBuf.push_back(0);
    // request the result buffer as the last command
    WriteBuf.push_back(CMD_GETBUF);
    // set the length
    WriteBuf[0] = (int)WriteBuf.size() - 1;

    // send the commands
    driver->Channels->Item[name]->TEDS->WriteTEDS(WriteBuf);
    std::cout << "DS2431 Read Memory (WriteData)" << std::endl;
    PrintPacket(WriteBuf);

    // retrieve the response
    driver->Channels->Item[name]->TEDS->ReadTEDS(ReadBuf);
    std::cout << "DS2431 Read Memory (ReadData)" << std::endl;
    PrintPacket(ReadBuf);

    recLen = (int)ReadBuf.size();
    return recLen;
}

int write_and_copy_scratchpad_2431(std::string name, const char* data, int address)
{
    int recLen = 0;
    ReadBuf.clear();
    WriteBuf.clear();

    if(strlen(data) != ((DS2431_SCRATCHPAD_LEN * 2) + (DS2431_SCRATCHPAD_LEN-1)))
    {
        printf("Data was not the right length (wanted 23, got %i)\n", (int)strlen(data));
        return -1;
    }

    WriteBuf.push_back(0); // reserve first byte for length
    // access the current device with address in DATA_ID
    WriteBuf.push_back(CMD_ML_ACCESS);
    // construct a block of communication to MicroLAN
    WriteBuf.push_back(CMD_ML_DATA);
    WriteBuf.push_back(4+DS2431_SCRATCHPAD_LEN); // block length
    WriteBuf.push_back(5+DS2431_SCRATCHPAD_LEN); // data length
    // send the write scratchpad command
    WriteBuf.push_back(WRITE_SCRATCHPAD);
    // send the address byte
    if (address > (DS2431_MEMORY_LEN-DS2431_SCRATCHPAD_LEN) || address < 0)
    {
        printf("Invalid scratchpad address, must be between 0 and 88 hex\n");
        return -1;
    }
    WriteBuf.push_back(address);
    WriteBuf.push_back(0);
    // the 5 bytes of data to write
    char byte[3];
    for(int i = 0; i < ((2*DS2431_SCRATCHPAD_LEN) + (DS2431_SCRATCHPAD_LEN-1)); i+=3)
    {
        strncpy(byte, &data[i], 2);
        byte[2]='\0';
        WriteBuf.push_back((uint8_t)strtoul(byte, nullptr, 16)); //convert to hex
    }

    // the copy command
    // access the current device with address in DATA_ID
    WriteBuf.push_back(CMD_ML_ACCESS);
    // construct a block of communication to MicroLAN
    WriteBuf.push_back(CMD_ML_DATA);
    WriteBuf.push_back(5); // block length
    WriteBuf.push_back(4); // data length
    // send the copy scratchpad command
    WriteBuf.push_back(COPY_SCRATCHPAD);
    // send the address validation key
    if (address > (DS2431_MEMORY_LEN-DS2431_SCRATCHPAD_LEN) || address < 0)
    {
        printf("Invalid scratchpad address, must be between 0 and 88 hex\n");
        return -1;
    }
    WriteBuf.push_back(address);
    WriteBuf.push_back(0);
    WriteBuf.push_back(0x07); // ES register
    // delay for 128ms
    WriteBuf.push_back(CMD_DELAY);
    WriteBuf.push_back(1);
    WriteBuf.push_back(DELAY_128 | DELAY_MS);
    // request the result buffer as the last command
    WriteBuf.push_back(CMD_GETBUF);

    // set the length
    WriteBuf[0] = (int)WriteBuf.size() - 1;

    // send the commands
    driver->Channels->Item[name]->TEDS->WriteTEDS(WriteBuf);
    std::cout << "DS2431 Write & Copy Scratchpad (WriteData)" << std::endl;
    PrintPacket(WriteBuf);
    CRCcalc(WriteBuf, 6, 11);

    // retrieve the response
    driver->Channels->Item[name]->TEDS->ReadTEDS(ReadBuf);
    std::cout << "DS2431 Write & Copy Scratchpad (ReadData)" << std::endl;
    PrintPacket(ReadBuf);

    recLen = (int)ReadBuf.size();
    return recLen;
}

// This function prints MLAN packets in a format that makes them easier to read
void PrintPacket(std::vector<int16_t> buf)
{
    size_t len = buf.size();
    printf("Packet length: %i\n", (int)len);
    for(size_t i = 0; i < len; i++)
    {
        printf("%02X ", buf[i]);
    }
    printf("\n");
}

/* The CRC check function is called to calculate a CRC16 for the written data and the read data on the DS2431.
 *
 * The function first calculates a normal CRC16 and then does a bit-shift operation to swap the top
 * and bottom halves of the CRC bytes (due to platform endian-ness) before inverting the CRC.
 *
 * This is what the MLAN bus master will return to us on a little-endian host computer, like an x86
 * CPU (Intel or AMD): a byte-swapped, inverted CRC16. This way, the CRC16 value can be
 * visually compared instead of having to do bitwise operations on what the MLAN device gives us.
 */
 unsigned int CRCcalc(std::vector<int16_t> buf, int offset, int len)
{
    int i, j, k;
    int16_t byte;
    unsigned int r = 0;
    for(k = (offset-1); k < ((offset + len)-1); k++)
    {
        // CRC16 CALCULATION
        byte = buf[k];
        for(i=0; i!=8; byte>>=1, i++)
        {
            j=(byte^r)&1;
            r>>=1;
            if(j) {
                r^=0xa001;
            }
        }
    }
    r = ( ((r & 0x00FF) << 8) | ((r & 0xFF00) >> 8) ); // bit-swapping for endian-ness
    r = (uint16_t)~r; // inverting to match MLAN
    printf("CRC16: %02X\n", r);
    return r;
}
