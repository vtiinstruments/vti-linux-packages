#include "libDigitizer.h"
#include <iostream>

int main(int argc, char* argv[])
{
    //Create a VTEXDigitizer pointer
    LibDigitizer *digitizer;
    try
    {
        // Create a new instance of the Digitizer driver
        digitizer = LibDigitizer::Create();
        try
        {
            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             */
            if(argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                std::cout << "Ex: " << argv[0] << "TCPIP::192.168.0.1::INSTR" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // Initialize the Digitizer driver
            digitizer->Initialize(resource_string, false, true, "");

            // "ALL" is a channel group which allows you to modify all of the channels at once
            digitizer->Channels->Item["ALL"]->Enabled = true; // Enable the channels
            digitizer->Channels->Item["ALL"]->AutoRangeMode = VTEXDigitizerAutoRangeModeOff;
            digitizer->Channels->Item["ALL"]->Range = 10;
            digitizer->Channels->Item["ALL"]->Function = VTEXDigitizerChannelFunctionVoltage; // Set the channels to measure voltage

            // Setup sample rate, record size and number record per trigger on all channels
            digitizer->Measurement->Sampling->SampleRate = 4096;
            digitizer->Measurement->Sampling->RecordSize = 128;
            digitizer->Measurement->NumRecordsPerTrigger = 10;

            //Initiate the measurement
            digitizer->Measurement->Initiate();
            digitizer->Measurement->WaitForMeasurementComplete(5000); // Wait up to 5 seconds for the measurement to finish.

            int actual_records = 0;
            std::vector<double> data;
            std::vector<double> ts_sec;
            std::vector<double> ts_frac;
            std::string addl_data;
            std::string channels;

            int64_t count = digitizer->Measurement->NumFIFORecords;
            std::cout << "Count: " << count << std::endl;

            if(count > 0) // Make sure there is data in the FIFO
            {
                /* Read out all of the data from the FIFO with a timeout of 1000ms
                 * Set the number of records to read to -1, which indicates that all records should be read
                 */
                digitizer->Measurement->Read(1000, -1, actual_records, channels, data, ts_sec, ts_frac, addl_data);
                std::vector<double>::iterator it;
                for(it = data.begin(); it != data.end(); it++)
                {
                    std::cout << *it << std::endl; // Print out all of the data - Note, this can produce a lot of output
                }
            }
            digitizer->Close();
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(digitizer->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    digitizer->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(digitizer->Initialized)
            {
                digitizer->Close();
            }
        }
    }
    catch(...)
    {
        //Do something to intelligently deal with any other non-VTEX errors.
    }

    return 0;
}
