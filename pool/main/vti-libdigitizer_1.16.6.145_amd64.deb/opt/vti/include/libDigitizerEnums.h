#ifndef _DIGITIZER_ENUMS_
#define _DIGITIZER_ENUMS_

#ifndef ___VTEXDigitizer_h__

typedef enum
{
    VTEXDigitizerTimeOutImmediate = 0,
    VTEXDigitizerTimeOutInfinite = -1,
} VTEXDigitizerTimeOutEnum;

typedef enum
{
    VTEXDigitizerSelfTestStatusSuccess = 0,
    VTEXDigitizerSelfTestStatusFailed = 1,
    VTEXDigitizerSelfTestStatusRunning = 2,
    VTEXDigitizerSelfTestStatusNotStarted = 3,
    VTEXDigitizerSelfTestStatusWarning = 4,
} VTEXDigitizerSelfTestStatusEnum;

typedef enum
{
    VTEXDigitizerMeasurementStateIdle = 1000,
    VTEXDigitizerMeasurementStateSettling = 1001,
    VTEXDigitizerMeasurementStateWaitingForStart = 1002,
    VTEXDigitizerMeasurementStateWaitingForArm = 1003,
    VTEXDigitizerMeasurementStateWaitingForTrigger = 1004,
    VTEXDigitizerMeasurementStatePretriggerSamples = 1005,
    VTEXDigitizerMeasurementStateMeasuring = 1006,
    VTEXDigitizerMeasurementStateTriggerHoldoff = 1007,
    VTEXDigitizerMeasurementStateMixed = 1008,
} VTEXDigitizerMeasurementStateEnum;

typedef enum
{
    VTEXDigitizerFifoModeWait = 1000,
    VTEXDigitizerFifoModeOverwrite = 1001,
    VTEXDigitizerFifoModeStop = 1002,
} VTEXDigitizerFifoModeEnum;

typedef enum
{
    VTEXDigitizerDataFormatEUFixedPoint32 = 1000,
    VTEXDigitizerDataFormatEUReal64 = 1001,
    VTEXDigitizerDataFormatEUReal32 = 1002,
    VTEXDigitizerDataFormatRawInt32 = 1100,
    VTEXDigitizerDataFormatRawInt16 = 1101,
    VTEXDigitizerDataFormatVReal64 = 1102,
    VTEXDigitizerDataFormatVReal32 = 1103,
} VTEXDigitizerDataFormatEnum;

typedef enum
{
    VTEXDigitizerDecimationFilterNone = 1000,
    VTEXDigitizerDecimationFilterLowLatency = 1001,
    VTEXDigitizerDecimationFilterMedLatency = 1002,
    VTEXDigitizerDecimationFilterHighPerformance = 1003,
} VTEXDigitizerDecimationFilterEnum;

typedef enum
{
    VTEXDigitizerTriggerSourceDetectionRise = 0,
    VTEXDigitizerTriggerSourceDetectionFall = 1,
    VTEXDigitizerTriggerSourceDetectionHigh = 1000,
    VTEXDigitizerTriggerSourceDetectionLow = 1001,
} VTEXDigitizerTriggerSourceDetectionEnum;

typedef enum
{
    VTEXDigitizerTriggerSourceOperatorAND = 0,
    VTEXDigitizerTriggerSourceOperatorOR = 1,
} VTEXDigitizerTriggerSourceOperatorEnum;

typedef enum
{
    VTEXDigitizerArmSourceDetectionRise = 0,
    VTEXDigitizerArmSourceDetectionFall = 1,
    VTEXDigitizerArmSourceDetectionHigh = 2,
    VTEXDigitizerArmSourceDetectionLow = 3,
} VTEXDigitizerArmSourceDetectionEnum;

typedef enum
{
    VTEXDigitizerArmSourceOperatorAND = 0,
    VTEXDigitizerArmSourceOperatorOR = 1,
} VTEXDigitizerArmSourceOperatorEnum;

typedef enum
{
    VTEXDigitizerSourceSlopeRise = 0,
    VTEXDigitizerSourceSlopeFall = 1,
} VTEXDigitizerSourceSlopeEnum;

typedef enum
{
    VTEXDigitizerEventDriveModeDriven = 0,
    VTEXDigitizerEventDriveModeOff = 1,
    VTEXDigitizerEventDriveModeWiredOr = 2,
} VTEXDigitizerEventDriveModeEnum;

typedef enum
{
    VTEXDigitizerReferenceOscillatorSourceInternal = 0,
    VTEXDigitizerReferenceOscillatorSourceExternal = 1,
    VTEXDigitizerReferenceOscillatorSourcePXIClk10 = 2,
    VTEXDigitizerReferenceOscillatorSourcePXIeClk100 = 3,
    VTEXDigitizerReferenceOscillatorSourcePXIeDSTARA = 1,
    VTEXDigitizerReferenceOscillatorSourceSystem = 1002,
} VTEXDigitizerReferenceOscillatorSourceEnum;

typedef enum
{
    VTEXDigitizerReferenceOscillatorTimestampSourceInternal = 0,
    VTEXDigitizerReferenceOscillatorTimestampSourceExternal = 1,
    VTEXDigitizerReferenceOscillatorTimestampSourcePXIClk10 = 2,
    VTEXDigitizerReferenceOscillatorTimestampSourcePXIeClk100 = 3,
    VTEXDigitizerReferenceOscillatorTimestampSourcePXIeDSTARA = 1,
    VTEXDigitizerReferenceOscillatorTimestampSourceSystem = 1002,
} VTEXDigitizerReferenceOscillatorTimestampSourceEnum;

typedef enum
{
    VTEXDigitizerTemperatureUnitsCelsius = 0,
    VTEXDigitizerTemperatureUnitsFahrenheit = 1,
    VTEXDigitizerTemperatureUnitsKelvin = 2,
} VTEXDigitizerTemperatureUnitsEnum;

typedef enum
{
    VTEXDigitizerCalibrationStatusNotStarted = 1000,
    VTEXDigitizerCalibrationStatusRunning = 1001,
    VTEXDigitizerCalibrationStatusSuccess = 1002,
    VTEXDigitizerCalibrationStatusFailed = 1003,
    VTEXDigitizerCalibrationStatusPrompt = 1004,
} VTEXDigitizerCalibrationStatusEnum;

typedef enum
{
    VTEXDigitizerChannelFunctionVoltage = 1000,
    VTEXDigitizerChannelFunctionIEPE = 1001,
    VTEXDigitizerChannelFunctionCharge = 1002,
    VTEXDigitizerChannelFunctionTemperature = 1003,
    VTEXDigitizerChannelFunctionStrain = 1004,
    VTEXDigitizerChannelFunctionMic = 1005,
    VTEXDigitizerChannelFunctionMic200 = 1006,
    VTEXDigitizerChannelFunctionCal = 1007,
    VTEXDigitizerChannelFunctionResistance = 1008,
} VTEXDigitizerChannelFunctionEnum;

typedef enum
{
    VTEXDigitizerCouplingAC = 0,
    VTEXDigitizerCouplingDC = 1,
    VTEXDigitizerCouplingGnd = 2,
} VTEXDigitizerCouplingEnum;

typedef enum
{ 
    VTEXDigitizerWeightingNone = 1000,
    VTEXDigitizerWeightingA = 1001,
    VTEXDigitizerWeightingB = 1002,
    VTEXDigitizerWeightingC = 1003,
    VTEXDigitizerWeightingIntegration = 1004,
} VTEXDigitizerWeightingEnum;

typedef enum
{
    VTEXDigitizerAutoRangeDirectionBoth = 1000,
    VTEXDigitizerAutoRangeDirectionUp = 1001,
    VTEXDigitizerAutoRangeDirectionDown = 1002,
} VTEXDigitizerAutoRangeDirectionEnum;

typedef enum
{
    VTEXDigitizerAutoRangeModeOn = 1000,
    VTEXDigitizerAutoRangeModeOff = 1001,
    VTEXDigitizerAutoRangeModeOnce = 1002,
} VTEXDigitizerAutoRangeModeEnum;

typedef enum
{
    VTEXDigitizerFilterFIR = 1000,
    VTEXDigitizerFilterEclipse = 1001,
    VTEXDigitizerFilterBessel = 1002,
    VTEXDigitizerFilterButterworth = 1003,
} VTEXDigitizerFilterEnum;

typedef enum
{
    VTEXDigitizerChannelModeDifferential = 1000,
    VTEXDigitizerChannelModeSingleEnded = 1001,
    VTEXDigitizerChannelModePseudoDifferential = 1002,
} VTEXDigitizerChannelModeEnum;

typedef enum
{
    VTEXDigitizerShuntSourceExternal = 1000,
    VTEXDigitizerShuntSourceInternal = 1001,
    VTEXDigitizerShuntSourceInternal47k = 1002,
    VTEXDigitizerShuntSourceInternal310k = 1003,
    VTEXDigitizerShuntSourceRemote = 1004,
    VTEXDigitizerShuntSourceInternalCustom1 = 1002,
    VTEXDigitizerShuntSourceInternalCustom2 = 1003,
} VTEXDigitizerShuntSourceEnum;

typedef enum
{
    VTEXDigitizerCompletionResistorUser = 1000,
    VTEXDigitizerCompletionResistor120Ohm = 1001,
    VTEXDigitizerCompletionResistor350Ohm = 1002,
    VTEXDigitizerCompletionResistor1000Ohm = 1003,
    VTEXDigitizerCompletionResistorCustom1 = 1001,
    VTEXDigitizerCompletionResistorCustom2 = 1002,
    VTEXDigitizerCompletionResistorCustom3 = 1003,
} VTEXDigitizerCompletionResistorEnum;

typedef enum
{
    VTEXDigitizerBridgeTypeQuarter120 = 1000,
    VTEXDigitizerBridgeTypeQuarter350 = 1001,
    VTEXDigitizerBridgeTypeQuarterUser = 1002,
    VTEXDigitizerBridgeTypeHalfBending = 1003,
    VTEXDigitizerBridgeTypeHalfPoisson = 1004,
    VTEXDigitizerBridgeTypeFullBending = 1005,
    VTEXDigitizerBridgeTypeFullPoisson = 1006,
    VTEXDigitizerBridgeTypeFullPoissonBending = 1007,
    VTEXDigitizerBridgeTypeQuarter1000 = 1008,
    VTEXDigitizerBridgeTypeTwoWireOhm = 1009,
    VTEXDigitizerBridgeTypeFourWireOhm = 1010,
    VTEXDigitizerBridgeTypeRatiometric = 1011,
    VTEXDigitizerBridgeTypeLinear = 1012,
    VTEXDigitizerBridgeTypeExcitationVoltage = 1013,
    VTEXDigitizerBridgeTypeWagnerVoltage = 1014,
    VTEXDigitizerBridgeTypeQuarterCustom1 = 1000,
    VTEXDigitizerBridgeTypeQuarterCustom2 = 1001,
    VTEXDigitizerBridgeTypeQuarterCustom3 = 1008,
}  VTEXDigitizerBridgeTypeEnum;

typedef enum
{
    VTEXDigitizerExcitationTypeVoltage = 1000,
    VTEXDigitizerExcitationTypeCurrent = 1001,
    VTEXDigitizerExcitationTypeNone = 1002,
    VTEXDigitizerExcitationTypeExternal = 1003,
} VTEXDigitizerExcitationTypeEnum;

typedef enum
{
    VTEXDigitizerExcitationSlewRateFast = 1000,
    VTEXDigitizerExcitationSlewRateSlow = 1001,
} VTEXDigitizerExcitationSlewRateEnum;

typedef enum
{
    VTEXDigitizerTemperatureTransducerTypeThermocouple = 0,
    VTEXDigitizerTemperatureTransducerTypeThermistor = 1,
    VTEXDigitizerTemperatureTransducerType2WireRTD = 2,
    VTEXDigitizerTemperatureTransducerType4WireRTD = 3,
    VTEXDigitizerTemperatureTransducerType3WireRTD = 1000,
} VTEXDigitizerTemperatureTransducerTypeEnum;

typedef enum
{
    VTEXDigitizerRefJunctionTypeInternal = 1000,
    VTEXDigitizerRefJunctionTypeFixed = 1001,
} VTEXDigitizerRefJunctionTypeEnum;

typedef enum
{
    VTEXDigitizerThermocoupleTypeB = 0,
    VTEXDigitizerThermocoupleTypeC = 1,
    VTEXDigitizerThermocoupleTypeD = 2,
    VTEXDigitizerThermocoupleTypeE = 3,
    VTEXDigitizerThermocoupleTypeG = 4,
    VTEXDigitizerThermocoupleTypeJ = 5,
    VTEXDigitizerThermocoupleTypeK = 6,
    VTEXDigitizerThermocoupleTypeN = 7,
    VTEXDigitizerThermocoupleTypeR = 8,
    VTEXDigitizerThermocoupleTypeS = 9,
    VTEXDigitizerThermocoupleTypeT = 10,
    VTEXDigitizerThermocoupleTypeU = 11,
    VTEXDigitizerThermocoupleTypeV = 12,
    VTEXDigitizerThermocoupleTypeCustom = 1000,
} VTEXDigitizerThermocoupleTypeEnum;

#endif //___VTEXDigitizer_h__
#endif //_DIGITIZER_ENUMS_
