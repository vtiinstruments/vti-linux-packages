/******************************************************************************
*
*  .----------------------.    File Name: libDigitizer.h
*  |==     ==  ======  == |    Project : EX Platform
*  | ==   ==   ======  == |    $Author$
*  |  == ==      ==    == |    $Revision$
*  |   ===       ==    == |    $Date$
*  |    =        ==    == | $HeadURL$
*  `----------------------'
*
* Copyright 2010 VTI Instruments Inc. as an unpublished work.
* All rights reserved. The information contained herein is confidential
* property of VTI Instruments, Inc. Use, copy, transfer or disclosure
* of such information is prohibited except by express written agreement
* with VTI Instruments, Inc.
*
* PURPOSE:
*   Main public interface file for the Digitizer library.
*
* First Written By: James Vogel On Oct-2010
******************************************************************************/
#ifndef _libDigitizer_H
#define _libDigitizer_H

/**************************
 *       Includes         *
 **************************/
#include <string>
#include <vector>
#include "vtexExport.h"
#include "vtexInherent.h"
#include "libVtexException.h"

#include "libDigitizerEnums.h"
#include "libDigitizerErrors.h"

/**
 * Digitizer.Registers
 *
 */

class VTEX_EXPORT LibDigitizerRegisters
{
public:
    virtual ~LibDigitizerRegisters() {};

    virtual VTEXResult GetRegister(int32_t slot, int32_t address, int32_t &val) = 0;
    virtual VTEXResult SetRegister(int32_t slot, int32_t address, int32_t val) = 0;
    virtual VTEXResult GetRegisters(int32_t slot, int32_t address, int32_t length, std::vector<int32_t> &values) = 0;
    virtual VTEXResult SetRegisters(int32_t slot, int32_t address, std::vector<int32_t> values) = 0;
};

//=============================================================================

/**
 * Digitizer.Channel.Item[].Sampling
 *
 */

class VTEX_EXPORT LibDigitizerSampling
{
public:
    virtual ~LibDigitizerSampling() {};

    virtual VTEXResult Configure(int64_t record_size, double sample_rate, bool oversample) = 0;

    virtual VTEXResult GetFilterCoefficients(std::vector<double> &coeffs) = 0;
    virtual VTEXResult SetFilterCoefficients(std::vector<double> coeffs) = 0;

    virtual VTEXResult get_ClockFrequency(double &val) = 0;
    virtual VTEXResult put_ClockFrequency(double val) = 0;
    virtual VTEXResult get_RecordSize(int64_t &val) = 0;
    virtual VTEXResult put_RecordSize(int64_t val) = 0;
    virtual VTEXResult get_SampleRate(double &val) = 0;
    virtual VTEXResult put_SampleRate(double val) = 0;
    virtual VTEXResult get_Span(double &val) = 0;
    virtual VTEXResult put_Span(double val) = 0;
    virtual VTEXResult get_Oversample(bool &val) = 0;
    virtual VTEXResult put_Oversample(bool val) = 0;
    virtual VTEXResult get_Prescaler(int32_t &val) = 0;
    virtual VTEXResult put_Prescaler(int32_t val) = 0;
    virtual VTEXResult get_Multipass(bool &val) = 0;
    virtual VTEXResult put_Multipass(bool val) = 0;
    virtual VTEXResult get_DownsamplingFactor(int32_t &val) = 0;
    virtual VTEXResult put_DownsamplingFactor(int32_t val) = 0;
    virtual VTEXResult get_FilterType(VTEXDigitizerDecimationFilterEnum &val) = 0;
    virtual VTEXResult put_FilterType(VTEXDigitizerDecimationFilterEnum val) = 0;
    virtual VTEXResult get_GroupDelay(double &val) = 0;
    virtual VTEXResult put_GroupDelay(double val) = 0;

    vtexProperty <LibDigitizerSampling, double, READ_WRITE> ClockFrequency;
    vtexProperty <LibDigitizerSampling, int64_t, READ_WRITE> RecordSize;
    vtexProperty <LibDigitizerSampling, double, READ_WRITE> SampleRate;
    vtexProperty <LibDigitizerSampling, double, READ_WRITE> Span;
    vtexProperty <LibDigitizerSampling, bool, READ_WRITE> Oversample;
    vtexProperty <LibDigitizerSampling, int32_t, READ_WRITE> Prescaler;
    vtexProperty <LibDigitizerSampling, bool, READ_WRITE> Multipass;
    vtexProperty <LibDigitizerSampling, int32_t, READ_WRITE> DownsamplingFactor;
    vtexProperty <LibDigitizerSampling, VTEXDigitizerDecimationFilterEnum, READ_WRITE> FilterType;
    vtexProperty <LibDigitizerSampling, double, READ_WRITE> GroupDelay;
};

//=============================================================================

/**
* Digitizer.Dio.Channels.Item.Sampling
*/

class VTEX_EXPORT LibDigitizerDioChannelSampling
{
public:
    virtual ~LibDigitizerDioChannelSampling() {};

    virtual VTEXResult Configure(int64_t record_size, double sample_rate) = 0;

    virtual VTEXResult get_ClockFrequency(double &val) = 0;
    virtual VTEXResult put_ClockFrequency(double val) = 0;
    virtual VTEXResult get_RecordSize(int64_t &val) = 0;
    virtual VTEXResult put_RecordSize(int64_t val) = 0;
    virtual VTEXResult get_SampleRate(double &val) = 0;
    virtual VTEXResult put_SampleRate(double val) = 0;
    virtual VTEXResult get_Span(double &val) = 0;
    virtual VTEXResult put_Span(double val) = 0;
    virtual VTEXResult get_Prescaler(int32_t &val) = 0;
    virtual VTEXResult put_Prescaler(int32_t val) = 0;

    vtexProperty <LibDigitizerDioChannelSampling, double, READ_WRITE> ClockFrequency;
    vtexProperty <LibDigitizerDioChannelSampling, int64_t, READ_WRITE> RecordSize;
    vtexProperty <LibDigitizerDioChannelSampling, double, READ_WRITE> SampleRate;
    vtexProperty <LibDigitizerDioChannelSampling, double, READ_WRITE> Span;
    vtexProperty <LibDigitizerDioChannelSampling, int32_t, READ_WRITE> Prescaler;
};

//=============================================================================

/**
 * Digitizer.Measurement.Sampling
 */

class VTEX_EXPORT LibDigitizerMeasurementSampling
{
public:
    virtual ~LibDigitizerMeasurementSampling() {};

    virtual VTEXResult Configure(int64_t record_size, double sample_rate, bool oversample) = 0;

    virtual VTEXResult GetFilterCoefficients(std::vector<double> &coeffs) = 0;
    virtual VTEXResult SetFilterCoefficients(std::vector<double> coeffs) = 0;

    virtual VTEXResult get_ClockFrequency(double &val) = 0;
    virtual VTEXResult put_ClockFrequency(double val) = 0;
    virtual VTEXResult get_RecordSize(int64_t &val) = 0;
    virtual VTEXResult put_RecordSize(int64_t val) = 0;
    virtual VTEXResult get_SampleRate(double &val) = 0;
    virtual VTEXResult put_SampleRate(double val) = 0;
    virtual VTEXResult get_Span(double &val) = 0;
    virtual VTEXResult put_Span(double val) = 0;
    virtual VTEXResult get_Oversample(bool &val) = 0;
    virtual VTEXResult put_Oversample(bool val) = 0;
    virtual VTEXResult get_Prescaler(int32_t &val) = 0;
    virtual VTEXResult put_Prescaler(int32_t val) = 0;
    virtual VTEXResult get_Multipass(bool &val) = 0;
    virtual VTEXResult put_Multipass(bool val) = 0;
    virtual VTEXResult get_DownsamplingFactor(int32_t &val) = 0;
    virtual VTEXResult put_DownsamplingFactor(int32_t val) = 0;
    virtual VTEXResult get_FilterType(VTEXDigitizerDecimationFilterEnum &val) = 0;
    virtual VTEXResult put_FilterType(VTEXDigitizerDecimationFilterEnum val) = 0;
    virtual VTEXResult get_GroupDelay(double &val) = 0;
    virtual VTEXResult put_GroupDelay(double val) = 0;

    vtexProperty <LibDigitizerMeasurementSampling, double, READ_WRITE> ClockFrequency;
    vtexProperty <LibDigitizerMeasurementSampling, int64_t, READ_WRITE> RecordSize;
    vtexProperty <LibDigitizerMeasurementSampling, double, READ_WRITE> SampleRate;
    vtexProperty <LibDigitizerMeasurementSampling, double, READ_WRITE> Span;
    vtexProperty <LibDigitizerMeasurementSampling, bool, READ_WRITE> Oversample;
    vtexProperty <LibDigitizerMeasurementSampling, int32_t, READ_WRITE> Prescaler;
    vtexProperty <LibDigitizerMeasurementSampling, bool, READ_WRITE> Multipass;
    vtexProperty <LibDigitizerMeasurementSampling, int32_t, READ_WRITE> DownsamplingFactor;
    vtexProperty <LibDigitizerMeasurementSampling, VTEXDigitizerDecimationFilterEnum, READ_WRITE> FilterType;
    vtexProperty <LibDigitizerMeasurementSampling, double, READ_WRITE> GroupDelay;
};

//=============================================================================

/**
 * Digitizer.Measurement
 *
 */

class VTEX_EXPORT LibDigitizerMeasurement
{
public:
    virtual ~LibDigitizerMeasurement() {};

    LibDigitizerMeasurementSampling* Sampling;

    virtual VTEXResult Abort() = 0;
    virtual VTEXResult Initiate() = 0;
    virtual VTEXResult Read(int32_t max_time_ms,
                            int32_t num_records, int32_t& actual_records,
                            std::string &channel, std::vector<double> &data,
                            std::vector<double> &ts_sec, std::vector<double> &ts_frac,
                            std::string &addl_data) = 0;
    virtual VTEXResult ReadWithCJC(int32_t max_time_ms,
        int32_t num_records, int32_t& actual_records,
        std::string &channel, std::vector<double> &data,
        std::vector<double> &ts_sec, std::vector<double> &ts_frac,
        std::string &addl_data,
        std::string &channel_cjc, std::vector<double> &data_cjc,
        std::vector<double> &ts_sec_cjc, std::vector<double> &ts_frac_cjc) = 0;
    virtual VTEXResult WaitForMeasurementComplete(int32_t max_time_milliseconds) = 0;

    virtual VTEXResult get_State(VTEXDigitizerMeasurementStateEnum &val) = 0;
    virtual VTEXResult get_NumFIFORecords(int64_t &val) = 0;
    virtual VTEXResult get_NumAcquiredRecords(int64_t &val) = 0;
    virtual VTEXResult get_NumRecordsPerTrigger(int64_t &val) = 0;
    virtual VTEXResult put_NumRecordsPerTrigger(int64_t val) = 0;
    virtual VTEXResult get_FIFOMode(VTEXDigitizerFifoModeEnum &val) = 0;
    virtual VTEXResult put_FIFOMode(VTEXDigitizerFifoModeEnum val) = 0;
    virtual VTEXResult get_DataFormat(VTEXDigitizerDataFormatEnum &val) = 0;
    virtual VTEXResult put_DataFormat(VTEXDigitizerDataFormatEnum val) = 0;

    vtexProperty <LibDigitizerMeasurement, VTEXDigitizerMeasurementStateEnum, READ_ONLY> State;
    vtexProperty <LibDigitizerMeasurement, int64_t, READ_ONLY> NumFIFORecords;
    vtexProperty <LibDigitizerMeasurement, int64_t, READ_ONLY> NumAcquiredRecords;
    vtexProperty <LibDigitizerMeasurement, int64_t, READ_WRITE> NumRecordsPerTrigger;
    vtexProperty <LibDigitizerMeasurement, VTEXDigitizerFifoModeEnum, READ_WRITE> FIFOMode;
    vtexProperty <LibDigitizerMeasurement, VTEXDigitizerDataFormatEnum, READ_WRITE> DataFormat;
};

//=============================================================================

/**
 * Digitizer.Alarm
 *
 */

class VTEX_EXPORT LibDigitizerAlarm
{
public:
    virtual ~LibDigitizerAlarm() {};

    virtual VTEXResult Configure(bool enabled, double time_seconds, double time_fraction, double period, int32_t repeat_count) = 0;

    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Period(double &val) = 0;
    virtual VTEXResult put_Period(double val) = 0;
    virtual VTEXResult get_RepeatCount(int32_t &val) = 0;
    virtual VTEXResult put_RepeatCount(int32_t val) = 0;
    virtual VTEXResult get_TimeSeconds(double &val) = 0;
    virtual VTEXResult put_TimeSeconds(double val) = 0;
    virtual VTEXResult get_TimeFraction(double &val) = 0;
    virtual VTEXResult put_TimeFraction(double val) = 0;

    vtexProperty <LibDigitizerAlarm, bool, READ_WRITE> Enabled;
    vtexProperty <LibDigitizerAlarm, double, READ_WRITE> Period;
    vtexProperty <LibDigitizerAlarm, int32_t, READ_WRITE> RepeatCount;
    vtexProperty <LibDigitizerAlarm, double, READ_WRITE> TimeSeconds;
    vtexProperty <LibDigitizerAlarm, double, READ_WRITE> TimeFraction;
};

//=============================================================================

/**
* Digitizer.Alarms
*
*/

class VTEX_EXPORT LibDigitizerAlarms
{
public:
    virtual ~LibDigitizerAlarms() {};

    virtual VTEXResult DisableAll() = 0;
    virtual LibDigitizerAlarm* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibDigitizerAlarms, int32_t, READ_ONLY> Count;
    arrayizer <LibDigitizerAlarms, LibDigitizerAlarm*, std::string> Item;
    arrayizer <LibDigitizerAlarms, std::string, int32_t> Name;
};

//=============================================================================

/**
 * Digitizer.Arm.Sources.Item
 *
 */

class VTEX_EXPORT LibDigitizerArmSource
{
public:
    virtual ~LibDigitizerArmSource() {};

    virtual VTEXResult Configure(bool enabled, VTEXDigitizerArmSourceDetectionEnum detection) = 0;

    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Detection(VTEXDigitizerArmSourceDetectionEnum &val) = 0;
    virtual VTEXResult put_Detection(VTEXDigitizerArmSourceDetectionEnum val) = 0;
    virtual VTEXResult get_Filter(std::string &val) = 0;
    virtual VTEXResult put_Filter(const std::string val) = 0;
    virtual VTEXResult get_EventId(std::string &val) = 0;
    virtual VTEXResult put_EventId(const std::string val) = 0;

    vtexProperty <LibDigitizerArmSource, bool, READ_WRITE> Enabled;
    vtexProperty <LibDigitizerArmSource, VTEXDigitizerArmSourceDetectionEnum, READ_WRITE> Detection;
    vtexProperty <LibDigitizerArmSource, std::string, READ_WRITE> Filter;
    vtexProperty <LibDigitizerArmSource, std::string, READ_WRITE> EventId;
};

//=============================================================================

/**
 * Digitizer.Arm.Sources
 *
 */

class VTEX_EXPORT LibDigitizerArmSources
{
public:
    virtual ~LibDigitizerArmSources() {};

    virtual VTEXResult DisableAll() = 0;
    virtual LibDigitizerArmSource* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibDigitizerArmSources, int32_t, READ_ONLY> Count;
    arrayizer <LibDigitizerArmSources, LibDigitizerArmSource*, std::string> Item;
    arrayizer <LibDigitizerArmSources, std::string, int32_t> Name;
};

//=============================================================================

/**
 * Digitizer.Arm
 *
 */

class VTEX_EXPORT LibDigitizerArm
{
public:
    virtual ~LibDigitizerArm() {};

    LibDigitizerArmSources* Sources;

    virtual VTEXResult SendSoftwareArm() = 0;

    virtual VTEXResult get_ArmCount(int32_t &val) = 0;
    virtual VTEXResult put_ArmCount(int32_t val) = 0;
    virtual VTEXResult get_Delay(double &val) = 0;
    virtual VTEXResult put_Delay(double val) = 0;
    virtual VTEXResult get_SourceOperator(VTEXDigitizerArmSourceOperatorEnum &val) = 0;
    virtual VTEXResult put_SourceOperator(VTEXDigitizerArmSourceOperatorEnum val) = 0;

    vtexProperty <LibDigitizerArm, int32_t, READ_WRITE> ArmCount;
    vtexProperty <LibDigitizerArm, double, READ_WRITE> Delay;
    vtexProperty <LibDigitizerArm, VTEXDigitizerArmSourceOperatorEnum, READ_WRITE> SourceOperator;
};

//=============================================================================

/**
 * Digitizer.Channels.Item.Temperature.RTD
 *
 */

class VTEX_EXPORT LibDigitizerTemperatureRTD
{
public:
    virtual ~LibDigitizerTemperatureRTD() {};

    virtual VTEXResult Configure(double alpha, double resistance) = 0;

    virtual VTEXResult get_Alpha(double &val) = 0;
    virtual VTEXResult put_Alpha(double val) = 0;
    virtual VTEXResult get_Resistance(double &val) = 0;
    virtual VTEXResult put_Resistance(double val) = 0;

    vtexProperty <LibDigitizerTemperatureRTD, double, READ_WRITE> Alpha;
    vtexProperty <LibDigitizerTemperatureRTD, double, READ_WRITE> Resistance;
};

//=============================================================================

/**
 * Digitizer.Channels.Item.Temperature.Thermocouple
 *
 */

class VTEX_EXPORT LibDigitizerTemperatureThermocouple
{
public:
    virtual ~LibDigitizerTemperatureThermocouple() {};

    virtual VTEXResult Configure(VTEXDigitizerThermocoupleTypeEnum thermocouple_type,
                                  double fixed_reference_junction,
                                  VTEXDigitizerRefJunctionTypeEnum reference_junction_type) = 0;

    virtual VTEXResult SetCustomCJCConversion(std::vector<double> conversion) = 0;
    virtual VTEXResult GetCustomCJCConversion(std::vector<double> &conversion) = 0;

    virtual VTEXResult get_FixedRefJunction(double &val) = 0;
    virtual VTEXResult put_FixedRefJunction(double val) = 0;
    virtual VTEXResult get_RefJunctionType(VTEXDigitizerRefJunctionTypeEnum &val) = 0;
    virtual VTEXResult put_RefJunctionType(VTEXDigitizerRefJunctionTypeEnum val) = 0;
    virtual VTEXResult get_Type(VTEXDigitizerThermocoupleTypeEnum &val) = 0;
    virtual VTEXResult put_Type(VTEXDigitizerThermocoupleTypeEnum val) = 0;
    virtual VTEXResult get_CJCReportingEnabled(bool &val) = 0;
    virtual VTEXResult put_CJCReportingEnabled(bool val) = 0;

    vtexProperty <LibDigitizerTemperatureThermocouple, double, READ_WRITE> FixedRefJunction;
    vtexProperty <LibDigitizerTemperatureThermocouple, VTEXDigitizerRefJunctionTypeEnum, READ_WRITE> RefJunctionType;
    vtexProperty <LibDigitizerTemperatureThermocouple, VTEXDigitizerThermocoupleTypeEnum, READ_WRITE> Type;
    vtexProperty <LibDigitizerTemperatureThermocouple, bool, READ_WRITE> CJCReportingEnabled;
};

//=============================================================================

/**
 * Digitizer.Channels.Item.Temperature.Thermistor
 *
 */

class VTEX_EXPORT LibDigitizerTemperatureThermistor
{
public:
    virtual ~LibDigitizerTemperatureThermistor() {};

    virtual VTEXResult get_Resistance(double &val) = 0;
    virtual VTEXResult put_Resistance(double val) = 0;

    vtexProperty <LibDigitizerTemperatureThermistor, double, READ_WRITE> Resistance;
};

//=============================================================================

/**
 * Digitizer.Channels.Item.Temperature
 *
 */

class VTEX_EXPORT LibDigitizerTemperature
{
public:
    virtual ~LibDigitizerTemperature() {};

    virtual VTEXResult get_TransducerType(VTEXDigitizerTemperatureTransducerTypeEnum &val) = 0;
    virtual VTEXResult put_TransducerType(VTEXDigitizerTemperatureTransducerTypeEnum val) = 0;
    virtual VTEXResult get_Units(VTEXDigitizerTemperatureUnitsEnum &val) = 0;
    virtual VTEXResult put_Units(VTEXDigitizerTemperatureUnitsEnum val) = 0;

    LibDigitizerTemperatureRTD* RTD;
    LibDigitizerTemperatureThermocouple* Thermocouple;
    LibDigitizerTemperatureThermistor* Thermistor;

    vtexProperty <LibDigitizerTemperature, VTEXDigitizerTemperatureTransducerTypeEnum, READ_WRITE> TransducerType;
    vtexProperty <LibDigitizerTemperature, VTEXDigitizerTemperatureUnitsEnum, READ_WRITE> Units;
};

//=============================================================================

/**
 * Digitizer.Channels.Item.Strain
 *
 */

class VTEX_EXPORT LibDigitizerStrain
{
public:
    virtual ~LibDigitizerStrain() {};

    virtual VTEXResult MeasureLeadWireResistance(double &val) = 0;
    virtual VTEXResult MeasureExcitationLevel(double &val) = 0;
    virtual VTEXResult MeasureUnstrainedVoltage(double &val) = 0;
    virtual VTEXResult MeasureWiringResistance(double &val) = 0;
    virtual VTEXResult MeasureThermalEMFOffset(double &val) = 0;
    virtual VTEXResult MeasureShuntCalibrationGain(double &val) = 0;

    virtual VTEXResult Configure(VTEXDigitizerBridgeTypeEnum bridge_type,
                                 double gauge_factor,
                                 double poisson_ratio,
                                 VTEXDigitizerExcitationTypeEnum excitation_type,
                                 double excitation_level,
                                 double unstrained_voltage,
                                 double leadwire_desensitization,
                                 double leadwire_resistance) = 0;

    virtual VTEXResult get_BridgeType(VTEXDigitizerBridgeTypeEnum &val) = 0;
    virtual VTEXResult put_BridgeType(VTEXDigitizerBridgeTypeEnum val) = 0;
    virtual VTEXResult get_CompletionResistance(double &val) = 0;
    virtual VTEXResult put_CompletionResistance(double val) = 0;
    virtual VTEXResult get_CompletionResistor(VTEXDigitizerCompletionResistorEnum &val) = 0;
    virtual VTEXResult put_CompletionResistor(VTEXDigitizerCompletionResistorEnum val) = 0;
    virtual VTEXResult get_DynamicExcitationEnabled(bool &val) = 0;
    virtual VTEXResult put_DynamicExcitationEnabled(bool val) = 0;
    virtual VTEXResult get_ExcitationLevel(double &val) = 0;
    virtual VTEXResult put_ExcitationLevel(double val) = 0;
    virtual VTEXResult get_ExcitationPin(int32_t &val) = 0;
    virtual VTEXResult put_ExcitationPin(int32_t val) = 0;
    virtual VTEXResult get_ExcitationSlewRate(VTEXDigitizerExcitationSlewRateEnum &val) = 0;
    virtual VTEXResult put_ExcitationSlewRate(VTEXDigitizerExcitationSlewRateEnum val) = 0;
    virtual VTEXResult get_ExcitationType(VTEXDigitizerExcitationTypeEnum &val) = 0;
    virtual VTEXResult put_ExcitationType(VTEXDigitizerExcitationTypeEnum val) = 0;
    virtual VTEXResult get_GaugeFactor(double &val) = 0;
    virtual VTEXResult put_GaugeFactor(double val) = 0;
    virtual VTEXResult get_HalfBridgeLeadWireDesensitization(double &val) = 0;
    virtual VTEXResult put_HalfBridgeLeadWireDesensitization(double val) = 0;
    virtual VTEXResult get_LeadWireResistance(double &val) = 0;
    virtual VTEXResult put_LeadWireResistance(double val) = 0;
    virtual VTEXResult get_OhmGaugeResistance(double &val) = 0;
    virtual VTEXResult put_OhmGaugeResistance(double val) = 0;
    virtual VTEXResult get_PoissonRatio(double &val) = 0;
    virtual VTEXResult put_PoissonRatio(double val) = 0;
    virtual VTEXResult get_RemoteExcitationSenseEnabled(bool &val) = 0;
    virtual VTEXResult put_RemoteExcitationSenseEnabled(bool val) = 0;
    virtual VTEXResult get_RemoteShuntEnabled(bool &val) = 0;
    virtual VTEXResult put_RemoteShuntEnabled(bool val) = 0;
    virtual VTEXResult get_ShortCircuitTestEnabled(bool &val) = 0;
    virtual VTEXResult put_ShortCircuitTestEnabled(bool val) = 0;
    virtual VTEXResult get_ShuntCalibrationGain(double &val) = 0;
    virtual VTEXResult put_ShuntCalibrationGain(double val) = 0;
    virtual VTEXResult get_ShuntEnabled(bool &val) = 0;
    virtual VTEXResult put_ShuntEnabled(bool val) = 0;
    virtual VTEXResult get_ShuntResistance(double &val) = 0;
    virtual VTEXResult put_ShuntResistance(double val) = 0;
    virtual VTEXResult get_ShuntSource(VTEXDigitizerShuntSourceEnum &val) = 0;
    virtual VTEXResult put_ShuntSource(VTEXDigitizerShuntSourceEnum val) = 0;
    virtual VTEXResult get_ThermalEMFOffset(double &val) = 0;
    virtual VTEXResult put_ThermalEMFOffset(double val) = 0;
    virtual VTEXResult get_ThermalEMFOffsetMeasurementPeriod(double &val) = 0;
    virtual VTEXResult put_ThermalEMFOffsetMeasurementPeriod(double val) = 0;
    virtual VTEXResult get_UnstrainedVoltage(double &val) = 0;
    virtual VTEXResult put_UnstrainedVoltage(double val) = 0;
    virtual VTEXResult get_ACCalibrationEnabled(bool &val) = 0;
    virtual VTEXResult put_ACCalibrationEnabled(bool val) = 0;
    virtual VTEXResult get_ACCalibrationAmplitude(double &val) = 0;
    virtual VTEXResult put_ACCalibrationAmplitude(double val) = 0;
    virtual VTEXResult get_ACCalibrationFrequency(double &val) = 0;
    virtual VTEXResult put_ACCalibrationFrequency(double val) = 0;

    vtexProperty <LibDigitizerStrain, VTEXDigitizerBridgeTypeEnum, READ_WRITE> BridgeType;
    vtexProperty <LibDigitizerStrain, double, READ_WRITE> CompletionResistance;
    vtexProperty <LibDigitizerStrain, VTEXDigitizerCompletionResistorEnum, READ_WRITE> CompletionResistor;
    vtexProperty <LibDigitizerStrain, bool, READ_WRITE> DynamicExcitationEnabled;
    vtexProperty <LibDigitizerStrain, double, READ_WRITE> ExcitationLevel;
    vtexProperty <LibDigitizerStrain, VTEXDigitizerExcitationSlewRateEnum, READ_WRITE> ExcitationSlewRate;
    vtexProperty <LibDigitizerStrain, int32_t, READ_WRITE> ExcitationPin;
    vtexProperty <LibDigitizerStrain, VTEXDigitizerExcitationTypeEnum, READ_WRITE> ExcitationType;
    vtexProperty <LibDigitizerStrain, double, READ_WRITE> GaugeFactor;
    vtexProperty <LibDigitizerStrain, double, READ_WRITE> HalfBridgeLeadWireDesensitization;
    vtexProperty <LibDigitizerStrain, double, READ_WRITE> LeadWireResistance;
    vtexProperty <LibDigitizerStrain, double, READ_WRITE> OhmGaugeResistance;
    vtexProperty <LibDigitizerStrain, double, READ_WRITE> PoissonRatio;
    vtexProperty <LibDigitizerStrain, bool, READ_WRITE> RemoteExcitationSenseEnabled;
    vtexProperty <LibDigitizerStrain, bool, READ_WRITE> RemoteShuntEnabled;
    vtexProperty <LibDigitizerStrain, bool, READ_WRITE> ShortCircuitTestEnabled;
    vtexProperty <LibDigitizerStrain, double, READ_WRITE> ShuntCalibrationGain;
    vtexProperty <LibDigitizerStrain, bool, READ_WRITE> ShuntEnabled;
    vtexProperty <LibDigitizerStrain, double, READ_WRITE> ShuntResistance;
    vtexProperty <LibDigitizerStrain, VTEXDigitizerShuntSourceEnum, READ_WRITE> ShuntSource;
    vtexProperty <LibDigitizerStrain, double, READ_WRITE> ThermalEMFOffset;
    vtexProperty <LibDigitizerStrain, double, READ_WRITE> ThermalEMFOffsetMeasurementPeriod;
    vtexProperty <LibDigitizerStrain, double, READ_WRITE> UnstrainedVoltage;
    vtexProperty <LibDigitizerStrain, bool, READ_WRITE> ACCalibrationEnabled;
    vtexProperty <LibDigitizerStrain, double, READ_WRITE> ACCalibrationAmplitude;
    vtexProperty <LibDigitizerStrain, double, READ_WRITE> ACCalibrationFrequency;
};

//=============================================================================

/**
 * Digitizer.Channels.Item.Overload
 *
 */

class VTEX_EXPORT LibDigitizerOverload
{
public:
    virtual ~LibDigitizerOverload() {};

    virtual VTEXResult Clear(int32_t mask) = 0;
    virtual VTEXResult Configure(int32_t latch_enabled, int32_t indicator, bool enabled, double lower_limit, double upper_limit) = 0;

    virtual VTEXResult get_Status(int32_t &val) = 0;
    virtual VTEXResult get_LatchEnabled(int32_t &val) = 0;
    virtual VTEXResult put_LatchEnabled(int32_t val) = 0;
    virtual VTEXResult get_Indicator(int32_t &val) = 0;
    virtual VTEXResult put_Indicator(int32_t val) = 0;
    virtual VTEXResult get_EventEnabled(int32_t &val) = 0;
    virtual VTEXResult put_EventEnabled(int32_t val) = 0;
    virtual VTEXResult get_UserLimitEnabled(bool &val) = 0;
    virtual VTEXResult put_UserLimitEnabled(bool val) = 0;
    virtual VTEXResult get_UserUpperLimit(double &val) = 0;
    virtual VTEXResult put_UserUpperLimit(double val) = 0;
    virtual VTEXResult get_UserLowerLimit(double &val) = 0;
    virtual VTEXResult put_UserLowerLimit(double val) = 0;
    virtual VTEXResult get_OTDEnabled(bool &val) = 0;
    virtual VTEXResult put_OTDEnabled(bool val) = 0;

    vtexProperty <LibDigitizerOverload, int32_t, READ_ONLY> Status;
    vtexProperty <LibDigitizerOverload, int32_t, READ_WRITE> LatchEnabled;
    vtexProperty <LibDigitizerOverload, int32_t, READ_WRITE> Indicator;
    vtexProperty <LibDigitizerOverload, int32_t, READ_WRITE> EventEnabled;
    vtexProperty <LibDigitizerOverload, bool, READ_WRITE> UserLimitEnabled;
    vtexProperty <LibDigitizerOverload, double, READ_WRITE> UserUpperLimit;
    vtexProperty <LibDigitizerOverload, double, READ_WRITE> UserLowerLimit;
    vtexProperty <LibDigitizerOverload, bool, READ_WRITE> OTDEnabled;
};

//=============================================================================

/**
 * Digitizer.Configuration
 *
 */

class VTEX_EXPORT LibDigitizerConfiguration
{
public:
    virtual ~LibDigitizerConfiguration() {};

    virtual VTEXResult SaveConfiguration() = 0;
    virtual VTEXResult LoadSavedConfiguration() = 0;
    virtual VTEXResult ClearSavedConfiguration() = 0;
    virtual VTEXResult get_CurrentConfigurationDigest(std::string &val) = 0;
    virtual VTEXResult get_SavedConfigurationDigest(std::string &val) = 0;

    virtual VTEXResult SaveConfigurationToStorageDevice(std::string device) = 0;
    virtual VTEXResult LoadConfigurationFromStorageDevice(std::string device) = 0;
    virtual VTEXResult ClearConfigurationFromStorageDevice(std::string device) = 0;
    virtual VTEXResult GetConfigurationDigestFromStorageDevice(std::string device, std::string &val) = 0;

    vtexProperty <LibDigitizerConfiguration, std::string, READ_ONLY> CurrentConfigurationDigest;
    vtexProperty <LibDigitizerConfiguration, std::string, READ_ONLY> SavedConfigurationDigest;
};

//=============================================================================

class VTEX_EXPORT LibDigitizerDioChannel
{
public:
    virtual ~LibDigitizerDioChannel() {};

    virtual VTEXResult Configure(int32_t output_mask, int32_t state) = 0;

    virtual VTEXResult get_OutputMask(int32_t &val) = 0;
    virtual VTEXResult put_OutputMask(int32_t val) = 0;
    virtual VTEXResult get_State(int32_t &val) = 0;
    virtual VTEXResult put_State(int32_t val) = 0;
    virtual VTEXResult get_Width(int32_t &val) = 0;
    virtual VTEXResult get_ReportingEnabled(bool &val) = 0;
    virtual VTEXResult put_ReportingEnabled(bool val) = 0;

    LibDigitizerDioChannelSampling* Sampling;

    vtexProperty <LibDigitizerDioChannel, int32_t, READ_WRITE> OutputMask;
    vtexProperty <LibDigitizerDioChannel, int32_t, READ_WRITE> State;
    vtexProperty <LibDigitizerDioChannel, int32_t, READ_ONLY> Width;
    vtexProperty <LibDigitizerDioChannel, bool, READ_WRITE> ReportingEnabled;
};

//=============================================================================

class VTEX_EXPORT LibDigitizerDioChannels
{
public:
    virtual ~LibDigitizerDioChannels() {};

    virtual LibDigitizerDioChannel* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibDigitizerDioChannels, int32_t, READ_ONLY> Count;
    arrayizer <LibDigitizerDioChannels, LibDigitizerDioChannel*, std::string> Item;
    arrayizer <LibDigitizerDioChannels, std::string, int32_t> Name;
};

//=============================================================================

class VTEX_EXPORT LibDigitizerDio
{
public:
    virtual ~LibDigitizerDio() {};

    LibDigitizerDioChannels *Channels;
};

//=============================================================================

/**
 * Digitizer.Channels.Item.Filter
 *
 */

class VTEX_EXPORT LibDigitizerFilter
{
public:
    virtual ~LibDigitizerFilter() {}

    virtual VTEXResult Configure(double min_frequency, double max_frequency) = 0;

    virtual VTEXResult get_Bypass(bool &val) = 0;
    virtual VTEXResult put_Bypass(bool val) = 0;
    virtual VTEXResult get_MaxFrequency(double &val) = 0;
    virtual VTEXResult put_MaxFrequency(double val) = 0;
    virtual VTEXResult get_MinFrequency(double &val) = 0;
    virtual VTEXResult put_MinFrequency(double val) = 0;
    virtual VTEXResult get_Type(VTEXDigitizerFilterEnum &val) = 0;
    virtual VTEXResult put_Type(VTEXDigitizerFilterEnum val) = 0;

    vtexProperty <LibDigitizerFilter, bool, READ_WRITE> Bypass;
    vtexProperty <LibDigitizerFilter, double, READ_WRITE> MaxFrequency;
    vtexProperty <LibDigitizerFilter, double, READ_WRITE> MinFrequency;
    vtexProperty <LibDigitizerFilter, VTEXDigitizerFilterEnum, READ_WRITE> Type;
};

//=============================================================================

/**
 * Digitizer.Channels.Item.Measurement
 *
 */

class VTEX_EXPORT LibDigitizerChannelMeasurement
{
public:
    virtual ~LibDigitizerChannelMeasurement() {};

    virtual VTEXResult FetchWaveform(std::vector<double> waveform_array,
                              int64_t &actual_points, int64_t &first_valid_point, double &initial_x_offset,
                              double &initial_x_time_sec, double &initial_x_time_frac, double &x_increment) = 0;

    virtual VTEXResult ReadWaveform(int32_t max_time_millis, std::vector<double> waveform_array,
                             int64_t &actual_points, int64_t &first_valid_point, double &initial_x_offset,
                             double &initial_x_time_sec, double &initial_x_time_frac, double &x_increment) = 0;
};

//=============================================================================

/**
 * Digitizer.Channels.Item.TEDS
 *
 */

class VTEX_EXPORT LibDigitizerTEDS
{
public:
    virtual ~LibDigitizerTEDS() {};

    virtual VTEXResult ReadURN(std::vector<int16_t> &urn) = 0;
    virtual VTEXResult ReadTEDS(std::vector<int16_t> &teds) = 0;
    virtual VTEXResult WriteTEDS(std::vector<int16_t> teds) = 0;

    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;

    vtexProperty <LibDigitizerTEDS, bool, READ_WRITE> Enabled;
};

//=============================================================================

/**
 * Digitizer.Channels.Item.Transducer
 *
 */

class VTEX_EXPORT LibDigitizerTransducer
{
public:
    virtual ~LibDigitizerTransducer() {};

    virtual VTEXResult SetConversion(std::vector<double> conversion) = 0;
    virtual VTEXResult GetConversion(std::vector<double> &conversion) = 0;

    virtual VTEXResult get_UpperLimit(double &val) = 0;
    virtual VTEXResult put_UpperLimit(double val) = 0;
    virtual VTEXResult get_LowerLimit(double &val) = 0;
    virtual VTEXResult put_LowerLimit(double val) = 0;

    vtexProperty <LibDigitizerTransducer, double, READ_WRITE> UpperLimit;
    vtexProperty <LibDigitizerTransducer, double, READ_WRITE> LowerLimit;
};

//=============================================================================

/**
 * Digitizer.Channels.Item
 *
 */

class VTEX_EXPORT LibDigitizerChannel
{
public:
    virtual ~LibDigitizerChannel() {};

    LibDigitizerTemperature*          Temperature;
    LibDigitizerStrain*               Strain;
    LibDigitizerOverload*             Overload;
    LibDigitizerFilter*               Filter;
    LibDigitizerChannelMeasurement*   Measurement;
    LibDigitizerTEDS*                 TEDS;
    LibDigitizerTransducer*           Transducer;
    LibDigitizerSampling*             Sampling;

    virtual VTEXResult Configure(bool enabled, VTEXDigitizerCouplingEnum coupling, double range,
                                 VTEXDigitizerChannelModeEnum mode, VTEXDigitizerChannelFunctionEnum function) = 0;
    virtual VTEXResult AutoRangeOnce() = 0;
    virtual VTEXResult AutoCal() = 0;
    virtual VTEXResult AutoZero() = 0;

    virtual VTEXResult get_Members(std::string &val) = 0;
    virtual VTEXResult get_Coupling(VTEXDigitizerCouplingEnum &val) = 0;
    virtual VTEXResult put_Coupling(VTEXDigitizerCouplingEnum val) = 0;
    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Impedance(double &val) = 0;
    virtual VTEXResult put_Impedance(double val) = 0;
    virtual VTEXResult get_Range(double &val) = 0;
    virtual VTEXResult put_Range(double val) = 0;
    virtual VTEXResult get_Weighting(VTEXDigitizerWeightingEnum &val) = 0;
    virtual VTEXResult put_Weighting(VTEXDigitizerWeightingEnum val) = 0;
    virtual VTEXResult get_Mode(VTEXDigitizerChannelModeEnum &val) = 0;
    virtual VTEXResult put_Mode(VTEXDigitizerChannelModeEnum val) = 0;
    virtual VTEXResult get_Function(VTEXDigitizerChannelFunctionEnum &val) = 0;
    virtual VTEXResult put_Function(VTEXDigitizerChannelFunctionEnum val) = 0;
    virtual VTEXResult get_IEPECurrent(double &val) = 0;
    virtual VTEXResult put_IEPECurrent(double val) = 0;
    virtual VTEXResult get_Offset(double &val) = 0;
    virtual VTEXResult put_Offset(double val) = 0;
    virtual VTEXResult get_AutoRangeMode(VTEXDigitizerAutoRangeModeEnum &val) = 0;
    virtual VTEXResult put_AutoRangeMode(VTEXDigitizerAutoRangeModeEnum val) = 0;
    virtual VTEXResult get_AutoRangeDirection(VTEXDigitizerAutoRangeDirectionEnum &val) = 0;
    virtual VTEXResult put_AutoRangeDirection(VTEXDigitizerAutoRangeDirectionEnum val) = 0;
    virtual VTEXResult get_AnalogFilterEnabled(bool &val) = 0;
    virtual VTEXResult put_AnalogFilterEnabled(bool val) = 0;
    virtual VTEXResult get_AnalogFilterCutoff(double &val) = 0;
    virtual VTEXResult put_AnalogFilterCutoff(double val) = 0;

    vtexProperty <LibDigitizerChannel, std::string, READ_ONLY> Members;
    vtexProperty <LibDigitizerChannel, VTEXDigitizerCouplingEnum, READ_WRITE> Coupling;
    vtexProperty <LibDigitizerChannel, bool, READ_WRITE> Enabled;
    vtexProperty <LibDigitizerChannel, double, READ_WRITE> Impedance;
    vtexProperty <LibDigitizerChannel, double, READ_WRITE> Range;
    vtexProperty <LibDigitizerChannel, VTEXDigitizerWeightingEnum, READ_WRITE> Weighting;
    vtexProperty <LibDigitizerChannel, VTEXDigitizerChannelModeEnum, READ_WRITE> Mode;
    vtexProperty <LibDigitizerChannel, VTEXDigitizerChannelFunctionEnum, READ_WRITE> Function;
    vtexProperty <LibDigitizerChannel, double, READ_WRITE> IEPECurrent;
    vtexProperty <LibDigitizerChannel, double, READ_WRITE> Offset;
    vtexProperty <LibDigitizerChannel, VTEXDigitizerAutoRangeModeEnum, READ_WRITE> AutoRangeMode;
    vtexProperty <LibDigitizerChannel, VTEXDigitizerAutoRangeDirectionEnum, READ_WRITE> AutoRangeDirection;
    vtexProperty <LibDigitizerChannel, bool, READ_WRITE> AnalogFilterEnabled;
    vtexProperty <LibDigitizerChannel, double, READ_WRITE> AnalogFilterCutoff;
};

//=============================================================================

/**
 * Digitizer.Channels
 *
 */

class VTEX_EXPORT LibDigitizerChannels
{
public:
    virtual ~LibDigitizerChannels() {};

    virtual VTEXResult AddChannelGroup(std::string name, std::string channels) = 0;
    virtual VTEXResult RemoveChannelGroup(std::string name) = 0;
    virtual VTEXResult RemoveAllChannelGroups() = 0;

    virtual LibDigitizerChannel* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;
    virtual VTEXResult get_NumChannels(int32_t &val) = 0;

    vtexProperty <LibDigitizerChannels, int32_t, READ_ONLY> Count;
    vtexProperty <LibDigitizerChannels, int32_t, READ_ONLY> NumChannels;
    arrayizer <LibDigitizerChannels, LibDigitizerChannel*, std::string> Item;
    arrayizer <LibDigitizerChannels, std::string, int32_t> Name;
};

//=============================================================================

/**
 * Digitizer.Events.Item
 *
 */

class VTEX_EXPORT LibDigitizerEvent
{
public:
    virtual ~LibDigitizerEvent() {};

    virtual VTEXResult Configure(VTEXDigitizerEventDriveModeEnum drive_mode,
                                 std::string source,
                                 std::string destination_path,
                                 VTEXDigitizerSourceSlopeEnum slope) = 0;

    virtual VTEXResult get_DestinationPath(std::string &val) = 0;
    virtual VTEXResult put_DestinationPath(std::string val) = 0;
    virtual VTEXResult get_DriveMode(VTEXDigitizerEventDriveModeEnum &val) = 0;
    virtual VTEXResult put_DriveMode(VTEXDigitizerEventDriveModeEnum val) = 0;
    virtual VTEXResult get_Source(std::string &val) = 0;
    virtual VTEXResult put_Source(std::string val) = 0;
    virtual VTEXResult get_Slope(VTEXDigitizerSourceSlopeEnum &val) = 0;
    virtual VTEXResult put_Slope(VTEXDigitizerSourceSlopeEnum val) = 0;

    vtexProperty <LibDigitizerEvent, std::string, READ_WRITE> DestinationPath;
    vtexProperty <LibDigitizerEvent, VTEXDigitizerEventDriveModeEnum, READ_WRITE> DriveMode;
    vtexProperty <LibDigitizerEvent, std::string, READ_WRITE> Source;
    vtexProperty <LibDigitizerEvent, VTEXDigitizerSourceSlopeEnum, READ_WRITE> Slope;
};

//=============================================================================

/**
 * Digitizer.Events
 *
 */

class VTEX_EXPORT LibDigitizerEvents
{
public:
    virtual ~LibDigitizerEvents() {};

    virtual VTEXResult Add(std::string name) = 0;
    virtual VTEXResult Remove(std::string name) = 0;
    virtual VTEXResult DisableAll() = 0;
    virtual VTEXResult Pulse(std::string list_of_events) = 0;

    virtual LibDigitizerEvent* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    virtual VTEXResult get_WiredOrBiasMode(int32_t &val) = 0;
    virtual VTEXResult put_WiredOrBiasMode(int32_t val) = 0;
    virtual VTEXResult get_ListOfSources(std::string &val) = 0;

    vtexProperty <LibDigitizerEvents, int32_t, READ_ONLY> Count;
    vtexProperty <LibDigitizerEvents, int32_t, READ_WRITE> WiredOrBiasMode;
    vtexProperty <LibDigitizerEvents, std::string, READ_ONLY> ListOfSources;
    arrayizer <LibDigitizerEvents, LibDigitizerEvent*, std::string> Item;
    arrayizer <LibDigitizerEvents, std::string, int32_t> Name;
};

//=============================================================================

/**
 * Digitizer.Trigger.Sources.Item
 *
 */

class VTEX_EXPORT LibDigitizerTriggerSource
{
public:
    virtual ~LibDigitizerTriggerSource() {};

    virtual VTEXResult Configure(bool enabled,
                                 VTEXDigitizerTriggerSourceDetectionEnum detection) = 0;
    virtual VTEXResult ConfigureAnalog(bool enabled,
                                 VTEXDigitizerTriggerSourceDetectionEnum detection,
                                 double level,
                                 double hysteresis) = 0;

    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Detection(VTEXDigitizerTriggerSourceDetectionEnum &val) = 0;
    virtual VTEXResult put_Detection(VTEXDigitizerTriggerSourceDetectionEnum val) = 0;
    virtual VTEXResult get_Filter(std::string &val) = 0;
    virtual VTEXResult put_Filter(const std::string val) = 0;
    virtual VTEXResult get_EventId(std::string &val) = 0;
    virtual VTEXResult put_EventId(const std::string val) = 0;
    virtual VTEXResult get_Hysteresis(double &val) = 0;
    virtual VTEXResult put_Hysteresis(double val) = 0;
    virtual VTEXResult get_Level(double &val) = 0;
    virtual VTEXResult put_Level(double val) = 0;

    vtexProperty <LibDigitizerTriggerSource, bool, READ_WRITE> Enabled;
    vtexProperty <LibDigitizerTriggerSource, VTEXDigitizerTriggerSourceDetectionEnum, READ_WRITE> Detection;
    vtexProperty <LibDigitizerTriggerSource, std::string, READ_WRITE> Filter;
    vtexProperty <LibDigitizerTriggerSource, std::string, READ_WRITE> EventId;
    vtexProperty <LibDigitizerTriggerSource, double, READ_WRITE> Hysteresis;
    vtexProperty <LibDigitizerTriggerSource, double, READ_WRITE> Level;
};

//=============================================================================

/**
 * Digitizer.Trigger.Sources
 *
 */

class VTEX_EXPORT LibDigitizerTriggerSources
{
public:
    virtual ~LibDigitizerTriggerSources() {};

    virtual VTEXResult DisableAll() = 0;
    virtual LibDigitizerTriggerSource* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibDigitizerTriggerSources, int32_t, READ_ONLY> Count;
    arrayizer <LibDigitizerTriggerSources, LibDigitizerTriggerSource*, std::string> Item;
    arrayizer <LibDigitizerTriggerSources, std::string, int32_t> Name;
};

//=============================================================================

/**
 * Digitizer.Trigger
 *
 */

class VTEX_EXPORT LibDigitizerTrigger
{
public:
    virtual ~LibDigitizerTrigger() {};

    virtual VTEXResult SendSoftwareTrigger() = 0;

    virtual VTEXResult get_TriggerCount(int32_t &val) = 0;
    virtual VTEXResult put_TriggerCount(int32_t val) = 0;
    virtual VTEXResult get_Delay(double &val) = 0;
    virtual VTEXResult put_Delay(double val) = 0;
    virtual VTEXResult get_Holdoff(double &val) = 0;
    virtual VTEXResult put_Holdoff(double val) = 0;
    virtual VTEXResult get_SourceOperator(VTEXDigitizerTriggerSourceOperatorEnum &val) = 0;
    virtual VTEXResult put_SourceOperator(VTEXDigitizerTriggerSourceOperatorEnum val) = 0;
    virtual VTEXResult get_MaxQueueSize(int32_t &val) = 0;
    virtual VTEXResult put_MaxQueueSize(int32_t val) = 0;
    virtual VTEXResult get_QueueEnabled(bool &val) = 0;
    virtual VTEXResult put_QueueEnabled(bool val) = 0;

    LibDigitizerTriggerSources* Sources;

    vtexProperty <LibDigitizerTrigger, int32_t, READ_WRITE> TriggerCount;
    vtexProperty <LibDigitizerTrigger, double, READ_WRITE> Delay;
    vtexProperty <LibDigitizerTrigger, double, READ_WRITE> Holdoff;
    vtexProperty <LibDigitizerTrigger, VTEXDigitizerTriggerSourceOperatorEnum, READ_WRITE> SourceOperator;
    vtexProperty <LibDigitizerTrigger, int32_t, READ_WRITE> MaxQueueSize;
    vtexProperty <LibDigitizerTrigger, bool, READ_WRITE> QueueEnabled;
};

//=============================================================================

/**
 * Digitizer.Calibration.Self
 *
 */

class VTEX_EXPORT LibDigitizerCalibrationSelf
{
public:
    virtual ~LibDigitizerCalibrationSelf() {};

    virtual VTEXResult Initiate() = 0;
    virtual VTEXResult SaveAdjustments() = 0;
    virtual VTEXResult LoadAdjustments() = 0;
    virtual VTEXResult ClearSavedAdjustments() = 0;
    virtual VTEXResult GetStatus(VTEXDigitizerCalibrationStatusEnum &code, std::string &msg) = 0;

    virtual VTEXResult get_Date(std::string &val) = 0;
    virtual VTEXResult get_Adjustments(std::string &val) = 0;
    virtual VTEXResult get_Results(std::string &val) = 0;
    virtual VTEXResult get_Report(std::string &val) = 0;
    virtual VTEXResult get_Log(std::string &val) = 0;
    virtual VTEXResult get_IsSaved(bool &val) = 0;

    vtexProperty <LibDigitizerCalibrationSelf, std::string, READ_ONLY> Date;
    vtexProperty <LibDigitizerCalibrationSelf, std::string, READ_ONLY> Adjustments;
    vtexProperty <LibDigitizerCalibrationSelf, std::string, READ_ONLY> Results;
    vtexProperty <LibDigitizerCalibrationSelf, std::string, READ_ONLY> Report;
    vtexProperty <LibDigitizerCalibrationSelf, std::string, READ_ONLY> Log;
    vtexProperty <LibDigitizerCalibrationSelf, bool, READ_ONLY> IsSaved;
};

//=============================================================================

/**
 * Digitizer.Calibration.Full
 *
 */

class VTEX_EXPORT LibDigitizerCalibrationFull
{
public:
    virtual ~LibDigitizerCalibrationFull() {};

    virtual VTEXResult SaveAdjustments() = 0;
    virtual VTEXResult LoadAdjustments() = 0;
    virtual VTEXResult ClearSavedAdjustments() = 0;
    virtual VTEXResult Initiate() = 0;
    virtual VTEXResult Abort() = 0;
    virtual VTEXResult GetStatus(VTEXDigitizerCalibrationStatusEnum &code, std::string &msg) = 0;
    virtual VTEXResult PromptResponse(std::string response) = 0;

    virtual VTEXResult get_Date(std::string &val) = 0;
    virtual VTEXResult get_Adjustments(std::string &val) = 0;
    virtual VTEXResult put_Adjustments(std::string val) = 0;
    virtual VTEXResult get_LoadByDefault(bool &val) = 0;
    virtual VTEXResult put_LoadByDefault(bool val) = 0;
    virtual VTEXResult get_SpecialOperations(std::string &val) = 0;
    virtual VTEXResult put_SpecialOperations(std::string val) = 0;
    virtual VTEXResult get_IsSaved(bool &val) = 0;
    virtual VTEXResult get_Report(std::string &val) = 0;
    virtual VTEXResult get_Log(std::string &val) = 0;

    vtexProperty <LibDigitizerCalibrationFull, std::string, READ_ONLY> Date;
    vtexProperty <LibDigitizerCalibrationFull, std::string, READ_WRITE> Adjustments;
    vtexProperty <LibDigitizerCalibrationFull, bool, READ_WRITE> LoadByDefault;
    vtexProperty <LibDigitizerCalibrationFull, std::string, READ_WRITE> SpecialOperations;
    vtexProperty <LibDigitizerCalibrationFull, bool, READ_ONLY> IsSaved;
    vtexProperty <LibDigitizerCalibrationFull, std::string, READ_ONLY> Report;
    vtexProperty <LibDigitizerCalibrationFull, std::string, READ_ONLY> Log;
};

//=============================================================================

/**
 * Digitizer.Calibration.Factory
 *
 */

class VTEX_EXPORT LibDigitizerCalibrationFactory
{
public:
    virtual ~LibDigitizerCalibrationFactory() {};

    virtual VTEXResult Replace(std::string password) = 0;
    virtual VTEXResult Load() = 0;

    virtual VTEXResult get_Date(std::string &val) = 0;
    virtual VTEXResult get_Adjustments(std::string &val) = 0;

    vtexProperty <LibDigitizerCalibrationFactory, std::string, READ_ONLY> Date;
    vtexProperty <LibDigitizerCalibrationFactory, std::string, READ_ONLY> Adjustments;
};

//=============================================================================

/**
 * Digitizer.Calibration.InternalReferences.Item
 *
 */

class VTEX_EXPORT LibDigitizerCalibrationInternalReference
{
public:
    virtual ~LibDigitizerCalibrationInternalReference() {};

    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_OutputEnabled(bool &val) = 0;
    virtual VTEXResult put_OutputEnabled(bool val) = 0;
    virtual VTEXResult get_Amplitude(double &val) = 0;
    virtual VTEXResult put_Amplitude(double val) = 0;
    virtual VTEXResult get_Frequency(double &val) = 0;
    virtual VTEXResult put_Frequency(double val) = 0;

    vtexProperty <LibDigitizerCalibrationInternalReference, bool, READ_WRITE> Enabled;
    vtexProperty <LibDigitizerCalibrationInternalReference, bool, READ_WRITE> OutputEnabled;
    vtexProperty <LibDigitizerCalibrationInternalReference, double, READ_WRITE> Amplitude;
    vtexProperty <LibDigitizerCalibrationInternalReference, double, READ_WRITE> Frequency;
};

//=============================================================================

/**
 * Digitizer.Calibration.InternalReferences
 *
 */

class VTEX_EXPORT LibDigitizerCalibrationInternalReferences
{
public:
    virtual ~LibDigitizerCalibrationInternalReferences() {};

    virtual LibDigitizerCalibrationInternalReference* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibDigitizerCalibrationInternalReferences, int32_t, READ_ONLY> Count;
    arrayizer <LibDigitizerCalibrationInternalReferences, LibDigitizerCalibrationInternalReference*, std::string> Item;
    arrayizer <LibDigitizerCalibrationInternalReferences, std::string, int32_t> Name;
};

/**
 * Digitizer.Calibration
 *
 */

class VTEX_EXPORT LibDigitizerCalibration
{
public:
    virtual ~LibDigitizerCalibration() {};

    LibDigitizerCalibrationSelf* Self;
    LibDigitizerCalibrationFull* Full;
    LibDigitizerCalibrationFactory* Factory;
    LibDigitizerCalibrationInternalReferences* InternalReferences;
};

//=============================================================================

/**
 * Digitizer.ReferenceOscillator
 *
 */

class VTEX_EXPORT LibDigitizerReferenceOscillator
{
public:
    virtual ~LibDigitizerReferenceOscillator() {};

    virtual VTEXResult Configure(VTEXDigitizerReferenceOscillatorSourceEnum source, double frequency) = 0;

    virtual VTEXResult get_ExternalFrequency(double &val) = 0;
    virtual VTEXResult put_ExternalFrequency(double val) = 0;
    virtual VTEXResult get_OutputEnabled(bool &val) = 0;
    virtual VTEXResult put_OutputEnabled(bool val) = 0;
    virtual VTEXResult get_Source(VTEXDigitizerReferenceOscillatorSourceEnum &val) = 0;
    virtual VTEXResult put_Source(VTEXDigitizerReferenceOscillatorSourceEnum val) = 0;
    virtual VTEXResult get_TimestampSource(VTEXDigitizerReferenceOscillatorTimestampSourceEnum &val) = 0;
    virtual VTEXResult put_TimestampSource(VTEXDigitizerReferenceOscillatorTimestampSourceEnum val) = 0;

    vtexProperty <LibDigitizerReferenceOscillator, double, READ_WRITE> ExternalFrequency;
    vtexProperty <LibDigitizerReferenceOscillator, bool, READ_WRITE> OutputEnabled;
    vtexProperty <LibDigitizerReferenceOscillator, VTEXDigitizerReferenceOscillatorSourceEnum, READ_WRITE> Source;
    vtexProperty <LibDigitizerReferenceOscillator, VTEXDigitizerReferenceOscillatorTimestampSourceEnum, READ_WRITE> TimestampSource;
};

//=============================================================================

/**
 * Digitizer.Start
 *
 */

class VTEX_EXPORT LibDigitizerStart
{
public:
    virtual ~LibDigitizerStart() {};
    virtual VTEXResult SendSoftwareStart() = 0;

    virtual VTEXResult get_Source(std::string &val) = 0;
    virtual VTEXResult put_Source(std::string val) = 0;
    virtual VTEXResult get_ListOfSources(std::string &val) = 0;

    vtexProperty <LibDigitizerStart, std::string, READ_WRITE> Source;
    vtexProperty <LibDigitizerStart, std::string, READ_ONLY> ListOfSources;
};

//=============================================================================

// forward declaration needed for cross-session AutoConfigure
class LibDigitizer;

/**
 * Digitizer.Sync
 *
 */

class VTEX_EXPORT LibDigitizerSync
{
public:
    virtual ~LibDigitizerSync() {};

    virtual VTEXResult SendSoftwareSync() = 0;
    virtual VTEXResult SendSoftwareSyncAtTime(double seconds, double fraction) = 0;
    virtual VTEXResult AutoConfigure() = 0;
    virtual VTEXResult AutoConfigure(std::vector<LibDigitizer*> other_sessions) = 0;

    virtual VTEXResult get_CoordinationLine(std::string &val) = 0;
    virtual VTEXResult put_CoordinationLine(std::string val) = 0;
    virtual VTEXResult get_IsSynchronized(bool &val) = 0;
    virtual VTEXResult get_Line(std::string &val) = 0;
    virtual VTEXResult put_Line(std::string val) = 0;
    virtual VTEXResult get_Delay(double &val) = 0;
    virtual VTEXResult put_Delay(double val) = 0;
    virtual VTEXResult get_ListOfSources(std::string &val) = 0;
    
    vtexProperty <LibDigitizerSync, std::string, READ_WRITE> CoordinationLine;
    vtexProperty <LibDigitizerSync, bool, READ_ONLY> IsSynchronized;
    vtexProperty <LibDigitizerSync, std::string, READ_WRITE> Line;
    vtexProperty <LibDigitizerSync, double, READ_WRITE> Delay;
    vtexProperty <LibDigitizerSync, std::string, READ_ONLY> ListOfSources;
};

//=============================================================================

//User-overridable class implementing the callback
class VTEX_EXPORT LibDigitizerStreamingCallback
{
public:
    virtual ~LibDigitizerStreamingCallback() {};
    virtual void StreamingCallback(int32_t num_records,
        std::string& channel, std::vector<double>& data, std::vector<double>& ts_sec, std::vector<double>& ts_frac, std::string& additional_data) = 0;
};

//=============================================================================

/*
 * Digitizer Streaming Interface
 */

class VTEX_EXPORT LibDigitizerStreamingData
{
public:
    virtual ~LibDigitizerStreamingData() {};

    virtual VTEXResult EnableStreaming() = 0;
    virtual VTEXResult DisableStreaming() = 0;

    virtual VTEXResult MemoryRead(int32_t num_records, int32_t& actual_records, std::string& channel, std::vector<double>& data,
        std::vector<double>& ts_sec, std::vector<double>& ts_frac, std::string& additional_data) = 0;
    virtual VTEXResult MemoryReadWithCJC(int32_t num_records, int32_t& actual_records,
        std::string &channel, std::vector<double> &data, std::vector<double> &ts_sec, std::vector<double> &ts_frac, std::string &addl_data,
        std::string &channel_cjc, std::vector<double> &data_cjc, std::vector<double> &ts_sec_cjc, std::vector<double> &ts_frac_cjc) = 0;

    virtual VTEXResult RegisterStreamingCallback(LibDigitizerStreamingCallback& callback, std::string channel_list) = 0;
    virtual VTEXResult UnregisterStreamingCallback(LibDigitizerStreamingCallback& callback) = 0;

    virtual VTEXResult SetCustomAttribute(std::string name, std::string value) = 0;
    virtual VTEXResult GetCustomAttributes(std::string& val) = 0;
    virtual VTEXResult RemoveCustomAttribute(std::string name) = 0;
    virtual VTEXResult RemoveAllCustomAttributes() = 0;

    virtual VTEXResult UpdateDataReader() = 0;

    //Property methods
    virtual VTEXResult get_NumStreamedRecords(int64_t &val) = 0;
    virtual VTEXResult get_NumMemoryRecords(int64_t &val) = 0;
    virtual VTEXResult get_MemoryChannelList(std::string& list) = 0;
    virtual VTEXResult put_MemoryChannelList(std::string list) = 0;
    virtual VTEXResult get_MemoryLimit(int32_t& limit) = 0;
    virtual VTEXResult put_MemoryLimit(int32_t limit) = 0;
    virtual VTEXResult get_MemoryLimitEx(int64_t& limit) = 0;
    virtual VTEXResult put_MemoryLimitEx(int64_t limit) = 0;
    virtual VTEXResult get_Filename(std::string& filename) = 0;
    virtual VTEXResult put_Filename(std::string filename) = 0;
    virtual VTEXResult get_FileCount(int32_t& filecount) = 0;
    virtual VTEXResult put_FileCount(int32_t filecount) = 0;
    virtual VTEXResult get_FileMaxSize(int32_t& maxsize) = 0;
    virtual VTEXResult put_FileMaxSize(int32_t maxsize) = 0;
    virtual VTEXResult get_FileRotate(bool& rotate) = 0;
    virtual VTEXResult put_FileRotate(bool rotate) = 0;

    vtexProperty <LibDigitizerStreamingData, int64_t, READ_ONLY> NumStreamedRecords;
    vtexProperty <LibDigitizerStreamingData, int64_t, READ_ONLY> NumMemoryRecords;
    vtexProperty <LibDigitizerStreamingData, std::string, READ_WRITE> MemoryChannelList;
    vtexProperty <LibDigitizerStreamingData, int32_t, READ_WRITE> MemoryLimit;
    vtexProperty <LibDigitizerStreamingData, int64_t, READ_WRITE> MemoryLimitEx;
    vtexProperty <LibDigitizerStreamingData, std::string, READ_WRITE> Filename;
    vtexProperty <LibDigitizerStreamingData, int32_t, READ_WRITE> FileCount;
    vtexProperty <LibDigitizerStreamingData, int32_t, READ_WRITE> FileMaxSize;
    vtexProperty <LibDigitizerStreamingData, bool, READ_WRITE> FileRotate;
};

//=============================================================================

/*
 * Digitizer Board Temperature Interface
 */

class VTEX_EXPORT LibDigitizerBoardTemperature
{
public:
    virtual ~LibDigitizerBoardTemperature() {};

    virtual VTEXResult get_BoardTemperature(double &val) = 0;
    virtual VTEXResult get_Units(VTEXDigitizerTemperatureUnitsEnum &val) = 0;
    virtual VTEXResult put_Units(VTEXDigitizerTemperatureUnitsEnum val) = 0;

    vtexProperty <LibDigitizerBoardTemperature, double, READ_ONLY> BoardTemperature;
    vtexProperty <LibDigitizerBoardTemperature, VTEXDigitizerTemperatureUnitsEnum, READ_WRITE> Units;
};

//=============================================================================

/*
 * Digitizer Time Interface
 */

class VTEX_EXPORT LibDigitizerTime
{
public:
    virtual ~LibDigitizerTime() {};

    virtual VTEXResult GetSystemTime(double &seconds, double &fraction) = 0;

    virtual VTEXResult get_IsMaster(bool &val) = 0;
    virtual VTEXResult get_IsSynchronized(bool &val) = 0;

    vtexProperty <LibDigitizerTime, bool, READ_ONLY> IsMaster;
    vtexProperty <LibDigitizerTime, bool, READ_ONLY> IsSynchronized;
};

//=============================================================================

/*
 * Digitizer Self-Test Interface
 */

class VTEX_EXPORT LibDigitizerSelfTest
{
public:
    virtual ~LibDigitizerSelfTest() {};

    virtual VTEXResult Initiate() = 0;
    virtual VTEXResult GetStatus(int32_t &status, std::string &message) = 0;
    virtual VTEXResult get_Report(std::string &val) = 0;

    vtexProperty <LibDigitizerSelfTest, std::string, READ_ONLY> Report;
};

//=============================================================================

/**
* Digitizer.Storage.Devices.Item
*
*/

class VTEX_EXPORT LibDigitizerStorageDevice
{
public:
    virtual ~LibDigitizerStorageDevice() {};

    virtual VTEXResult SetCustomAttribute(std::string name, std::string value) = 0;
    virtual VTEXResult GetCustomAttributes(std::string& val) = 0;
    virtual VTEXResult RemoveCustomAttribute(std::string name) = 0;
    virtual VTEXResult RemoveAllCustomAttributes() = 0;

    virtual VTEXResult get_Info(std::string& val) = 0;
    virtual VTEXResult get_NumSavedRecords(int64_t& val) = 0;

    virtual VTEXResult get_Enabled(bool& val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Filename(std::string& val) = 0;
    virtual VTEXResult put_Filename(std::string val) = 0;
    virtual VTEXResult get_FileCount(int32_t& val) = 0;
    virtual VTEXResult put_FileCount(int32_t val) = 0;
    virtual VTEXResult get_FileMaxRecords(int32_t& val) = 0;
    virtual VTEXResult put_FileMaxRecords(int32_t val) = 0;
    virtual VTEXResult get_FileRotate(bool& val) = 0;
    virtual VTEXResult put_FileRotate(bool val) = 0;
    virtual VTEXResult get_FileFormat(std::string& val) = 0;
    virtual VTEXResult put_FileFormat(std::string val) = 0;

    vtexProperty <LibDigitizerStorageDevice, int64_t, READ_ONLY> NumSavedRecords;
    vtexProperty <LibDigitizerStorageDevice, std::string, READ_ONLY> Info;
    vtexProperty <LibDigitizerStorageDevice, bool, READ_WRITE> Enabled;
    vtexProperty <LibDigitizerStorageDevice, std::string, READ_WRITE> Filename;
    vtexProperty <LibDigitizerStorageDevice, int32_t, READ_WRITE> FileCount;
    vtexProperty <LibDigitizerStorageDevice, int32_t, READ_WRITE> FileMaxRecords;
    vtexProperty <LibDigitizerStorageDevice, bool, READ_WRITE> FileRotate;
    vtexProperty <LibDigitizerStorageDevice, std::string, READ_WRITE> FileFormat;
};

//=============================================================================

/**
* Digitizer.Storage.Devices
*
*/

class VTEX_EXPORT LibDigitizerStorageDevices
{
public:
    virtual ~LibDigitizerStorageDevices() {};

    virtual VTEXResult Update() = 0;

    virtual LibDigitizerStorageDevice* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibDigitizerStorageDevices, int32_t, READ_ONLY> Count;
    arrayizer <LibDigitizerStorageDevices, LibDigitizerStorageDevice*, std::string> Item;
    arrayizer <LibDigitizerStorageDevices, std::string, int32_t> Name;
};

//=============================================================================

/**
* Digitizer.Storage
*
*/

class VTEX_EXPORT LibDigitizerStorage
{
public:
    virtual ~LibDigitizerStorage() {};

    LibDigitizerStorageDevices* Devices;
};

//=============================================================================


/**
 * Digitizer base class
 *
 */

class VTEX_EXPORT LibDigitizer : public vtexInherent
{
public:
    static LibDigitizer* Create();
    virtual ~LibDigitizer() {};

    //Inherent capabilitites
    vtexInherentCapabilityIdentity* Identity;
    vtexInherentCapabilityUtility* Utility;
    vtexInherentCapabilityDriverOperation* DriverOperation;
    vtexInherentPlatform* Platform;

    LibDigitizerAlarms*               Alarms;
    LibDigitizerArm*                  Arm;
    LibDigitizerCalibration*          Calibration;
    LibDigitizerChannels*             Channels;
    LibDigitizerConfiguration*        Configuration;
    LibDigitizerDio*                  Dio;
    LibDigitizerEvents*               Events;
    LibDigitizerMeasurement*          Measurement;
    LibDigitizerReferenceOscillator*  ReferenceOscillator;
    LibDigitizerSelfTest*             SelfTest;
    LibDigitizerStart*                Start;
    LibDigitizerStorage*              Storage;
    LibDigitizerStreamingData*        StreamingData;
    LibDigitizerSync*                 Sync;
    LibDigitizerBoardTemperature*     Temperature;
    LibDigitizerTime*                 Time;
    LibDigitizerTrigger*              Trigger;

    LibDigitizerRegisters*            Registers;

    vtexProperty <LibDigitizer, bool, READ_ONLY> Initialized;
};

#endif /* _libDigitizer_H */
