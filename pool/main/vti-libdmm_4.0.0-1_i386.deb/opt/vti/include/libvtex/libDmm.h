/******************************************************************************
*
*  .----------------------.	File Name: libDmm.h
*  |==     ==  ======  == |	Project : EX Platform
*  | ==   ==   ======  == |	$Author$
*  |  == ==      ==    == |	$Revision$
*  |   ===       ==    == |	$Date$
*  |    =        ==    == |
*  `----------------------'
*
* Copyright 2006 VXI Technology Inc. as an unpublished work.
* All rights reserved. The information contained herein is confidential
* property of VXI Technology, Inc. Use, copy, transfer or disclosure
* of such information is prohibited except by express written agreement
* with VXI Technology, Inc.
*
* PURPOSE:
*   Main public interface file for the Dmm library.
*
* First Written By: Gershon Shamay On Jan-2007
******************************************************************************/
#ifndef		_libDmm_H
#define		_libDmm_H

#include <string>
#include <vector>

#include "vtexapi.h"
#include "property.h"
#include "libInherent.h"
#include "vtexException.h"

#ifndef _ATL_ATTRIBUTES
#include "DmmConstants.h"
#endif

#include "DmmErrors.h"
#include "CommonErrors.h"

using namespace std;

class ImpDmm;

//////////////////////////////////////////////////////////////////////////////
///	DMM Class and interface definitions
//////////////////////////////////////////////////////////////////////////////
//
//	The class hierarchy follows the IVI Dmm Class specification, namely:
//
//	Dmm
//		AC
//		Advanced
//		Frequency
//		Math
//		Measurement
//		System
//		Temperature
//			RTD
//			Thermistor
//			Thermocouple
//		Trigger
//			MultiPoint
//      Platform
//			Limit
//			Math
//
//	The public part of each class definition follows this template:
//	- Class constructor
//	- Class destructor
//	- Public methods
//	- Public properties
//	- Member derived classes, if any
//
//	The private part of each class definition follows this template:
//	- Private get_ and put_ [accessors] for each property
//	- Other private data members
//
//////////////////////////////////////////////////////////////////////////////
class UtilsContainer;

//=============================================================================
//	AC interface

class VTEX_API LibDmmAC
{
public:
   virtual ~LibDmmAC();

   virtual VTEXResult ConfigureBandwidth (double MinFreq, double MaxFreq) = 0;
   virtual VTEXResult get_FrequencyMax (double *val) = 0;
   virtual VTEXResult put_FrequencyMax (double val) = 0;
   virtual VTEXResult get_FrequencyMin (double *val) = 0;
   virtual VTEXResult put_FrequencyMin (double val) = 0;

   property <LibDmmAC, double, READ_WRITE> FrequencyMax;
   property <LibDmmAC, double, READ_WRITE> FrequencyMin;
};

//=============================================================================


//=============================================================================
//	Advanced interface

class VTEX_API LibDmmAdvanced
{
public:
   virtual ~LibDmmAdvanced();

   virtual VTEXResult get_ActualRange (double *val) = 0;
   virtual VTEXResult get_ApertureTime (double *val) = 0;
   virtual VTEXResult put_ApertureTime (double val) = 0;
   virtual VTEXResult get_ApertureTimeUnits (VTEXDmmApertureTimeUnitsEnum *val) = 0;
   virtual VTEXResult get_AutoZero (VTEXDmmAutoZeroEnum *val) = 0;
   virtual VTEXResult put_AutoZero (VTEXDmmAutoZeroEnum val) = 0;
   virtual VTEXResult get_PowerlineFrequency (double *val) = 0;
   virtual VTEXResult put_PowerlineFrequency (double val) = 0;

   property <LibDmmAdvanced, double, READ_ONLY> ActualRange;
   property <LibDmmAdvanced, double, READ_WRITE> ApertureTime;
   property <LibDmmAdvanced, VTEXDmmApertureTimeUnitsEnum, READ_ONLY> ApertureTimeUnits;
   property <LibDmmAdvanced, VTEXDmmAutoZeroEnum, READ_WRITE> AutoZero;
   property <LibDmmAdvanced, double, READ_WRITE> PowerlineFrequency;
};

//=============================================================================
//	Frequency interface

class VTEX_API LibDmmFrequency
{
public:
   virtual ~LibDmmFrequency();
   virtual VTEXResult	get_VoltageRange (double *val) = 0;
   virtual VTEXResult	put_VoltageRange (double val) = 0;
   property	<LibDmmFrequency, double, READ_WRITE> VoltageRange;
};

//=============================================================================

//=============================================================================
//	Thermistor interface

class VTEX_API LibDmmThermistor
{
public:
   virtual ~LibDmmThermistor();
   virtual VTEXResult	get_Resistance (double *val) = 0;
   virtual VTEXResult	put_Resistance (double val) = 0;
   virtual VTEXResult	get_A (double *val) = 0;
   virtual VTEXResult	put_A (double val) = 0;
   virtual VTEXResult	get_B (double *val) = 0;
   virtual VTEXResult	put_B (double val) = 0;
   virtual VTEXResult	get_C (double *val) = 0;
   virtual VTEXResult	put_C (double val) = 0;

   property	<LibDmmThermistor, double, READ_WRITE> Resistance;
   property	<LibDmmThermistor, double, READ_WRITE> A;
   property	<LibDmmThermistor, double, READ_WRITE> B;
   property	<LibDmmThermistor, double, READ_WRITE> C;
};

//=============================================================================


//=============================================================================
//	Thermocouple interface

class VTEX_API LibDmmThermocouple
{
public:
   virtual ~LibDmmThermocouple();
   virtual VTEXResult	Configure (VTEXDmmThermocoupleTypeEnum Type, VTEXDmmRefJunctionTypeEnum RefJunctionType) = 0;
   virtual VTEXResult	get_FixedRefJunction (double *val) = 0;
   virtual VTEXResult	put_FixedRefJunction (double val) = 0;
   virtual VTEXResult	get_RefJunctionType (VTEXDmmRefJunctionTypeEnum *val) = 0;
   virtual VTEXResult	put_RefJunctionType (VTEXDmmRefJunctionTypeEnum val) = 0;
   virtual VTEXResult	get_Type (VTEXDmmThermocoupleTypeEnum *val) = 0;
   virtual VTEXResult	put_Type (VTEXDmmThermocoupleTypeEnum val) = 0;

   property	<LibDmmThermocouple,	double, READ_WRITE> FixedRefJunction;
   property	<LibDmmThermocouple,	VTEXDmmRefJunctionTypeEnum, READ_WRITE> RefJunctionType;
   property	<LibDmmThermocouple,	VTEXDmmThermocoupleTypeEnum, READ_WRITE> Type;
};

//=============================================================================


//=============================================================================
//	RTD interface

class VTEX_API LibDmmRTD
{
public:
   virtual ~LibDmmRTD();
   virtual VTEXResult	Configure (double Alpha, double Resistance) = 0;
   virtual VTEXResult	get_Alpha (double *val) = 0;
   virtual VTEXResult	put_Alpha (double val) = 0;
   virtual VTEXResult	get_Beta (double *val) = 0;
   virtual VTEXResult	put_Beta (double val) = 0;
   virtual VTEXResult	get_Delta (double *val) = 0;
   virtual VTEXResult	put_Delta (double val) = 0;
   virtual VTEXResult	get_Type (VTEXDmmRtdTypeEnum *val) = 0;
   virtual VTEXResult	put_Type (VTEXDmmRtdTypeEnum val) = 0;
   virtual VTEXResult	get_Resistance (double *val) = 0;
   virtual VTEXResult	put_Resistance (double val) = 0;

   property	<LibDmmRTD, double, READ_WRITE> Alpha;
   property	<LibDmmRTD, double, READ_WRITE> Beta;
   property	<LibDmmRTD, double, READ_WRITE> Delta;
   property	<LibDmmRTD, VTEXDmmRtdTypeEnum, READ_WRITE> Type;
   property	<LibDmmRTD, double, READ_WRITE> Resistance;
};

//=============================================================================

//=============================================================================
//	Temperature interface

class VTEX_API LibDmmTemperature
{
public:
   virtual ~LibDmmTemperature();
   virtual VTEXResult	get_TransducerType (VTEXDmmTransducerTypeEnum *val) = 0;
   virtual VTEXResult	put_TransducerType (VTEXDmmTransducerTypeEnum val) = 0;

   LibDmmRTD			*RTD;
   LibDmmThermistor	*Thermistor;
   LibDmmThermocouple	*Thermocouple;

   property			<LibDmmTemperature, VTEXDmmTransducerTypeEnum, READ_WRITE> TransducerType;
};

//=============================================================================

//=============================================================================
//	Measurement interface

class VTEX_API LibDmmMeasurement
{
public:
   virtual ~LibDmmMeasurement();
   virtual VTEXResult Initiate () = 0;
   virtual VTEXResult SendSoftwareTrigger () = 0;
   virtual VTEXResult Abort () = 0;
   virtual bool IsOverRange(double MeasurementValue) = 0;

   virtual VTEXResult Fetch (int32_t MaxTimeMilliseconds, double *Reading) = 0;
   virtual VTEXResult Read (int32_t MaxTimeMilliseconds, double *Reading) = 0;
   virtual VTEXResult FetchTimeStamped (int32_t MaxTimeMilliseconds, double *Reading, double *TimeSeconds, double *TimeFraction) = 0;
   virtual VTEXResult ReadTimeStamped (int32_t MaxTimeMilliseconds, double *Reading, double *TimeSeconds, double *TimeFraction) = 0;

   virtual VTEXResult FetchMultiPoint(int32_t MaxTimeMilliseconds, vector<double>&ReadingArray) = 0;
   virtual VTEXResult ReadMultiPoint (int32_t MaxTimeMilliseconds, vector<double>&ReadingArray) = 0;
   virtual VTEXResult FetchMultiPointTimeStamped (int32_t MaxTimeMilliseconds, vector<double>&ReadingArray, vector<double>&TimeSeconds, vector<double>&TimeFraction) = 0;
   virtual VTEXResult ReadMultiPointTimeStamped (int32_t MaxTimeMilliseconds, vector<double>&ReadingArray, vector<double>&TimeSeconds, vector<double>&TimeFraction) = 0;

   virtual VTEXResult ClearFIFO() = 0;
   virtual VTEXResult get_FIFOCount(int32_t *val) = 0;
   virtual VTEXResult get_Input(VTEXDmmInputSelectEnum *val) = 0;
   virtual VTEXResult put_Input(VTEXDmmInputSelectEnum val) = 0;

   property	<LibDmmMeasurement, int32_t, READ_ONLY> FIFOCount;
   property	<LibDmmMeasurement, VTEXDmmInputSelectEnum, READ_WRITE> Input;
};

//=============================================================================

//=============================================================================
//	MultiPoint interface

class VTEX_API LibDmmMultiPoint
{
public:
   virtual ~LibDmmMultiPoint();
   virtual VTEXResult	Configure (int32_t TriggerCount, int32_t SampleCount, VTEXDmmSampleTriggerEnum SampleTrigger, double SampleInterval) = 0;
   virtual VTEXResult	get_Count (int32_t *val) = 0;
   virtual VTEXResult	put_Count (int32_t val) = 0;
   virtual VTEXResult	get_MeasurementComplete (VTEXDmmMeasCompleteDestEnum *val) = 0;
   virtual VTEXResult	put_MeasurementComplete (VTEXDmmMeasCompleteDestEnum val) = 0;
   virtual VTEXResult	get_SampleCount (int32_t *val) = 0;
   virtual VTEXResult	put_SampleCount (int32_t val) = 0;
   virtual VTEXResult	get_SampleInterval (double *val) = 0;
   virtual VTEXResult	put_SampleInterval (double val) = 0;
   virtual VTEXResult	get_SampleTrigger (VTEXDmmSampleTriggerEnum *val) = 0;
   virtual VTEXResult	put_SampleTrigger (VTEXDmmSampleTriggerEnum val) = 0;
   /* instrument specific */
   virtual VTEXResult	get_SampleDelay (double *val) = 0;
   virtual VTEXResult	put_SampleDelay (double val) = 0;
   virtual VTEXResult	get_SampleTriggerSlope (VTEXDmmSampleTriggerSlopeEnum *val) = 0;
   virtual VTEXResult	put_SampleTriggerSlope (VTEXDmmSampleTriggerSlopeEnum val) = 0;

   property	<LibDmmMultiPoint, int32_t, READ_WRITE> Count;
   property	<LibDmmMultiPoint, VTEXDmmMeasCompleteDestEnum, READ_WRITE> MeasurementComplete;
   property	<LibDmmMultiPoint, int32_t, READ_WRITE> SampleCount;
   property	<LibDmmMultiPoint, double, READ_WRITE> SampleDelay;
   property	<LibDmmMultiPoint, double, READ_WRITE> SampleInterval;
   /* instrument specific */
   property	<LibDmmMultiPoint, VTEXDmmSampleTriggerEnum, READ_WRITE> SampleTrigger;
   property	<LibDmmMultiPoint, VTEXDmmSampleTriggerSlopeEnum, READ_WRITE> SampleTriggerSlope;
};

//=============================================================================

//=============================================================================
//	Trigger interface

class VTEX_API LibDmmTrigger
{
public:
   virtual ~LibDmmTrigger();
   virtual VTEXResult	Configure (VTEXDmmTriggerSourceEnum TriggerSource, double TriggerDelay) = 0;
   virtual VTEXResult	get_Delay (double *val) = 0;
   virtual VTEXResult	put_Delay (double val) = 0;
   virtual VTEXResult	get_Slope (VTEXDmmTriggerSlopeEnum *val) = 0;
   virtual VTEXResult	put_Slope (VTEXDmmTriggerSlopeEnum val) = 0;
   virtual VTEXResult	get_Source (VTEXDmmTriggerSourceEnum *val) = 0;
   virtual VTEXResult	put_Source (VTEXDmmTriggerSourceEnum val) = 0;
   /* instrument specific */
   virtual VTEXResult	get_Buffered(bool *val) = 0;
   virtual VTEXResult	put_Buffered(bool val) = 0;

   property	<LibDmmTrigger, double, READ_WRITE> Delay;
   property	<LibDmmTrigger, VTEXDmmTriggerSlopeEnum, READ_WRITE> Slope;
   property	<LibDmmTrigger, VTEXDmmTriggerSourceEnum, READ_WRITE> Source;
   /* instrument specific */
   property	<LibDmmTrigger, bool, READ_WRITE> Buffered;

   LibDmmMultiPoint        *MultiPoint;
};

//=============================================================================
//	Math interface

class VTEX_API LibDmmMath
{
public:
   virtual ~LibDmmMath();
   virtual double FetchCalculation(VTEXDmmMathRequestEnum Request, double *TimeSeconds, double *TimeFraction) = 0;
   virtual VTEXResult	get_Factor(double *val) = 0;
   virtual VTEXResult	put_Factor(double val) = 0;
   virtual VTEXResult	get_Offset(double *val) = 0;
   virtual VTEXResult	put_Offset(double val) = 0;
   virtual VTEXResult	get_DBReference(double *val) = 0;
   virtual VTEXResult	put_DBReference(double val) = 0;
   virtual VTEXResult	get_DBmReference(double *val) = 0;
   virtual VTEXResult	put_DBmReference(double val) = 0;
   virtual VTEXResult	get_RatioReference(double *val) = 0;
   virtual VTEXResult	put_RatioReference(double val) = 0;

   property <LibDmmMath, double, READ_WRITE> Factor;
   property <LibDmmMath, double, READ_WRITE> Offset;
   property <LibDmmMath, double, READ_WRITE> DBReference;
   property <LibDmmMath, double, READ_WRITE> DBmReference;
   property <LibDmmMath, double, READ_WRITE> RatioReference;
};
//=============================================================================

//=============================================================================
//	Limit interface

class VTEX_API LibDmmLimit
{
public:
   virtual ~LibDmmLimit();

   virtual VTEXResult	get_High (double *val) = 0;
   virtual VTEXResult	put_High (double val) = 0;
   virtual VTEXResult	get_Low (double *val) = 0;
   virtual VTEXResult	put_Low (double val) = 0;
   virtual VTEXResult	get_Dest (VTEXDmmSampleLimitDestEnum *val) = 0;
   virtual VTEXResult	put_Dest (VTEXDmmSampleLimitDestEnum val) = 0;

   property	<LibDmmLimit, double, READ_WRITE> High;
   property	<LibDmmLimit, double, READ_WRITE> Low;
   property	<LibDmmLimit, VTEXDmmSampleLimitDestEnum, READ_WRITE> Dest;
};

//=============================================================================

//=============================================================================
//	Config interface

class VTEX_API LibDmmConfiguration
{
public:
   virtual ~LibDmmConfiguration();

   //Attributes
   property <LibDmmConfiguration, int32_t, READ_ONLY> Count;
   property <LibDmmConfiguration, VTEXString, READ_ONLY> List;

   //Methods
   virtual VTEXResult Load(const VTEXString val) = 0;
   virtual VTEXResult Save(const VTEXString val) = 0;
   virtual VTEXResult Delete(const VTEXString val) = 0;
   virtual VTEXResult DeleteAll() = 0;
   virtual VTEXDmmFunctionEnum GetFunction(const VTEXString config) = 0;
   virtual bool  Exists(const VTEXString val) = 0;

   virtual VTEXResult get_Count(int32_t* val) = 0;
   virtual VTEXResult get_List(VTEXString *val) = 0;

};
//=============================================================================

//=============================================================================
// Calibration interface

class VTEX_API LibDmmCalibration
{
public:
   virtual ~LibDmmCalibration();

   //Attributes
   property <LibDmmCalibration, bool, READ_WRITE> LowFreqACCalBypassK2;
   
   //
   // Properties
   //
   virtual VTEXResult ReadDate(int32_t *day, int32_t *month, int32_t *year) = 0;
   virtual VTEXResult LoadData(int32_t id) = 0;
   virtual VTEXResult SaveData(int32_t id) = 0;
   virtual VTEXResult WriteDate(int32_t day, int32_t month, int32_t year) = 0;
   virtual VTEXResult ReadDueDate(int32_t *day, int32_t *month, int32_t *year) = 0;
   virtual VTEXResult WriteDueDate(int32_t day, int32_t month, int32_t year) = 0;
   virtual VTEXResult WriteData(VTEXDmmCalibrationFunctionEnum Function, VTEXDmmCalibrationFunctionOptionEnum Option,VTEXDmmCalibrationItemEnum Item, double Range, double Data) = 0;
   virtual VTEXResult ReadData(VTEXDmmCalibrationFunctionEnum Function, VTEXDmmCalibrationFunctionOptionEnum Option,VTEXDmmCalibrationItemEnum Item, double Range, double* Data) = 0;
   virtual VTEXResult get_LowFreqACCalBypassK2(bool* val) = 0;
   virtual VTEXResult put_LowFreqACCalBypassK2(bool val) = 0;
};

//=============================================================================
//	Platform interface

class VTEX_API LibDmmPlatform
{
public:
   virtual ~LibDmmPlatform();
   virtual VTEXResult CloseLogFile() = 0;
   virtual VTEXResult OpenLogFile(const VTEXString& fileName, const VTEXString& accessMode) = 0;
   virtual VTEXResult get_InternalTemperature (double *val) = 0;
   virtual VTEXResult get_SerialNumber (VTEXString *val) = 0;
   virtual VTEXResult get_State(VTEXDmmStateEnum *val) = 0;

   property	<LibDmmPlatform, VTEXString, READ_ONLY> SerialNumber;
   property	<LibDmmPlatform, VTEXDmmStateEnum, READ_ONLY> State;
   property	<LibDmmPlatform, double, READ_ONLY> InternalTemperature;
};

//=============================================================================

class VTEX_API LibDmm : public LibInherent
{
public:
   static LibDmm* Create();
   virtual ~LibDmm();
   //Inherent capabilitites
   /// <summary>Pointer to Utility interface</summary>
   LibInherentCapabilityUtility* Utility;

   /// <summary>Pointer to DriverOperation interface</summary>
   LibInherentCapabilityDriverOperation* DriverOperation;

   /// <summary>Pointer to Identity interface</summary>
   LibInherentCapabilityIdentity* Identity;
   property	<LibDmm, bool, READ_ONLY> Initialized;

   property	<LibDmm, VTEXDmmFunctionEnum, READ_WRITE> Function;
   property	<LibDmm, double, READ_WRITE> Range;
   property	<LibDmm, double, READ_WRITE> Resolution;
   property	<LibDmm, VTEXDmmFunctionOptionEnum, READ_WRITE> FunctionOption;
   property	<LibDmm, double, READ_WRITE> RangeChangeDelay;

   virtual VTEXResult	Configure (VTEXDmmFunctionEnum Function,
      double Range,
      double Resolution) = 0;
   virtual VTEXResult	get_Function (VTEXDmmFunctionEnum *val) = 0;
   virtual VTEXResult	put_Function (VTEXDmmFunctionEnum val) = 0;
   virtual VTEXResult	get_Range (double *val) = 0;
   virtual VTEXResult	put_Range (double val) = 0;
   virtual VTEXResult	get_Resolution (double *val) = 0;
   virtual VTEXResult	put_Resolution (double val) = 0;
   virtual VTEXResult  get_FunctionOption (VTEXDmmFunctionOptionEnum *val) = 0;
   virtual VTEXResult  put_FunctionOption (VTEXDmmFunctionOptionEnum val) = 0;
   virtual VTEXResult  get_RangeChangeDelay(double *val) = 0;
   virtual VTEXResult  put_RangeChangeDelay(double val) = 0;

   LibDmmAC                  *AC;
   LibDmmAdvanced            *Advanced;
   LibDmmFrequency           *Frequency;
   LibDmmMeasurement         *Measurement;
   LibDmmTrigger             *Trigger;
   LibDmmTemperature         *Temperature;
   LibDmmPlatform            *Platform;
   LibDmmMath                *Math;
   LibDmmLimit               *Limit;
   LibDmmConfiguration		  *Configuration;
   LibDmmCalibration         *Calibration;
};

#endif	/* _libDmm_H */
