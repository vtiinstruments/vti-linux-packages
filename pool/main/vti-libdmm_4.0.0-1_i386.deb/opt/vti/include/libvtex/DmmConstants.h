#include "exErrors.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#if defined(_WIN32) && !defined(_CVI_)
#define INLINE __inline
#else
#define INLINE inline
#endif

#ifdef __cplusplus
extern "C" {
#endif

 //!
 //! @file
 //!
 //! Dmm constants.
 //!

#ifndef _DmmConstants_H
#define _DmmConstants_H

 //!
 //! Dmm->Advanced
 //!
enum VTEXDmmApertureTimeUnitsEnum
{
  VTEXDmmApertureSeconds = 0,
  VTEXDmmAperturePowerLineCycles = 1
};

enum VTEXDmmAutoZeroEnum
{
  VTEXDmmAutoZeroOff = 0,
  VTEXDmmAutoZeroOn = 1,
  VTEXDmmAutoZeroOnce = 2
};

 //!
 //! Dmm->Measurement
 //!   
enum VTEXDmmInputSelectEnum
{
  VTEXDmmInputSelectInternal = 1000,
  VTEXDmmInputSelectFrontPanel = 1001
};

 //!
 //! Dmm->Trigger
 //!       
enum VTEXDmmTriggerSourceEnum
{
  VTEXDmmTriggerSourceImmediate = 1,
  VTEXDmmTriggerSourceExternal = 2,
  VTEXDmmTriggerSourceSwTrigFunc = 3,
  VTEXDmmTriggerSourceBPL0 = 1000,
  VTEXDmmTriggerSourceBPL1 = 1001,
  VTEXDmmTriggerSourceBPL2 = 1002,
  VTEXDmmTriggerSourceBPL3 = 1003,
  VTEXDmmTriggerSourceBPL4 = 1004,
  VTEXDmmTriggerSourceBPL5 = 1005,
  VTEXDmmTriggerSourceBPL6 = 1006,
  VTEXDmmTriggerSourceBPL7 = 1007
};

enum VTEXDmmTriggerSlopeEnum
{
  VTEXDmmTriggerSlopePositive = 0,
  VTEXDmmTriggerSlopeNegative = 1
};

enum VTEXDmmArmSourceEnum
{
  VTEXDmmArmSourceImmediate = 1,
  VTEXDmmArmSourceExternal = 2,
  VTEXDmmArmSourceSwTrigFunc = 3,
  VTEXDmmArmSourceBPL0 = 1000,
  VTEXDmmArmSourceBPL1 = 1001,
  VTEXDmmArmSourceBPL2 = 1002,
  VTEXDmmArmSourceBPL3 = 1003,
  VTEXDmmArmSourceBPL4 = 1004,
  VTEXDmmArmSourceBPL5 = 1005,
  VTEXDmmArmSourceBPL6 = 1006,
  VTEXDmmArmSourceBPL7 = 1007
};

enum VTEXDmmArmTriggerSlopeEnum
{
  VTEXDmmArmTriggerSlopePositive = 0,
  VTEXDmmArmTriggerSlopeNegative = 1
};

enum VTEXDmmSampleTriggerEnum
{
  VTEXDmmSampleTriggerImmediate = 1,
  VTEXDmmSampleTriggerExternal = 2,
  VTEXDmmSampleTriggerSwTrigFunc = 3,
  VTEXDmmSampleTriggerInterval = 10,
  VTEXDmmSampleTriggerBPL0 = 1000,
  VTEXDmmSampleTriggerBPL1 = 1001,
  VTEXDmmSampleTriggerBPL2 = 1002,
  VTEXDmmSampleTriggerBPL3 = 1003,
  VTEXDmmSampleTriggerBPL4 = 1004,
  VTEXDmmSampleTriggerBPL5 = 1005,
  VTEXDmmSampleTriggerBPL6 = 1006,
  VTEXDmmSampleTriggerBPL7 = 1007
};

enum VTEXDmmSampleTriggerSlopeEnum
{
  VTEXDmmSampleTriggerSlopePositive = 0,
  VTEXDmmSampleTriggerSlopeNegative = 1
};

enum VTEXDmmMeasCompleteDestEnum
{
  VTEXDmmMeasCompleteDestNone = -1,
  VTEXDmmMeasCompleteDestExternal = 2,
  VTEXDmmMeasCompleteDestBPL0 = 1000,
  VTEXDmmMeasCompleteDestBPL1 = 1001,
  VTEXDmmMeasCompleteDestBPL2 = 1002,
  VTEXDmmMeasCompleteDestBPL3 = 1003,
  VTEXDmmMeasCompleteDestBPL4 = 1004,
  VTEXDmmMeasCompleteDestBPL5 = 1005,
  VTEXDmmMeasCompleteDestBPL6 = 1006,
  VTEXDmmMeasCompleteDestBPL7 = 1007
};

 //!
 //! Dmm->Math
 //!    
enum VTEXDmmMathRequestEnum
{
  VTEXDmmMathRequestMinValue = 1000,
  VTEXDmmMathRequestMaxValue = 1001,
  VTEXDmmMathRequestScalarAverage = 1002
};


 //!
 //! Dmm->Limit
 //!     
enum VTEXDmmSampleLimitDestEnum
{
  VTEXDmmSampleLimitDestNone = -1,
  VTEXDmmSampleLimitDestExternal = 2,
  VTEXDmmSampleLimitDestBPL0 = 1000,
  VTEXDmmSampleLimitDestBPL1 = 1001,
  VTEXDmmSampleLimitDestBPL2 = 1002,
  VTEXDmmSampleLimitDestBPL3 = 1003,
  VTEXDmmSampleLimitDestBPL4 = 1004,
  VTEXDmmSampleLimitDestBPL5 = 1005,
  VTEXDmmSampleLimitDestBPL6 = 1006,
  VTEXDmmSampleLimitDestBPL7 = 1007
};


 //!
 //! Dmm->InstrumentSpecific
 //!  
enum VTEXDmmFunctionOptionEnum
{
  VTEXDmmFunctionOptionACFilterLow = 1000,
  VTEXDmmFunctionOptionACFilterMedium = 1001,
  VTEXDmmFunctionOptionACFilterHigh = 1002,
  VTEXDmmFunctionOptionDCExtProbeOff = 1003,
  VTEXDmmFunctionOptionDCExtProbeOn = 1004,
  VTEXDmmFunctionOptionResTestCurrentLow = 1005,
  VTEXDmmFunctionOptionResTestCurrentHigh = 1006,
  VTEXDmmFunctionOptionNone = 1007,
  VTEXDmmFunctionOptionFreqSlow = 1008,
  VTEXDmmFunctionOptionFreqMedium = 1009,
  VTEXDmmFunctionOptionFreqFast = 1010,
  VTEXDmmFunctionOptionFreqUser = 1011
};

enum VTEXDmmStateEnum
{
  VTEXDmmStateIdle = 1000,
  VTEXDmmStateWaitingForTrigger = 1001,
  VTEXDmmStateSampling = 1002,
  VTEXDmmStateSelfTestInProgress = 1003
};


 //!
 //! Dmm
 //!    
enum VTEXDmmFunctionEnum
{
  VTEXDmmFunctionDCVolts = 1,
  VTEXDmmFunctionACVolts = 2,
  VTEXDmmFunctionDCCurrent = 3,
  VTEXDmmFunctionACCurrent = 4,
  VTEXDmmFunction2WireRes = 5,
  VTEXDmmFunction4WireRes = 101,
  VTEXDmmFunctionACPlusDCVolts = 106,
  VTEXDmmFunctionACPlusDCCurrent = 107,
  VTEXDmmFunctionFreq = 104,
  VTEXDmmFunctionPeriod = 105,
  VTEXDmmFunctionTemperature = 108
};

 //!
 //! Dmm->Temperature
 //!     
enum VTEXDmmTransducerTypeEnum
{
  VTEXDmmTransducerTypeThermocouple = 1,
  VTEXDmmTransducerTypeThermistor = 2,
  VTEXDmmTransducerType2WireRtd = 3,
  VTEXDmmTransducerType3WireRtd = 1001,
  VTEXDmmTransducerType4WireRtd = 4
};

enum VTEXDmmThermocoupleTypeEnum
{
  VTEXDmmThermocoupleTypeB = 1,
  VTEXDmmThermocoupleTypeC = 2,
  VTEXDmmThermocoupleTypeD = 3,
  VTEXDmmThermocoupleTypeE = 4,
  VTEXDmmThermocoupleTypeG = 5,
  VTEXDmmThermocoupleTypeJ = 6,
  VTEXDmmThermocoupleTypeK = 7,
  VTEXDmmThermocoupleTypeN = 8,
  VTEXDmmThermocoupleTypeR = 9,
  VTEXDmmThermocoupleTypeS = 10,
  VTEXDmmThermocoupleTypeT = 11,
  VTEXDmmThermocoupleTypeU = 12,
  VTEXDmmThermocoupleTypeV = 13
};

enum VTEXDmmRefJunctionTypeEnum
{
  VTEXDmmRefJunctionTypeInternal = 1,
  VTEXDmmRefJunctionTypeFixed = 2,
  VTEXDmmRefJunctionTypeExternal = 1000
};

enum VTEXDmmRtdTypeEnum
{
  VTEXDmmRtdTypePT100 = 1000,
  VTEXDmmRtdTypeD100 = 1001,
  VTEXDmmRtdTypeF100 = 1002,
  VTEXDmmRtdTypePT385 = 1003,
  VTEXDmmRtdTypePT3916 = 1004,
  VTEXDmmRtdTypeUser = 1100
};

enum VTEXDmmAutoRangeEnum
{
  VTEXDmmAutoRangeOn = -1,
  VTEXDmmAutoRangeOff = -2,
  VTEXDmmAutoRangeOnce = -3
};

enum VTEXDmmRangeDelayEnum
{
  VTEXDmmRangeAutoDelayOn = -1
};

enum VTEXDmmMaxTimeEnum
{
  VTEXDmmMaxTimeImmediate = 0,
  VTEXDmmMaxTimeInfinite = -1
};

enum VTEXDmmTriggerDelayEnum
{
  VTEXDmmTriggerDelayAutoDelayOn = -1,
  VTEXDmmTriggerDelayAutoDelayOff = -2
};

enum VTEXDmmCalibrationFunctionEnum
{
  VTEXDmmCalibrationFunctionGMUX = 1000,
  VTEXDmmCalibrationFunctionDCVolts = 1001,
  VTEXDmmCalibrationFunctionDCCurrent = 1002,
  VTEXDmmCalibrationFunction2WireRes = 1003,
  VTEXDmmCalibrationFunction4WireRes = 1004,
  VTEXDmmCalibrationFunctionACFilter = 1005,
  VTEXDmmCalibrationFunctionACVolts = 1006,
  VTEXDmmCalibrationFunctionACCurrent = 1007,
  VTEXDmmCalibrationFunctionInfo = 1008
};

enum VTEXDmmCalibrationItemEnum
{
  VTEXDmmCalibrationItemGain = 1000,
  VTEXDmmCalibrationItemPositiveGain = 1001,
  VTEXDmmCalibrationItemNegativeGain = 1002,
  VTEXDmmCalibrationItemOffset = 1003,
  VTEXDmmCalibrationItemDACCompensation = 1004,
  VTEXDmmCalibrationItemR10M = 1005,
  VTEXDmmCalibrationItemISRC = 1006,
  VTEXDmmCalibrationItemK1 = 1007,
  VTEXDmmCalibrationItemK2 = 1008,
  VTEXDmmCalibrationItemK4 = 1009,
  VTEXDmmCalibrationItemInternalTemp = 1010,
  VTEXDmmCalibrationItemExternalTemp = 1011,
  VTEXDmmCalibrationItemDate = 1012,
  VTEXDmmCalibrationItemDueDate = 1013,
  VTEXDmmCalibrationItemNoItem = 1014
};

enum VTEXDmmCalibrationFunctionOptionEnum
{
  VTEXDmmCalibrationFunctionOptionNoProbe = 1000,
  VTEXDmmCalibrationFunctionOptionExternalProbe = 1001,
  VTEXDmmCalibrationFunctionOptionLowTestCurrent = 1002,
  VTEXDmmCalibrationFunctionOptionHighTestCurrent = 1003,
  VTEXDmmCalibrationFunctionOptionSlowFilter = 1004,
  VTEXDmmCalibrationFunctionOptionMediumFilter = 1005,
  VTEXDmmCalibrationFunctionOptionFastFilter = 1006,
  VTEXDmmCalibrationFunctionOptionNone = 1007
};

enum VTEXDmmFrequencyVoltageRangeEnum
{
  VTEXDmmFrequencyVoltageRangeAutoRangeOn = -1,
  VTEXDmmFrequencyVoltageRangeAutoRangeOff = -2,
  VTEXDmmFrequencyVoltageRangeAutoRangeOnce = -3
};

enum VTEXDmmOptionalMeasurementUnitsEnum
{
  VTEXDmmOptionalMeasurementUnitsDefault = 1000,
  VTEXDmmOptionalMeasurementUnitsRatio = 1001,
  VTEXDmmOptionalMeasurementUnitsdB = 1002,
  VTEXDmmOptionalMeasurementUnitsdBm = 1003
};

enum VTEXDmmDataTypeEnum
{
  VTEXDmmDataTypeDataOnly = 1000,
  VTEXDmmDataTypeDataAndTimestamp = 1001,
  VTEXDmmDataTypeDebug = 1002
};



#endif /* ! _DmmConstants_H */

#ifdef  __cplusplus
}
#endif

