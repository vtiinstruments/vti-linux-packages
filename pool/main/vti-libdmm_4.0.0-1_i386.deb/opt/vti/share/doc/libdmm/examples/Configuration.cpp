#include "libDmm.h"
#include <stdio.h>

int main()
{
	//Create a VTEXDmm pointer
	LibDmm *pDmm;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created dmm pointer
		pDmm = LibDmm::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pDmm->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			/*The Dmm drivers provides function for you to save and load configuration.
			Given a configuration name, you can save and load any configuration
			easily so that you do not need to set different functions every time you
			want to take a new measurement.*/
			//First set the desired function, range and resolution.
			pDmm->Function = VTEXDmmFunctionDCVolts;
			pDmm->Range = 300;
			pDmm->Resolution = 0.001;

			//Trigger and sample information can also be saved in a configuration
			pDmm->Trigger->Source = VTEXDmmTriggerSourceImmediate;
			pDmm->Trigger->Delay = 0;
			pDmm->Trigger->MultiPoint->Count = 1;
			pDmm->Trigger->MultiPoint->SampleCount = 1;
			pDmm->Trigger->MultiPoint->SampleDelay = 0;
			pDmm->Trigger->MultiPoint->SampleTrigger = VTEXDmmSampleTriggerImmediate;
			/*Note that there are many other properties you can save in a configuration.
			Please read the user manual for more information about Configuration.*/

			//Save the configuration in your desired name.
			pDmm->Configuration->Save("DCV"); //You can save it with whatever name you want.

			/*To load the configuration, simply call the load function with the
			name of the configuration you want to load*/
			pDmm->Configuration->Load("DCV");

			/*If you like to know what configuration you have saved, you can get the
			value of the property "List". It returns a list of the saved configuration*/
			std::string list = pDmm->Configuration->List;

			/*If you like to delete a specific saved configuration, you can 
			simply call the delete function with the name of the configuration
			you want to delete.*/
			pDmm->Configuration->Delete("DCV");

			/*You can also delete all the saved configuration. To do that, you 
			can simply call the deleteAll function*/
			pDmm->Configuration->DeleteAll();
			
			//Close the initialized session
			pDmm->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
