#include "libDmm.h"
#include <stdio.h>

int main()
{
	//Create a VTEXDmm pointer
	LibDmm *pDmm;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created dmm pointer
		pDmm = LibDmm::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pDmm->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			/*In order to take a measurement using the Dmm, you have to first
			set the function, range and resolution.*/
			/*You can use the Configure function to configure all function, range and
			resolution in one line*/
			pDmm->Configure(VTEXDmmFunctionDCVolts, 300, 0.001);
			//Or you can set them separately
			pDmm->Function = VTEXDmmFunctionDCVolts;
			pDmm->Range = 300;
			pDmm->Resolution = 0.001;

			//Function option can also affect the accuracy of the measurement.
			pDmm->FunctionOption = VTEXDmmFunctionOptionDCExtProbeOn;
			
			//Close the initialized session
			pDmm->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
