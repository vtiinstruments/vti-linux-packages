#include "libDmm.h"
#include <stdio.h>

int main()
{
	//Create a VTEXDmm pointer
	LibDmm *pDmm;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created dmm pointer
		pDmm = LibDmm::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		double reading = 0.0;

		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pDmm->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			//Set the function, range and resolution 
			pDmm->Configure(VTEXDmmFunctionDCVolts, 10, 0.00001);
			//Set the trigger output properties
			pDmm->Trigger->MultiPoint->MeasurementComplete = VTEXDmmMeasCompleteDestBPL0;
			/*In this case, we set the Measurementcomplete to BPL0. Therefore, once the measurement is 
			complete, the Dmm will route a signal on BPL0.*/
			/*We can also set the sample limit so that when the sample is higher than 
			the high limit or lower than the low limit, the Dmm will route a signal on 
			the specified destination.*/
			pDmm->Limit->High = 0;
			pDmm->Limit->Low = 100;
			pDmm->Limit->Dest = VTEXDmmSampleLimitDestBPL1;
			/*In this case, if the sample we take is higher than 0 or lower than 100,
			the Dmm will route a signal on BPL1.*/

			//Initiate a measurement
			pDmm->Measurement->Initiate();

			//Fetch the data
			pDmm->Measurement->Fetch(1000, &reading);
			/*In order to detect the signal on the specified BPL, you may want to 
			use the VTEXSystem driver to help. For more information, please read the
			user manual.*/
			
			//Close the initialized session
			pDmm->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
