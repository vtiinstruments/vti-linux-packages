#include "libDmm.h"
#include <stdio.h>
#ifndef _WIN32
#include <unistd.h>
#endif
int main()
{
	//Create a VTEXDmm pointer
	LibDmm *pDmm;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created dmm pointer
		pDmm = LibDmm::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/

		std::vector<double> reading;
		std::vector<double> timeSeconds;
		std::vector<double> timeFraction;
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pDmm->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			//Setup the function, range and resolution
			pDmm->Configure(VTEXDmmFunctionDCVolts, 10, 0.00001);
			/*In this case, the Dmm is to measure DC Voltage in 10V range with resolution 
			0.00001.*/

			//Setup the trigger properties
			/*In this example, we will be using Software Trigger as the trigger source.
			You can always set the trigger source to BPL or External. Please read the 
			user manual for more information about using BPL and External.*/
			pDmm->Trigger->Configure(VTEXDmmTriggerSourceSwTrigFunc, 0);
			pDmm->Trigger->MultiPoint->Configure(1, 5, VTEXDmmSampleTriggerImmediate, 0);
			pDmm->Trigger->MultiPoint->SampleDelay = 0;
			/*In this case, the Dmm is to take exact 5 samples in each measurement and takes exact 1
			measurement. The Dmm is to wait for a Software Trigger to take a measurement and take
			samples immediately without any delay. So, in this case, the sequences after initiate will be
			Step #1. Wait for trigger to take a measurement
			Step #2. Take 5 samples (after receiving a software trigger)*/

			//Initiate the measurement
			pDmm->Measurement->Initiate();

			/*At this point, the Dmm is waiting for a software trigger in order to start taking
			the measurement. So we have to send a software trigger.*/
			pDmm->Measurement->SendSoftwareTrigger();
			//After this, the Dmm will start taking the measurement. It will take 5 samples

			/*you can always check the fifo count to see how many data is ready in the fifo, 
			it may take some time to get all the sample. The time varies depend on the Dmm
			function you set to.*/
			int fifoCount = pDmm->Measurement->FIFOCount;

			//At this point, you may want to wait until the Dmm finishes taking all 5 samples.
			usleep(5000000);

			//Fetch the data
			pDmm->Measurement->FetchMultiPoint(1000, reading);	
			/*By calling Fetch MultiPoint, all the available data in the fifo will 
			be returned. Instead of calling Fetch function 5 times to get all the
			data in the fifo, we can call FetchMultiPoint to get all the data
			at once. Note that this function does not care how many data is in the 
			fifo. This function will return all available data in the fifo
			at the time you call this function. So, if you want to get all 5 samples, 
			you need to make sure that all the sample you want to get are ready 
			before calling this function.*/

			/*You can also call FetchMultiPointTimeStamped to get the time when each data 
			is taken. We need to initiate a measurement again at this point to see how
			FetchMultiPointTimeStamped function works.*/
			pDmm->Measurement->Initiate();
			pDmm->Measurement->SendSoftwareTrigger();

			//At this point, you may want to wait until the Dmm finishes taking all 5 samples.
			usleep(5000000);

			pDmm->Measurement->FetchMultiPointTimeStamped(1000, reading, timeSeconds, timeFraction);
			//Not only the data is returned, the time the data is taken is also returned.
			
			/*You can also call ReadMultiPoint function to initiate the measurement 
			and fetch the data at once. However, the ReadMutliPoint function will 
			not return until all required data is ready or will generate an exception
			if not all the required data is ready in a specified amount of time. So, 
			in this case, we cannot set the trigger source to Software since there
			is no way we can send a software trigger after the Read function is called.
			So, let's change the trigger source to Immediate.*/
			pDmm->Trigger->Source = VTEXDmmTriggerSourceImmediate;
			pDmm->Measurement->ReadMultiPoint(10000, reading);
			/*Make sure that you give enough time for the Dmm to finish taking all 5 samples.
			The time is in milli second. In this case, we give 10 seconds. This function
			returns as soon as all the data is available, so it will not be slow down
			even though you are giving a long time.*/
	        
			/*Same as FetchMultiPoint function, you can also get the time when the data is taken
			simply by calling ReadMultiPointTimeStamped.*/
            pDmm->Measurement->ReadMultiPointTimeStamped(10000, reading, timeSeconds, timeFraction);
			
			//Close the initialized session
			pDmm->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
