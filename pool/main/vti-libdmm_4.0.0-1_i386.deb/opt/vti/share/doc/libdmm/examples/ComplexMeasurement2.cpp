#include "libDmm.h"
#include <stdio.h>
#ifndef _WIN32
#include <unistd.h>
#endif

int main()
{
	//Create a VTEXDmm pointer
	LibDmm *pDmm;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created dmm pointer
		pDmm = LibDmm::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		int fifoCount = 0;
		std::vector<double> reading;
		std::vector<double> timeSeconds;
		std::vector<double> timeFraction;

		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pDmm->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			//Setup the function, range and resolution 
			pDmm->Configure(VTEXDmmFunctionDCCurrent, 0.001, 0.000000001);
			/*In this case, the Dmm is to measure DC Current in 100mA range with resolution 
			0.000000001.*/

			//Setup the trigger properties
			/*In this example, we will be using Software Trigger as the sample trigger source.
			You can always set the sample trigger source to BPL or External. Please read
			the user manual for more information about using BPL and External.*/
			pDmm->Trigger->Configure(VTEXDmmTriggerSourceImmediate, 0);
			pDmm->Trigger->MultiPoint->Configure(3, 2, VTEXDmmSampleTriggerSwTrigFunc, 0);
			pDmm->Trigger->MultiPoint->SampleDelay = 0;
			/*In this case, the Dmm is to take exact 3 measurements and 2 samples in each measurement.
            The Dmm is to immediately take a measurement after the measurement is initiated, and 
            wait for a software trigger to take each sample (except the first sample in each measurement
            since the first one is always taken regardless to the sample trigger source.) without any delay.
            So, in this case, the sequences after initiate will be :
            Step #1. Take 1 sample (The first sample is always taken regardless to the sample trigger source)
            Step #2. Wait for a software trigger to take the 2nd sample
            Step #3. Take the 2nd sample (after receiving a software trigger)
            Step #4. Take the 3rd sample (This is the first sample in the second measurement)
            Step #5. Wait for a software trigger to take the 4th sample
            Step #6. Take the 4th sample (after receiving a software trigger)
            Step #7. Take 5th sample (this is the first sample in the third measurment)
            Step #8. Wait for a software trigger to take the 6th sample                     
            Step #9. Take the 6th sample (after receiving a software trigger)*/

			//Initiate the measurement
			pDmm->Measurement->Initiate();

			//You may want to wait a bit here until the first sample is taken.
			usleep(1000000);

			/*At this point, the Dmm has been taking the first sample. The first
			sample is always taken no matter what sample trigger source is set to.
			Since we set sample count to be 2, so we have to send a
			Software Trigger to get the second sample in the first measurement*/
			pDmm->Measurement->SendSoftwareTrigger();

			for(int i=0; i<2; i++)
			{
				/*Since we set trigger count to be 3, so we have to send 2 more software 
				trigger in order to get all the 6 data.*/

				//You may want to wait a bit here for the previous measurement to be complete.
				//Or you can always check if the data is ready or not in the fifo
				fifoCount = pDmm->Measurement->FIFOCount;
				/*There should be 3 data in the fifo in the first loop (this first two in the
				first measurement plus the first sample in the second measurement. And there
				should be 5 data in the fifo at the second loop (the 4 samples in the first
				and second measurement and the first sample in the third measurement*/
				while(fifoCount != 2*i+3)
				{
					//Wait some time here beofre checking the fifo count again
					usleep(500000);
					fifoCount = pDmm->Measurement->FIFOCount;
					/*Be careful to use the while loop here. It may cause infinite loop
					if something is not setting correctly*/
				}

				//Send software trigger
				pDmm->Measurement->SendSoftwareTrigger();
			}

			/*You may also want to wait a bit here for the previous measurement to be complete.
			Or you can check the fifo count*/
			fifoCount = pDmm->Measurement->FIFOCount;
			while(fifoCount != 6)
			{
				usleep(500);
				fifoCount = pDmm->Measurement->FIFOCount;
			}
			
			//Fetch the data
			pDmm->Measurement->FetchMultiPoint(1000, reading);
			/*By calling Fetch MultiPoint, all the available data in the fifo will
			be returned. Instead of calling Fetch function 6 times to get all the 
			data in the fifo, we can call FetchMultiPoint to get all the data at
			once. Note that the function does not care how many data is in the
			fifo. This function will return all available data in the fifo at the
			time you call this function. So, if you want to get all 6 data, you 
			need to make sure that all the samples you want to get are ready
			before calling this function.*/

			/*You can do the same thing with FetchMultiPointTimeStamped to get the time when
			each data is taken. We need to initiate a measurement again at this point to see
			how FetchMultiPointTimeStamped function works.*/
			pDmm->Measurement->Initiate();

			//You may want to wait a bit here for the previoius measurement to be complete
			usleep(1000000);

			//Send software trigger
			pDmm->Measurement->SendSoftwareTrigger();
			for(int i=0; i<2; i++)
			{
				//Check the fifo count
				fifoCount = pDmm->Measurement->FIFOCount;
				while(fifoCount != 2*i+3) //Wait until we get specified amount of data
				{
					usleep(500000);
					fifoCount = pDmm->Measurement->FIFOCount;
				}
				pDmm->Measurement->SendSoftwareTrigger(); //Send software trigger
			}

			//Check if we get all the data we want, trigger count * sample count = 6 in this case.
			fifoCount = pDmm->Measurement->FIFOCount;
			while(fifoCount != 6)
			{
				usleep(500);
				fifoCount = pDmm->Measurement->FIFOCount;
			}
			//Get back the data and the time of the data being taken
			pDmm->Measurement->FetchMultiPointTimeStamped(1000, reading, timeSeconds, timeFraction);
			
			//Close the initialized session
			pDmm->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
