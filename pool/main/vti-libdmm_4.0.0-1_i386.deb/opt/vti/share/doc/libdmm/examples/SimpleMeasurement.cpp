#include "exTypes.h"
#include "libDmm.h"
#include <stdio.h>

int main()
{
	//Create a VTEXDmm pointer
	LibDmm *pDmm;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created dmm pointer
		pDmm = LibDmm::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		double reading = 0.0;
		double timeSeconds = 0.0;
		double timeFraction = 0.0;

		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pDmm->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			//Setup the function, range and resolution 
			pDmm->Configure(VTEXDmmFunctionDCVolts, 10, 0.00001);
			/*In this case, the Dmm is to measure DC Voltage in 10V range with resolution 
			0.00001*/

			//Setup the trigger properties
			pDmm->Trigger->Configure(VTEXDmmTriggerSourceImmediate, 0);
			pDmm->Trigger->MultiPoint->Configure(1, 1, VTEXDmmSampleTriggerImmediate, 0);
			pDmm->Trigger->MultiPoint->SampleDelay = 0;
			/*In this case, the Dmm is to take exact 1 sample and take exact 1 measurement.
			The Dmm is to take measurement and sample immediately without depending on any source.
			There is no delay before taking any measurement and sample.*/

			//Initiate the measurement
			pDmm->Measurement->Initiate();
			/*Call Initiate to initiate the measurement, the data should be available
			in a short time since only one measurement and sample is taken. The time 
			varies depend on what Dmm function is set to.*/

			/*You can always check the fifo count to see howmany data is ready in the fifo.
			Note that you have to wait until the Dmm finishes taking a measurement before
			you can see the fifo count incrments.*/
			int fifoCount = pDmm->Measurement->FIFOCount;
			//in this case, the fifo count should be 1.

			//Fetch the data
			pDmm->Measurement->Fetch(1000, &reading);
			/*Given a specified amount of time, the function will return when the data
			is available or generates an exception if the data is not ready after the
			specified amount of time. The given time is in milli second, so in this case,
			we are giving 1 second for the Dmm to fetch the data. Note that, after you 
			fetch the data, the fifo count will be decreased by 1. */

			/*The VTEXDmm driver provides different kinds of Fetch call. We are now to 
			initiate a measurement again and use a different Fetch call to fetch the 
			data.*/
			pDmm->Measurement->Initiate();
			pDmm->Measurement->FetchTimeStamped(1000, &reading, &timeSeconds, &timeFraction);
			/*By using FetchTimeStamped function, not only the data will be returned, 
			the time that the data is taken is also returned in this function.*/

			/*You can also initiate a measurement and fetch data in one line. by calling
			Read function, you do not need to call initiate and fetch. It will automatically
			fetch the data after initiate is done, and return the data. Or it will generate
			an error if the data is not ready in the specified amount of time.*/
			pDmm->Measurement->Read(1000, &reading);
			/*Make sure that you give enough of time for the Dmm to finish taking the 
			measurement. Otherwise, an error message will be returned. The time is
			in milli second. In this case, we are giving the Dmm 1 second. */

			/*Just like Fetch function, you can also get the time when the data is taken
			simply by calling ReadTimeStamped function.*/
			pDmm->Measurement->ReadTimeStamped(1000, &reading, &timeSeconds, &timeFraction);
			
			//Close the initialized session
			pDmm->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
