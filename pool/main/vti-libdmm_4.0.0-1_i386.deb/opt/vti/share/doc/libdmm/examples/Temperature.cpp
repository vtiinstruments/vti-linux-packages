#include "libDmm.h"
#include <stdio.h>

int main()
{
	//Create a VTEXDmm pointer
	LibDmm *pDmm;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created dmm pointer
		pDmm = LibDmm::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		double reading = 0.0;

		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pDmm->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			//Set the function to temperature
			pDmm->Function = VTEXDmmFunctionTemperature;
			/*Since the range and resolution are fixed for temperature
			we do not need to set them*/

			//Set the transducer type
			pDmm->Temperature->TransducerType = VTEXDmmTransducerTypeThermocouple;

			//Set the properties of thermocouple
			pDmm->Temperature->Thermocouple->Type = VTEXDmmThermocoupleTypeB;
			//The Dmm driver supports thermocouple type B,E,J,K,N,R,S and T
			//Set the reference junction type
			pDmm->Temperature->Thermocouple->RefJunctionType = VTEXDmmRefJunctionTypeFixed;
			//The Dmm driver only supports fixed reference junction type
			/*Set the fixed reference junction temperature, for more
			information about reference junction please read the user manual.*/
			pDmm->Temperature->Thermocouple->FixedRefJunction = 0;

			//Take a temperature measurement using thermocouple transducer type
			pDmm->Measurement->Initiate();
			//Fetch the data
			pDmm->Measurement->Fetch((int)VTEXDmmMaxTimeInfinite, &reading);
			/*Fetch function will return as soon as there is data available in the fifo, 
			so we can give a large amount of time for it without slowing down the 
			process. In this case, we give infinite time for the Dmm to fetch a data, so
			it will return as soon as it gets one data in the fifo.*/

			//You can also use RTD to measure temperature
			pDmm->Temperature->TransducerType = VTEXDmmTransducerType2WireRtd;
			//the Dmm driver supports 2Wire, 3Wire and 4Wire RTD.
			//Set the RTD type
			pDmm->Temperature->RTD->Type = VTEXDmmRtdTypeD100;
			/*The Dmm driver supports different RTD types. Each type has its own RTD constant values.
			Once the RTD type is configured, the RTD Alpha, Beta, Delta and resistance will automatically
			be set as well. If you want to specify the RTD Alpha, Beta, Delta and resistance, 
			you can set the type to User and then set them to the desired values. Or you can 
			just set the constants to the desired values, the type will be automatically 
			set to User.*/
			//Take a temperature measurement using RTD transducer type
			pDmm->Measurement->Initiate();
			//Fetch the data
			pDmm->Measurement->Fetch((int)VTEXDmmMaxTimeInfinite, &reading);
			/*Fetch function will return as soon as there is data available in the fifo, 
			so we can give a large amount of time for it without slowing down the process.
			In this case, we give infinite time for the Dmm to fetch a data, so it will
			return as soon as it gets one data in the fifo.*/

			//You can also use Thermistor to measure temperature
			pDmm->Temperature->TransducerType = VTEXDmmTransducerTypeThermistor;
			//Set the thermistor resistance
			pDmm->Temperature->Thermistor->Resistance = 2252;
			/*The Dmm driver supports 3 models - 2252K, 5K and 10K, for
			more information about the thermistor models, please read the user manual.
			Once the resistance is configured to a positive value, the thermistor constant
			values will be automatically set as well. If you want to specify the thermistor 
			constants A, B and C, you can set the resistance to any negative value 
			and then set the constants to the desired values. Or you can just set the
			constants to the desired values, the resistance will automatically be set 
			to -1.*/
			//Take a temperature measurement using Thermistor transducer type
			pDmm->Measurement->Initiate();
			//Fetch the data
			pDmm->Measurement->Fetch((int)VTEXDmmMaxTimeInfinite, &reading);
			/*Fetch function will return as soon as there is data available in the fifo, 
			so we can give a large amount of time for it without slowing down the process.
			In this case, we give infinite time for the Dmm to fetch a data, so
			it will return as soon as it gets one data in the fifo.*/
			
			//Close the initialized session
			pDmm->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
