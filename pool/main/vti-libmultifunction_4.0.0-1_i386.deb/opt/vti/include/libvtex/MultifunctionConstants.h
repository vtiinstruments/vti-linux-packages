#include "exErrors.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#if defined(_WIN32) && !defined(_CVI_)
#define INLINE __inline
#else
#define INLINE inline
#endif

#ifdef __cplusplus
extern "C" {
#endif

#ifndef _MultifunctionConstants_H
#define _MultifunctionConstants_H

#define MULTIFUNCTION_MAX_TIMEOUT_SECS 20
#define MULTIFUNCTION_MAX_SAMPLES_PER_READ 32
#define MAX_COUNTER_CHANNELS 8
#define MAX_DAC_CHANNELS 2
#define MAX_DIO_CHANNELS 16

enum VTEXMultifunctionCounterFunctionEnum
{
  VTEXMultifunctionCounterFunctionTotalize = 1000,
  VTEXMultifunctionCounterFunctionFrequency = 1001,
  VTEXMultifunctionCounterFunctionPulseWidth = 1002,
  VTEXMultifunctionCounterFunctionTimeInterval = 1003,
  VTEXMultifunctionCounterFunctionRpm = 1004,
  VTEXMultifunctionCounterFunctionQuadrature = 1005,
  VTEXMultifunctionCounterFunctionDutyCycle = 1006,
  VTEXMultifunctionCounterFunctionPhase = 1007,
  VTEXMultifunctionCounterFunctionEdgeCount = 1008,
  VTEXMultifunctionCounterFunctionPeriod = 1009
};

enum VTEXMultifunctionCounterAverageModeEnum
{
  VTEXMultifunctionCounterAverageModeApertureTime = 1000,
  VTEXMultifunctionCounterAverageModeAverageCount = 1001
};

enum VTEXMultifunctionCounterCouplingEnum
{
  VTEXMultifunctionCounterCouplingDC = 1000,
  VTEXMultifunctionCounterCouplingAC = 1001
};

enum VTEXMultifunctionCounterOverflowModeEnum
{
  VTEXMultifunctionCounterOverflowModeStop = 1000,
  VTEXMultifunctionCounterOverflowModePreset = 1001,
  VTEXMultifunctionCounterOverflowModeWraparound = 1002
};


enum VTEXMultifunctionCounterInputModeEnum
{
  VTEXMultifunctionCounterInputModeSingleEnded = 1000,
  VTEXMultifunctionCounterInputModeDifferential = 1001
};

enum VTEXMultifunctionCounterInputTypeEnum
{
  VTEXMultifunctionCounterInputTypeDigital = 1000,
  VTEXMultifunctionCounterInputTypeAnalog = 1001
};


enum VTEXMultifunctionCounterPolarityEnum
{
  VTEXMultifunctionCounterPolarityNormal = 1000,
  VTEXMultifunctionCounterPolarityInverse = 1001
};

enum VTEXMultifunctionCounterRpmToothStateEnum
{
  VTEXMultifunctionCounterRpmToothStateNormal = 1000,
  VTEXMultifunctionCounterRpmToothStateExtra = 1001,
  VTEXMultifunctionCounterRpmToothStateMissing = 1002
};


enum VTEXMultifunctionCounterSlopeEnum
{
  VTEXMultifunctionCounterSlopePositive = 1000,
  VTEXMultifunctionCounterSlopeNegative = 1001
};

enum VTEXMultifunctionCounterQuadratureCountModeEnum
{
  VTEXMultifunctionCounterQuadratureCountMode2x = 1000,
  VTEXMultifunctionCounterQuadratureCountMode4x = 1001
};

enum VTEXMultifunctionDacOutputModeEnum
{
  VTEXMultifunctionDacOutputModeStatic = 1000,
  VTEXMultifunctionDacOutputModeDynamic = 1001
};

enum VTEXMultifunctionDacDriveModeEnum
{
  VTEXMultifunctionDacDriveModeVoltage = 1000,
  VTEXMultifunctionDacDriveModeCurrent = 1001
};

enum VTEXMultifunctionDioDirectionEnum
{
  VTEXMultifunctionDioDirectionInput = 1000,
  VTEXMultifunctionDioDirectionOutput = 1001
};


enum VTEXMultifunctionDioPolarityEnum
{
  VTEXMultifunctionDioPolarityNormal = 1000,
  VTEXMultifunctionDioPolarityInverse = 1001
};


enum VTEXMultifunctionFifoOverflowModeEnum
{
  VTEXMultifunctionFifoOverflowModeStop = 1000,
  VTEXMultifunctionFifoOverflowModeOverwrite = 1001
};

enum VTEXMultifunctionMeasurementStateEnum
{
  VTEXMultifunctionMeasurementStateIdle = 1000,
  VTEXMultifunctionMeasurementStateWaitingForTrigger = 1001,
  VTEXMultifunctionMeasurementStateAcquiring = 1002
};

enum VTEXMultifunctionTriggerSourceEnum
{
  VTEXMultifunctionTriggerSourceImmediate = 1000,
  VTEXMultifunctionTriggerSourceSoftware = 1001,
  VTEXMultifunctionTriggerSourceBPL0 = 1002,
  VTEXMultifunctionTriggerSourceBPL1 = 1003,
  VTEXMultifunctionTriggerSourceBPL2 = 1004,
  VTEXMultifunctionTriggerSourceBPL3 = 1005,
  VTEXMultifunctionTriggerSourceBPL4 = 1006,
  VTEXMultifunctionTriggerSourceBPL5 = 1007,
  VTEXMultifunctionTriggerSourceBPL6 = 1008,
  VTEXMultifunctionTriggerSourceBPL7 = 1009
};


enum VTEXMultifunctionCalibrationCounterBackplaneConnectionItemEnum
{
  VTEXMultifunctionCalibrationCounterBackplaneConnectionItemRawDacLo = 1001,
  VTEXMultifunctionCalibrationCounterBackplaneConnectionItemSignal = 1002,
  VTEXMultifunctionCalibrationCounterBackplaneConnectionItemRawDacHi = 1004
};


enum VTEXMultifunctionCalibrationConstantEnum
{
  VTEXMultifunctionCalibrationConstantCounterGain = 1000,
  VTEXMultifunctionCalibrationConstantCounterOffset = 1001,
  VTEXMultifunctionCalibrationConstantCounterRawDacHiGain = 1002,
  VTEXMultifunctionCalibrationConstantCounterRawDacHiOffset = 1003,
  VTEXMultifunctionCalibrationConstantCounterRawDacLoGain = 1004,
  VTEXMultifunctionCalibrationConstantCounterRawDacLoOffset = 1005,
  VTEXMultifunctionCalibrationConstantDACVoltageGain = 1006,
  VTEXMultifunctionCalibrationConstantDACVoltageOffset = 1007,
  VTEXMultifunctionCalibrationConstantDACCurrentGain = 1008,
  VTEXMultifunctionCalibrationConstantDACCurrentOffset = 1009,
  VTEXMultifunctionCalibrationConstantDate = 1010,
  VTEXMultifunctionCalibrationConstantDueDate = 1011
};
#endif /* ! _MultifunctionConstants_H */

#ifdef  __cplusplus
}
#endif

