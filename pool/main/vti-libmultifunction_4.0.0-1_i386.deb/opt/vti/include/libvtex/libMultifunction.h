/******************************************************************************
 *
 *  .----------------------.	
 *  |==     ==  ======  == |	$Author: Praveen S $
 *  | ==   ==   ======  == |	$Revision: ----- $ 
 *  |  == ==      ==    == |	$Date: 2009-11-18 22:36:39 +0530 (Tue, 18 Nov 2009) $ 
 *  |   ===       ==    == |	$HeadURL: http://10.1.0.10/svn/nextgen/trunk/software/Instrument_drivers/------.h $
 *  |    =        ==    == |	
 *  `----------------------'
 *
 * Copyright 2006 VXI Technology Inc. as an unpublished work. 
 * All rights reserved. The information contained herein is confidential
 * property of VXI Technology, Inc. Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement 
 * with VXI Technology, Inc.
 *
 * PURPOSE: 
 *   Class definition of the LibMultifunction class
 *
 ******************************************************************************/

#ifndef _LIB_MF_H
#define _LIB_MF_H

/* System Header */
#include <vector>

/* Local Header */
#include "vtexapi.h"
#include "vtexException.h"
#include "libInherent.h"

#ifndef _ATL_ATTRIBUTES
#include "MultifunctionConstants.h"
#endif

#include "CommonErrors.h"
#include "MultifunctionErrors.h"

class VTEX_API LibMultifunctionDioChannel
{
	public:
		virtual ~LibMultifunctionDioChannel() {};

		property <LibMultifunctionDioChannel, bool, READ_WRITE> Data;
		property <LibMultifunctionDioChannel, VTEXMultifunctionDioDirectionEnum, READ_WRITE> Direction;
		property <LibMultifunctionDioChannel, VTEXMultifunctionDioPolarityEnum, READ_WRITE> Polarity;
		property <LibMultifunctionDioChannel, double, READ_WRITE> Range;
		
		virtual VTEXResult Configure(VTEXMultifunctionDioDirectionEnum direction, 
									 VTEXMultifunctionDioPolarityEnum polarity,
									 double range)		= 0;

		virtual VTEXResult put_Data(bool ch_data)			= 0;
		virtual VTEXResult get_Data(bool* ch_data)			= 0;
		virtual VTEXResult put_Direction(VTEXMultifunctionDioDirectionEnum ch_direction)		= 0;
		virtual VTEXResult get_Direction(VTEXMultifunctionDioDirectionEnum* ch_direction)		= 0;
		virtual VTEXResult put_Polarity(VTEXMultifunctionDioPolarityEnum ch_polarity)			= 0;
		virtual VTEXResult get_Polarity(VTEXMultifunctionDioPolarityEnum* ch_polarity)			= 0;
		virtual VTEXResult put_Range(double ch_range)		= 0;
		virtual VTEXResult get_Range(double* ch_range)		= 0;
};

class VTEX_API LibMultifunctionDacChannel
{
	public:
		virtual ~LibMultifunctionDacChannel() {};
		
		property <LibMultifunctionDacChannel, VTEXString, READ_WRITE> CounterChannel;
		property <LibMultifunctionDacChannel, double, READ_WRITE> Current;
		property <LibMultifunctionDacChannel, VTEXMultifunctionDacOutputModeEnum, READ_WRITE> OutputMode;
		property <LibMultifunctionDacChannel, VTEXMultifunctionDacDriveModeEnum, READ_WRITE> DriveMode;
		property <LibMultifunctionDacChannel, bool, READ_WRITE> Enabled;
		property <LibMultifunctionDacChannel, double, READ_WRITE> RefreshInterval;		
		property <LibMultifunctionDacChannel, double, READ_WRITE> Voltage;


		virtual VTEXResult put_CounterChannel(const VTEXString & counter_channel)					= 0;
		virtual VTEXResult get_CounterChannel(VTEXString* counter_channel)					= 0;
		virtual VTEXResult put_Current(double current)					= 0;
		virtual VTEXResult get_Current(double* current)					= 0;
		virtual VTEXResult put_OutputMode(VTEXMultifunctionDacOutputModeEnum output_mode)		= 0;
		virtual VTEXResult get_OutputMode(VTEXMultifunctionDacOutputModeEnum* output_mode)		= 0;
		virtual VTEXResult put_DriveMode(VTEXMultifunctionDacDriveModeEnum drive_mode)	= 0;
		virtual VTEXResult get_DriveMode(VTEXMultifunctionDacDriveModeEnum* drive_mode)	= 0;
		virtual VTEXResult put_Enabled(bool enable)						= 0;
		virtual VTEXResult get_Enabled(bool* enable)					= 0;
		virtual VTEXResult put_RefreshInterval(double refresh_interval)			= 0;
		virtual VTEXResult get_RefreshInterval(double* refresh_interval)		= 0;
		virtual VTEXResult put_Voltage(double voltage)					= 0;
		virtual VTEXResult get_Voltage(double* voltage)					= 0;
};

class VTEX_API LibMultifunctionCounterChannel
{
	public:
		virtual ~LibMultifunctionCounterChannel() {};

		property <LibMultifunctionCounterChannel, double, READ_WRITE> ApertureTime;
		property <LibMultifunctionCounterChannel, int32_t, READ_WRITE> AverageCount;
		property <LibMultifunctionCounterChannel, VTEXMultifunctionCounterAverageModeEnum, READ_WRITE> AverageMode;
		property <LibMultifunctionCounterChannel, bool, READ_WRITE> AverageRepeat;
		property <LibMultifunctionCounterChannel, VTEXMultifunctionCounterCouplingEnum, READ_WRITE> Coupling;
		property <LibMultifunctionCounterChannel, bool, READ_WRITE> Enabled;
		property <LibMultifunctionCounterChannel, bool, READ_WRITE> FifoEnabled;
		property <LibMultifunctionCounterChannel, VTEXMultifunctionCounterFunctionEnum, READ_WRITE> Function;
		property <LibMultifunctionCounterChannel, VTEXMultifunctionCounterOverflowModeEnum, READ_WRITE> OverflowMode;
		property <LibMultifunctionCounterChannel, double, READ_WRITE> Hysteresis;
		property <LibMultifunctionCounterChannel, VTEXString, READ_WRITE> IndexChannel;
		property <LibMultifunctionCounterChannel, double, READ_WRITE> InputImpedance;
		property <LibMultifunctionCounterChannel, VTEXMultifunctionCounterInputModeEnum, READ_ONLY> InputMode;
		property <LibMultifunctionCounterChannel, VTEXMultifunctionCounterInputTypeEnum, READ_ONLY> InputType;
		property <LibMultifunctionCounterChannel, double, READ_WRITE> Level;
		property <LibMultifunctionCounterChannel, double, READ_WRITE> LowerFrequencyLimit;
		property <LibMultifunctionCounterChannel, VTEXMultifunctionCounterPolarityEnum, READ_WRITE> Polarity;
		property <LibMultifunctionCounterChannel, int32_t, READ_WRITE> PresetCount;
		property <LibMultifunctionCounterChannel, VTEXMultifunctionCounterQuadratureCountModeEnum, READ_WRITE> QuadratureCountMode;
		property <LibMultifunctionCounterChannel, VTEXString, READ_WRITE> ReferenceChannel;
		property <LibMultifunctionCounterChannel, double, READ_WRITE> Range;
		property <LibMultifunctionCounterChannel, int32_t, READ_WRITE> RpmToothCount;
		property <LibMultifunctionCounterChannel, VTEXMultifunctionCounterRpmToothStateEnum, READ_WRITE> RpmToothState;
		property <LibMultifunctionCounterChannel, VTEXMultifunctionCounterSlopeEnum, READ_WRITE> Slope;
		property <LibMultifunctionCounterChannel, double, READ_WRITE> UpperFrequencyLimit;


		virtual VTEXResult put_ApertureTime(double aperture_time)			 = 0;
		virtual VTEXResult get_ApertureTime(double* aperture_time)			 = 0;
		virtual VTEXResult put_AverageCount(int32_t average_count)			 = 0;
		virtual VTEXResult get_AverageCount(int32_t* average_count)			 = 0;
		virtual VTEXResult put_AverageMode(VTEXMultifunctionCounterAverageModeEnum average_mode)	= 0;
		virtual VTEXResult get_AverageMode(VTEXMultifunctionCounterAverageModeEnum* average_mode)	= 0;
		virtual VTEXResult put_AverageRepeat(bool average_repeat)	= 0;
		virtual VTEXResult get_AverageRepeat(bool* average_repeat)	= 0;
		virtual VTEXResult put_Coupling(VTEXMultifunctionCounterCouplingEnum couple)		= 0;
		virtual VTEXResult get_Coupling(VTEXMultifunctionCounterCouplingEnum* couple)		= 0;
		virtual VTEXResult put_Enabled(bool enable)							= 0;
		virtual VTEXResult get_Enabled(bool* enable)						= 0;
		virtual VTEXResult put_FifoEnabled(bool fifo_enable)							= 0;
		virtual VTEXResult get_FifoEnabled(bool* fifo_enable)						= 0;
		virtual VTEXResult put_Function(VTEXMultifunctionCounterFunctionEnum function)		    	= 0;
		virtual VTEXResult get_Function(VTEXMultifunctionCounterFunctionEnum* function)				= 0;
		virtual VTEXResult put_OverflowMode(VTEXMultifunctionCounterOverflowModeEnum overflow_mode)		= 0;
		virtual VTEXResult get_OverflowMode(VTEXMultifunctionCounterOverflowModeEnum* overflow_mode)	= 0;
		virtual VTEXResult put_Hysteresis(double hysteresis)			 = 0;
		virtual VTEXResult get_Hysteresis(double* hysteresis)			 = 0;
		virtual VTEXResult put_IndexChannel(const VTEXString& ch_index)	 = 0;
		virtual VTEXResult get_IndexChannel(VTEXString* ch_index)		 = 0;
		virtual VTEXResult put_InputImpedance(double impedance)			 = 0;
		virtual VTEXResult get_InputImpedance(double* impedance)		 = 0;
		virtual VTEXResult get_InputMode(VTEXMultifunctionCounterInputModeEnum* input_mode)		= 0;
		virtual VTEXResult get_InputType(VTEXMultifunctionCounterInputTypeEnum* input_type)		= 0;
		virtual VTEXResult put_Level(double level)					= 0;
		virtual VTEXResult get_Level(double* level)					= 0;
		virtual VTEXResult put_LowerFrequencyLimit(double lower_limit)				= 0;
		virtual VTEXResult get_LowerFrequencyLimit(double* lower_limit)			= 0;
		virtual VTEXResult put_Polarity(VTEXMultifunctionCounterPolarityEnum polarity)				= 0;
		virtual VTEXResult get_Polarity(VTEXMultifunctionCounterPolarityEnum* polarity)				= 0;
		virtual VTEXResult put_PresetCount(int32_t preset_Count)									= 0;
		virtual VTEXResult get_PresetCount(int32_t* preset_Count)									= 0;
		virtual VTEXResult put_QuadratureCountMode(VTEXMultifunctionCounterQuadratureCountModeEnum quadrature_count_mode) = 0;
		virtual VTEXResult get_QuadratureCountMode(VTEXMultifunctionCounterQuadratureCountModeEnum* quadrature_count_mode)= 0;
		virtual VTEXResult put_ReferenceChannel(const VTEXString& ch_reference)						= 0;
		virtual VTEXResult get_ReferenceChannel(VTEXString* ch_reference)							= 0;
		virtual VTEXResult put_Range(double range)					= 0;
		virtual VTEXResult get_Range(double* range)					= 0;
		virtual VTEXResult put_RpmToothCount(int32_t rpm_tooth_count)			= 0;
		virtual VTEXResult get_RpmToothCount(int32_t* rpm_tooth_count)			= 0;
		virtual VTEXResult put_RpmToothState(VTEXMultifunctionCounterRpmToothStateEnum rpm_tooth_state)		= 0;
		virtual VTEXResult get_RpmToothState(VTEXMultifunctionCounterRpmToothStateEnum* rpm_tooth_state)	= 0;
		virtual VTEXResult put_Slope(VTEXMultifunctionCounterSlopeEnum slope)					= 0;
		virtual VTEXResult get_Slope(VTEXMultifunctionCounterSlopeEnum* slope)					= 0;
		virtual VTEXResult put_UpperFrequencyLimit(double upper_limit)				= 0;
		virtual VTEXResult get_UpperFrequencyLimit(double* upper_limit)				= 0;

		virtual	VTEXResult ConfigureInput(bool Enabled, VTEXMultifunctionCounterInputTypeEnum InputType, 
								VTEXMultifunctionCounterInputModeEnum InputMode, 
								double Range, VTEXMultifunctionCounterCouplingEnum Coupling)							= 0;
		virtual	VTEXResult ConfigureRPM(int32_t ToothCount, VTEXMultifunctionCounterRpmToothStateEnum ToothState)		= 0;
		virtual	VTEXResult ConfigureThreshold(double Level, double Hysteresys, VTEXMultifunctionCounterSlopeEnum Slope)	= 0;
};

class VTEX_API LibMultifunctionDioChannels
{
	public:
		virtual ~LibMultifunctionDioChannels() {};

		property <LibMultifunctionDioChannels, int32_t, READ_ONLY> Count;
		arrayizer <LibMultifunctionDioChannels, LibMultifunctionDioChannel*, const std::string&> Item;
		arrayizer <LibMultifunctionDioChannels, std::string, int32_t> Name;
		
		virtual LibMultifunctionDioChannel * get_Item(const std::string& DioChannelName)    = 0;
		virtual std::string get_Name(int32_t Index)											= 0;
		virtual VTEXResult get_Count(int32_t* count)									    = 0;
};

class VTEX_API LibMultifunctionDacChannels
{
	public:
		virtual ~LibMultifunctionDacChannels() {};

		property <LibMultifunctionDacChannels, int32_t, READ_ONLY> Count;
		arrayizer <LibMultifunctionDacChannels, LibMultifunctionDacChannel*, const std::string&> Item;
		arrayizer <LibMultifunctionDacChannels, std::string, int32_t> Name;
		
		virtual LibMultifunctionDacChannel	* get_Item(const std::string& DacChannelName)	= 0;
		virtual std::string get_Name(int32_t Index)											= 0;
		virtual VTEXResult get_Count(int32_t* count)										= 0;
};

class VTEX_API LibMultifunctionCounterChannels
{	
	public:
		virtual ~LibMultifunctionCounterChannels() {};

        property <LibMultifunctionCounterChannels, int32_t, READ_ONLY> Count;
		arrayizer <LibMultifunctionCounterChannels, LibMultifunctionCounterChannel*, const std::string&> Item;
		arrayizer <LibMultifunctionCounterChannels, std::string, int32_t> Name;
		
		virtual LibMultifunctionCounterChannel *get_Item(const std::string& Name)	= 0;
		virtual std::string get_Name(int32_t Index)									= 0;
		virtual VTEXResult get_Count(int32_t* count)								= 0;
};

class VTEX_API LibMultifunctionDio
{
	public:
		virtual ~LibMultifunctionDio() {};

		LibMultifunctionDioChannels			*Channels;
		
		virtual VTEXResult Read(uint32_t *data)  = 0;        
		virtual VTEXResult Write(uint32_t data)  = 0;
};

class VTEX_API LibMultifunctionDac
{
	public:
		virtual ~LibMultifunctionDac() {};

		LibMultifunctionDacChannels			* Channels;
};

class VTEX_API LibMultifunctionCounter
{
	public:
		virtual ~LibMultifunctionCounter() {};

		LibMultifunctionCounterChannels		* Channels;
};

class VTEX_API LibMultifunctionMeasurement
{
	public:
		virtual ~LibMultifunctionMeasurement() {};

		property <LibMultifunctionMeasurement, int32_t, READ_ONLY> FifoCount;
		property <LibMultifunctionMeasurement, VTEXMultifunctionFifoOverflowModeEnum, READ_WRITE> FifoOverflowMode;
		property <LibMultifunctionMeasurement, VTEXMultifunctionMeasurementStateEnum, READ_ONLY> State;

		virtual VTEXResult put_FifoOverflowMode(VTEXMultifunctionFifoOverflowModeEnum overflow_mode)			= 0;
		virtual VTEXResult get_FifoOverflowMode(VTEXMultifunctionFifoOverflowModeEnum* overflow_mode)		    = 0;
		virtual VTEXResult get_FifoCount(int32_t* count)														= 0;
		virtual VTEXResult get_State(VTEXMultifunctionMeasurementStateEnum* state)								= 0;

		virtual VTEXResult Abort()			= 0;
		virtual VTEXResult ClearFifo()		= 0;
		virtual VTEXResult Initiate()		= 0;
		virtual VTEXResult ReadLatest(int32_t Timeout, std::vector<double>&Data, double *TimeSeconds, double *TimeFraction) = 0;
		virtual VTEXResult ReadFifo(int32_t Timeout, int32_t Scans, std::vector<double>&Data,
									std::vector<double>&TimeSeconds, std::vector<double>&TimeFraction)	= 0;
		virtual VTEXResult SendSoftwareTrigger()		= 0 ;
};

class VTEX_API LibMultifunctionTrigger
{
	public:
		virtual ~LibMultifunctionTrigger() {};

		property <LibMultifunctionTrigger, VTEXMultifunctionTriggerSourceEnum, READ_WRITE> Source;
		
		virtual VTEXResult put_Source(VTEXMultifunctionTriggerSourceEnum source)				= 0;
		virtual VTEXResult get_Source(VTEXMultifunctionTriggerSourceEnum* source)				= 0;
};

class VTEX_API LibMultifunctionPlatform
{
	public:
		virtual ~LibMultifunctionPlatform() {};

		property <LibMultifunctionPlatform, VTEXString, READ_ONLY> SerialNumber;

		virtual VTEXResult get_SerialNumber(VTEXString *serial)	= 0;
		virtual VTEXResult CloseLogFile()						= 0;
		virtual VTEXResult OpenLogFile(const VTEXString& fileName, const VTEXString& accessMode) = 0;
};

class VTEX_API LibMultifunctionCalibrationCounter
{
	public:
		virtual ~LibMultifunctionCalibrationCounter() {};

		property <LibMultifunctionCalibrationCounter, VTEXString, READ_ONLY> BackplaneConnectionChannel;
		property <LibMultifunctionCalibrationCounter, VTEXMultifunctionCalibrationCounterBackplaneConnectionItemEnum, READ_ONLY> BackplaneConnectionItem;
		property <LibMultifunctionCalibrationCounter, bool, READ_WRITE> BackplaneConnectionEnabled;

		virtual VTEXResult get_BackplaneConnectionChannel(VTEXString* channel)				 = 0;
		virtual VTEXResult get_BackplaneConnectionItem(VTEXMultifunctionCalibrationCounterBackplaneConnectionItemEnum* item) = 0;
		virtual VTEXResult put_BackplaneConnectionEnabled(bool enable)						 = 0;
		virtual VTEXResult get_BackplaneConnectionEnabled(bool* enable)						 = 0;

		virtual VTEXResult put_RawDacHi(VTEXString channel, int32_t data)		= 0;
		virtual VTEXResult get_RawDacHi(VTEXString channel, int32_t *data)		= 0;
		virtual VTEXResult put_RawDacLo(VTEXString channel, int32_t data)		= 0;
		virtual VTEXResult get_RawDacLo(VTEXString channel, int32_t *data)		= 0;
		
		virtual VTEXResult ConfigureBackplaneConnection (bool Enabled, VTEXString ChannelName, VTEXMultifunctionCalibrationCounterBackplaneConnectionItemEnum Item)	= 0;
};

class VTEX_API LibMultifunctionCalibrationDac
{
	public:
		virtual ~LibMultifunctionCalibrationDac() {};

		virtual	VTEXResult put_RawDac(VTEXString channel, int32_t data)		= 0;
		virtual VTEXResult get_RawDac(VTEXString channel, int32_t* data)	= 0;
};

class VTEX_API LibMultifunctionCalibration
{
	public:
		virtual ~LibMultifunctionCalibration() {};

		LibMultifunctionCalibrationCounter	*Counter;
		LibMultifunctionCalibrationDac		*Dac;

		property <LibMultifunctionCalibration, bool, READ_WRITE> Mode;

		virtual VTEXResult put_Mode(bool mode)			= 0;
		virtual VTEXResult get_Mode(bool* mode)			= 0;


		virtual VTEXResult Load(int32_t CalibrationSet)							= 0;
		virtual VTEXResult Save(int32_t CalibrationSet, int32_t Password)		= 0;
		virtual VTEXResult Read(VTEXString ChannelName, VTEXMultifunctionCalibrationConstantEnum Type, 
								double Range, double *Value)								= 0;
		virtual VTEXResult Write(VTEXString ChannelName, VTEXMultifunctionCalibrationConstantEnum Type, 
								 double Range, double Value)								= 0;
		virtual VTEXResult ReadFile(int32_t CalibrationSet, VTEXString &String)				= 0;
		virtual VTEXResult WriteFile(int32_t CalibrationSet, int32_t Password, VTEXString &data)		= 0;
};

class VTEX_API LibMultifunction : public LibInherent
{
	public:
		static LibMultifunction* Create();
		virtual ~LibMultifunction();
		
	    property <LibMultifunction, bool, READ_ONLY> Initialized;
		LibInherentCapabilityUtility			*Utility;
		LibInherentCapabilityDriverOperation	*DriverOperation;
		LibInherentCapabilityIdentity			*Identity;

		LibMultifunctionCounter		*Counter;
		LibMultifunctionDac			*Dac;
		LibMultifunctionDio			*Dio;
		LibMultifunctionMeasurement *Measurement;           
		LibMultifunctionTrigger		*Trigger;
		LibMultifunctionCalibration	*Calibration;
		LibMultifunctionPlatform	*Platform;
};

#endif
