//This example measures the Time interval between two sinewaves of �10 volts and �5 volts.
//This example can be also used for measuring Phase measurement
//Note that for finding the phase measurement and time interval measurement of continuous signal both the signal should be of same frequency

#include <stdio.h>
#ifndef _WIN32
#include <unistd.h>
#endif
#include <vector>
#include "libMultifunction.h"

int main(int argc, char* argv[])
{
    LibMultifunction* mfunction = NULL;

	try
	{
		//Create a new VTEXMultifunction object
        mfunction = LibMultifunction::Create();
	
		try
		{
			//Initialize a new session
            mfunction->Initialize("TCPIP::10.20.11.158::INSTR", true, true, "");
			//Differential measurement
            //This example uses AC coupling to cutoff offset voltage in the sinewave.
            //Analog channels Configuration
            mfunction->Counter->Channels->Item["CH1"]->ConfigureInput(true, VTEXMultifunctionCounterInputTypeAnalog,
                VTEXMultifunctionCounterInputModeDifferential, 48, VTEXMultifunctionCounterCouplingAC);
            //Setting reference channel configuration
            mfunction->Counter->Channels->Item["CH2"]->ConfigureInput(true, VTEXMultifunctionCounterInputTypeAnalog,
                VTEXMultifunctionCounterInputModeDifferential, 48, VTEXMultifunctionCounterCouplingAC);

            mfunction->Counter->Channels->Item["CH1"]->Function = VTEXMultifunctionCounterFunctionTimeInterval;
            //Time interval measurement setting
            /* You can also work with the following functions by changing the channel function
             * Phase measurement
             */
            //Set channel 2 as the reference channel
            mfunction->Counter->Channels->Item["CH1"]->ReferenceChannel = "CH2";
            //Reference channel can be used for any measurement even though it is used as the reference channel for channel 1 measurement.
            mfunction->Counter->Channels->Item["CH2"]->Function = VTEXMultifunctionCounterFunctionFrequency;
			
			//Enable Fifo for the channels
			mfunction->Counter->Channels->Item["CH1"]->FifoEnabled   = true;
			mfunction->Counter->Channels->Item["CH2"]->FifoEnabled   = true;
			
            //In case of Digital channel type, Level and Hysteresis settings are ignored. 
            //5V treshold for measuring the sine wave. Measure on  the Rising edges only. 
            mfunction->Counter->Channels->Item["CH1"]->ConfigureThreshold(0, 5, VTEXMultifunctionCounterSlopePositive);
            //2.5V treshold for measuring the sine wave. Note that this will affect only the Channel 2 frequency measurement only NOT Time interval measurement.The slope configuration will NOT have any effect.
            mfunction->Counter->Channels->Item["CH2"]->ConfigureThreshold(0, 2.5, VTEXMultifunctionCounterSlopeNegative);
            
            //This measures the frequency between 1000Hz and 1Hz. Both the channel's input signal frequency should be same
            mfunction->Counter->Channels->Item["CH1"]->UpperFrequencyLimit = 1000;  //Maximum frequency of 1000Hz
            mfunction->Counter->Channels->Item["CH1"]->LowerFrequencyLimit = 1;     //Lower frequency of 1Hz
            mfunction->Counter->Channels->Item["CH2"]->UpperFrequencyLimit = 1000;  //Maximum frequency of 1000Hz
            mfunction->Counter->Channels->Item["CH2"]->LowerFrequencyLimit = 0.5;     //Lower frequency of 0.5Hz

            //Aperture time of 2 seconds. It averages the timeinterval for 2 seconds
            mfunction->Counter->Channels->Item["CH1"]->AverageMode = VTEXMultifunctionCounterAverageModeApertureTime;
            mfunction->Counter->Channels->Item["CH1"]->ApertureTime = 2;        //aperature time in seconds

            //Aperture time of 1 senconds. It averages the frequency for 1 second
            mfunction->Counter->Channels->Item["CH2"]->AverageMode = VTEXMultifunctionCounterAverageModeApertureTime;
            mfunction->Counter->Channels->Item["CH2"]->ApertureTime = 1;        //aperature time in seconds
                    
             mfunction->Trigger->Source = VTEXMultifunctionTriggerSourceImmediate;
                    
             //Start measurement
			 mfunction->Measurement->Abort();
             mfunction->Measurement->Initiate();
             int fifocount, loopcount = 0;
             do
             {   
                  //Take measurement for 10 times.
                  fifocount = mfunction->Measurement->FifoCount;
                  sleep(1);
				  if(loopcount > 10)
				  {
					  printf("Expected Fifo count (10) is not Available, Exiting loop\n");
					  break;
				  }
				  loopcount++;
             } while (fifocount < 10);

			 printf("Fifo Count = %d\n",fifocount);
			 if(fifocount <= 0)
			 {  //Exiting function when no data available
			 	printf("No Fifo data, Exiting function...\n");
			 	return 0;
			 }
             //No. of enabled channels(here it is two. Channel 1 and channel 2)
             int no_of_channels_enabled = 2;
             /*For each trigger all channels data will be stored. In our case 2 channels is enabled and 10 readings are taken. 
               So we will get 20 data points in the data array*/
			 std::vector<double> data;
			 std::vector<double> time;
			 std::vector<double> time_fraction;

             //Read the measurements
             mfunction->Measurement->ReadFifo(0, fifocount, data, time, time_fraction);
             for (long scan = 0; scan<fifocount; scan++)
             {
                 fprintf(stderr, "@Time = %f\n", time.at(scan) + time_fraction.at(scan));
                 for (int channel = 0; channel < no_of_channels_enabled; channel++)
                 {
                      fprintf(stderr, "Channel  = %d, %s = %f\n", channel+1, (channel==0)?"Time interval":"Frequency", data.at(scan * no_of_channels_enabled + channel));
					  //Channel 1 is measuring time interval and channel 2 is measuring Frequency
                 }

             }
             //Abort the measurement.
             mfunction->Measurement->Abort();

		}
		catch (VTEXException e)
		{
			printf("Error code: %d\n", (unsigned int)e.errorCode);
			printf("Error message: %s\n", e.errorMessage.c_str());
		}

		if (mfunction != NULL && mfunction->Initialized)
		{
			// Close driver
			mfunction->Close();
			delete(mfunction);
		}
	}
	catch (VTEXException e)
	{
        printf("Error code: %d\n", (unsigned int)e.errorCode);
        printf("Error message: %s\n", e.errorMessage.c_str());
	}

	printf("\nDone - Press Enter to Exit");
    getchar();

	return 0;
}

