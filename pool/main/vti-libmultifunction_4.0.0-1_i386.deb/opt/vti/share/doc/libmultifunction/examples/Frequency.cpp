// Program.cpp : Defines the entry point for the console application.

#include <stdio.h>
#include <vector>
#ifndef _WIN32
#include <unistd.h>
#endif
#include "libMultifunction.h"

//This example measures the frequency of a sinewave �10 volts and a TTL digital signal.
int main(int argc, char* argv[])
{
    LibMultifunction* mfunction = NULL;

	try
	{
		//Create a new VTEXMultifunction object
        mfunction = LibMultifunction::Create();
	
		try
		{
	
			//Initialize a new session
            mfunction->Initialize("TCPIP::10.30.1.43::INSTR", true, true, "");
                    
                    
            //measuring frequency in a anaglog channel
            //Differential measurement
            //This example uses AC coupling to cutoff offset voltage in the sinewave.
            //Analog channels Configuration
            mfunction->Counter->Channels->Item["CH1"]->ConfigureInput(true, 
                        VTEXMultifunctionCounterInputTypeAnalog,
                        VTEXMultifunctionCounterInputModeDifferential, 
                        48, VTEXMultifunctionCounterCouplingAC);

            //5V�1V treshold for measuring the sine wave. 
            mfunction->Counter->Channels->Item["CH1"]->Function = VTEXMultifunctionCounterFunctionFrequency;
            //Frequency measurement setting
            /* You can also work with the following functions by changing the channel function
             * VTEXMultifunctionCounterFunctionFrequency
             * VTEXMultifunctionCounterFunctionPulseWidth
             * VTEXMultifunctionCounterFunctionDutyCycle
             * VTEXMultifunctionCounterFunctionPeriod
             */
             mfunction->Counter->Channels->Item["CH1"]->ConfigureThreshold(0, 4, VTEXMultifunctionCounterSlopePositive);
             //Measure on all the falling edges by inversing the polarity.
             mfunction->Counter->Channels->Item["CH1"]->Polarity = VTEXMultifunctionCounterPolarityInverse;
             //This measures the frequency between 1000Hz and 1Hz.
             mfunction->Counter->Channels->Item["CH1"]->UpperFrequencyLimit = 1000;  //Maximum frequency of 1000Hz
             mfunction->Counter->Channels->Item["CH1"]->LowerFrequencyLimit = 1;     //Lower frequency of 1Hz

                    
             //Aperture time of 2 senconds, since the minimum frequency to be measures is 1Hz i.e 1second period. It averages the frequency of the signal for timespan of 2seconds 
             mfunction->Counter->Channels->Item["CH1"]->AverageMode = VTEXMultifunctionCounterAverageModeApertureTime;
             mfunction->Counter->Channels->Item["CH1"]->ApertureTime = 1;        //aperature time in seconds
                  
			 //Enable Fifo for the channels
			 mfunction->Counter->Channels->Item["CH1"]->FifoEnabled   = true;
             //measuring frequency in a Digital channel
             //Only single measurement possible with EX1200 - 1538
             //EX1200-1538 has only TTL logic for Digital channels. So range setting is ignored.

                        
             //Digital channels configuration
             mfunction->Counter->Channels->Item["CH2"]->ConfigureInput(true, 
                        VTEXMultifunctionCounterInputTypeDigital,
                        VTEXMultifunctionCounterInputModeSingleEnded, 
                        0, VTEXMultifunctionCounterCouplingDC);

             //Frequency measurement setting
             mfunction->Counter->Channels->Item["CH2"]->Function = VTEXMultifunctionCounterFunctionFrequency;
             //Frequency measurement setting
             /* You can also work with the following functions by changing the channel function
              * VTEXMultifunctionCounterFunctionFrequency
              * VTEXMultifunctionCounterFunctionPulseWidth
              * VTEXMultifunctionCounterFunctionDutyCycle
              * VTEXMultifunctionCounterFunctionPeriod
              */

             // Threshold limits setting for Digital signal measurements are not required

             //This measures the frequency between 5000Hz and 1Hz.
             mfunction->Counter->Channels->Item["CH2"]->UpperFrequencyLimit = 5000;  //Maximum frequency of 5000Hz
             mfunction->Counter->Channels->Item["CH2"]->LowerFrequencyLimit = 0.5;     //Lower frequency of 0.5Hz

             //Measure on all the Rising edges
             mfunction->Counter->Channels->Item["CH2"]->Polarity = VTEXMultifunctionCounterPolarityInverse;

             //Aperture time of 10 seconds, say the minimum frequency to be measures is 1Hz i.e 1second period. This setting averages the measured frequency for timespan of 10seconds 
             mfunction->Counter->Channels->Item["CH2"]->AverageMode = VTEXMultifunctionCounterAverageModeApertureTime;
			 mfunction->Counter->Channels->Item["CH2"]->ApertureTime = 1.2;        //aperature time in seconds
			 //Enable Fifo for the channels
			 mfunction->Counter->Channels->Item["CH2"]->FifoEnabled   = true;

             mfunction->Trigger->Source = VTEXMultifunctionTriggerSourceImmediate;
                    
             //Start measurement
             mfunction->Measurement->Initiate();
             int fifocount,loopcount = 0;
             do
             {   
                  //Take measurement for 10 times.
				  //The trigger mode is set to "immediate", which expects user to input 
				  //data from the front panel.
				  //Unless data is available, Fifo count will not increase 
                  fifocount = mfunction->Measurement->FifoCount;
                  sleep(1);
				  if(loopcount > 10)
				  {
					  printf("Expected Fifo count (10) is not Available, Exiting loop\n");
					  break;
				  }
				  loopcount++;
             } while (fifocount < 10);
			 
			 printf("Fifo Count = %d\n",fifocount);
			 if(fifocount <= 0)
			 {  //Exiting function when no data available
			 	printf("No Fifo data, Exiting function...\n");
			 	return 0;
			 }

             //No. of enabled channels(here it is two. Channel 1 and channel 2)
             int no_of_channels_enabled = 2;
             /*For each trigger all channels data will be stored. In our case 2 channels is enabled and 10 readings are taken. 
               So we will get 20 data points in the data array*/
			 std::vector<double> data;
			 std::vector<double> time;
			 std::vector<double> time_fraction;

             //Read the measurements
             mfunction->Measurement->ReadFifo(0, fifocount, data, time, time_fraction);
             for (long scan = 0; scan<fifocount; scan++)
             {
                 fprintf(stderr, "@Time = %f\n", time.at(scan) + time_fraction.at(scan));
                 for (int channel = 0; channel < no_of_channels_enabled; channel++)
                 {
                      fprintf(stderr, "Channel  = %d, Frequency = %f\n", channel+1, data.at(scan * no_of_channels_enabled + channel));
                 }

             }
             //Abort the measurement.
             mfunction->Measurement->Abort();

		}
		catch (VTEXException e)
		{
			printf("Error code: %d\n", (unsigned int)e.errorCode);
			printf("Error message: %s\n", e.errorMessage.c_str());
		}

		if (mfunction != NULL && mfunction->Initialized)
		{
			// Close driver
			mfunction->Close();
			delete(mfunction);
		}
	}
	catch (VTEXException e)
	{
        printf("Error code: %d\n", (unsigned int)e.errorCode);
        printf("Error message: %s\n", e.errorMessage.c_str());
	}

	printf("\nDone - Press Enter to Exit");
    getchar();

	return 0;
}
