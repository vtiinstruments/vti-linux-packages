//This example measures the totalize of a sinewave �19 volts and a TTL digital signal.
//This example can be also used for measuring edge count

#include <stdio.h>
#ifndef _WIN32
#include <unistd.h>
#endif
#include <vector>
#include "libMultifunction.h"

int main(int argc, char* argv[])
{
    LibMultifunction* mfunction = NULL;

	try
	{
		//Create a new VTEXMultifunction object
        mfunction = LibMultifunction::Create();
	
		try
		{
			//Initialize a new session
            mfunction->Initialize("TCPIP::10.20.11.158::INSTR", true, true, "");
			//Differential measurement
            //This example uses AC coupling to cutoff offset voltage in the sinewave.
            //Analog channels Configuration
            mfunction->Counter->Channels->Item["CH2"]->ConfigureInput(true, VTEXMultifunctionCounterInputTypeAnalog,
                VTEXMultifunctionCounterInputModeDifferential, 48, VTEXMultifunctionCounterCouplingAC);

            
            mfunction->Counter->Channels->Item["CH2"]->Function = VTEXMultifunctionCounterFunctionTotalize;
            //Totalize measurement setting
            /* You can also work with the following functions by changing the channel function
             * VTEXMultifunctionCounterFunctionEdgeCount
             */

            //�5V hysteresis for measuring the sine wave. 
            mfunction->Counter->Channels->Item["CH2"]->ConfigureThreshold(0, 5, VTEXMultifunctionCounterSlopePositive);
            //Polarity setting will NOT have any effet on totalize measurement, since it counts both the rising and falling edges. 
            //But in case of Edgecount measurement, normal polarity will count rising edges and inverse polarity will count falling edges.
            mfunction->Counter->Channels->Item["CH2"]->Polarity = VTEXMultifunctionCounterPolarityNormal;
            //This measures the frequency between 5000Hz and 1Hz.
            mfunction->Counter->Channels->Item["CH2"]->UpperFrequencyLimit = 5000;  //Maximum frequency of 5000Hz
            mfunction->Counter->Channels->Item["CH2"]->LowerFrequencyLimit = 1;     //Lower frequency of 1Hz
			//Enable Fifo for the channels
			mfunction->Counter->Channels->Item["CH2"]->FifoEnabled   = true;
            //Aperature time setting is not required for Edge count and totalize measurement. This setting will NOT have any effect on totalize and edge count measurements.

            //measuring frequency in a Digital channel
            //Only single measurement possible with EX1200 - 1538
            //EX1200-1538 has only TTL logic for Digital channels. So range setting is ignored.


            //Digital channels configuration
            mfunction->Counter->Channels->Item["CH3"]->ConfigureInput(true, VTEXMultifunctionCounterInputTypeDigital,
                VTEXMultifunctionCounterInputModeSingleEnded, 0, VTEXMultifunctionCounterCouplingDC);

            
            mfunction->Counter->Channels->Item["CH3"]->Function = VTEXMultifunctionCounterFunctionTotalize;
            //Totalize measurement setting
            /* You can also work with the following functions by changing the channel function
             * VTEXMultifunctionCounterFunctionEdgeCount
             */

            // Threshold limits setting for Digital signal measurements are not required.

            //This measures the frequency between 2000Hz and 2Hz.
            mfunction->Counter->Channels->Item["CH3"]->UpperFrequencyLimit = 2000;  //Maximum frequency of 2000Hz
            mfunction->Counter->Channels->Item["CH3"]->LowerFrequencyLimit = 0.5;     //Lower frequency of 0.5Hz


            //Polarity setting will NOT have any effet on totalize measurement, since it counts both the rising and falling edges. 
            //But in case of Edgecount measurement, normal polarity will count rising edges and inverse polarity will count falling edges.
            //Alternatively Slope can also be used for the measurement
            mfunction->Counter->Channels->Item["CH3"]->Polarity = VTEXMultifunctionCounterPolarityInverse;

			//Enable Fifo for the channels
			mfunction->Counter->Channels->Item["CH3"]->FifoEnabled   = true;
            //Aperature time setting is not required for Edge count and totalize measurement.This setting will NOT have any effect on totalize and edge count measurements.

            //Here we are using software trigger. Using immediate trigger will store the value for every edge.
            //Since we need the count say after 2 seconds we are using software trigger
            mfunction->Trigger->Source = VTEXMultifunctionTriggerSourceSoftware;
                    
             //Start measurement
             mfunction->Measurement->Initiate();
             int fifocount = 0;
             do
             {   
				//Wait for 2 seconds for collecting no. of edges(rising and falling).
				printf("Waiting for 2 seconds");
				sleep(2);
				printf("sending software trigger");
				//send a software trigger for transferring data to get a snap short of totalize count
				mfunction->Measurement->SendSoftwareTrigger();
				fifocount = mfunction->Measurement->FifoCount;
             } while (fifocount < 10);
	
			 printf("Fifo Count = %d\n",fifocount);
             //No. of enabled channels(here it is two. Channel 1 and channel 2)
             int no_of_channels_enabled = 2;
             /*For each trigger all channels data will be stored. In our case 2 channels is enabled and 10 readings are taken. 
               So we will get 20 data points in the data array*/
			 std::vector<double> data;
			 std::vector<double> time;
			 std::vector<double> time_fraction;

             //Read the measurements
             mfunction->Measurement->ReadFifo(0, fifocount, data, time, time_fraction);
             for (long scan = 0; scan<fifocount; scan++)
             {
                 fprintf(stderr, "@Time = %f\n", time.at(scan) + time_fraction.at(scan));
                 for (int channel = 0; channel < no_of_channels_enabled; channel++)
                 {
                      fprintf(stderr, "Channel  = %d, Totalize = %f\n", channel+1, data.at(scan * no_of_channels_enabled + channel));
					  //Channel 1 is measuring time interval and channel 2 is measuring Frequency
                 }

             }
             //Abort the measurement.
             mfunction->Measurement->Abort();

		}
		catch (VTEXException e)
		{
			printf("Error code: %d\n", (unsigned int)e.errorCode);
			printf("Error message: %s\n", e.errorMessage.c_str());
		}

		if (mfunction != NULL && mfunction->Initialized)
		{
			// Close driver
			mfunction->Close();
			delete(mfunction);
		}
	}
	catch (VTEXException e)
	{
		printf("Error code: %d\n", (unsigned int)e.errorCode);
		printf("Error message: %s\n", e.errorMessage.c_str());
	}

	printf("\nDone - Press Enter to Exit");
    getchar();

	return 0;
}
