//This example measures the RPM and shaft position(quadrature measurement) using TTL quadrature encoders

#include <stdio.h>
#ifndef _WIN32
#include <unistd.h>
#endif
#include <vector>
#include "libMultifunction.h"

int main(int argc, char* argv[])
{
    LibMultifunction* mfunction = NULL;

	try
	{
		//Create a new VTEXMultifunction object
        mfunction = LibMultifunction::Create();
	
		try
		{
			//Initialize a new session
            mfunction->Initialize("TCPIP::10.20.11.158::INSTR", true, true, "");
                    
            //Channel configuration. Note that coupling will NOT have any effect on Digital inputs
				mfunction->Counter->Channels->Item["CH1"]->ConfigureInput(true, VTEXMultifunctionCounterInputTypeDigital,
				VTEXMultifunctionCounterInputModeSingleEnded, 0, VTEXMultifunctionCounterCouplingDC);

            //Quadrature measurement setting
            mfunction->Counter->Channels->Item["CH1"]->Function = VTEXMultifunctionCounterFunctionQuadrature;

            // Threshold limits setting for Digital signal measurements are not required

            //This measures the frequency between 10000Hz and 1Hz.
            mfunction->Counter->Channels->Item["CH1"]->UpperFrequencyLimit = 10000;  //Maximum frequency of 10000Hz
            mfunction->Counter->Channels->Item["CH1"]->LowerFrequencyLimit = 1;     //Lower frequency of 1Hz


            //Aperture time of 1 seconds. This setting averages the measured frequency for timespan of 10seconds 
            mfunction->Counter->Channels->Item["CH1"]->AverageMode = VTEXMultifunctionCounterAverageModeApertureTime;
            mfunction->Counter->Channels->Item["CH1"]->ApertureTime = 1;        //aperature time in seconds

            //Set Channel 2 as the reference channel[B signal of quadrature endcoder]. Channel 1 is for A signal
            mfunction->Counter->Channels->Item["CH1"]->ReferenceChannel = "CH2";
            
            //Using 1st index channel. Note that this refers to Index channel name not measurement channel name.
            mfunction->Counter->Channels->Item["CH1"]->IndexChannel = "CH1";

            mfunction->Counter->Channels->Item["CH2"]->ConfigureInput(true, VTEXMultifunctionCounterInputTypeDigital,
                VTEXMultifunctionCounterInputModeSingleEnded, 0, VTEXMultifunctionCounterCouplingDC);

            mfunction->Counter->Channels->Item["CH2"]->Function = VTEXMultifunctionCounterFunctionRpm;
			//Enable Fifo for the channels
			mfunction->Counter->Channels->Item["CH1"]->FifoEnabled   = true;
			mfunction->Counter->Channels->Item["CH2"]->FifoEnabled   = true;
            //This setting determines the no. of pulses for each revolution. In our case it is 32, So 32 pulses makes one full revolution
            mfunction->Counter->Channels->Item["CH2"]->RpmToothCount = 32;
            //No missing count would be added or subtracted from actual count
            mfunction->Counter->Channels->Item["CH2"]->RpmToothState = VTEXMultifunctionCounterRpmToothStateNormal;

            //Aperture time of 1 sencond. It averages the RPM for timespan for every second.
            mfunction->Counter->Channels->Item["CH2"]->AverageMode = VTEXMultifunctionCounterAverageModeApertureTime;
            mfunction->Counter->Channels->Item["CH2"]->ApertureTime = 1;        //aperature time in seconds

            mfunction->Trigger->Source = VTEXMultifunctionTriggerSourceSoftware;
                    
             //Start measurement
             mfunction->Measurement->Initiate();
             int fifocount = 0;
             do
             {   
				//Wait for 2 seconds for collecting no. of edges(rising and falling).
				sleep(2);
				printf("sending software trigger\n");
				//send a software trigger for transferring data to get a snap short of totalize count
				mfunction->Measurement->SendSoftwareTrigger();
				fifocount = mfunction->Measurement->FifoCount;
             } while (fifocount < 10);
			
			 printf("Fifo Count = %d\n",fifocount);
             //No. of enabled channels(here it is two. Channel 1 and channel 2)
             int no_of_channels_enabled = 2;
             /*For each trigger all channels data will be stored. In our case 2 channels is enabled and 10 readings are taken. 
               So we will get 20 data points in the data array*/
			 std::vector<double> data;
			 std::vector<double> time;
			 std::vector<double> time_fraction;

			 //Read the measurements
             mfunction->Measurement->ReadFifo(0, fifocount, data, time, time_fraction);
             for (long scan = 0; scan<fifocount; scan++)
             {
                 fprintf(stderr, "@Time = %f\n", time.at(scan) + time_fraction.at(scan));
                 for (int channel = 0; channel < no_of_channels_enabled; channel++)
                 {
                      fprintf(stderr, "Channel  = %d, %s = %f\n", channel+1,(channel==0)? "Pulse count":"RPM", data.at(scan * no_of_channels_enabled + channel));
                 }

             }
             //Abort the measurement.
             mfunction->Measurement->Abort();

		}
		catch (VTEXException e)
		{
			printf("Error code: %d\n", (unsigned int)e.errorCode);
			printf("Error message: %s\n", e.errorMessage.c_str());
		}

		if (mfunction != NULL && mfunction->Initialized)
		{
			// Close driver
			mfunction->Close();
			delete(mfunction);
		}
	}
	catch (VTEXException e)
	{
		printf("Error code: %d\n", (unsigned int)e.errorCode);
		printf("Error message: %s\n", e.errorMessage.c_str());
	}

	printf("\nDone - Press Enter to Exit");
    getchar();

	return 0;
}


