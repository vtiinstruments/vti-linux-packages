//This example measures the RPM using an encoder or syncro resolver(less voltage type)

#include <stdio.h>
#ifndef _WIN32
#include <unistd.h>
#endif
#include <vector>
#include "libMultifunction.h"

int main(int argc, char* argv[])
{
    LibMultifunction* mfunction = NULL;

	try
	{
		//Create a new VTEXMultifunction object
        mfunction = LibMultifunction::Create();
	
		try
		{
			//Initialize a new session
            mfunction->Initialize("TCPIP::10.20.11.158::INSTR", true, true, "");
            
            //Differential measurement
            //This example uses AC coupling to cutoff offset voltage in the sinewave.
            //Analog channels Configuration
			mfunction->Counter->Channels->Item["CH1"]->ConfigureInput(true, VTEXMultifunctionCounterInputTypeAnalog, 
				VTEXMultifunctionCounterInputModeDifferential, 48, VTEXMultifunctionCounterCouplingAC);

	        
			mfunction->Counter->Channels->Item["CH1"]->Function = VTEXMultifunctionCounterFunctionRpm;
	        
			//5V treshold for measuring the sine wave. Note that slope configuration will NOT have any effect.
			mfunction->Counter->Channels->Item["CH1"]->ConfigureThreshold(0, 5, VTEXMultifunctionCounterSlopePositive);
			//Enable Fifo for the channel
			mfunction->Counter->Channels->Item["CH1"]->FifoEnabled   = true;
	       
			//This measures the frequency between 10000Hz and 1Hz.
			mfunction->Counter->Channels->Item["CH1"]->UpperFrequencyLimit = 10000;  //Maximum frequency of 10000Hz
			mfunction->Counter->Channels->Item["CH1"]->LowerFrequencyLimit = 1;     //Lower frequency of 1Hz

			//This setting determines the no. of pulses for each revolution. In our case it is 32, So 32 pulses makes one full revolution
			mfunction->Counter->Channels->Item["CH1"]->RpmToothCount = 32;
			//No missing count would be added or subtracted from actual count
			mfunction->Counter->Channels->Item["CH1"]->RpmToothState = VTEXMultifunctionCounterRpmToothStateNormal;

			//Aperture time of 1 sencond. It averages the RPM for timespan for every second.
			mfunction->Counter->Channels->Item["CH1"]->AverageMode = VTEXMultifunctionCounterAverageModeApertureTime;
			mfunction->Counter->Channels->Item["CH1"]->ApertureTime = 1;        //aperature time in seconds

			//measuring frequency in a Digital channel
			//Only single measurement possible with EX1200 - 1538
			//EX1200-1538 has only TTL logic for Digital channels. So range setting is ignored.


			//Digital channels configuration. Coupling setting is ignored for Digital channel. Only DC coupling  is possible for Digital channel.
			mfunction->Counter->Channels->Item["CH2"]->ConfigureInput(true, VTEXMultifunctionCounterInputTypeDigital,
				VTEXMultifunctionCounterInputModeSingleEnded, 0, VTEXMultifunctionCounterCouplingDC);

			//RPM measurement setting
			mfunction->Counter->Channels->Item["CH2"]->Function = VTEXMultifunctionCounterFunctionRpm;

			// Threshold limits setting for Digital signal measurements are not required

			//This measures the frequency between 10000Hz and 1Hz.
			mfunction->Counter->Channels->Item["CH2"]->UpperFrequencyLimit = 10000;  //Maximum frequency of 10000Hz
			mfunction->Counter->Channels->Item["CH2"]->LowerFrequencyLimit = 0.5;     //Lower frequency of 0.5Hz

			//This setting determines the no. of pulses for each revolution. In our case it is 32, So 32 pulses makes one full revolution
			mfunction->Counter->Channels->Item["CH2"]->RpmToothCount = 32;
			//No missing count would be added or subtracted from actual count
			mfunction->Counter->Channels->Item["CH2"]->RpmToothState = VTEXMultifunctionCounterRpmToothStateNormal;
			//Aperture time of 1 sencond. It averages the RPM for timespan for every second.
			mfunction->Counter->Channels->Item["CH2"]->AverageMode = VTEXMultifunctionCounterAverageModeApertureTime;
			mfunction->Counter->Channels->Item["CH2"]->ApertureTime = 1;        //aperature time in seconds

			//Enable Fifo for the channel
			mfunction->Counter->Channels->Item["CH2"]->FifoEnabled   = true;
             mfunction->Trigger->Source = VTEXMultifunctionTriggerSourceImmediate;
                    
             //Start measurement
             mfunction->Measurement->Initiate();
             int fifocount,loopcount = 0;
             do
             {   
                  //Take measurement for 10 times.
                  fifocount = mfunction->Measurement->FifoCount;
                  sleep(1);
				  if(loopcount > 10)
				  {
					  printf("Expected Fifo count (10) is not Available, Exiting loop\n");
					  break;
				  }
				  loopcount++;
             } while (fifocount < 10);

			 printf("Fifo Count = %d\n",fifocount);
			 if(fifocount <= 0)
			 {	//Exiting function when no data available
			 	printf("No Fifo data, Exiting function...\n");
			 	return 0;
			 }
             //No. of enabled channels(here it is two. Channel 1 and channel 2)
             int no_of_channels_enabled = 2;
             /*For each trigger all channels data will be stored. In our case 2 channels is enabled and 10 readings are taken. 
               So we will get 20 data points in the data array*/
			 std::vector<double> data;
			 std::vector<double> time;
			 std::vector<double> time_fraction;

			 //Read the measurements
             mfunction->Measurement->ReadFifo(0, fifocount, data, time, time_fraction);
             for (long scan = 0; scan<fifocount; scan++)
             {
                 fprintf(stderr, "@Time = %f\n", time.at(scan) + time_fraction.at(scan));
                 for (int channel = 0; channel < no_of_channels_enabled; channel++)
                 {
                      fprintf(stderr, "Channel  = %d, RPM = %f\n", channel+1, data.at(scan * no_of_channels_enabled + channel));
                 }

             }
             //Abort the measurement.
             mfunction->Measurement->Abort();

		}
		catch (VTEXException e)
		{
			printf("Error code: %d\n", (unsigned int)e.errorCode);
			printf("Error message: %s\n", e.errorMessage.c_str());
		}

		if (mfunction != NULL && mfunction->Initialized)
		{
			// Close driver
			mfunction->Close();
			delete(mfunction);
		}
	}
	catch (VTEXException e)
	{
        printf("Error code: %d\n", (unsigned int)e.errorCode);
        printf("Error message: %s\n", e.errorMessage.c_str());
	}

	printf("\nDone - Press Enter to Exit");
    getchar();

	return 0;
}
