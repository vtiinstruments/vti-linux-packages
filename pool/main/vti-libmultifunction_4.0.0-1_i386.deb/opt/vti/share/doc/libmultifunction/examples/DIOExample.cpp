//This example explains how to use Digital inputs and outputs

#include <stdio.h>
#include "libMultifunction.h"

int main(int argc, char* argv[])
{
    LibMultifunction* mfunction = NULL;

	try
	{
		//Create a new VTEXMultifunction object
        mfunction = LibMultifunction::Create();
	
		try
		{
			//Initialize a new session
            mfunction->Initialize("TCPIP::10.20.11.158::INSTR", true, true, "");                   
			//Any channel can be configured for voltage or current

					//Any channel can be configured as input or output
                    //Digital input configuration
                    mfunction->Dio->Channels->Item["DIO1"]->Direction = VTEXMultifunctionDioDirectionInput;//Digital input operation
                    mfunction->Dio->Channels->Item["DIO1"]->Polarity = VTEXMultifunctionDioPolarityNormal;// Data will be read without inverting
					printf("Channel 1: %s",(mfunction->Dio->Channels->Item["DIO1"]->Data)?"TRUE":"FALSE");

                    //Digital Output configuration
                    mfunction->Dio->Channels->Item["DIO2"]->Direction = VTEXMultifunctionDioDirectionOutput;//Digital Output operation
                    mfunction->Dio->Channels->Item["DIO2"]->Polarity = VTEXMultifunctionDioPolarityInverse;// Data will be inverted before writing
					mfunction->Dio->Channels->Item["DIO2"]->Data = false; //This will write the data as true, since this channel is being inverted   
		}
		catch (VTEXException e)
		{
			printf("Error code: %d\n", (unsigned int)e.errorCode);
			printf("Error message: %s\n", e.errorMessage.c_str());
			//Put code here to catch any test code errors
		}

		if (mfunction != NULL && mfunction->Initialized)
		{
			// Close driver
			mfunction->Close();
			delete(mfunction);
		}
	}
	catch (VTEXException e)
	{
		printf("Error code: %d\n", (unsigned int)e.errorCode);
		printf("Error message: %s\n", e.errorMessage.c_str());
	}

	printf("\nDone - Press Enter to Exit");
    getchar();

	return 0;
}
