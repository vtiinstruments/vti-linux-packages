//This example explains how to program voltage and current output using Multifunction DAC

#include <stdio.h>
#include <iostream>
#include "libMultifunction.h"

using namespace std;
int main(int argc, char* argv[])
{
    LibMultifunction* mfunction = NULL;

	try
	{
		//Create a new VTEXMultifunction object
        mfunction = LibMultifunction::Create();
	
		try
		{
			//Initialize a new session
			mfunction->Initialize("TCPIP::10.30.1.28::INSTR", true, true,"");
			//Any channel can be configured for voltage or current
			mfunction->Dac->Channels->Item["DAC1"]->DriveMode = VTEXMultifunctionDacDriveModeVoltage;
			mfunction->Dac->Channels->Item["DAC1"]->Voltage = 2;//Voltage in volts
			mfunction->Dac->Channels->Item["DAC1"]->Enabled = true;//Start giving out the voltage
			
			cout<<mfunction->Dac->Channels->Item["DAC1"]->DriveMode<<endl;
			cout<<mfunction->Dac->Channels->Item["DAC1"]->Voltage<<endl;
			cout<<mfunction->Dac->Channels->Item["DAC1"]->Enabled<<endl;

			mfunction->Dac->Channels->Item["DAC2"]->DriveMode = VTEXMultifunctionDacDriveModeCurrent;
			mfunction->Dac->Channels->Item["DAC2"]->Current = 0.01;//Current in Amperes
			mfunction->Dac->Channels->Item["DAC2"]->Enabled = true;//Start giving out the voltage      
		}
		catch (VTEXException e)
		{
			printf("Error code: %d\n", (unsigned int)e.errorCode);
			printf("Error message: %s\n", e.errorMessage.c_str());
			//Put code here to catch any test code errors
		}

		if (mfunction != NULL && mfunction->Initialized)
		{
			// Close driver
			mfunction->Close();
			delete(mfunction);
		}
	}
	catch (VTEXException e)
	{
        printf("Error code: %d\n", (unsigned int)e.errorCode);
        printf("Error message: %s\n", e.errorMessage.c_str());
	}

	printf("\nDone - Press Enter to Exit");
    getchar();

	return 0;
}

