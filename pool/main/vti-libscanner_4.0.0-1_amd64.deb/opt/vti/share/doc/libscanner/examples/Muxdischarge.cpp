#include "libScanner.h"
#include <stdio.h>

int main()
{
	//Create a VTEXScanner pointer
	LibScanner *pScanner;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created scanner pointer
		pScanner = LibScanner::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pScanner->Initialize("TCPIP::10.20.5.160::INSTR",true,true,"");

			//First setup the Dmm and save the setting as a configuration
            pScanner->Dmm->Configuration->DeleteAll(); //Clear all configs from permanent storage
            pScanner->Dmm->Function = VTEXScannerDmmFunctionDCVolts;
            pScanner->Dmm->Range = 300.0; //10 Volt Range. AutoRange is slow, so we specify one
            pScanner->Dmm->Resolution = 10000.0; //This reduces us to the fewest digits of accuracy
            pScanner->Dmm->Trigger->Delay = 0; //Delays of 0 mean faster sampling
            pScanner->Dmm->Advanced->AutoZero = VTEXScannerDmmAutoZeroOff; //AutoZero is slow as well
            pScanner->Dmm->Configuration->Save("DCV"); //We can name these anything we want

			/* Let�s say I have a 300V signal being fed into CH1_1, and a 0.0001V signal being fed 
			into CH1_2. I may want to discharge the backplane lines before I measure the second signal. */
			pScanner->Clear();
			pScanner->Add("", "3!CH1_1=DCV");
			pScanner->Add("3!BPL_HI->3!BPL_LO;~3!BPL_HI->3!BPL_LO", "3!CH1_2=DCV");
			pScanner->Initiate();

			//Wait for the scan complete
			pScanner->WaitForScanComplete(1000);

			/*It might also be the case that I want to make sure that the path that connects BPL_HI 
			and BPL_LO goes through COM1, so we discharge that appropriately. */
			pScanner->Clear();
			pScanner->Add("", "3!CH1_1=DCV");
			pScanner->Add("3!BPL_HI->3!CH1_COMH->3!CH1_COML->3!BPL_LO;~3!BPL_HI->3!BPL_LO", "3!CH1_2=DCV");
			pScanner->Initiate();
			
			//Close the initialized session
			pScanner->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
