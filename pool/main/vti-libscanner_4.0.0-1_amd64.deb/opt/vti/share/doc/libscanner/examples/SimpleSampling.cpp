#include "libScanner.h"
#include <stdio.h>

int main()
{
	//Create a VTEXScanner pointer
	LibScanner *pScanner;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Scanner pointer
		pScanner = LibScanner::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pScanner->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			/* The next two lines set up the DMM configuration. We need to set up the DMM so that it
			knows what kind of measurement we are taking on the switch card�s inputs */
			pScanner->Dmm->Function = VTEXScannerDmmFunctionDCVolts; 
			//More DMM configuration could go here
			pScanner->Dmm->Configuration->Save("DCV");

			/* Now we need to set up a scanlist of channels to read with the DMM. Let�s say we have
			one channel, CH1_1, that we want to read a voltage on. We use 3! to represent the 12xx
			slot our card is in, and "DCV" to represent the saved DMM configuration above. */
			pScanner->Add("", "3!CH1_1=DCV"); 

			/* The Initiate call takes no arguments, and tells the device to start its trigger model.
			We don�t worry about that in this example because the default Arm and Trigger sources are
			"Immediate", which means the device will sample as soon as it is ready. We will cover Arm
			and Trigger more in-depth in the next section. */
			//We could set up our trigger/arm sources here
			pScanner->Initiate();

			/* Now that we are sampling, we need to wait for the scanlist to be completed. The
			timeout here is in milliseconds, so we give the device 2 seconds to be finished. Since
			the call will return immediately upon the completion of the scanlist, we can give large
			timeouts without slowing down our system. */
			pScanner->WaitForScanComplete(2000);

			/*Now we need to read the data, probably the most complicated thing in this example. To
			do this, we need to create three SAFEARRAY pointers, and then let the Read call allocate
			and fill in these arrays for us. We will need to destroy them when we are done, but
			that�s beyond the scope of this example. The Microsoft website has more information on
			working with SAFEARRAY types. */

			std::vector<double> Data;
			std::vector<double> ts_sec; //Timestamps, seconds component
			std::vector<double> ts_nsec; //Timestamps, nanoseconds or fractional seconds component
			pScanner->Read(1000, 1, Data, ts_sec, ts_nsec);
			
			//Close the initialized session
			pScanner->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
