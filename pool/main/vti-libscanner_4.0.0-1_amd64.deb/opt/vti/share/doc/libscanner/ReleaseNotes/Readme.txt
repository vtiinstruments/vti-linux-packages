==========================================================================================================================
Upgrade Image / Instrument Model Compatibility Matrix:
==========================================================================================================================
Part Number | File Name                           | Supported Models
--------------------------------------------------------------------------------------------------------------------------
62-0074-000 | ex7000_upgrade.img                  | EX7000, all models
--------------------------------------------------------------------------------------------------------------------------
62-0080-000 | ex12x2_ex12x6_upgrade.img           | EX1202, EX1206, EX1262, EX1266
--------------------------------------------------------------------------------------------------------------------------
62-0088-100 | ex12x7A_ex12x8A_ex12x9A_upgrade.img | EX1208A, EX1268A
--------------------------------------------------------------------------------------------------------------------------
62-0083-000 | ex1200_switch_card_upgrade.img      | EX1200- 2001 2002 5001 5002 3048 3048S 3072 3096 3164
            |                                     |         4120 4148 4164 4003 4128 6101 6216 6301 6301T
            |                                     |         3001 6102 5004 5006 6216HV 2007A 2008H 4260 4264
            |                                     |         2087A 6111 4265 7316 7316b 7000s 3824 6216-S 6112-S 
--------------------------------------------------------------------------------------------------------------------------
62-0083-100 | ex1200_nonswitch_card_upgrade.img   | EX1200- 3604 3608 7416 7416m1 7500 7600 1538
--------------------------------------------------------------------------------------------------------------------------
62-0083-200 | ex1200_nonswitch_card_upgrade_2.img | EX1200- 7008 7000
--------------------------------------------------------------------------------------------------------------------------
62-0083-400 | ex1200_switch_card_upgrade_2.img    | EX1200- 4264I
==========================================================================================================================
EX1200, EX7000 Driver/Firmware Revision History
==========================================================================================================================
==========================================================================================================================
Date of the Release: Jun 11, 2024
Version Number: v3.14.2
Model Number: EX7000 Firmware
Operating System: N/A
	Fix:
	     - Fixed SFP to list all the possible paths in matrix relays and show correct image
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
	     - N/A
Compatibility Details:
	Firmware version: N/A
	Driver version: N/A
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: Aug 07, 2023
Version Number: v3.14.1
Model Number: EX12xx,EX12xxA,Switch Card upgrade image,Switch Card upgrade image 2
Operating System: N/A
	Fix:
         - Fixed SCPI communications for Switch cards
	     - DMM Calibration: Fixed issues with stability of communications with newer Fluke calibrators.
	     - Updated signing key of Java SFP for DMM, Scanner, and Switch
	New Feature:
	     - DMM Calibration: Added support for Keysight 33520B function generator.
	System level dependency:
	     - N/A
	Known Issue:
	     - N/A
Compatibility Details:
	Firmware version: N/A
	Driver version: N/A
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: Feb 06, 2023
Version Number: v3.14.0
Model Number: EX12xx,EX12xxA,Non-Switch Card upgrade image,Non-Switch Card upgrade image 2,Switch Card upgrade image,Switch Card upgrade image 2
Operating System: N/A
	Fix:
	     - N/A
	New Feature:
	     - Changed all SFP to use Java web start instead of Applets.
	     - SFP modified to support Java web start
	System level dependency:
	     - N/A
	Known Issue:
	     - N/A
Compatibility Details:
	Firmware version: N/A
	Driver version: N/A
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: May 19, 2022
Version Number: v3.13.38
Model Number: EX1200 Switch Card upgrade image 2
Operating System: N/A
	Fix:
	     - N/A
	New Feature:
	     - Added support for ex1200-4264i model.
	System level dependency:
	     - N/A
	Known Issue:
	     - N/A
Compatibility Details:
	Firmware version: N/A
	Driver version: N/A
	
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: Mar 23, 2022
Version Number: v3.13.38
Model Number: EX7000 Firmware
Operating System: N/A
	Fix:
	     - N/A
	New Feature:
	     - Added support for front panel LEDs from SFP.
	System level dependency:
	     - N/A
	Known Issue:
	     - N/A
Compatibility Details:
	Firmware version: N/A
	Driver version: N/A
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: Feb 25, 2022
Version Number: v3.13.37
Model Number: EX7000 Firmware
Operating System: N/A
	Fix:
	     - Added support for Lambda RFSP4TA5M18G-C2 SP4T relay
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
	     - N/A
Compatibility Details:
	Firmware version: N/A
	Driver version: N/A
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
=================================================================================
Date of the Release: Dec 15, 2021
Version Number: v3.13.36
Model Number: EX7000 Firmware
Operating System: N/A
	Fix:
	     - Fixed Reset web page
	     - Updated all website links for the new vtiinstruments.com
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
	     - N/A
Compatibility Details:
	Firmware version: N/A
	Driver version: N/A
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: Nov 23, 2021
Version Number: v3.13.35
Model Number: EX7000 Firmware
Operating System: N/A
	Fix:
	    - Fixed a bug that caused incorrect relay driver behavior when using Path-based operation via the Soft Front Panel in some systems.
	    - Fixed latching behavior of latching relays in the Soft Front Panel on some EX7000 systems.
	    - Fixed an error during loading saved states in the Soft Front Panel.
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
	     - N/A
Compatibility Details:
	Firmware version: N/A
	Driver version: N/A
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: Nov 16, 2021
Version Number: v3.13.34
Model Number: EX7000 Firmware
Operating System: N/A
	Fix:
	     - Displayed value of Attenautors and PIOs now updates properly after reset in the Soft Front Panel.
	     - Fixed an error during reset in the Soft Front Panel on some EX7000 systems.
	     - Fixed an issue that caused inputs of Soft PIOs to not update in the Soft Front Panel in some cases.
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
	     - N/A
Compatibility Details:
	Firmware version: N/A
	Driver version: N/A
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: April 28, 2021
Version Number: v3.13.33
Model Number: EX7000 Configurator
Operating System: N/A
	Fix:
	     - Removed outdated EX7000 Component Library and Template DCFs from installer.
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
	     - N/A
Compatibility Details:
	Firmware version: N/A
	Driver version: N/A
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: April 23, 2021
Version Number: v3.13.32
Model Number: EX7000 Firmware
Operating System: N/A
	Fix:
	     - Fixed resetting and disconnecting paths with latching relays in EX7000 SFP.
	     - Fixed coloring relay closures according to indicators in EX7000 SFP.
	     - Fixed connecting long paths in EX7000 SFP.
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
	     - N/A
Compatibility Details:
	Firmware version: N/A
	Driver version: 3.x.xx
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: December 22, 2020
Version Number: v3.13.31
Model Number: EX12xx,EX12xxA
Operating System: N/A
	New Feature:
	     - Added SCPI-like interface for setting and querying status of relays on Switch plugins, available via both a raw socket and VXI-11.
	     - Added SCPI-like interface for reading the port input data of EX1200-7500 DIO plugins, available via both a raw socket and VXI-11.
	     - Added SCPI-like interface for configuring the software output state of chassis triggers, available via both a raw socket and VXI-11.
             - Added a binary streaming data interface for EX1200-7500 DIO plugins, which allows reading port input data at regular intervals in Normal mode with minimal overhead and latency.
	System level dependency:
	     - N/A
	Known Issue:
	     - N/A
Compatibility Details:
	Firmware version: N/A
	Driver version: 3.x.xx
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: December 22, 2020
Version Number: v3.13.30
Model Number: EX7000 Firmware
Operating System: N/A
	Fix:
	     - Fixed a problem with saving odometer values beyond 4 RDBs (originally fixed in v3.12.11, reintroduced in v3.12.42)
	New Feature:
	     - Added a JavaScript/HTML SFP to replace the Java Applet SFP. This will allow the SFP to be used in modern browsers.
	System level dependency:
	     - N/A
	Known Issue:
	     - The JavaScript/HTML SFP does not function properly in Internet Explorer. Contact support if you need to use the 
           Java Applet SFP.
Compatibility Details:
	Firmware version: N/A
	Driver version: 3.x.xx
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: October 2, 2020
Version Number: v3.13.29
Model Number: EX12xx,EX12xxA
Operating System: N/A
	Fix:
	     - EX1200-DMM: Serial number can now be programmed before factory calibration is completed
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
	     - N/A
Compatibility Details:
	Firmware version: N/A
	Driver version: 3.x.xx
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: June 20, 2020
Version Number: v3.13.27
Model Number: Non-Switch Card Upgrade Image
Operating System: N/A
	Fix:
	     - EX1200-3608: Updated limits for DC Current test points of post-calibration verification to be in-line with latest accuracy limits.
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
	     - N/A
Compatibility Details:
	Firmware version: 3.13.26
	Driver version: 3.x.xx
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: June 18, 2020
Version Number: v3.13.26
Model Number: EX12xx,EX12xxA,Non-Switch Card Upgrade Image
Operating System: N/A
	Fix:
	     - EX1200-1538: Corrected the bug that caused filling zeros to the read FIFO intermittently
		   when data streaming enabled with immediate trigger method (FPGA Version: 32)
		 - Corrected the bug associated with displaying time configuration menu on internet explorer.
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
	     - N/A
Compatibility Details:
	Firmware version: 3.13.26
	Driver version: 3.x.xx
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: May 19, 2020
Version Number: v3.13.25
Model Number: EX7000 Firmware
Operating System: N/A
	Fix:
	     - Corrected a bug that caused the SFP to discover impossible paths that attempted to use one leg of a transfer switch in both positions.
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
	     - The SFP may not discover complex loop-back paths that use both legs of a transfer switch.
           These paths may still be created by explicitly providing the complete path using the "New Path" dialog.
Compatibility Details:
	Firmware version: 3.13.25
	Driver version: 3.x.xx
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: March 19, 2020
Version Number: v3.13.24
Model Number: EX12xx,EX12xxA,Non-Switch Card upgrade image
Operating System: N/A
	Fix:
	     - N/A
	New Feature:
	     - Added SRAM self test for EX1200-1538 Multifunction card
	System level dependency:
	     - N/A
	Known Issue:
Compatibility Details:
	Firmware version: 3.13.24
	Driver version: 3.x.xx
        EX1200-1538 FPGA Version: 31
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: March 5, 2020
Version Number: v3.13.23
Model Number: EX12xx,EX12xxA,Non-Switch Card upgrade image,Switch Card upgrade image
Operating System: N/A
	Fix:
	     - Updated signing key of Java SFP for DMM, Scanner, and all card types
	     - EX1200-3608/4: The Java SFP's limits for calibration and verification were updated to match latest specifications
	     - EX1200-7316B: Corrected card configuration issue that was causing relays not to close
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
Compatibility Details:
	Firmware version: N/A
	Driver version: 3.x.xx
Hardware Version:
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version:
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: October 22, 2019
Version Number: v3.13.22
Model Number: EX12xx,EX12xxA,Non-Switch Card upgrade image
Operating System: N/A
	Fix:
	     - EX1200-3608/3604 now disable output properly when changing range to avoid introducing transient spikes in output during range transition.
	     - EX1200-7500 SFP now populates the Voltage field properly if "5V TTL Emulation" or "3.3V LV Emulation" are selected initially.
	New Feature:
	     - Added support for new plugin card flash type
	     - EX1200-7416 and DMM SFPs now support Fluke 5730 and 5730A calibrators.
	System level dependency:
	     - N/A
	Known Issue:
Compatibility Details:
	Firmware version: N/A
	Driver version: 3.x.xx
Hardware Version:
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version: 
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: Feb 12, 2019
Version Number: v3.13.20
Model Number: libSwitch/libDio drivers
Operating System: Linux
	Fix:
		- N/A
	New Feature:
	     - Added support for the "ex1200timeout" option in the DriverSetup portion of the option string.
	System level dependency:
	     - N/A
	Known Issue:
Compatibility Details:
	Firmware version: 3.13.18
	Driver version: 3.x.xx
Hardware Version:
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version: 
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: May 22, 2018
Version Number: v3.13.19
Model Number: EX12xx/EX12xxA/Switch/NonSwitch/NonSwitch-2 - All series card & chassis FW
Operating System: Windows
	Fix:
		- Fixed an issue with switch cards scan hangs when both thermistor and thermocouple measured in same step.
		- Fixed an issue in the hardware booting up issue with lower & higher FW version combination.
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
Compatibility Details:
	Firmware version: 3.13.18
	Driver version: 3.x.xx
Hardware Version:
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version: 
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: November 27, 2017
Version Number: v3.13.18 - Beta
Model Number: EX12xx series chassis FW
Operating System: Windows
	Fix:
		- Fixed an issue in the FW code where plugin card timestamps not programmed unless chassis is 1588 slave.
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
Compatibility Details:
	Firmware version: 3.13.18
	Driver version: 3.x.xx
Hardware Version:
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version: 
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: November 2, 2017
Version Number: v3.13.18
Model Number: EX1200 3608 (FGen card) Upgrade FW
Operating System: Windows
	Fix:
		- Fixed an issue with 3608 card where offset voltage is consistently high by about 25mv after bootup and before inital parameters are configured in SFP.
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
Compatibility Details:
	Firmware version: 3.13.18
	Driver version: 3.x.xx
Hardware Version:
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version: 
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: September 12, 2017
Version Number: v3.13.17
Model Number: EX1200 Switch Upgrade FW
Operating System: Windows
	Fix:
		- Fixed an issue where EX1200-7000s upgrades would fail.
	New Feature:
	     - N/A
	System level dependency:
	     - N/A
	Known Issue:
Compatibility Details:
	Firmware version: 3.13.17
	Driver version: 4.x.x
Hardware Version:
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version: 
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: May 25, 2017
Version Number: v3.13.16
Model Number: EX7000 FW/Switch SFP/EX7000 Configurator
Operating System: Windows
	Fix:
		- N/A
	New Feature:
	     - Add new flag to DCF to allow control of channel sorting when pathfinding 
	System level dependency:
	     - N/A
	Known Issue:
Compatibility Details:
	Firmware version: 3.13.16
	Driver version: 4.x.x
Hardware Version:
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version: 
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: Mar 16, 2017
Version Number: v3.13.15
Model Number: EX1200 FW 
Operating System: Windows
	Fix:
		- N/A
	New Feature:
	     - Fix precision display in SFP for EX1200-7008 RTD measured current 
	System level dependency:
	     - N/A
	Known Issue:
Compatibility Details:
	Firmware version: 3.13.13
	Driver version: 4.x.x
Hardware Version:
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version: 
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: Dec 5, 2016
Version Number: v3.13.14
Model Number: EX7000 FW 
Operating System: Windows
	Fix:
		- N/A
	New Feature:
	     - Load DCF through the web interface with the correct password 
	System level dependency:
	     - N/A
	Known Issue:
Compatibility Details:
	Firmware version: 3.13.13
	Driver version: 4.x.x
Hardware Version:
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version: 
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: Nov 28, 2016
Version Number: v3.13.13
Model Number: EX7000 FW, FGen 64 bit IVI Drivers 
Operating System: Windows
	Fix:
		 - N/A
	New Feature:
	     - EX7000 improved upload security via DCF password protection 
		 - 64 bit IVI driver for FGen
	System level dependency:
	     - Common & System driver libraries are dependencies components need to be installed in the system
	Known Issue:
Compatibility Details:
	Firmware version: 3.13.12
	Driver version: 4.x.x
Hardware Version:
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version: 
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: Oct 21, 2016
Version Number: v3.13.12
Model Number: EX1200 Series Drivers 
Operating System: Linux
	Fix:
		N/A
	New Feature:
	     - 64 bit Linux driver support for RTDSimulator, Breadboard, Scanner, Comparator, DIO, DMM, FGen, Multifunction & Varres cards
	System level dependency:
	     - Common & System driver libraries are dependencies components need to be installed in the system
	Known Issue:
Compatibility Details:
	Firmware version: 3.13.11
	Driver version: 4.x.x
Hardware Version:
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version: 
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
==========================================================================================================================
Date of the Release: Sep 5, 2016
Version Number: v3.13.11
Model Number: EX1200 Series FW 
Operating System:	Windows
	Fix:
		N/A
	New Feature:
	     - Added support for RTD simulator IVI driver 64 bit version
		 - Added support for serial & model entry for SMP carrier plug-in cards
	System level dependency:
		N/A
	Known Issue:
Compatibility Details:
	Firmware version: 3.13.11
	Driver version: 4.x.x
Hardware Version:
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version: 
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================

==========================================================================================================================
Date of the Release: Jun 17, 2016
Version Number: v3.13.10
Model Number: EX1200 Series FW 
Operating System:	Windows
	Fix:
		N/A
	New Feature:
	     - Added DMM version display in SFP.
		 - Added 'Chassis' suffix to Scanner list in SFP
		 - Showing scan list in SFP is added for EX1200-SMP 
	System level dependency:
		N/A
	Known Issue:
Compatibility Details:
	Firmware version: 3.13.10
	Driver version: 4.x.x
Hardware Version:
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version: 
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
==========================================================================================================================
EX1200, EX7000 Firmware
 - Add support for PTPv2 (IEEE 1588-2008) and releasing as non-beta version

==========================================================================================================================
Date of the Release: May 24, 2016
Version Number: v3.13.9
Model Number: EX1200 Series FW ( EX1200-SMP New Model Support)
Operating System:	Windows
	Fix:
		N/A
	New Feature:
	     - Added support for additional Keysight (Agilent) relays.
		 - Added new SMP hardware support
	System level dependency:
		N/A
	Known Issue:
		 - Scan list doesn't show in SFP for some switch cards. 
		 - Scanner feature is not supported in SMP
		 - The above issues will be corrected in subsequent release
Compatibility Details:
	Firmware version: 3.13.9
	Driver version: 4.x.x
Hardware Version:
--------------------------------------------------------------------------------------------------------------------------
Digital_FPGA_Firmware_version | Digital_FPGA_Version | Analog_FPGA_version | New_Hardware_Revision_Number |	DMM Version: 
--------------------------------------------------------------------------------------------------------------------------
			27				  |			46			 |        9   		   | 		39					  |  2.0.18
			
==========================================================================================================================

==========================================================================================================================
Date of the Release: February 2, 2016
Version Number: v3.13.8
Model Number: EX7000 FW
Release Note Item:
	New Feature:
		- FPGA reverted to an older version to resolve SFP loading issue of some cards.
Compatibility Details:
	Firmware version: NA
	Driver version: NA		
==========================================================================================================================

==========================================================================================================================
Date of the Release: February 1, 2016
Version Number: v3.13.7 - Beta
Model Number: EX7000 FW
Release Note Item:
	Fix:
		- FPGA updated for switch card 5002 detection issue.
		- Added support for EX1200-7316b card	
Compatibility Details:
	Firmware version: NA
	Driver version: NA
==========================================================================================================================

==========================================================================================================================
Date of the Release: November 17, 2015
Version Number: v3.13.7
Model Number: EX7000 FW
Release Note Item:
	New Feature:
		- Added support for additional Radiall relays.
Compatibility Details:
	Firmware version: NA
	Driver version: NA		
=================================================================================

=================================================================================
Date of the Release: October 20, 2015
Version Number: v3.13.5
Model Number: EX1200-7000 Breadboard
Release Note Item:
	Fix:
		- Fixed issue with bank 7 which is not able to function properly with newer PCB revision.
=================================================================================

=================================================================================
Date of the Release: September 29, 2015
Version Number: v3.13.4
Model Number: EX1200, EX7000 FW / Switch SFP
Release Note Item:
	Fix:
		- Fixed SFP issue to load appropriate java run time version i.e. 1.6 to 1.8.
=================================================================================

=================================================================================
Date of the Release: September 2, 2015
Version Number: v3.13.3
Model Number: EX7000 FW / Switch SFP
Release Note Item:
	Fix:
		- Fixed an issue where manually entering an attenuation value could result in an unexpected value being applied.
=================================================================================

=================================================================================
Date of the Release: August 25, 2015
Version Number: v3.13.2
Model Number: EX7000 FW / Switch SFP
Release Note Item:
	Fix:
		- Fixed an issue where some attenuators could not be set to the full range of valid values.
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.13.1
Model Number: EX1200 FW
Release Note Item:
	Fix:
		- Fixed memory usage issues in comparator reset and self test
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.13.0
Model Number: EX1200 Scanner and DMM IVI drivers
Release Note Item:
	System level dependency:
		- Initial release of 64 bit drivers
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.53
Model Number: EX1200,EX7000 FW
Release Note Item:
	System level dependency:
		- (PTPv2) Updated current UTC offset to 36
=================================================================================

=================================================================================
Date of the Release: June 19, 2015
Version Number: v3.12.52
Model Number: EX7000 FW
Release Note Item:
	Fix:
		- Fixed an issue with systems containing 3 RDBs
=================================================================================

=================================================================================
Date of the Release: June 17, 2015
Version Number: v3.12.51
Model Number: EX7000 Configurator
Release Note Item:
	Fix:
		- Fixed an issue where non-linear attenuators were not assigned enough control bits.
=================================================================================

=================================================================================
Date of the Release: June 01, 2015
Version Number: v3.12.50
Model Number: EX7000 FW
Release Note Item:
	New Feature:
		- Add scanner support in the Software with limited trigger support (as of now supporting only Immediate and Software triggers).
=================================================================================

=================================================================================
Date of the Release: May 29, 2015
Version Number: v3.12.49
Model Number: EX7000 FW
Release Note Item:
	New Feature:
		- Add images for AMC pin diode and Kratos phase shifter
=================================================================================

=================================================================================
Date of the Release: May 21, 2015
Version Number: v3.12.48
Model Number: VTEXScanner Driver
			  EX1200 FW
			  All SFPs
Release Note Item:
	System level dependency:
		- (VTEXScanner) Updated to include new DMM error codes.
		- (DMM SFP) If nominal calibration data is loaded, initiating a measurement will return an error unless calibration is in progress.
		- All SFPs are now built with Java 8
	New Feature:
		- (DMM SFP) Added protection to prevent calibration data from being mistakenly overwritten
=================================================================================

=================================================================================
Date of the Release: May 15, 2015
Version Number: v3.12.47
Model Number: VTEXDmm Driver
Release Note Item:
	New Feature:
        - Added ability to set ApertureTime in VTEXDmm.
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.46
Model Number: EX7000 FW Image
Release Note Item:
	Fix:
		- Fixed an issue where setting the RDB serial number corrupts relay drive mode settings
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.45
Model Number: EX1200 Chassis FW Images
Release Note Item:
	Fix:
		- Fixed an issue where setting the serial of a DMM would replace cal constants with nominal values
=================================================================================

=================================================================================
Date of the Release: 
Version Number: 3.12.44
Model Number: VTEXSwitch LV Driver
Release Note Item:
	Fix: EX1200 Switch card upgrade image
		- Added both ex1200-6112-s and ex1200-6216-s switch card in the EX1200 family
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v4.1.2
Model Number: VTEXSwitch LV Driver
Release Note Item:
	Fix:
		- Update all labVIEW vi's to call function names as �VtexSwitch� instead of �VTEXSwitch� with the updated IVI driver.
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.43
Model Number: DMM SFP - EX1200 FW Images
Release Note Item:
	Fix:
		- Fixed an issue where the SFP did not properly dump all of the calibration coefficients
	System level dependency:
		- Altered the calibration routine to better handle DMM drift in certain functions and ranges.
	New Feature:
		- Added logging of ADC counts when running calibration or verification
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.42
Model Number: EX7000 FW
Release Note Item:
	Fix:
		- Fixed a FPGA issue where the unit did not properly power up.
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.41
Model Number: EX1200 FW
Release Note Item:
	Fix: DMM SFP - EX1200 FW Images
		- Updated the ACV test points during verification of DMM in SFP jar file
=================================================================================

=================================================================================
 
Date of the Release: 
Version Number: v3.12.40
Model Number: DMM SFP - EX1200 FW Images
Release Note Item:
	Fix:
		- Fixed the issue with saving both calibrated date and due calibration date in DMM SFP jar file
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.39
Model Number: System IVI/LabVIEW Driver
Release Note Item:
	New Feature:
		- Add support for 64-bit and releasing both 32-bit and 64-bit versions of VTEXSystem IVI driver as 3.12.39
		- Add support for calling 64-bit/32-bit VTEXSystem dll (based on the OS) in VTEXSystem LabVIEW wrapper
Model Number: EX1200, EX7000 Firmware
Release Note Item:
	New Feature:
		- Add support for PTPv2 (IEEE 1588-2008) and releasing as non-beta version
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.38-Beta
Model Number: EX1200, EX7000 Firmware
Release Note Item:
	New Feature:
		- Add support for PTPv2 (IEEE 1588-2008)
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.37
Model Number: EX1200 Switch card upgrade image
Release Note Item:
	Fix:
		- Fixed the issue with pin number mismatch in fpga for 3824
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.36-Beta
Model Number: EX1200 Switch card upgrade image
Release Note Item:
	New Feature:
		- Added 3824 switch card in the EX1200 family
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.35
Model Number: VTEXSystem IVI Driver/EX1200 FW images
Release Note Item:
	System level dependency:
		- Updated FIFO_POLL_MSEC to 10 instead of 250 for dmm measurements in firmware
	Fix:
		- Fixed the issue of loading saved configuration with Reset method of VTEXSystem IVI driver
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.34
Model Number: Fgen IVI Driver
Release Note Item:
	Fix:
		- Fixed the issue with returning the status of self test call
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.33
Model Number: Comparator IVI Driver
Release Note Item:
	Fix:
		- Fixed the issue with Initialize method in simulation mode
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.31 and v3.12.32
Model Number: VT series FW Images (new product support)
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.30
Model Number: EX1200/EX7000 FW Images
Release Note Item:
	Fix:
		- Added manifest permissions attribute to all SFP jar files
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.29
Model Number: EX1200 Switch card upgrade image
Release Note Item:
	New Feature:
		- Added both 7000s and 7316 switch cards in the EX1200 family
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.28
Model Number: EX1200 Firmware, IVI, LV and Linux images
Release Note Item:
	New Feature:
		- Added 7000 Breadboard in the EX1200 family
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.27
Model Number: EX1200 non-switch Upgrade image
Release Note Item:
	System level dependency:
		- Rebuild the ex1200-3608 FPGA by including the changes in 4bb (fix for not detecting 3608 in some of the slots of EX1268A chassis)
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.26
Model Number: Switch IVI (both 32-bit and 64-bit versions) and Linux drivers
Release Note Item:
	New Feature:
		- Added new property to get the list of relays and releasing both 32-bit and 64-bit VTEXSwitch IVI Drivers as 3.12.26 version
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.25
Model Number: EX1200 Upgrade images
Release Note Item:
	Fix:
		- Fixed the DmmSfp to correctly wait until the Fluke calibrator has settled before taking measurements when being calibrated.
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.24
Model Number: EX1200 Firmware card upgrade image/IVI driver/Linux driver - Multifunction
Release Note Item:
	System level dependency:
		- Modified the FPGA to give an error signal upon receiving trigger when NO new data available and SFP/Lib layers will treat the measurement as zero based on the error signal
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.23
Model Number: EX1200 Upgrade images, VTEXSystem IVI/LV drivers
Release Note Item:
	Fix:
		- Fixed the issue with ACV measurement in DMM SFP
	New Feature:
		- Added the feature to support saving the configuration and loading it back from non-volatile memory and removed the earlier way ("Default=") of storing source/invertedsource list.
=================================================================================
  
=================================================================================
Date of the Release: 
Version Number: v3.12.22
Model Number: Non-Switch Card upgrade image, VTEXMultifunction IVI/Linux driver
Release Note Item:
	Fix:
		- Fixed the issue with readings when there is no input in FPGA and IVI driver
	New Feature:
		- Added a missing case to calculate time interval measurement and corrected dutycycle caluculation
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.21
Model Number: Non-Switch Card upgrade image
Release Note Item:
	Fix:
		- Fixed the issue with ReadLatest by not allowing the write during the read in progres to the block memory
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.20
Model Number: Switch Card upgrade image
Release Note Item:
	System level dependency:
		- Modified common code between scanner and switch SFP's.
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.19
Model Number: EX1200 Firmware/IVI driver/Linux driver/LV wrapper
Release Note Item:
	System level dependency:
		- Releasing the firmware, Comparator IVI/Linux driver and Comparator LabVIEW wrapper as 3.12.19 version
	Fix:
		- Fixed the backplace trigger level option - active low or active high
	New Feature:
		- Added ex1200-7416m1 model to support 50.0V range instead of 100.0V in ex1200-7416
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.18
Model Number: Switch IVI Driver
Release Note Item:
	System level dependency:
		- Releasing both 32-bit and 64-bit VTEXSwitch IVI Drivers as 3.12.18 (non-beta) version
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.17 Beta
Model Number: EX7000 Firmware
Release Note Item:
	New Feature:
		- Added support for new relays
=================================================================================  

=================================================================================
Date of the Release: 
Version Number: v3.12.16 Beta
Model Number: Switch IVI Driver
Release Note Item:
	System level dependency:
		- Releasing VTEXSwitch IVI Driver as 64-bit version	
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v4.0.0 Beta
Model Number: VTEXSwitch LV Driver
Release Note Item:
	System level dependency:
		- Updated all the vi's to work with 64-bit machine.
=================================================================================  

=================================================================================
Date of the Release: 
Version Number: v3.12.15
Model Number: Scanner IVI Driver
Release Note Item:
	Fix:
		- Fixed the problem with driver going into indefinite loop while ethernet cable is removed.
=================================================================================
  
=================================================================================
Date of the Release: 
Version Number: v3.12.14
Model Number: Switch LV Driver
Release Note Item:
	Fix:
		- Fixed the problem with VTEXSwitch LabVIEW wrapper opening with older version of LabVIEW.
=================================================================================  

=================================================================================
Date of the Release: 
Version Number: v3.12.13
Model Number: Switch Firmware
Release Note Item:
	Fix:
		- Fixed power on saved state for EX1200-3164 switch card.

Model Number: RTDSimulator Firmware
Release Note Item:
	System level dependency:
		- Updated the Pulsed current lower threshold in FPGA.
=================================================================================  

=================================================================================
Date of the Release: 
Version Number: v3.12.11
Model Number: EX7000 Firmware
Release Note Item:
	Fix:
		- Fixed a problem saving odometer values beyond 4 RDBs
=================================================================================  

=================================================================================
Date of the Release: 
Version Number: v3.12.10
Model Number: Switch Driver/Firmware
Release Note Item:
	New Feature:
		- Added the support for EX1200-4265 card.
=================================================================================  

=================================================================================
Date of the Release: 
Version Number: v3.12.9
Model Number: EX1200 Firmware
Release Note Item:
	New Feature:
		- Added support for storing the BPL_INSFAIL configuration in NV RAM.
	System level dependency:
		- Releasing Fgen card upgrade image - fix in SFP calibration
=================================================================================  

=================================================================================
Date of the Release: 
Version Number: v3.12.8
Model Number: NonSwitch Card Upgrade Image - Multifunction
Release Note Item:
	Fix:
		- Fixed the problem with setting the output direction for dio channels in SFP.
		- Fixed the problem while writing the direction in FPGA by increasing the latch enable time.
=================================================================================
  
=================================================================================
Date of the Release: 
Version Number: v3.12.7
Model Number: RTDSimulator Card Upgrade Image
Release Note Item:
	System level dependency:
		- Updated the Pulsed current settling time with 1.6 milli-seconds in FPGA.
=================================================================================
  
=================================================================================
Date of the Release: 
Version Number: v3.12.6
Model Number: RTDSimulator Driver/ Firmware
Release Note Item:
	New Feature:
		- Added the Pulsed Current Excitation Feature.

Model Number: Switch Driver/Firmware
Release Note Item:
	New Feature:
		- Added the support for EX1200-6111 card.
=================================================================================  

=================================================================================
Date of the Release: 
Version Number: v3.12.5
Model Number: EX7000 Firmware
Release Note Item:
	New Feature:
		- Added Support for RelComm RMT-12S6DB (SP12T) relay.
  
Model Number: Switch Firmware
Release Note Item:
	Fix:
		- Fixed occasional self-test failure with EX1200-2087A switch card.
=================================================================================
 
=================================================================================
Date of the Release: 
Version Number: v3.12.4
Model Number: Switch Driver/Firmware
Release Note Item:
	New Feature:
		- Support for EX1200-2087A switch card relay built in self test feature.

Model Number: Switch Card upgrade image
Release Note Item:
	New Feature:
		- Added Support for relay built in self test feature in the EX1200-2087A FPGA.
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.12.3
Model Number: EX1200 Firmware, IVI, LV and Linux images
Release Note Item:
	New feature:
		- Added 7008 RTDSimulator in the EX1200 family.
	System level dependency:
		- Releasing all the EX1200 related images as 3.12.3 version.
================================================================================= 
 
=================================================================================
Date of the Release: 
Version Number: v3.12.2
Model Number: Fgen Card upgrade image
Release Note Item:
	Fix:
		- Fix for Calibration COnstants for 20mA range in SFP
=================================================================================
 
=================================================================================
Date of the Release: 
Version Number: v3.11.4
Model Number: EX7000 Firmware
Release Note Item:
	System level dependency:
		- Updated with matching SFP.
=================================================================================
 
=================================================================================
Date of the Release: 
Version Number: v3.11.3
Model Number: EX7000 Firmware
Release Note Item:
	New Feature:
		- Added library and image support for amplifier modules.
=================================================================================
 
=================================================================================
Date of the Release: 
Version Number: v3.10.6
Model Number: Comparator Card upgrade Image
Release Note Item:
	Fix:
		- Fix for FPGA bit file for RJR cards
================================================================================= 

=================================================================================
Date of the Release: 
Version Number: v3.10.5
Model Number: Switch Driver
Release Note Item:
	fix:
		- Fix for verify relay state on latching relays
================================================================================= 

=================================================================================
Date of the Release: 
Version Number: v3.10.3
Model Number: EX1200 Firmware
Release Note Item:
	System level dependency:
		- Resolved an issue with the ex1200-6301 and -6301T cards.
=================================================================================
 
=================================================================================
Date of the Release: 
Version Number: v3.10.2
Model Number: EX1200 Firmware
Release Note Item:
	System level dependency:
		- Resistance tolerances updated for revision B boards.
================================================================================= 
 
=================================================================================
Date of the Release: 
Version Number: v3.10.1
Model Number: VarRes Driver/Firmware
Release Note Item:
	System level dependency:
		- Previously this driver had a dependence on VISA to be installed. Since VISA is not used in this driver, it was removed.

Model Number: DIO Driver/Firmware
Release Note Item:
	System level dependency:
		- The maximum pattern output rate has been permanently reduced to 2MHz. This is a specification change for the card.
		- The card can now generate many more clock frequencies, including many between 1.25MHz and 2MHz.
		- Pattern output now works reliably at all supported frequencies.

Model Number: Fgen Driver/Firmware
Release Note Item:
	System level dependency:
		- The Marker output is now correctly syncronized to the start of
			sample.  (It was previously generated at the end of sample.)

		- Standard waveforms (Square, Triangle, RampUp, RampDown) were
			incorrectly shaped and/or had the wrong frequency for low
			frequencies.
			
Model Number: EX7000 Firmware
Release Note Item:
	System level dependency:
		- Now more robustly handles incorrect and invalid scpi commands.

Model Number: System Driver
Release Note Item:
	System level dependency:
		- Updated supported models.

Model Number: Multifunction Driver/Firmware
Release Note Item:
	System level dependency:
		- Max average count corrected from 255 to 256 in FPGA
		- DMM connectivity of Comparator (DAC) changed according to Hardware changes
	Fix:
		- Fixed the RPM measurement issue in missing tooth mode.
		- Fixed the Frequency and pulse width measurement issue when in moving average mode (Average Repeat off)
		- Fixed the DAC Channel reset issue by Reset command.
================================================================================= 

=================================================================================
Date of the Release: 
Version Number: v3.9.8
Model Number: EX1200 Firmware
Release Note Item:
	New Feature:
		- Added support for user-replaceable DMM.
		- Added support for EX1268A chassis.
=================================================================================
 
=================================================================================
Date of the Release: 
Version Number: v3.9.5
Model Number: Switch Driver
Release Note Item:
	fix:
		- Fix for linear (new-style) attenuator definitions.
=================================================================================
 
=================================================================================
Date of the Release: 
Version Number: v3.9.3
Model Number: Switch Driver
Release Note Item:
	System level dependency:
		Rebuild to include a change intended to be in v3.9.2
	Fix:
		- Fix fractional attenuator dB settings
================================================================================= 
 
=================================================================================
Date of the Release: 
Version Number: v3.9.2
Model Number: Switch Driver/Firmware
Release Note Item:
	Fix:
		- Fix support for YIG filters
		- Fix odometers display in the SFP
		- Fix fractional attenuator dB settings

Model Number: Fgen Driver/Firmware
Release Note Item:
	System level dependency:
		- The Arbitrary.Configure() and Sequence.Configure() methods
			are now working properly on channels 2,3,4 on the 3604.
=================================================================================
   
=================================================================================
Date of the Release: 
Version Number: v3.9.1
Model Number: Switch Driver/Firmware
Release Note Item:
	Fix:
		- Fix support for matrix relays in SetPath()
	New Feature:
		- Add support for YIG filters
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.9.0
Model Number: All Drivers
Release Note Item:
	System level dependency:
		- Driver Sessions are now closed properly when simulating.

Model Number: Dio Driver/Firmware
Release Note Item:
	System level dependency:
		- Simulating mode no longer requires a model number.
		- EndState now works properly.
		- Pattern Acquisition Fifo can now be cleared properly.

Model Number: Fgen Driver/Firmware
Release Note Item:
	System level dependency:
		- The 3608 (and 3604) is now recognized in EX12x7, EX12x8, and EX12x9
			devices.
		- Autorange now works properly for Arbitrary and Sequence
			OutputModes.  Previously, the 20V range was always selected.
		- Initial values of arbitrary waveform generation were
			incorrect. Fixed.
		- Sometimes Arbitrary waveforms would generate before the first
			trigger in a triggered OperationMode.  Fixed.
		- Two triggers were needed to advance in Sequenced OperationMode.
			Fixed.
		- Initial generation of Square waves had extra samples.  Fixed.
		- Arbitrary.Configure() and Sequence.Configure() would not select the
			initial range correctly when in autorange mode. Fixed.

Model Number: Scanner Driver/Firmware
Release Note Item:
	System level dependency:
		- When calling Scanner::Read, timeouts over 60 seconds now work properly.
		- Several new APIs were added to give customers more flexibility when
			debugging Scanlists. This breaks backwards compatibility.
		- The DMM::Trigger::Multipoint API was not useful in Scanner and was removed.
		- Driver help file updated to have proper EBNF grammar for scanlists.
		- Drastically improved maximum possible scan speed.

Model Number: Switch Driver/Firmware
Release Note Item:
	System level dependency:
		- Corrected ex1200-4120, 4148, and 4164 configuration files

Model Number: VarRes Firmware
Release Note Item:
	System level dependency:
		- A change was made to the firmware to correct submitted resistances for the
			presence of a 1GOhm parallel resistance. This will result in higher
			accuracy.

Model Number: EX7000 Firmware
Release Note Item:
	System level dependency:
		- Closing a vxi11 connection without calling destroy_link() no
			longer prevents a scpi connection from being opened.
	
Release Note Item:
	Known issues:
		- The mark output is currently generated one sample late, and not
			generated at all at the last sample of a waveform. (Fgen)
		- Scanner driver breaks backward compatibility.
=================================================================================
 
=================================================================================
Date of the Release: 
Version Number: v3.8.2
Model Number: Switch Driver
Release Note Item:
	System level dependency:
		- Change the value returned from CanConnect() when both channels are the same
=================================================================================
 
=================================================================================
Date of the Release: 
Version Number: v3.8.1
Model Number: Switch Driver
Release Note Item:
	Fix:
		- Fixed latching relay reset when multiple Connect() or Disconnect()
			calls are made without debouncing between
=================================================================================
   
=================================================================================
Date of the Release: 
Version Number: v3.8.0
Model Number: Newly Supported Models
Release Note Item:
		System level dependency:
			- ex1200-4260
			- ex1200-4264

Model Number: VarRes Driver
Release Note Item:
	System level dependency:
		- The VarRes driver now includes example programs

Model Number: DIO Driver
Release Note Item:
	Fix:
		- Fixes an issue where DIO interfered with Scanner and the two could not be
			active at the same time.

Model Number: Scanner SFP
Release Note Item:
	New Feature:
		- Added the Scan Delay property to the SFP.

Model Number: Fgen Driver/Firmware
Release Note Item:
	System level dependency:
		- The Range is now set to Autorange by default.
=================================================================================
 
=================================================================================
Date of the Release: 
Version Number: v3.7.0
Model Number: Newly Supported Models
Release Note Item:
	System level dependency:
		- ex1200-7600

Model Number: FGen Driver/Firmware
Release Note Item:
	System level dependency:
		- Sequenced OperationMode now supports the AsyncAdvance mode.
		- Events are fully supported.
		- Marker output is fully supported.

Model Number: VarRes Driver/Firmware
Release Note Item:
	System level dependency:
		- Initial official release. 

Model Number: Scanner Driver
Release Note Item:
	New Feature:
		- Added new property, "Delay" - Delay acts as a holdoff to enforce a minimum delay
			between scan steps. Also, we now allow the use of commas in sweep steps. A comma
			indicates that the driver should disconnect the previous sweep channel and
			connect the next sweep channel at the same time.
=================================================================================
   
=================================================================================
Date of the Release: 
Version Number: v3.6.2
Model Number: EX7000 Firmware
Release Note Item:
	New Feature:
		- Add an SFP graphic for another type of SP4T relay
=================================================================================
  
=================================================================================
Date of the Release: 
Version Number: v3.6.1
Model Number: Switch Driver
Release Note Item:
	System level dependency:
		- Solved issue with NI Switch Executive and the Config Store
=================================================================================

=================================================================================
Date of the Release: 
Version Number: v3.6.0
Model Number: Newly Supported Models
Release Note Item:
	System level dependency:
		- ex1200-2007a
		- ex1200-2008h
		- ex1200-5004
		- ex1200-5006
		- ex1200-6216hv

Model Number: Dio Dirver
Release Note Item:
System level dependency:
		- VTEXDio functionality is now complete. All interfaces are implemented, and Pattern and 
			Async modes are now available.

Model Number: FGen Driver/Firmware
Release Note Item:
	System level dependency:
		- Standard, Arbitrary, and Arbitrary Sequence OutputModes are supported.
		- Sine, Square, Triangle, RampUp and RampDown standard waveforms add to
			the already existing DC standard waveform.
		- StartPhase is supported on all cyclic waveforms.
		- DutyCycle is supported for Square waveform.
		- Continuous and Burst OperationModes are supported as well as the VTI
			Extensions Sequenced and SingleStep.		
		- AutoRange is now supported.
		- Frontpanel, Backplane (and so any LXI trigger source), Internal and
			Software triggers are supported.
		- VTEXResult get_Name(int32_t index, VTEXString *ChannelName) is now changed to 
			VTEXString get_Name(int32_t index)
			
Release Note Item:
	Known Issues:
		- The AsyncAdvanced capability of Sequenced OperationMode is not supported at this time. (FGen)
		- Events outputs are not supported at this time. (FGen)
		- Marker output is not supported at this time. (FGen)
=================================================================================
 
=================================================================================
Date of the Release: 
Version Number: v3.5.0
Model Number: System Driver
Release Note Item:
	System level dependency:
		- Solved multi-threading issues with C interface
=================================================================================
 
=================================================================================
Date of the Release: 
Version Number: v3.4.0 
Model Number: Switch Driver
Release Note Item:
	 System level dependency:
		- Solved multi-threading issues with C interface
=================================================================================
 
=================================================================================
Date of the Release: 
Version Number: v3.3.0
Model Number: EX1200 Switch Firmware
Release Note Item:
	System level dependency:
		- Minor change to signalling on data backplane

Model Number: EX1200 Non Switch Firmware
Release Note Item:
	System level dependency:
		- Resolved memory leak on reset of DIO plugin modules
		- Resolved transfer errors on data backplane
=================================================================================
  
=================================================================================
Date of the Release: 
Version Number: v3.2.0
Model Number: Switch Driver
Release Note Item:
	Fix:
		- fixed environment variable needed for simulation
=================================================================================
 
=================================================================================
Date of the Release: 
Version Number: v3.1.0
Model Number: Switch Driver/firmware
Release Note Item:
	System level dependency:
		- Cleaned up self-test error message
	New Feature:
		- Added support for scanning current in ex1200-3001
	Fix:
		- Fixed example code

Model Number: Scanner Driver
Release Note Item:
	Fix:
		- Fixed the Close() API.
		- Fixed example code
=================================================================================
 
=================================================================================
Date of the Release: 
Version Number: v3.0.0
Model Number: 
Release Note Item:
	Comparator Driver/Firmware
	 - The way calibrations are applied to thresholds has changed since the previous
	   release. If you are upgrading from a previous release a new calibration will
	   be neccesary.

	Dio Driver/Firmware
	 - The version of the VTEXDio driver and firmware released under Version 3.0.0 is incomplete.
	 - Normal mode operation is supported.
	 - The Ports interface is supported.

	FGen Driver
	 - In this version of the VTEXFgen driver, only static DC operation is supported. 
	 - This is the DC waveform in StandardWaveform mode. 
	 - The ex1200-3604 is now supported.
	 - Autorange is not available at this time. Only fixed ranges are supported.

	Scanner Driver
	 - Currently the LibScanner driver supports all varieties of Switch card as well 
	   as the integrated DMM in the EX1200 chassis. Future support is planned for 
	   other card models.

	Known Issues
	 - There is not currently a calibration application built into the Soft Front
	   Panel for Comparator cards. This is planned in a future release. (Comparator)
	 - None of the calls that work in Async mode (InitAsync, etc) are supported. (DIO)
	 - There is nothing preventing users from accessing unsupported functionality in this release. 
	   Users must ensure they are only using supported functionality as listed in this release note or proper operation is not guaranteed. (DIO)
=================================================================================

=================================================================================
Prior to v3.0.0
Supported Models
 - ex1200-2001
 - ex1200-2002
 - ex1200-3001
 - ex1200-3048
 - ex1200-3048s
 - ex1200-3072
 - ex1200-3096
 - ex1200-3164
 - ex1200-3604
 - ex1200-3608
 - ex1200-4003
 - ex1200-4120
 - ex1200-4128
 - ex1200-4148
 - ex1200-4164
 - ex1200-5001
 - ex1200-5002
 - ex1200-6101
 - ex1200-6102
 - ex1200-6216
 - ex1200-7416
 - ex1200-7500
 =================================================================================
