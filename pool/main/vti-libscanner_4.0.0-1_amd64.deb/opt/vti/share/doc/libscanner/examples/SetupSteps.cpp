#include "libScanner.h"
#include <stdio.h>

int main()
{
	//Create a VTEXScanner pointer
	LibScanner *pScanner;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Scanner pointer
		pScanner = LibScanner::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pScanner->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			/*Let's say I wish to measure CH1_1 on my 3048. CH1_1 is connected to CH2_1, which then
			multiplexes out to CH2_2, CH2_3, and CH2_4. To measure CH1_1, first I have to pick which
			of the multiplexed connections I am measuring. 
      
      Also notice that because Setup steps are permanent once created, we have to disconnect
      the previous channel before we connect the next one.*/

			pScanner->Clear();
      pScanner->Add("3!CH2_1->3!CH2_2", "3!CH1_1=DCV");
			pScanner->Add("~3!CH2_1->3!CH2_2; 3!CH2_1->3!CH2_3", "3!CH1_1=DCV");
			pScanner->Add("~3!CH2_1->3!CH2_3; 3!CH2_1->3!CH2_4", "3!CH1_1=DCV");

			/* We can even alter multiplexers on another card to help us take readings on this card. Let's say we have a 5002 multiplexer card in slot 5. */

			pScanner->Clear();
			pScanner->Add("5!CH1_1->5!CH1_2", "3!CH1_1=DCV");
			
			//Close the initialized session
			pScanner->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
