#include "libScanner.h"
#include <stdio.h>

int main()
{
	//Create a VTEXScanner pointer
	LibScanner *pScanner;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Scanner pointer
		pScanner = LibScanner::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pScanner->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			/*Creating a list that scans 3 channels. We use the ; character as the separator for 
			actions that should happen sequentially*/
			pScanner->Clear();
			pScanner->Add("", "3!CH1_1=DCV; 3!CH1_2=DCV; 3!CH1_3=DCV"); /* The empty quotes are the
			Setup portion */

			/* The problem with the above list is that it will scan these three channels as fast as 
			possible, with no external input. What if I want to wait for a trigger between each one? 
			Then I need to make them separate scanlist steps */
			pScanner->Clear();
			pScanner->Add("", "3!CH1_1=DCV");
			pScanner->Add("", "3!CH1_2=DCV");
			pScanner->Add("", "3!CH1_3=DCV");

			/* What if I want to set the original scanlist in one function call, rather than calling 
			Clear and Add? I can just set the List property directly. Note that we use the | 
			character to separate the Setup and Sweep portions of a scanlist step, and we have no 
			setup step. */
			pScanner->List = "|3!CH1_1=DCV; 3!CH1_2=DCV; 3!CH1_3=DCV"; 

			/*Now, what if I want to set the second scanlist this way? I have to know about the /
			character, which separates scanlist steps from each other. Note that I can still have an 
			empty Setup step right after a new scanlist step.*/
			pScanner->List = "|3!CH1_1=DCV/|3!CH1_2=DCV/|3!CH1_3=DCV"; 
			
			//Close the initialized session
			pScanner->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
