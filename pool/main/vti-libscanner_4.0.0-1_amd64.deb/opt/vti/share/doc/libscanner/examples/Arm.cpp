#include "libScanner.h"
#include <stdio.h>

int main()
{
	//Create a VTEXScanner pointer
	LibScanner *pScanner;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Scanner pointer
		pScanner = LibScanner::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pScanner->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			/* Need to turn off the Immediate source, which is the default. */
			pScanner->System->Arm->Sources->DisableAll();

			//Enable the LXI3 arm source so that the device needs a rising edge on LXI3 to operate
			pScanner->System->Arm->Sources->Item["LXI3"]->Enabled = true;
			/* The line above contains serveral concepts we have not talked about. The Item[] syntax
			used to select a particular source is specified in the IVI LxiSync specification.*/

			//If we want to run the scanlist more than once, we can now change the Arm Count
			pScanner->System->Arm->ArmCount = 5; //run the scanlist 5 times

			/*Perhaps we want to wait for LXI3 or DIO2. It is possible to do this. We frist enabled
			DIO2 as well as LXI3 */
			/* One thing to note here is that unlike some other instruments (the EX1629 is one example),
         the DIO lines on the EX1200 do not require a user to set them to input or output. The
         lines are always readable, and only drive an output if requested to. */
      pScanner->System->Arm->Sources->Item["DIO2"]->Enabled = true;

			/* The current state the device is in is actually very bad right now. We have two Arm
			signals, both waiting for a rising edge from a hardware line, logical-ANDed together. If
			we left the device like this, the chances of us actually Arming the device would be very
			small, because the two hardware edgese would have to happen at exactly the same time. So
			instead, we change the OrEnable bit so either one of those edges trigger us. */
			pScanner->System->Arm->Sources->OrEnabled = true;

			/* The Arm layer also supports Alarms. There work based on IEEE 1588, and allow a device
			to be armed based on a time in the future. This means two devices on totally separate
			networks, with nothing in common but 1588 time, can both be made to trigger fairly
			simultaneously. */

			pScanner->System->Arm->Alarms->Item["ALARM0"]->Configure(true, 1234567890.0, 0.01234567, 0, 0);

			/* This configuration says I want my arm alarm to be enabled, to go off at the IEEE 1588 
			time 1234567890.01234567, and to fire exactly once (0 is a special case for both Period
			and Repeat Count). Note that Alarms still count as Sources despite having their own area,
			and therefore OrEnabled still affects them. They do have their own disableAll function. */
			
			//Close the initialized session
			pScanner->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
