#include "libScanner.h"
#include <stdio.h>

int main()
{
	//Create a VTEXScanner pointer
	LibScanner *pScanner;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Scanner pointer
		pScanner = LibScanner::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pScanner->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			/*We can set up sources like hardware lines easily */
			pScanner->System->Trigger->TriggerSource = "LAN3";

			/*Or, we can set it to an alarm. Note that the Trigger->Alarms section�s Configure
			function does not have a boolean for Enabled, but that we must still enable the alarm
			with the Enabled property. If we do not enable the alarm, it will not fire when the time
			is reached. In Arm, the Enabled property both turns the alarm on and sets it as an Arm
			source.*/
			pScanner->System->Trigger->Alarms->Item["ALARM0"]->Configure(1234567890.0, 0.01234567, 0, 0);
			pScanner->System->Trigger->Alarms->Item["ALARM0"]->Enabled = true;
			pScanner->System->Trigger->TriggerSource = "ALARM0";
			
			//Close the initialized session
			pScanner->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
