#include "libScanner.h"
#include <stdio.h>

int main()
{
	//Create a VTEXScanner pointer
	LibScanner *pScanner;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Scanner pointer
		pScanner = LibScanner::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pScanner->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			/* "Fast" config. This configuration should allow for the shortest time between readings, at the expense of accuracy. */
			pScanner->Dmm->Configuration->DeleteAll(); //Clear all configs from permanent storage
			pScanner->Dmm->Function = VTEXScannerDmmFunctionDCVolts;
			pScanner->Dmm->Range = 10.0; //10 Volt Range. AutoRange is slow, so we specify one
			pScanner->Dmm->Resolution = 10000; //This reduces us to the fewest digits of accuracy
			pScanner->Dmm->Trigger->Delay = 0; //Delays of 0 mean faster sampling
			pScanner->Dmm->Advanced->AutoZero = VTEXScannerDmmAutoZeroOff; //AutoZero is slow as well
			pScanner->Dmm->Configuration->Save("Fast"); //We can name these anything we want

			/* "Slow" Config. This would be a high-accuracy configuration which could significantly
			increase the amount of time it takes for your scanlist to run. */

			pScanner->Dmm->Function = VTEXScannerDmmFunctionDCVolts;
			pScanner->Dmm->Range = VTEXScannerDmmAutoRangeOn; /* This is really only neccesary if
			you don�t know the range the signal will be in. Otherwise, choose the minimum range that the signal fits in. */
			pScanner->Dmm->Resolution = 1e-9; //This gets us the most digits of accuracy
			pScanner->Dmm->Advanced->AutoZero = VTEXScannerDmmAutoZeroOn; 
			pScanner->Dmm->Configuration->Save("Slow");

			/*Many more DMM Configurations are possible depending on what you need to measure.*/
			
			//Close the initialized session
			pScanner->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
