#include "libScanner.h"
#include <stdio.h>

int main()
{
	//Create a VTEXScanner pointer
	LibScanner *pScanner;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Scanner pointer
		pScanner = LibScanner::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pScanner->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			/*First, set up a DMM configuration */
			pScanner->Dmm->Configuration->DeleteAll(); 
			pScanner->Dmm->Function = VTEXScannerDmmFunctionDCVolts;
			pScanner->Dmm->Range = 10.0; 
			pScanner->Dmm->Resolution = 10000; //
			pScanner->Dmm->Trigger->Delay = 0; 
			pScanner->Dmm->Advanced->AutoZero = VTEXScannerDmmAutoZeroOff; 
			pScanner->Dmm->Configuration->Save("Fast"); 

			/* Set up a Scanlist */
			pScanner->List = "|3!CH1_1=Fast/|3!CH1_2=Fast";

			/*Set up trigger & Arm. Let�s say I want to run through this scanlist twice, waiting for 
			LXI1 to trigger and LXI2 to arm. This means I will need incoming events in the following 
			sequence: LXI2, LXI1, LXI1, LXI2, LXI1, LXI1. */
			pScanner->System->Arm->ArmCount = 2;
			pScanner->System->Arm->Sources->DisableAll();
			pScanner->System->Arm->Sources->Item["LXI2"]->Enabled = true;
			pScanner->System->Trigger->TriggerSource = "LXI1";

			pScanner->Initiate();
			/* We want to give WaitForScanComplete longer this time because we don�t know when the 
			hardware lines will toggle. Let�s say we wait 10 seconds. */
			pScanner->WaitForScanComplete(10000);

			std::vector<double> Data;
			std::vector<double> ts_sec;
			std::vector<double> ts_nsec;
			/* Read has an �instant� timeout here (0ms) because the scan should be done by the time 
			we get to this point. We should error instantly if all 4 samples are not ready. */
			pScanner->Read(0, 4, Data, ts_sec, ts_nsec);  
			
			//Close the initialized session
			pScanner->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
