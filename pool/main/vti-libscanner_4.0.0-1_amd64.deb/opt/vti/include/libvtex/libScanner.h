/******************************************************************************
 *
 *  .----------------------.	File Name: LibScanner.h
 *  |==     ==  ======  == |	Project : EX Platform
 *  | ==   ==   ======  == |	$Author$
 *  |  == ==      ==    == |	$Revision$
 *  |   ===       ==    == |	$Date$
 *  |    =        ==    == |
 *  `----------------------'
 *
 * Copyright 2008 VXI Technology Inc. as an unpublished work.
 * All rights reserved. The information contained herein is confidential
 * property of VXI Technology, Inc. Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement
 * with VXI Technology, Inc.
 *
 * PURPOSE:
 *   Main public interface file for the scanner library.
 *
 * First Written By: Sangram Gaikwad On Apr-2008
 ******************************************************************************/
#ifndef		_LIBSCANNER_H
#define		_LIBSCANNER_H



/*******************
 * System header
 *******************/
#include <vector>


/*******************
 * Library header
 *******************/


/*******************
 * Local header
 *******************/
#include "vtexapi.h"

#ifndef _ATL_ATTRIBUTES
    #include "ScannerConstants.h"
#endif

#include "vtexException.h"
#include "CommonErrors.h"

#include "libInherent.h"
#include "libScannerSwitch.h"
#include "libScannerDmm.h"
#include "libScannerSystem.h"


class VTEX_API LibScanner : public LibInherent
{
    public:
        static LibScanner* Create();
        virtual ~ LibScanner () {};

        //Inherent capabilitites
        LibInherentCapabilityUtility* Utility;
        LibInherentCapabilityDriverOperation* DriverOperation;
        LibInherentCapabilityIdentity* Identity;

        LibScannerSwitch      *Switch;
        LibScannerDmm         *Dmm;
        LibScannerSystem      *System;

        property <LibScanner, bool, READ_ONLY> Initialized;        
        property <LibScanner, VTEXString, READ_WRITE> List;
        property <LibScanner, bool, READ_ONLY> IsScanning;   
        property <LibScanner, VTEXString, READ_ONLY> SerialNumber;
        property <LibScanner, int32_t, READ_ONLY> FIFOCount;
    		property <LibScanner, double, READ_WRITE> Delay;
        property <LibScanner, VTEXString, READ_ONLY> CurrentScanStepString;
        property <LibScanner, int32_t, READ_ONLY> CurrentScanStep;
        property <LibScanner, int32_t, READ_ONLY> CurrentArmCount;
        property <LibScanner, VTEXScannerScanStateEnum, READ_ONLY> ScanState;

        virtual VTEXResult get_List(VTEXString *val) = 0;
        virtual VTEXResult put_List(const VTEXString &val) = 0;
        virtual VTEXResult get_IsScanning(bool *val) = 0;    
        virtual VTEXResult get_SerialNumber(VTEXString *val) = 0;
        virtual VTEXResult get_FIFOCount(int32_t* val) = 0;
		virtual VTEXResult get_Delay(double* val) = 0;
		virtual VTEXResult put_Delay(double val) = 0;
        virtual VTEXResult get_CurrentScanStepString(VTEXString* val) = 0;
        virtual VTEXResult get_CurrentScanStep(int32_t* val) = 0;
        virtual VTEXResult get_CurrentArmCount(int32_t* val) = 0;
        virtual VTEXResult get_ScanState(VTEXScannerScanStateEnum* val) = 0;
        
        virtual VTEXResult Clear() = 0;
        virtual VTEXResult Add(const VTEXString& setupPhase, const VTEXString& sweepPhase) = 0;
        virtual VTEXResult Initiate() = 0;        
        virtual VTEXResult Abort() = 0;
        virtual VTEXResult WaitForScanComplete(int32_t MaxTimeMilliseconds) = 0;
        virtual VTEXResult SendSoftwareTrigger() = 0;
        virtual VTEXResult Read(int32_t MaxTimeMilliseconds, 
                                int32_t Count,
                                VTEXDoubleVector& Data, 
                                VTEXDoubleVector& TimeSeconds, 
                                VTEXDoubleVector& TimeFraction) = 0;
        virtual VTEXResult FIFOClear() = 0;
};

#endif	/* _LIBSCANNER_H */
