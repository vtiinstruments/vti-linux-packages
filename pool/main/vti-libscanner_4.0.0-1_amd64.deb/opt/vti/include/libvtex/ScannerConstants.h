#include "exErrors.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#if defined(_WIN32) && !defined(_CVI_)
#define INLINE __inline
#else
#define INLINE inline
#endif

#ifdef __cplusplus
extern "C" {
#endif

 //!
 //! @file
 //!
 //! Scanner constants.
 //!

#ifndef _ScannerConstants_H
#define _ScannerConstants_H


 //!
 //! DMM constants.
 //!

enum VTEXScannerDmmFunctionEnum
{
  VTEXScannerDmmFunctionDCVolts = 1,
  VTEXScannerDmmFunctionACVolts = 2,
  VTEXScannerDmmFunctionDCCurrent = 3,
  VTEXScannerDmmFunctionACCurrent = 4,
  VTEXScannerDmmFunction2WireRes = 5,
  VTEXScannerDmmFunction4WireRes = 101,
  VTEXScannerDmmFunctionFreq = 104,
  VTEXScannerDmmFunctionPeriod = 105,
  VTEXScannerDmmFunctionTemperature = 108
};

enum VTEXScannerDmmFunctionOptionEnum
{
  VTEXScannerDmmFunctionOptionACFilterLow = 1000,
  VTEXScannerDmmFunctionOptionACFilterMedium = 1001,
  VTEXScannerDmmFunctionOptionACFilterHigh = 1002,
  VTEXScannerDmmFunctionOptionDCExtProbeOff = 1003,
  VTEXScannerDmmFunctionOptionDCExtProbeOn = 1004,
  VTEXScannerDmmFunctionOptionResTestCurrentLow = 1005,
  VTEXScannerDmmFunctionOptionResTestCurrentHigh = 1006,
  VTEXScannerDmmFunctionOptionNone = 1007,
  VTEXScannerDmmFunctionOptionFreqSlow = 1008,
  VTEXScannerDmmFunctionOptionFreqMedium = 1009,
  VTEXScannerDmmFunctionOptionFreqFast = 1010,
  VTEXScannerDmmFunctionOptionFreqUser = 1011
};

enum VTEXScannerDmmApertureTimeUnitsEnum
{
  VTEXScannerDmmApertureSeconds = 0,
  VTEXScannerDmmAperturePowerLineCycles = 1
};

enum VTEXScannerDmmAutoZeroEnum
{
  VTEXScannerDmmAutoZeroOff = 0,
  VTEXScannerDmmAutoZeroOn = 1,
  VTEXScannerDmmAutoZeroOnce = 2
};

enum VTEXScannerDmmTransducerTypeEnum
{
  VTEXScannerDmmTransducerTypeThermocouple = 1,
  VTEXScannerDmmTransducerTypeThermistor = 2,
  VTEXScannerDmmTransducerType2WireRtd = 3,
  VTEXScannerDmmTransducerType3WireRtd = 1001,
  VTEXScannerDmmTransducerType4WireRtd = 4
};

enum VTEXScannerDmmThermocoupleTypeEnum
{
  VTEXScannerDmmThermocoupleTypeB = 1,
  VTEXScannerDmmThermocoupleTypeC = 2,
  VTEXScannerDmmThermocoupleTypeD = 3,
  VTEXScannerDmmThermocoupleTypeE = 4,
  VTEXScannerDmmThermocoupleTypeG = 5,
  VTEXScannerDmmThermocoupleTypeJ = 6,
  VTEXScannerDmmThermocoupleTypeK = 7,
  VTEXScannerDmmThermocoupleTypeN = 8,
  VTEXScannerDmmThermocoupleTypeR = 9,
  VTEXScannerDmmThermocoupleTypeS = 10,
  VTEXScannerDmmThermocoupleTypeT = 11,
  VTEXScannerDmmThermocoupleTypeU = 12,
  VTEXScannerDmmThermocoupleTypeV = 13
};

enum VTEXScannerDmmRefJunctionTypeEnum
{
  VTEXScannerDmmRefJunctionTypeInternal = 1,
  VTEXScannerDmmRefJunctionTypeFixed = 2,
  VTEXScannerDmmRefJunctionTypeExternal = 1000
};

enum VTEXScannerDmmThermistorResistanceEnum
{
  VTEXScannerDmmThermistorResistance2252 = 1000,
  VTEXScannerDmmThermistorResistance5000 = 1001,
  VTEXScannerDmmThermistorResistance10000 = 1002,
  VTEXScannerDmmThermistorUser
};

enum VTEXScannerDmmRtdTypeEnum
{
  VTEXScannerDmmRtdTypePT100 = 1000,
  VTEXScannerDmmRtdTypeD100 = 1001,
  VTEXScannerDmmRtdTypeF100 = 1002,
  VTEXScannerDmmRtdTypePT385 = 1003,
  VTEXScannerDmmRtdTypePT3916 = 1004,
  VTEXScannerDmmRtdTypeUser = 1100
};


enum VTEXScannerDmmAutoRangeEnum
{
  VTEXScannerDmmAutoRangeOn = -1,
  VTEXScannerDmmAutoRangeOff = -2,
  VTEXScannerDmmAutoRangeOnce = -3
};

enum VTEXScannerDmmRangeDelayEnum
{
  VTEXScannerDmmRangeAutoDelayOn = -1
};

enum VTEXScannerDmmMaxTimeEnum
{
  VTEXScannerDmmMaxTimeImmediate = 0,
  VTEXScannerDmmMaxTimeInfinite = -1
};

enum VTEXScannerDmmTriggerDelayEnum
{
  VTEXScannerDmmTriggerDelayAutoDelayOff = -2,
  VTEXScannerDmmTriggerDelayAutoDelayOn = -1
};

enum VTEXScannerDmmSampleLimitDestEnum
{
  VTEXScannerDmmSampleLimitDestNone = -1,
  VTEXScannerDmmSampleLimitDestExternal = 2,
  VTEXScannerDmmSampleLimitDestBPL0 = 1000,
  VTEXScannerDmmSampleLimitDestBPL1 = 1001,
  VTEXScannerDmmSampleLimitDestBPL2 = 1002,
  VTEXScannerDmmSampleLimitDestBPL3 = 1003,
  VTEXScannerDmmSampleLimitDestBPL4 = 1004,
  VTEXScannerDmmSampleLimitDestBPL5 = 1005,
  VTEXScannerDmmSampleLimitDestBPL6 = 1006,
  VTEXScannerDmmSampleLimitDestBPL7 = 1007
};

enum VTEXScannerDmmFrequencyVoltageRangeEnum
{
  VTEXScannerDmmFrequencyVoltageRangeAutoRangeOff = -2,
  VTEXScannerDmmFrequencyVoltageRangeAutoRangeOn = -1
};

 //!
 //! LxiSync Constants
 //!

enum VTEXScannerSystemArmSourceDetectionEnum
{
  VTEXScannerSystemArmSourceDetectionRise = 0,
  VTEXScannerSystemArmSourceDetectionFall = 1,
  VTEXScannerSystemArmSourceDetectionHigh = 2,
  VTEXScannerSystemArmSourceDetectionLow = 3
};

enum VTEXScannerSystemEventDriveModeEnum
{
  VTEXScannerSystemEventDriveModeDriven = 0,
  VTEXScannerSystemEventDriveModeOff = 1,
  VTEXScannerSystemEventDriveModeWiredOr = 2
};

enum VTEXScannerSystemSourceSlopeEnum
{
  VTEXScannerSystemSourceSlopeRise = 0,
  VTEXScannerSystemSourceSlopeFall = 1
};

enum VTEXScannerSystemTriggerSourceDetectionEnum
{
  VTEXScannerSystemTriggerSourceDetectionRise = 0,
  VTEXScannerSystemTriggerSourceDetectionFall = 1
};

enum VTEXScannerSystemEventLogOverflowEnum
{
  VTEXScannerSystemEventLogOverflowStop = 1000,
  VTEXScannerSystemEventLogOverflowOverride = 1001
};


 // Switch enums
enum VTEXScannerSwitchPathCapabilityEnum
{
  VTEXScannerSwitchPathAvailable = 100,
  VTEXScannerSwitchPathExists = 101,
  VTEXScannerSwitchPathUnsupported = 102,
  VTEXScannerSwitchPathRsrcInUse = 103,
  VTEXScannerSwitchPathSourceConflict = 104,
  VTEXScannerSwitchPathChannelNotAvailable = 105,
  VTEXScannerSwitchPathChannelOneUnknown = 106,
  VTEXScannerSwitchPathChannelTwoUnknown = 107,
  VTEXScannerSwitchPathCannotConnectToItself = 108,
  VTEXScannerSwitchPathWireModeMismatch = 109
};

 // Scanning enum

enum VTEXScannerScanStateEnum
{
  VTEXScannerScanStateTransitioning = 1000,
  VTEXScannerScanStateIdle = 1001,
  VTEXScannerScanStateWaitingForArm = 1002,
  VTEXScannerScanStateScanning = 1003,
  VTEXScannerScanStateWaitingForDelay = 1004,
  VTEXScannerScanStateWaitingForTrigger = 1005
};
#endif /* ! _ScannerConstants_H */

#ifdef  __cplusplus
}
#endif

