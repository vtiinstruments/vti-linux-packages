/******************************************************************************
*
* Copyright 2008 VTI Instruments Corporation
*
*****************************************************************************/
#pragma once
#ifndef __VTEXSCANNER_HEADER
#define __VTEXSCANNER_HEADER

#include "libScannerCApiExports.h"
#if defined(__cplusplus) || defined(__cplusplus__)
extern "C" {
#endif

    /****************************************************************************
    *---------------------------- Attribute Defines ---------------------------*
    ****************************************************************************/
#ifndef IVI_ATTR_BASE
#define IVI_ATTR_BASE                 1000000
#endif

#ifndef IVI_INHERENT_ATTR_BASE		        
#define IVI_INHERENT_ATTR_BASE        (IVI_ATTR_BASE +  50000)   /* base for inherent capability attributes */
#endif

#ifndef IVI_CLASS_ATTR_BASE           
#define IVI_CLASS_ATTR_BASE           (IVI_ATTR_BASE + 250000)   /* base for IVI-defined class attributes */
#endif

#ifndef IVI_LXISYNC_ATTR_BASE         
#define IVI_LXISYNC_ATTR_BASE         (IVI_ATTR_BASE + 950000)   /* base for IviLxiSync attributes */
#endif

#ifndef IVI_SPECIFIC_ATTR_BASE        
#define IVI_SPECIFIC_ATTR_BASE        (IVI_ATTR_BASE + 150000)   /* base for attributes of specific drivers */
#endif


    /*===== IVI Inherent Instrument Attributes ==============================*/

    /*- Driver Identification */

#define VTEXSCANNER_ATTR_SPECIFIC_DRIVER_DESCRIPTION              (IVI_INHERENT_ATTR_BASE + 514L)  /* ViString, read-only */
#define VTEXSCANNER_ATTR_SPECIFIC_DRIVER_PREFIX                   (IVI_INHERENT_ATTR_BASE + 302L)  /* ViString, read-only */
#define VTEXSCANNER_ATTR_SPECIFIC_DRIVER_VENDOR                   (IVI_INHERENT_ATTR_BASE + 513L)  /* ViString, read-only */
#define VTEXSCANNER_ATTR_SPECIFIC_DRIVER_REVISION                 (IVI_INHERENT_ATTR_BASE + 551L)  /* ViString, read-only */
#define VTEXSCANNER_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MAJOR_VERSION (IVI_INHERENT_ATTR_BASE + 515L)  /* ViInt32, read-only */
#define VTEXSCANNER_ATTR_SPECIFIC_DRIVER_CLASS_SPEC_MINOR_VERSION (IVI_INHERENT_ATTR_BASE + 516L)  /* ViInt32, read-only */

    /*- User Options */

#define VTEXSCANNER_ATTR_RANGE_CHECK                        (IVI_INHERENT_ATTR_BASE + 2L)  /* ViBoolean, read-write */
#define VTEXSCANNER_ATTR_QUERY_INSTRUMENT_STATUS            (IVI_INHERENT_ATTR_BASE + 3L)  /* ViBoolean, read-write */
#define VTEXSCANNER_ATTR_CACHE                              (IVI_INHERENT_ATTR_BASE + 4L)  /* ViBoolean, read-write */
#define VTEXSCANNER_ATTR_SIMULATE                           (IVI_INHERENT_ATTR_BASE + 5L)  /* ViBoolean, read-write */
#define VTEXSCANNER_ATTR_RECORD_COERCIONS                   (IVI_INHERENT_ATTR_BASE + 6L)  /* ViBoolean, read-write */
#define VTEXSCANNER_ATTR_INTERCHANGE_CHECK                  (IVI_INHERENT_ATTR_BASE + 21L)  /* ViBoolean, read-write */

    /*- Advanced Session Information */

#define VTEXSCANNER_ATTR_LOGICAL_NAME                       (IVI_INHERENT_ATTR_BASE + 305L)  /* ViString, read-only */
#define VTEXSCANNER_ATTR_IO_RESOURCE_DESCRIPTOR             (IVI_INHERENT_ATTR_BASE + 304L)  /* ViString, read-only */
#define VTEXSCANNER_ATTR_DRIVER_SETUP                       (IVI_INHERENT_ATTR_BASE + 7L)  /* ViString, read-only */

    /*- Driver Capabilities */

#define VTEXSCANNER_ATTR_GROUP_CAPABILITIES                 (IVI_INHERENT_ATTR_BASE + 401L)  /* ViString, read-only */
#define VTEXSCANNER_ATTR_SUPPORTED_INSTRUMENT_MODELS        (IVI_INHERENT_ATTR_BASE + 327L)  /* ViString, read-only */

    /*- Instrument Identification */

#define VTEXSCANNER_ATTR_INSTRUMENT_FIRMWARE_REVISION       (IVI_INHERENT_ATTR_BASE + 510L)  /* ViString, read-only */
#define VTEXSCANNER_ATTR_INSTRUMENT_MANUFACTURER            (IVI_INHERENT_ATTR_BASE + 511L)  /* ViString, read-only */
#define VTEXSCANNER_ATTR_INSTRUMENT_MODEL                   (IVI_INHERENT_ATTR_BASE + 512L)  /* ViString, read-only */


    /*===== Instrument-Specific Attributes =====================================*/

    /*- VTEXScanner */

#define VTEXSCANNER_ATTR_IS_SCANNING                        (IVI_SPECIFIC_ATTR_BASE + 1L)  /* ViBoolean, read-only */
#define VTEXSCANNER_ATTR_LIST                               (IVI_SPECIFIC_ATTR_BASE + 28L)  /* ViString, read-write */
#define VTEXSCANNER_ATTR_SERIAL_NUMBER                      (IVI_SPECIFIC_ATTR_BASE + 39L)  /* ViString, read-only */
#define VTEXSCANNER_ATTR_FIFO_COUNT                         (IVI_SPECIFIC_ATTR_BASE + 90L)  /* ViInt32, read-only */
#define VTEXSCANNER_ATTR_DELAY                              (IVI_SPECIFIC_ATTR_BASE + 103L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_CURRENT_SCAN_STEP                  (IVI_SPECIFIC_ATTR_BASE + 104L)  /* ViInt32, read-only */
#define VTEXSCANNER_ATTR_CURRENT_SCAN_STEP_STRING           (IVI_SPECIFIC_ATTR_BASE + 105L)  /* ViString, read-only */
#define VTEXSCANNER_ATTR_CURRENT_ARM_COUNT                  (IVI_SPECIFIC_ATTR_BASE + 106L)  /* ViInt32, read-only */
#define VTEXSCANNER_ATTR_SCAN_STATE                         (IVI_SPECIFIC_ATTR_BASE + 107L)  /* ViInt32, read-only */

    /*- Channel */

#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_IS_CONFIGURATION_CHANNEL (IVI_SPECIFIC_ATTR_BASE + 42L)  /* ViBoolean, read-write */
#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_IS_SOURCE_CHANNEL        (IVI_SPECIFIC_ATTR_BASE + 43L)  /* ViBoolean, read-write */
#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_COUNT                    (IVI_SPECIFIC_ATTR_BASE + 1000L)  /* ViInt32, read-only */

    /*- Characteristics */

#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_CHARACTERISTICS_AC_CURRENT_CARRY_MAX     (IVI_SPECIFIC_ATTR_BASE + 44L)  /* ViReal64, read-only */
#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_CHARACTERISTICS_AC_CURRENT_SWITCHING_MAX (IVI_SPECIFIC_ATTR_BASE + 45L)  /* ViReal64, read-only */
#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_CHARACTERISTICS_AC_POWER_CARRY_MAX       (IVI_SPECIFIC_ATTR_BASE + 46L)  /* ViReal64, read-only */
#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_CHARACTERISTICS_AC_POWER_SWITCHING_MAX   (IVI_SPECIFIC_ATTR_BASE + 47L)  /* ViReal64, read-only */
#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_CHARACTERISTICS_AC_VOLTAGE_MAX           (IVI_SPECIFIC_ATTR_BASE + 48L)  /* ViReal64, read-only */
#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_CHARACTERISTICS_BANDWIDTH                (IVI_SPECIFIC_ATTR_BASE + 49L)  /* ViReal64, read-only */
#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_CHARACTERISTICS_IMPEDANCE                (IVI_SPECIFIC_ATTR_BASE + 50L)  /* ViReal64, read-only */
#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_CHARACTERISTICS_DC_CURRENT_CARRY_MAX     (IVI_SPECIFIC_ATTR_BASE + 51L)  /* ViReal64, read-only */
#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_CHARACTERISTICS_DC_CURRENT_SWITCHING_MAX (IVI_SPECIFIC_ATTR_BASE + 52L)  /* ViReal64, read-only */
#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_CHARACTERISTICS_DC_POWER_CARRY_MAX       (IVI_SPECIFIC_ATTR_BASE + 53L)  /* ViReal64, read-only */
#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_CHARACTERISTICS_DC_POWER_SWITCHING_MAX   (IVI_SPECIFIC_ATTR_BASE + 54L)  /* ViReal64, read-only */
#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_CHARACTERISTICS_SETTLING_TIME            (IVI_SPECIFIC_ATTR_BASE + 55L)  /* ViReal64, read-only */
#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_CHARACTERISTICS_WIRE_MODE                (IVI_SPECIFIC_ATTR_BASE + 56L)  /* ViInt32, read-only */
#define VTEXSCANNER_ATTR_SWITCH_CHANNEL_CHARACTERISTICS_DC_VOLTAGE_MAX           (IVI_SPECIFIC_ATTR_BASE + 41L)  /* ViReal64, read-only */

    /*- Dmm */

#define VTEXSCANNER_ATTR_DMM_RANGE_CHANGE_DELAY             (IVI_SPECIFIC_ATTR_BASE + 87L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_DMM_FUNCTION_OPTION                (IVI_SPECIFIC_ATTR_BASE + 88L)  /* ViInt32, read-write */
#define VTEXSCANNER_ATTR_FUNCTION                           (IVI_SPECIFIC_ATTR_BASE + 100L)  /* ViInt32, read-write */
#define VTEXSCANNER_ATTR_RANGE                              (IVI_SPECIFIC_ATTR_BASE + 101L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_RESOLUTION                         (IVI_SPECIFIC_ATTR_BASE + 102L)  /* ViReal64, read-write */

    /*- AC */

#define VTEXSCANNER_ATTR_DMM_AC_FREQUENCY_MAX               (IVI_SPECIFIC_ATTR_BASE + 5L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_DMM_AC_FREQUENCY_MIN               (IVI_SPECIFIC_ATTR_BASE + 6L)  /* ViReal64, read-write */

    /*- Advanced */

#define VTEXSCANNER_ATTR_DMM_ADVANCED_APERTURE_TIME         (IVI_SPECIFIC_ATTR_BASE + 7L)  /* ViReal64, read-only */
#define VTEXSCANNER_ATTR_DMM_ADVANCED_APERTURE_TIME_UNITS   (IVI_SPECIFIC_ATTR_BASE + 8L)  /* ViInt32, read-only */
#define VTEXSCANNER_ATTR_DMM_ADVANCED_AUTO_ZERO             (IVI_SPECIFIC_ATTR_BASE + 9L)  /* ViInt32, read-write */
#define VTEXSCANNER_ATTR_DMM_ADVANCED_POWERLINE_FREQUENCY   (IVI_SPECIFIC_ATTR_BASE + 10L)  /* ViReal64, read-write */

    /*- Frequency */

#define VTEXSCANNER_ATTR_DMM_FREQUENCY_VOLTAGE_RANGE        (IVI_SPECIFIC_ATTR_BASE + 11L)  /* ViReal64, read-write */

    /*- Temperature */

#define VTEXSCANNER_ATTR_DMM_TEMPERATURE_TRANSDUCER_TYPE       (IVI_SPECIFIC_ATTR_BASE + 36L)  /* ViInt32, read-write */
#define VTEXSCANNER_ATTR_DMM_TEMPERATURE_IS_REFERENCE_JUNCTION (IVI_SPECIFIC_ATTR_BASE + 93L)  /* ViBoolean, read-write */

    /*- RTD */

#define VTEXSCANNER_ATTR_DMM_TEMPERATURE_RTD_ALPHA          (IVI_SPECIFIC_ATTR_BASE + 26L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_DMM_TEMPERATURE_RTD_RESISTANCE     (IVI_SPECIFIC_ATTR_BASE + 27L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_DMM_TEMPERATURE_RTD_BETA           (IVI_SPECIFIC_ATTR_BASE + 97L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_DMM_TEMPERATURE_RTD_DELTA          (IVI_SPECIFIC_ATTR_BASE + 98L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_DMM_TEMPERATURE_RTD_TYPE           (IVI_SPECIFIC_ATTR_BASE + 99L)  /* ViInt32, read-write */

    /*- Thermistor */

#define VTEXSCANNER_ATTR_DMM_TEMPERATURE_THERMISTOR_RESISTANCE (IVI_SPECIFIC_ATTR_BASE + 31L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_DMM_TEMPERATURE_THERMISTOR_A          (IVI_SPECIFIC_ATTR_BASE + 94L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_DMM_TEMPERATURE_THERMISTOR_B          (IVI_SPECIFIC_ATTR_BASE + 95L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_DMM_TEMPERATURE_THERMISTOR_C          (IVI_SPECIFIC_ATTR_BASE + 96L)  /* ViReal64, read-write */

    /*- Thermocouple */

#define VTEXSCANNER_ATTR_DMM_TEMPERATURE_THERMOCOUPLE_FIXED_REF_JUNCTION (IVI_SPECIFIC_ATTR_BASE + 32L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_DMM_TEMPERATURE_THERMOCOUPLE_REF_JUNCTION_TYPE  (IVI_SPECIFIC_ATTR_BASE + 33L)  /* ViInt32, read-write */
#define VTEXSCANNER_ATTR_DMM_TEMPERATURE_THERMOCOUPLE_TYPE               (IVI_SPECIFIC_ATTR_BASE + 34L)  /* ViInt32, read-write */

    /*- Trigger */

#define VTEXSCANNER_ATTR_DMM_TRIGGER_DELAY                  (IVI_SPECIFIC_ATTR_BASE + 14L)  /* ViReal64, read-write */

    /*- Configuration */

#define VTEXSCANNER_ATTR_DMM_CONFIGURATION_COUNT            (IVI_SPECIFIC_ATTR_BASE + 37L)  /* ViInt32, read-only */
#define VTEXSCANNER_ATTR_DMM_CONFIGURATION_LIST             (IVI_SPECIFIC_ATTR_BASE + 38L)  /* ViString, read-only */

    /*- Math */

#define VTEXSCANNER_ATTR_DMM_MATH_FACTOR                    (IVI_SPECIFIC_ATTR_BASE + 82L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_DMM_MATH_OFFSET                    (IVI_SPECIFIC_ATTR_BASE + 83L)  /* ViReal64, read-write */

    /*- Limit */

#define VTEXSCANNER_ATTR_DMM_LIMIT_HIGH                     (IVI_SPECIFIC_ATTR_BASE + 57L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_DMM_LIMIT_LOW                      (IVI_SPECIFIC_ATTR_BASE + 80L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_DMM_LIMIT_DEST                     (IVI_SPECIFIC_ATTR_BASE + 81L)  /* ViInt32, read-write */

    /*- System */

#define VTEXSCANNER_ATTR_SYSTEM_LXI_DOMAIN                  (IVI_SPECIFIC_ATTR_BASE + 12L)  /* ViInt32, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_SYSTEM_INVENTORY            (IVI_SPECIFIC_ATTR_BASE + 29L)  /* ViString, read-only */

    /*- Arm */

#define VTEXSCANNER_ATTR_SYSTEM_ARM_ARM_COUNT               (IVI_SPECIFIC_ATTR_BASE + 13L)  /* ViInt32, read-write */

    /*- Alarm */

#define VTEXSCANNER_ATTR_SYSTEM_ARM_ALARM_ENABLED           (IVI_SPECIFIC_ATTR_BASE + 58L)  /* ViBoolean, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_ARM_ALARM_TIME_SECONDS      (IVI_SPECIFIC_ATTR_BASE + 59L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_ARM_ALARM_TIME_FRACTION     (IVI_SPECIFIC_ATTR_BASE + 60L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_ARM_ALARM_PERIOD            (IVI_SPECIFIC_ATTR_BASE + 61L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_ARM_ALARM_REPEAT_COUNT      (IVI_SPECIFIC_ATTR_BASE + 62L)  /* ViInt32, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_ARM_ALARM_COUNT             (IVI_SPECIFIC_ATTR_BASE + 1004L)  /* ViInt32, read-only */

    /*- Source */

#define VTEXSCANNER_ATTR_SYSTEM_ARM_SOURCE_ENABLED          (IVI_SPECIFIC_ATTR_BASE + 63L)  /* ViBoolean, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_ARM_SOURCE_DETECTION        (IVI_SPECIFIC_ATTR_BASE + 64L)  /* ViInt32, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_ARM_SOURCE_FILTER           (IVI_SPECIFIC_ATTR_BASE + 65L)  /* ViString, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_ARM_SOURCE_EVENT_ID         (IVI_SPECIFIC_ATTR_BASE + 66L)  /* ViString, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_ARM_SOURCE_COUNT            (IVI_SPECIFIC_ATTR_BASE + 1005L)  /* ViInt32, read-only */

    /*- Sources */

#define VTEXSCANNER_ATTR_SYSTEM_ARM_SOURCES_OR_ENABLED      (IVI_SPECIFIC_ATTR_BASE + 67L)  /* ViBoolean, read-write */

    /*- Trigger */

#define VTEXSCANNER_ATTR_SYSTEM_TRIGGER_TRIGGER_COUNT       (IVI_SPECIFIC_ATTR_BASE + 15L)  /* ViInt32, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_TRIGGER_TRIGGER_SOURCE      (IVI_SPECIFIC_ATTR_BASE + 16L)  /* ViString, read-write */

    /*- Alarm */

#define VTEXSCANNER_ATTR_SYSTEM_TRIGGER_ALARM_ENABLED       (IVI_SPECIFIC_ATTR_BASE + 71L)  /* ViBoolean, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_TRIGGER_ALARM_TIME_SECONDS  (IVI_SPECIFIC_ATTR_BASE + 72L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_TRIGGER_ALARM_TIME_FRACTION (IVI_SPECIFIC_ATTR_BASE + 73L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_TRIGGER_ALARM_PERIOD        (IVI_SPECIFIC_ATTR_BASE + 74L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_TRIGGER_ALARM_REPEAT_COUNT  (IVI_SPECIFIC_ATTR_BASE + 75L)  /* ViInt32, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_TRIGGER_ALARM_COUNT         (IVI_SPECIFIC_ATTR_BASE + 1002L)  /* ViInt32, read-only */

    /*- Source */

#define VTEXSCANNER_ATTR_SYSTEM_TRIGGER_SOURCE_DELAY        (IVI_SPECIFIC_ATTR_BASE + 76L)  /* ViReal64, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_TRIGGER_SOURCE_FILTER       (IVI_SPECIFIC_ATTR_BASE + 77L)  /* ViString, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_TRIGGER_SOURCE_EVENT_ID     (IVI_SPECIFIC_ATTR_BASE + 78L)  /* ViString, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_TRIGGER_SOURCE_DETECTION    (IVI_SPECIFIC_ATTR_BASE + 79L)  /* ViInt32, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_TRIGGER_SOURCE_COUNT        (IVI_SPECIFIC_ATTR_BASE + 1003L)  /* ViInt32, read-only */

    /*- EventLog */

#define VTEXSCANNER_ATTR_SYSTEM_EVENTLOG_ENABLED            (IVI_SPECIFIC_ATTR_BASE + 17L)  /* ViBoolean, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_EVENTLOG_ENTRY_COUNT        (IVI_SPECIFIC_ATTR_BASE + 18L)  /* ViInt32, read-only */
#define VTEXSCANNER_ATTR_SYSTEM_EVENTLOG_OVERFLOW_MODE      (IVI_SPECIFIC_ATTR_BASE + 89L)  /* ViInt32, read-write */

    /*- Time */

#define VTEXSCANNER_ATTR_SYSTEM_TIME_IS_MASTER              (IVI_SPECIFIC_ATTR_BASE + 19L)  /* ViBoolean, read-only */
#define VTEXSCANNER_ATTR_SYSTEM_TIME_IS_SYNCHRONIZED        (IVI_SPECIFIC_ATTR_BASE + 20L)  /* ViBoolean, read-only */

    /*- Event */

#define VTEXSCANNER_ATTR_SYSTEM_EVENT_SOURCE                (IVI_SPECIFIC_ATTR_BASE + 35L)  /* ViString, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_EVENT_DRIVE_MODE            (IVI_SPECIFIC_ATTR_BASE + 68L)  /* ViInt32, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_EVENT_DESTINATION_PATH      (IVI_SPECIFIC_ATTR_BASE + 69L)  /* ViString, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_EVENT_SLOPE                 (IVI_SPECIFIC_ATTR_BASE + 70L)  /* ViInt32, read-write */
#define VTEXSCANNER_ATTR_SYSTEM_EVENT_COUNT                 (IVI_SPECIFIC_ATTR_BASE + 1001L)  /* ViInt32, read-only */

    /*- Events */

#define VTEXSCANNER_ATTR_SYSTEM_EVENTS_WIRED_OR_BIAS_MODE   (IVI_SPECIFIC_ATTR_BASE + 21L)  /* ViInt32, read-write */





    /****************************************************************************
    *----------------- Instrument Error And Completion Codes ------------------*
    ****************************************************************************/
#ifndef _IVIC_ERROR_BASE_DEFINES_
#define _IVIC_ERROR_BASE_DEFINES_

#define IVIC_WARN_BASE                           (0x3FFA0000L)
#define IVIC_CROSS_CLASS_WARN_BASE               (IVIC_WARN_BASE + 0x1000)
#define IVIC_CLASS_WARN_BASE                     (IVIC_WARN_BASE + 0x2000)
#define IVIC_SPECIFIC_WARN_BASE                  (IVIC_WARN_BASE + 0x4000)

#define IVIC_ERROR_BASE                          (-1074135040L)
#define IVIC_CROSS_CLASS_ERROR_BASE              (IVIC_ERROR_BASE + 0x1000)
#define IVIC_CLASS_ERROR_BASE                    (IVIC_ERROR_BASE + 0x2000)
#define IVIC_SPECIFIC_ERROR_BASE                 (IVIC_ERROR_BASE + 0x4000)
#define IVIC_LXISYNC_ERROR_BASE                  (IVIC_ERROR_BASE + 0x2000)

#define IVIC_ERROR_INVALID_ATTRIBUTE             (IVIC_ERROR_BASE + 0x000C)
#define IVIC_ERROR_TYPES_DO_NOT_MATCH            (IVIC_ERROR_BASE + 0x0015)
#define IVIC_ERROR_IVI_ATTR_NOT_WRITABLE         (IVIC_ERROR_BASE + 0x000D)
#define IVIC_ERROR_IVI_ATTR_NOT_READABLE         (IVIC_ERROR_BASE + 0x000E)
#define IVIC_ERROR_INVALID_SESSION_HANDLE        (IVIC_ERROR_BASE + 0x1190)

#endif


#define VTEXSCANNER_ERROR_CANNOT_RECOVER                       ((ViStatus)(IVIC_ERROR_BASE + 0x0000))
#define VTEXSCANNER_ERROR_INSTRUMENT_STATUS                    ((ViStatus)(IVIC_ERROR_BASE + 0x0001))
#define VTEXSCANNER_ERROR_CANNOT_OPEN_FILE                     ((ViStatus)(IVIC_ERROR_BASE + 0x0002))
#define VTEXSCANNER_ERROR_READING_FILE                         ((ViStatus)(IVIC_ERROR_BASE + 0x0003))
#define VTEXSCANNER_ERROR_WRITING_FILE                         ((ViStatus)(IVIC_ERROR_BASE + 0x0004))
#define VTEXSCANNER_ERROR_INVALID_PATHNAME                     ((ViStatus)(IVIC_ERROR_BASE + 0x000B))
#define VTEXSCANNER_ERROR_INVALID_VALUE                        ((ViStatus)(IVIC_ERROR_BASE + 0x0010))
#define VTEXSCANNER_ERROR_FUNCTION_NOT_SUPPORTED               ((ViStatus)(IVIC_ERROR_BASE + 0x0011))
#define VTEXSCANNER_ERROR_ATTRIBUTE_NOT_SUPPORTED              ((ViStatus)(IVIC_ERROR_BASE + 0x0012))
#define VTEXSCANNER_ERROR_VALUE_NOT_SUPPORTED                  ((ViStatus)(IVIC_ERROR_BASE + 0x0013))
#define VTEXSCANNER_ERROR_NOT_INITIALIZED                      ((ViStatus)(IVIC_ERROR_BASE + 0x001D))
#define VTEXSCANNER_ERROR_UNKNOWN_CHANNEL_NAME                 ((ViStatus)(IVIC_ERROR_BASE + 0x0020))
#define VTEXSCANNER_ERROR_TOO_MANY_OPEN_FILES                  ((ViStatus)(IVIC_ERROR_BASE + 0x0023))
#define VTEXSCANNER_ERROR_CHANNEL_NAME_REQUIRED                ((ViStatus)(IVIC_ERROR_BASE + 0x0044))
#define VTEXSCANNER_ERROR_MISSING_OPTION_NAME                  ((ViStatus)(IVIC_ERROR_BASE + 0x0049))
#define VTEXSCANNER_ERROR_MISSING_OPTION_VALUE                 ((ViStatus)(IVIC_ERROR_BASE + 0x004A))
#define VTEXSCANNER_ERROR_BAD_OPTION_NAME                      ((ViStatus)(IVIC_ERROR_BASE + 0x004B))
#define VTEXSCANNER_ERROR_BAD_OPTION_VALUE                     ((ViStatus)(IVIC_ERROR_BASE + 0x004C))
#define VTEXSCANNER_ERROR_OUT_OF_MEMORY                        ((ViStatus)(IVIC_ERROR_BASE + 0x0056))
#define VTEXSCANNER_ERROR_OPERATION_PENDING                    ((ViStatus)(IVIC_ERROR_BASE + 0x0057))
#define VTEXSCANNER_ERROR_NULL_POINTER                         ((ViStatus)(IVIC_ERROR_BASE + 0x0058))
#define VTEXSCANNER_ERROR_UNEXPECTED_RESPONSE                  ((ViStatus)(IVIC_ERROR_BASE + 0x0059))
#define VTEXSCANNER_ERROR_FILE_NOT_FOUND                       ((ViStatus)(IVIC_ERROR_BASE + 0x005B))
#define VTEXSCANNER_ERROR_INVALID_FILE_FORMAT                  ((ViStatus)(IVIC_ERROR_BASE + 0x005C))
#define VTEXSCANNER_ERROR_STATUS_NOT_AVAILABLE                 ((ViStatus)(IVIC_ERROR_BASE + 0x005D))
#define VTEXSCANNER_ERROR_ID_QUERY_FAILED                      ((ViStatus)(IVIC_ERROR_BASE + 0x005E))
#define VTEXSCANNER_ERROR_RESET_FAILED                         ((ViStatus)(IVIC_ERROR_BASE + 0x005F))
#define VTEXSCANNER_ERROR_RESOURCE_UNKNOWN                     ((ViStatus)(IVIC_ERROR_BASE + 0x0060))
#define VTEXSCANNER_ERROR_ALREADY_INITIALIZED                  ((ViStatus)(IVIC_ERROR_BASE + 0x0061))
#define VTEXSCANNER_ERROR_CANNOT_CHANGE_SIMULATION_STATE       ((ViStatus)(IVIC_ERROR_BASE + 0x0062))
#define VTEXSCANNER_ERROR_INVALID_NUMBER_OF_LEVELS_IN_SELECTOR ((ViStatus)(IVIC_ERROR_BASE + 0x0063))
#define VTEXSCANNER_ERROR_INVALID_RANGE_IN_SELECTOR            ((ViStatus)(IVIC_ERROR_BASE + 0x0064))
#define VTEXSCANNER_ERROR_UNKOWN_NAME_IN_SELECTOR              ((ViStatus)(IVIC_ERROR_BASE + 0x0065))
#define VTEXSCANNER_ERROR_BADLY_FORMED_SELECTOR                ((ViStatus)(IVIC_ERROR_BASE + 0x0066))
#define VTEXSCANNER_ERROR_UNKNOWN_PHYSICAL_IDENTIFIER          ((ViStatus)(IVIC_ERROR_BASE + 0x0067))



#define VTEXSCANNER_SUCCESS                                 0
#define VTEXSCANNER_WARN_NSUP_ID_QUERY                      (IVIC_WARN_BASE + 0x0065)
#define VTEXSCANNER_WARN_NSUP_RESET                         (IVIC_WARN_BASE + 0x0066)
#define VTEXSCANNER_WARN_NSUP_SELF_TEST                     (IVIC_WARN_BASE + 0x0067)
#define VTEXSCANNER_WARN_NSUP_ERROR_QUERY                   (IVIC_WARN_BASE + 0x0068)
#define VTEXSCANNER_WARN_NSUP_REV_QUERY                     (IVIC_WARN_BASE + 0x0069)



#define VTEXSCANNER_ERROR_PERSONALITY_NOT_ACTIVE            ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0211))
#define VTEXSCANNER_ERROR_PERSONALITY_NOT_INSTALLED         ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0212))
#define VTEXSCANNER_ERROR_PERSONALITY_NOT_LICENSED          ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0213))
#define VTEXSCANNER_ERROR_IO_GENERAL                        ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0214))
#define VTEXSCANNER_ERROR_IO_TIMEOUT                        ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0215))
#define VTEXSCANNER_ERROR_MODEL_NOT_SUPPORTED               ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0216))
#define VTEXSCANNER_ERROR_WRAPPED_DRIVER_ERROR              ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0218))
#define VTEXSCANNER_ERROR_SPECIFIC_DRIVER_EXCEPTION         ((ViStatus)(IVIC_SPECIFIC_ERROR_BASE + 0x0001))

    SCANNERTEST_API ViStatus VTEXScanner_InitWithOptions(ViRsrc ResourceName, ViBoolean IdQuery, ViBoolean Reset, ViConstString OptionsString, ViSession* Vi);

    SCANNERTEST_API ViStatus VTEXScanner_init(ViRsrc ResourceName, ViBoolean IdQuery, ViBoolean Reset, ViSession* Vi);
    SCANNERTEST_API ViStatus VTEXScanner_close(ViSession Vi);
    SCANNERTEST_API ViStatus VTEXScanner_Abort(ViSession Vi);
    SCANNERTEST_API ViStatus VTEXScanner_Add(ViSession Vi, ViConstString SetupPhase, ViConstString SweepPhase);
    SCANNERTEST_API ViStatus VTEXScanner_Clear(ViSession Vi);
    SCANNERTEST_API ViStatus VTEXScanner_Initiate(ViSession Vi);
    SCANNERTEST_API ViStatus VTEXScanner_Read(ViSession Vi, ViInt32 MaxTimeMilliseconds, ViInt32 Count, ViInt32 DataBufferSize, ViReal64 Data[], ViInt32* DataActualSize, ViInt32 TimeSecondsBufferSize, ViReal64 TimeSeconds[], ViInt32* TimeSecondsActualSize, ViInt32 TimeFractionBufferSize, ViReal64 TimeFraction[], ViInt32* TimeFractionActualSize);
    SCANNERTEST_API ViStatus VTEXScanner_SendSoftwareTrigger(ViSession Vi);
    SCANNERTEST_API ViStatus VTEXScanner_WaitForScanComplete(ViSession Vi, ViInt32 MaxTimeMilliseconds);
    SCANNERTEST_API ViStatus VTEXScanner_FIFOClear(ViSession Vi);

    /*- Utility */

    SCANNERTEST_API ViStatus VTEXScanner_revision_query(ViSession Vi, ViChar DriverRev[], ViChar InstrRev[]);
    SCANNERTEST_API ViStatus VTEXScanner_error_message(ViSession Vi, ViStatus ErrorCode, ViChar ErrorMessage[]);
    SCANNERTEST_API ViStatus VTEXScanner_GetError(ViSession Vi, ViStatus* ErrorCode, ViInt32 ErrorDescriptionBufferSize, ViChar ErrorDescription[]);
    SCANNERTEST_API ViStatus VTEXScanner_ClearError(ViSession Vi);
    SCANNERTEST_API ViStatus VTEXScanner_ClearInterchangeWarnings(ViSession Vi);
    SCANNERTEST_API ViStatus VTEXScanner_GetNextCoercionRecord(ViSession Vi, ViInt32 CoercionRecordBufferSize, ViChar CoercionRecord[]);
    SCANNERTEST_API ViStatus VTEXScanner_GetNextInterchangeWarning(ViSession Vi, ViInt32 InterchangeWarningBufferSize, ViChar InterchangeWarning[]);
    SCANNERTEST_API ViStatus VTEXScanner_InvalidateAllAttributes(ViSession Vi);
    SCANNERTEST_API ViStatus VTEXScanner_ResetInterchangeCheck(ViSession Vi);
    SCANNERTEST_API ViStatus VTEXScanner_Disable(ViSession Vi);
    SCANNERTEST_API ViStatus VTEXScanner_error_query(ViSession Vi, ViInt32* ErrorCode, ViChar ErrorMessage[]);
    SCANNERTEST_API ViStatus VTEXScanner_LockSession(ViSession Vi, ViBoolean* CallerHasLock);
    SCANNERTEST_API ViStatus VTEXScanner_reset(ViSession Vi);
    SCANNERTEST_API ViStatus VTEXScanner_ResetWithDefaults(ViSession Vi);
    SCANNERTEST_API ViStatus VTEXScanner_self_test(ViSession Vi, ViInt16* TestResult, ViChar TestMessage[]);
    SCANNERTEST_API ViStatus VTEXScanner_UnlockSession(ViSession Vi, ViBoolean* CallerHasLock);

    /*- Attribute Accessors */

    SCANNERTEST_API ViStatus VTEXScanner_GetAttributeViInt32(ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViInt32* AttributeValue);
    SCANNERTEST_API ViStatus VTEXScanner_GetAttributeViReal64(ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViReal64* AttributeValue);
    SCANNERTEST_API ViStatus VTEXScanner_GetAttributeViBoolean(ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViBoolean* AttributeValue);
    SCANNERTEST_API ViStatus VTEXScanner_GetAttributeViSession(ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViSession* AttributeValue);
    SCANNERTEST_API ViStatus VTEXScanner_GetAttributeViString(ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViInt32 AttributeValueBufferSize, ViChar AttributeValue[]);
    SCANNERTEST_API ViStatus VTEXScanner_SetAttributeViInt32(ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViInt32 AttributeValue);
    SCANNERTEST_API ViStatus VTEXScanner_SetAttributeViReal64(ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViReal64 AttributeValue);
    SCANNERTEST_API ViStatus VTEXScanner_SetAttributeViBoolean(ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViBoolean AttributeValue);
    SCANNERTEST_API ViStatus VTEXScanner_SetAttributeViSession(ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViSession AttributeValue);
    SCANNERTEST_API ViStatus VTEXScanner_SetAttributeViString(ViSession Vi, ViConstString RepCapIdentifier, ViAttr AttributeID, ViConstString AttributeValue);

    /*- Switch */

    SCANNERTEST_API ViStatus VTEXScanner_SwitchExternalConnection(ViSession Vi, ViConstString Channel1, ViConstString Channel2);
    SCANNERTEST_API ViStatus VTEXScanner_SwitchAddPathLevelExcludeList(ViSession Vi, ViConstString ExcludeList, ViConstString Name);
    SCANNERTEST_API ViStatus VTEXScanner_SwitchRemovePathLevelExcludeList(ViSession Vi, ViConstString Name);

    /*- Channel */

    SCANNERTEST_API ViStatus VTEXScanner_GetSwitchChannelName(ViSession Vi, ViInt32 Index, ViInt32 NameBufferSize, ViChar Name[]);

    /*- Dmm */

    SCANNERTEST_API ViStatus VTEXScanner_Configure(ViSession Vi, ViInt32 Function, ViReal64 Range, ViReal64 Resolution);

    /*- AC */

    SCANNERTEST_API ViStatus VTEXScanner_DmmACConfigureBandwidth(ViSession Vi, ViReal64 MinFreq, ViReal64 MaxFreq);

    /*- RTD */

    SCANNERTEST_API ViStatus VTEXScanner_DmmTemperatureRTDConfigure(ViSession Vi, ViReal64 Alpha, ViReal64 Resistance);

    /*- Thermocouple */

    SCANNERTEST_API ViStatus VTEXScanner_DmmTemperatureThermocoupleConfigure(ViSession Vi, ViInt32 Type, ViInt32 RefJunctionType);

    /*- Configuration */

    SCANNERTEST_API ViStatus VTEXScanner_DmmConfigurationSave(ViSession Vi, ViConstString Config);
    SCANNERTEST_API ViStatus VTEXScanner_DmmConfigurationDelete(ViSession Vi, ViConstString Config);
    SCANNERTEST_API ViStatus VTEXScanner_DmmConfigurationDeleteAll(ViSession Vi);
    SCANNERTEST_API ViStatus VTEXScanner_DmmConfigurationExists(ViSession Vi, ViConstString Config, ViBoolean* RetVal);

    /*- Alarm */

    SCANNERTEST_API ViStatus VTEXScanner_SystemArmAlarmConfigure(ViSession Vi, ViConstString RepCapIdentifier, ViBoolean Enabled, ViReal64 TimeSeconds, ViReal64 TimeFraction, ViReal64 Period, ViInt32 RepeatCount);
    SCANNERTEST_API ViStatus VTEXScanner_GetArmAlarmName(ViSession Vi, ViInt32 Index, ViInt32 NameBufferSize, ViChar Name[]);

    /*- Alarms */

    SCANNERTEST_API ViStatus VTEXScanner_SystemArmAlarmsDisableAll(ViSession Vi);

    /*- Source */

    SCANNERTEST_API ViStatus VTEXScanner_SystemArmSourceConfigure(ViSession Vi, ViConstString RepCapIdentifier, ViBoolean Enabled, ViInt32 Detection);
    SCANNERTEST_API ViStatus VTEXScanner_GetArmSourceName(ViSession Vi, ViInt32 Index, ViInt32 NameBufferSize, ViChar Name[]);

    /*- Sources */

    SCANNERTEST_API ViStatus VTEXScanner_SystemArmSourcesDisableAll(ViSession Vi);

    /*- Alarm */

    SCANNERTEST_API ViStatus VTEXScanner_SystemTriggerAlarmConfigure(ViSession Vi, ViConstString RepCapIdentifier, ViReal64 TimeSeconds, ViReal64 TimeFraction, ViReal64 Period, ViInt32 RepeatCount);
    SCANNERTEST_API ViStatus VTEXScanner_GetTriggerAlarmName(ViSession Vi, ViInt32 Index, ViInt32 NameBufferSize, ViChar Name[]);

    /*- Alarms */

    SCANNERTEST_API ViStatus VTEXScanner_SystemTriggerAlarmsDisableAll(ViSession Vi);

    /*- Source */

    SCANNERTEST_API ViStatus VTEXScanner_SystemTriggerSourceConfigure(ViSession Vi, ViConstString RepCapIdentifier, ViReal64 Delay, ViInt32 Detection);
    SCANNERTEST_API ViStatus VTEXScanner_GetTriggerSourceName(ViSession Vi, ViInt32 Index, ViInt32 NameBufferSize, ViChar Name[]);

    /*- EventLog */

    SCANNERTEST_API ViStatus VTEXScanner_SystemEventLogClear(ViSession Vi);
    SCANNERTEST_API ViStatus VTEXScanner_SystemEventLogGetNextEntry(ViSession Vi, ViInt32 RetValBufferSize, ViChar RetVal[]);

    /*- Time */

    SCANNERTEST_API ViStatus VTEXScanner_SystemTimeGetSystemTime(ViSession Vi, ViReal64* TimeSeconds, ViReal64* TimeFraction);

    /*- Event */

    SCANNERTEST_API ViStatus VTEXScanner_SystemEventConfigure(ViSession Vi, ViConstString RepCapIdentifier, ViInt32 DriveMode, ViConstString Source, ViConstString DestinationPath, ViInt32 Slope);
    SCANNERTEST_API ViStatus VTEXScanner_GetEventName(ViSession Vi, ViInt32 Index, ViInt32 NameBufferSize, ViChar Name[]);

    /*- Events */

    SCANNERTEST_API ViStatus VTEXScanner_SystemEventsDisableAll(ViSession Vi);

    /****************************************************************************
    *---------------------------- End Include File ----------------------------*
    ****************************************************************************/
#if defined(__cplusplus) || defined(__cplusplus__)
}
#endif
#endif // __VTEXSCANNER_HEADER
