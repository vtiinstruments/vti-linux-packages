/******************************************************************************
 *
 *  .----------------------.	File Name: libScannerDmm.h
 *  |==     ==  ======  == |	Project : EX Platform
 *  | ==   ==   ======  == |	$Author$
 *  |  == ==      ==    == |	$Revision$
 *  |   ===       ==    == |	$Date$
 *  |    =        ==    == |
 *  `----------------------'
 *
 * Copyright 2006 VXI Technology Inc. as an unpublished work.
 * All rights reserved. The information contained herein is confidential
 * property of VXI Technology, Inc. Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement
 * with VXI Technology, Inc.
 *
 * PURPOSE:
 *   Main public interface file for the Dmm library.
 *
 * First Written By: Gershon Shamay On Jan-2007
 ******************************************************************************/
#ifndef		_LIB_SCANNER_DMM_H
#define		_LIB_SCANNER_DMM_H

/*******************
 * System header
 *******************/
#include <string>
#include <vector>


/*******************
 * Local header
 *******************/
#include "vtexapi.h"
#ifndef _ATL_ATTRIBUTES
    #include "ScannerConstants.h"
#endif
#include "property.h"


class VTEX_API LibScannerDmmAC
{
    public:
	    virtual ~LibScannerDmmAC() {};
    	
        //Datamembers
        property <LibScannerDmmAC, double, READ_WRITE> FrequencyMax;
	    property <LibScannerDmmAC, double, READ_WRITE> FrequencyMin;

        //Methods
	    virtual VTEXResult ConfigureBandwidth (double MinFreq, double MaxFreq) = 0;
	    virtual VTEXResult get_FrequencyMax (double *val) = 0;
	    virtual VTEXResult put_FrequencyMax (double val) = 0;
	    virtual VTEXResult get_FrequencyMin (double *val) = 0;
	    virtual VTEXResult put_FrequencyMin (double val) = 0;
};


class VTEX_API LibScannerDmmAdvanced
{
    public:
	    virtual ~LibScannerDmmAdvanced() {};
    	
        //Datamembers
        property <LibScannerDmmAdvanced, double, READ_ONLY> ApertureTime;
        property <LibScannerDmmAdvanced, enum VTEXScannerDmmApertureTimeUnitsEnum, READ_ONLY> ApertureTimeUnits;
        property <LibScannerDmmAdvanced, enum VTEXScannerDmmAutoZeroEnum, READ_WRITE> AutoZero;
	    property <LibScannerDmmAdvanced, double, READ_WRITE> PowerlineFrequency;

        //Methods
	    virtual VTEXResult get_ApertureTime(double *val) = 0;
	    virtual VTEXResult get_ApertureTimeUnits(enum VTEXScannerDmmApertureTimeUnitsEnum *val) = 0;
	    virtual VTEXResult get_AutoZero(enum VTEXScannerDmmAutoZeroEnum *val) = 0;
	    virtual VTEXResult put_AutoZero(enum VTEXScannerDmmAutoZeroEnum val) = 0;
	    virtual VTEXResult get_PowerlineFrequency(double *val) = 0;
	    virtual VTEXResult put_PowerlineFrequency(double val) = 0;
};


class VTEX_API LibScannerDmmFrequency
{
    public:
	    virtual ~LibScannerDmmFrequency() {};

        //Datamembers
	    property <LibScannerDmmFrequency, double, READ_WRITE> VoltageRange;

        //Methods
        virtual VTEXResult get_VoltageRange (double *val) = 0;
	    virtual VTEXResult put_VoltageRange (double val) = 0;
};


class VTEX_API LibScannerDmmTemperatureThermistor
{
    public:
	    virtual ~LibScannerDmmTemperatureThermistor() {};

        //Datamembers
        property <LibScannerDmmTemperatureThermistor, double, READ_WRITE> Resistance;
        property <LibScannerDmmTemperatureThermistor, double, READ_WRITE> A;
        property <LibScannerDmmTemperatureThermistor, double, READ_WRITE> B;
        property <LibScannerDmmTemperatureThermistor, double, READ_WRITE> C;

        //Property Methods
	    virtual VTEXResult get_Resistance (double *val) = 0;
	    virtual VTEXResult put_Resistance (double val) = 0;
        virtual VTEXResult get_A (double *val) = 0;
        virtual VTEXResult put_A (double val) =0;
        virtual VTEXResult get_B (double *val) = 0;
        virtual VTEXResult put_B (double val) = 0;
        virtual VTEXResult get_C (double *val) = 0;
        virtual VTEXResult put_C (double val) = 0;
};


class VTEX_API LibScannerDmmTemperatureThermocouple
{
    public:
	    virtual ~LibScannerDmmTemperatureThermocouple() {};

        //Datamembers
        property <LibScannerDmmTemperatureThermocouple, double, READ_WRITE> FixedRefJunction;
	    property <LibScannerDmmTemperatureThermocouple, enum VTEXScannerDmmRefJunctionTypeEnum, READ_WRITE> RefJunctionType;
	    property <LibScannerDmmTemperatureThermocouple, enum VTEXScannerDmmThermocoupleTypeEnum, READ_WRITE> Type;

        //Methods
	    virtual VTEXResult Configure (enum VTEXScannerDmmThermocoupleTypeEnum Type, 
                                      enum VTEXScannerDmmRefJunctionTypeEnum RefJunctionType) = 0;
	    virtual VTEXResult get_FixedRefJunction (double *val) = 0;
	    virtual VTEXResult put_FixedRefJunction (double val) = 0;
	    virtual VTEXResult get_RefJunctionType (enum VTEXScannerDmmRefJunctionTypeEnum *val) = 0;
	    virtual VTEXResult put_RefJunctionType (enum VTEXScannerDmmRefJunctionTypeEnum val) = 0;
	    virtual VTEXResult get_Type (enum VTEXScannerDmmThermocoupleTypeEnum *val) = 0;
	    virtual VTEXResult put_Type (enum VTEXScannerDmmThermocoupleTypeEnum val) = 0;
};


class VTEX_API LibScannerDmmTemperatureRTD
{
    public:
	    virtual ~LibScannerDmmTemperatureRTD() {};

        //Datamembers
        property <LibScannerDmmTemperatureRTD, double, READ_WRITE> Alpha;
        property <LibScannerDmmTemperatureRTD, double, READ_WRITE> Beta;
        property <LibScannerDmmTemperatureRTD, double, READ_WRITE> Delta;
	    property <LibScannerDmmTemperatureRTD, double, READ_WRITE> Resistance;
        property <LibScannerDmmTemperatureRTD, enum VTEXScannerDmmRtdTypeEnum, READ_WRITE> Type;

        //Methods
	    virtual VTEXResult Configure (double Alpha, double Resistance) = 0;

        //Property Methods
	    virtual VTEXResult get_Alpha (double *val) = 0;
	    virtual VTEXResult put_Alpha (double val) = 0;
        virtual VTEXResult get_Beta (double *val) = 0;
	    virtual VTEXResult put_Beta (double val) = 0;
        virtual VTEXResult get_Delta (double *val) = 0;
	    virtual VTEXResult put_Delta (double val) = 0;
	    virtual VTEXResult get_Resistance (double *val) = 0;
	    virtual VTEXResult put_Resistance (double val) = 0;
        virtual VTEXResult get_Type (enum VTEXScannerDmmRtdTypeEnum* val) = 0;
	    virtual VTEXResult put_Type (enum VTEXScannerDmmRtdTypeEnum val) = 0;
};


class VTEX_API LibScannerDmmTemperature
{
    public:
	    virtual ~LibScannerDmmTemperature() {};

        //Datamembers
	    property <LibScannerDmmTemperature, enum VTEXScannerDmmTransducerTypeEnum, READ_WRITE> TransducerType;
        property <LibScannerDmmTemperature, bool, READ_WRITE> IsReferenceJunction;

        LibScannerDmmTemperatureRTD* RTD;
	    LibScannerDmmTemperatureThermistor* Thermistor;
	    LibScannerDmmTemperatureThermocouple* Thermocouple;

        //Property Methods
	    virtual VTEXResult get_TransducerType (enum VTEXScannerDmmTransducerTypeEnum *val) = 0;
	    virtual VTEXResult put_TransducerType (enum VTEXScannerDmmTransducerTypeEnum val) = 0;
        virtual VTEXResult get_IsReferenceJunction (bool* val) = 0;
        virtual VTEXResult put_IsReferenceJunction (bool val) = 0;
};

class VTEX_API LibScannerDmmTrigger
{
    public:
        virtual ~LibScannerDmmTrigger() {};
	    property <LibScannerDmmTrigger, double, READ_WRITE> Delay;

        virtual VTEXResult get_Delay (double *val) = 0;
	    virtual VTEXResult put_Delay (double val) = 0;
};


class VTEX_API LibScannerDmmConfig
{
    public:
	    virtual ~LibScannerDmmConfig(){};

	    //Attributes
	    property <LibScannerDmmConfig, int32_t, READ_ONLY> Count;
	    property <LibScannerDmmConfig, VTEXString, READ_ONLY> List;

  	    //Methods
	    virtual VTEXResult Load(const VTEXString val) = 0;
	    virtual VTEXResult Save(const VTEXString val) = 0;
	    virtual VTEXResult Delete(const VTEXString val) = 0;
	    virtual VTEXResult DeleteAll() = 0;
	    virtual bool Exists(const VTEXString val) = 0;

	    virtual VTEXResult get_Count(int32_t* val) = 0;
	    virtual VTEXResult get_List(VTEXString *val) = 0;
};


class VTEX_API LibScannerDmmMath
{
    public:
	    virtual ~LibScannerDmmMath() { };

	    virtual VTEXResult get_Factor(double *val) = 0;
	    virtual VTEXResult put_Factor(double val) = 0;
	    virtual VTEXResult get_Offset(double *val) = 0;
	    virtual VTEXResult put_Offset(double val) = 0;
    	
	    property <LibScannerDmmMath, double, READ_WRITE> Factor;
	    property <LibScannerDmmMath, double, READ_WRITE> Offset;
};

class VTEX_API LibScannerDmmLimit
{
    public:
	    virtual ~LibScannerDmmLimit() { };
    	
	    virtual VTEXResult get_High (double *val) = 0;
	    virtual VTEXResult put_High (double val) = 0;
	    virtual VTEXResult get_Low (double *val) = 0;
	    virtual VTEXResult put_Low (double val) = 0;
	    virtual VTEXResult get_Dest (VTEXScannerDmmSampleLimitDestEnum *val) = 0;
	    virtual VTEXResult put_Dest (VTEXScannerDmmSampleLimitDestEnum val) = 0;
    	
	    property <LibScannerDmmLimit, double, READ_WRITE> High;
	    property <LibScannerDmmLimit, double, READ_WRITE> Low;
	    property <LibScannerDmmLimit, VTEXScannerDmmSampleLimitDestEnum, READ_WRITE> Dest;
};


class VTEX_API LibScannerDmm
{
    public:
	    virtual ~LibScannerDmm() {};
	    
        //Datamembers
	    property <LibScannerDmm, enum VTEXScannerDmmFunctionEnum, READ_WRITE> Function;
	    property <LibScannerDmm, double, READ_WRITE> Range;
	    property <LibScannerDmm, double, READ_WRITE> Resolution;
        property <LibScannerDmm, VTEXScannerDmmFunctionOptionEnum, READ_WRITE> FunctionOption;
        property <LibScannerDmm, double, READ_WRITE> RangeChangeDelay;


	    LibScannerDmmAC* AC;
	    LibScannerDmmAdvanced* Advanced;
	    LibScannerDmmFrequency* Frequency;
	    LibScannerDmmTemperature* Temperature;
        LibScannerDmmTrigger* Trigger;
		LibScannerDmmConfig* Configuration;
        LibScannerDmmMath* Math;
        LibScannerDmmLimit* Limit;

        //Methods
        virtual VTEXResult Configure(enum VTEXScannerDmmFunctionEnum Function, double Range, double Resolution) = 0;

	    virtual VTEXResult get_Function(enum VTEXScannerDmmFunctionEnum *val) = 0;
	    virtual VTEXResult put_Function(enum VTEXScannerDmmFunctionEnum val) = 0;
	    virtual VTEXResult get_Range (double *val) = 0;
	    virtual VTEXResult put_Range (double val) = 0;
	    virtual VTEXResult get_Resolution (double *val) = 0;
	    virtual VTEXResult put_Resolution (double val) = 0;
    	virtual VTEXResult get_FunctionOption (VTEXScannerDmmFunctionOptionEnum *val) = 0;
        virtual VTEXResult put_FunctionOption (VTEXScannerDmmFunctionOptionEnum val) = 0;
        virtual VTEXResult get_RangeChangeDelay(double *val) = 0;
        virtual VTEXResult put_RangeChangeDelay(double val) = 0;
};

#endif	/* _LIB_SCANNER_DMM_H */
