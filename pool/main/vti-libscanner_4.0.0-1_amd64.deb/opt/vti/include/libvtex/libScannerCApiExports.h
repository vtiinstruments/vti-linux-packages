#pragma once
#include "vtexVisaTypes.h"

#ifdef _WIN32
#ifdef SCANNERTEST_EXPORTS
#define SCANNERTEST_API __declspec(dllexport)
#elif defined(VTEX_DLL)
#define SCANNERTEST_API __declspec(dllimport)
#else
#define SCANNERTEST_API
#endif
#else
#define SCANNERTEST_API __attribute__((visibility("default")))
#endif
