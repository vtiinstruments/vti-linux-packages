/******************************************************************************
 *
 *  .----------------------.	
 *  |==     ==  ======  == |	$Author$
 *  | ==   ==   ======  == |	$Revision$ 
 *  |  == ==      ==    == |	$Date$ 
 *  |   ===       ==    == |	$HeadURL$
 *  |    =        ==    == |	
 *  `----------------------' 
 *
 * Copyright 2006 VXI Technology Inc. as an unpublished work.
 * All rights reserved. The information contained herein is confidential
 * property of VXI Technology, Inc. Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement
 * with VXI Technology, Inc.
 *
 * PURPOSE:
 *   System class defininition for within Scanner driver
 *
 * Note:
 *   A class definition for the Scanner to interface with LxiSync/System
 *
 * First Written By: Ben Fitzpatrick, Sept 17, 2008
 ******************************************************************************/
#ifndef _LIB_SCANNER_SYSTEM_H
#define _LIB_SCANNER_SYSTEM_H

/*******************
 * System header
 *******************/
#include <vector>


/*******************
 * Library header
 *******************/

/*******************
 * Macros
 ******************/

/*******************
 * Local header
 *******************/
#include "vtexapi.h"
#ifndef _ATL_ATTRIBUTES
    #include "ScannerConstants.h"
#endif

#include "property.h"
#include "array.h"
#include "exTypes.h"
#include "libInherent.h"


/***********************
 * Forward Declarations
 ***********************/


//Arm interface
class VTEX_API LibScannerSystemArmSource
{
	public:

		virtual ~LibScannerSystemArmSource() { };

		//Datamembers
		property <LibScannerSystemArmSource, bool, READ_WRITE> Enabled;
		property <LibScannerSystemArmSource, enum VTEXScannerSystemArmSourceDetectionEnum, READ_WRITE> Detection;
		property <LibScannerSystemArmSource, VTEXString, READ_WRITE> Filter;
		property <LibScannerSystemArmSource, VTEXString, READ_WRITE> EventId;

		//Methods
		virtual VTEXResult Configure(bool enabled, enum VTEXScannerSystemArmSourceDetectionEnum detection) = 0;

		virtual VTEXResult get_Enabled(bool* enabled) = 0;
		virtual VTEXResult put_Enabled(bool enabled) = 0;
		virtual VTEXResult get_Detection(enum VTEXScannerSystemArmSourceDetectionEnum* detection) = 0;
		virtual VTEXResult put_Detection(enum VTEXScannerSystemArmSourceDetectionEnum detection) = 0;
		virtual VTEXResult get_Filter(VTEXString* filter) = 0;
		virtual VTEXResult put_Filter(const VTEXString &filter) = 0;
		virtual VTEXResult get_EventId(VTEXString* eventID) = 0;
		virtual VTEXResult put_EventId(const VTEXString &eventID) = 0;
};


class VTEX_API LibScannerSystemArmSources
{
	public:
		virtual ~LibScannerSystemArmSources() { };

		//Datamembers
		property <LibScannerSystemArmSources, int32_t, READ_ONLY> Count;
		property <LibScannerSystemArmSources, bool, READ_WRITE> OrEnabled;
		arrayizer <LibScannerSystemArmSources, LibScannerSystemArmSource*, VTEXString>Item;
		arrayizer <LibScannerSystemArmSources, VTEXString, int32_t>Name;

		//Methods
		virtual VTEXResult DisableAll() = 0;
		virtual LibScannerSystemArmSource *get_Item(VTEXString name) = 0;
		virtual VTEXString get_Name(int32_t index) = 0;
		virtual VTEXResult get_Count(int32_t* count) = 0;
		virtual VTEXResult get_OrEnabled(bool* enabled) = 0;
		virtual VTEXResult put_OrEnabled(bool enabled) = 0;
};

class VTEX_API LibScannerSystemArmAlarm
{
	public:
		virtual ~LibScannerSystemArmAlarm() { };

		//Datamembers
		property <LibScannerSystemArmAlarm, bool, READ_WRITE> Enabled;
        property <LibScannerSystemArmAlarm, double, READ_WRITE> Period;
		property <LibScannerSystemArmAlarm, int32_t, READ_WRITE> RepeatCount;
        property <LibScannerSystemArmAlarm, double, READ_WRITE> TimeSeconds;
		property <LibScannerSystemArmAlarm, double, READ_WRITE> TimeFraction;

		//Methods
		virtual VTEXResult Configure(bool enabled, double seconds, double fractionalSeconds, double period, int32_t repeatCount)=0;
		virtual VTEXResult get_TimeSeconds(double* seconds) = 0;
		virtual VTEXResult put_TimeSeconds(double seconds) = 0;
		virtual VTEXResult get_TimeFraction(double* fraction) = 0;
		virtual VTEXResult put_TimeFraction(double fraction) = 0;
		virtual VTEXResult get_Period(double* period) = 0;
		virtual VTEXResult put_Period(double period) = 0;
		virtual VTEXResult get_RepeatCount(int32_t* count) = 0;
		virtual VTEXResult put_RepeatCount(int32_t count) = 0;
		virtual VTEXResult get_Enabled(bool* enabled) = 0;
		virtual VTEXResult put_Enabled(bool enabled) = 0;
};


class VTEX_API LibScannerSystemArmAlarms
{
	public:
		virtual ~LibScannerSystemArmAlarms() { };

		//Datamembers
		property <LibScannerSystemArmAlarms, int32_t, READ_ONLY> Count;
		arrayizer <LibScannerSystemArmAlarms, LibScannerSystemArmAlarm*, VTEXString> Item;
		arrayizer <LibScannerSystemArmAlarms, VTEXString, int32_t> Name;

		//Methods
		virtual VTEXResult DisableAll() = 0;
		virtual LibScannerSystemArmAlarm *get_Item(VTEXString name) = 0;
		virtual VTEXString get_Name(int32_t index) = 0;
		virtual VTEXResult get_Count(int32_t* count) = 0;
};


class VTEX_API LibScannerSystemArm
{
	public:
		virtual ~LibScannerSystemArm() { };

		//Datamembers
		LibScannerSystemArmSources *Sources;
		LibScannerSystemArmAlarms *Alarms;

		property <LibScannerSystemArm, int32_t, READ_WRITE> ArmCount;

		//Methods
		virtual VTEXResult get_ArmCount(int32_t* count) = 0;
		virtual VTEXResult put_ArmCount(int32_t count) = 0;
};


//EventLog interface
class VTEX_API LibScannerSystemEventLog
{
	public:
		virtual ~LibScannerSystemEventLog() { };

		//Datamembers
		property <LibScannerSystemEventLog, int32_t, READ_ONLY> EntryCount;
		property <LibScannerSystemEventLog, bool, READ_WRITE> Enabled;
		property <LibScannerSystemEventLog, enum VTEXScannerSystemEventLogOverflowEnum, READ_WRITE> OverflowMode;

		//Methods
		virtual VTEXString GetNextEntry() = 0;
		virtual VTEXResult Clear() = 0;

		virtual VTEXResult get_EntryCount(int32_t* count) = 0;
		virtual VTEXResult get_Enabled(bool* enabled) = 0;
		virtual VTEXResult put_Enabled(bool enabled) = 0;
		virtual VTEXResult get_OverflowMode(enum VTEXScannerSystemEventLogOverflowEnum* mode) = 0;
		virtual VTEXResult put_OverflowMode(enum VTEXScannerSystemEventLogOverflowEnum mode) = 0;
};


//Events interface
class VTEX_API LibScannerSystemEvent
{
	public:
		virtual ~LibScannerSystemEvent() { };

		//Datamembers
		property <LibScannerSystemEvent, VTEXString, READ_WRITE> DestinationPath;
		property <LibScannerSystemEvent, enum VTEXScannerSystemEventDriveModeEnum, READ_WRITE> DriveMode;
		property <LibScannerSystemEvent, enum VTEXScannerSystemSourceSlopeEnum, READ_WRITE> Slope;
		property <LibScannerSystemEvent, VTEXString, READ_WRITE> Source;

		//Methods
		virtual VTEXResult Configure(enum VTEXScannerSystemEventDriveModeEnum mode, 
				                     VTEXString source, 
				                     VTEXString path, 
				                     enum VTEXScannerSystemSourceSlopeEnum slope) = 0;

		virtual VTEXResult get_Source(VTEXString* source) = 0;
		virtual VTEXResult put_Source(const VTEXString &source) = 0;
		virtual VTEXResult get_DestinationPath(VTEXString* path) = 0;
		virtual VTEXResult put_DestinationPath(const VTEXString &path) = 0;
		virtual VTEXResult get_Slope(enum VTEXScannerSystemSourceSlopeEnum* slope) = 0;
		virtual VTEXResult put_Slope(enum VTEXScannerSystemSourceSlopeEnum slope) = 0;
		virtual VTEXResult get_DriveMode(enum VTEXScannerSystemEventDriveModeEnum* mode) = 0;
		virtual VTEXResult put_DriveMode(enum VTEXScannerSystemEventDriveModeEnum mode) = 0;
};


class VTEX_API LibScannerSystemEvents
{
	public:
		virtual ~LibScannerSystemEvents() { };

		//Datamembers
		property <LibScannerSystemEvents, int32_t, READ_ONLY> Count;
		arrayizer <LibScannerSystemEvents, LibScannerSystemEvent*, VTEXString> Item;
		arrayizer <LibScannerSystemEvents, VTEXString, int32_t> Name;
		property <LibScannerSystemEvents, int32_t, READ_WRITE> WiredOrBiasMode;

		//Methods
		virtual VTEXResult DisableAll() = 0;
        virtual LibScannerSystemEvent *get_Item(VTEXString name) = 0;
		virtual VTEXString get_Name(int32_t index) = 0;
		virtual VTEXResult get_Count(int32_t* count) = 0;

        virtual VTEXResult get_WiredOrBiasMode(int32_t* bias) = 0;
		virtual VTEXResult put_WiredOrBiasMode(int32_t bias) = 0;
};


//Time interface
class VTEX_API LibScannerSystemTime
{
	public:
		virtual ~LibScannerSystemTime() { };

		//Datamembers
		property <LibScannerSystemTime, bool, READ_ONLY> IsMaster;
		property <LibScannerSystemTime, bool, READ_ONLY> IsSynchronized;

		//Methods
		virtual VTEXResult GetSystemTime(double* seconds, double* nanoseconds) = 0;
		virtual VTEXResult get_IsMaster(bool* master) = 0;
		virtual VTEXResult get_IsSynchronized(bool* sync) = 0;
};


//Trigger interface
class VTEX_API LibScannerSystemTriggerSource
{
	public:
		virtual ~LibScannerSystemTriggerSource() { };

		//Datamembers
		property <LibScannerSystemTriggerSource, double, READ_WRITE> Delay;
		property <LibScannerSystemTriggerSource, enum VTEXScannerSystemTriggerSourceDetectionEnum, READ_WRITE> Detection;
		property <LibScannerSystemTriggerSource, VTEXString, READ_WRITE> Filter;
		property <LibScannerSystemTriggerSource, VTEXString, READ_WRITE> EventId;

		//Methods
		virtual VTEXResult Configure(double delay, enum VTEXScannerSystemTriggerSourceDetectionEnum detection) = 0;

		virtual VTEXResult get_Delay(double* delay) = 0;
		virtual VTEXResult put_Delay(double delay) = 0;
		virtual VTEXResult get_Detection(enum VTEXScannerSystemTriggerSourceDetectionEnum* detection) = 0;
		virtual VTEXResult put_Detection(enum VTEXScannerSystemTriggerSourceDetectionEnum detection) = 0;
		virtual VTEXResult get_Filter(VTEXString* filter) = 0;
		virtual VTEXResult put_Filter(const VTEXString &filter) = 0;
		virtual VTEXResult get_EventId(VTEXString* eventID) = 0;
		virtual VTEXResult put_EventId(const VTEXString &eventID) = 0;
};


class VTEX_API LibScannerSystemTriggerSources
{
	public:
		virtual ~LibScannerSystemTriggerSources()  { };

		//Datamembers
		property <LibScannerSystemTriggerSources, int32_t, READ_ONLY> Count;
		arrayizer <LibScannerSystemTriggerSources, LibScannerSystemTriggerSource*, VTEXString> Item;
		arrayizer <LibScannerSystemTriggerSources, VTEXString, int32_t> Name;

		//Methods
		virtual LibScannerSystemTriggerSource *get_Item(VTEXString name) = 0;
		virtual VTEXString get_Name(int32_t index) = 0;
		virtual VTEXResult get_Count(int32_t* count) = 0;
};


class VTEX_API LibScannerSystemTriggerAlarm
{
	public:
		virtual ~LibScannerSystemTriggerAlarm() { };

		//Datamembers
		property <LibScannerSystemTriggerAlarm, bool, READ_WRITE> Enabled;
		property <LibScannerSystemTriggerAlarm, double, READ_WRITE> Period;
		property <LibScannerSystemTriggerAlarm, int32_t, READ_WRITE> RepeatCount;
        property <LibScannerSystemTriggerAlarm, double, READ_WRITE> TimeSeconds;
		property <LibScannerSystemTriggerAlarm, double, READ_WRITE> TimeFraction;

		//Methods
		virtual VTEXResult Configure(double, double, double, int32_t) = 0;

		virtual VTEXResult get_Period(double* period) = 0;
		virtual VTEXResult put_Period(double period) = 0;
		virtual VTEXResult get_TimeSeconds(double* seconds) = 0;
		virtual VTEXResult put_TimeSeconds(double seconds) = 0;
		virtual VTEXResult get_TimeFraction(double* fraction) = 0;
		virtual VTEXResult put_TimeFraction(double fraction) = 0;
		virtual VTEXResult get_RepeatCount(int32_t* count) = 0;
		virtual VTEXResult put_RepeatCount(int32_t count) = 0;
		virtual VTEXResult get_Enabled(bool* enabled) = 0;
		virtual VTEXResult put_Enabled(bool enabled) = 0;
};


class VTEX_API LibScannerSystemTriggerAlarms
{
	public:
		virtual ~LibScannerSystemTriggerAlarms() { };

		//Datamembers
		property <LibScannerSystemTriggerAlarms, int32_t, READ_ONLY> Count;
		arrayizer <LibScannerSystemTriggerAlarms, LibScannerSystemTriggerAlarm*, VTEXString> Item;
		arrayizer <LibScannerSystemTriggerAlarms, VTEXString, int32_t> Name;

		//Methods
		virtual VTEXResult DisableAll() = 0;
		virtual LibScannerSystemTriggerAlarm *get_Item(VTEXString name) = 0;
		virtual VTEXString get_Name(int32_t index) = 0;
		virtual VTEXResult get_Count(int32_t* val) = 0;
};


class VTEX_API LibScannerSystemTrigger
{
	public:
		virtual ~LibScannerSystemTrigger() { };

		//Datamembers
		LibScannerSystemTriggerAlarms *Alarms;
        LibScannerSystemTriggerSources *Sources;

		property <LibScannerSystemTrigger, int32_t, READ_WRITE> TriggerCount;
		property <LibScannerSystemTrigger, VTEXString, READ_WRITE> TriggerSource;

		//Methods
		virtual VTEXResult get_TriggerCount(int32_t* count) = 0;
		virtual VTEXResult put_TriggerCount(int32_t count) = 0;
		virtual VTEXResult get_TriggerSource(VTEXString* source) = 0;
		virtual VTEXResult put_TriggerSource(const VTEXString &source) = 0;
};


//class LibScannerSystem
class VTEX_API LibScannerSystem
{
	public:
		virtual ~LibScannerSystem() { };

		//Datamembers
		//Inherent capabilitites
		property <LibScannerSystem, int32_t, READ_WRITE> LXIDomain;

		/// <summary>Pointer to Arm interface</summary>
		LibScannerSystemArm *Arm;

		/// <summary>Pointer to EventLog interface</summary>
		LibScannerSystemEventLog *EventLog;

		/// <summary>Pointer to Events interface</summary>
		LibScannerSystemEvents *Events;

		/// <summary>Pointer to Time interface</summary>
		LibScannerSystemTime *Time;

		/// <summary>Pointer to Trigger interface</summary>
		LibScannerSystemTrigger *Trigger;

		/// <summary>Pointer to InstrumentSpecific interface</summary>
		//LibScannerSystemInstrumentSpecific* InstrumentSpecific;


		//Methods
		virtual VTEXResult get_LXIDomain(int32_t* domain) = 0;
		virtual VTEXResult put_LXIDomain(int32_t domain) = 0;
        virtual VTEXResult SetTimeout(uint16_t timeoutMilliseconds) = 0;


    virtual VTEXResult get_SystemInventory(VTEXString* inventory) = 0;
};

#endif  // _LIB_SYSTEM_H
