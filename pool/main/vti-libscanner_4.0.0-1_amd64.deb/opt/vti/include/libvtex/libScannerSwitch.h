
/******************************************************************************
 *
 *  .----------------------.	
 *  |==     ==  ======  == |	$Author$
 *  | ==   ==   ======  == |	$Revision$ 
 *  |  == ==      ==    == |	$Date$ 
 *  |   ===       ==    == |	$HeadURL$
 *  |    =        ==    == |	
 *  `----------------------'
 *
 * Copyright 2006 VXI Technology Inc. as an unpublished work. 
 * All rights reserved. The information contained herein is confidential
 * property of VXI Technology, Inc. Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement 
 * with VXI Technology, Inc.
 *
 * PURPOSE: 
 *   Class definition of the main LibSwitch class
 *
 * First Written By: David Sigler On Nov-2006
 ******************************************************************************/
#ifndef _LIB_SCANNER_SWITCH_H
#define _LIB_SCANNER_SWITCH_H


/*******************
 * System header
 *******************/
#include <vector>


/*******************
 * Library header
 *******************/


/*******************
 * Local header
 *******************/
#include "vtexapi.h"
#ifndef _ATL_ATTRIBUTES
    #include "ScannerConstants.h"
#endif
#include "property.h"
#include "array.h"



/***********************
 * Forward Declarations
 ***********************/
class UtilsContainer;
class State;

class VTEX_API LibScannerSwitchChannelCharacteristics
{
    public:
        virtual ~LibScannerSwitchChannelCharacteristics() { };

        //Attributes
        property <LibScannerSwitchChannelCharacteristics, double, READ_ONLY> ACCurrentCarryMax;
        property <LibScannerSwitchChannelCharacteristics, double, READ_ONLY> ACCurrentSwitchingMax;
        property <LibScannerSwitchChannelCharacteristics, double, READ_ONLY> ACPowerCarryMax;
        property <LibScannerSwitchChannelCharacteristics, double, READ_ONLY> ACPowerSwitchingMax;
        property <LibScannerSwitchChannelCharacteristics, double, READ_ONLY> ACVoltageMax;
        property <LibScannerSwitchChannelCharacteristics, double, READ_ONLY> Bandwidth;
        property <LibScannerSwitchChannelCharacteristics, double, READ_ONLY> Impedance;
        property <LibScannerSwitchChannelCharacteristics, double, READ_ONLY> DCCurrentCarryMax;
        property <LibScannerSwitchChannelCharacteristics, double, READ_ONLY> DCCurrentSwitchingMax;
        property <LibScannerSwitchChannelCharacteristics, double, READ_ONLY> DCPowerCarryMax;
        property <LibScannerSwitchChannelCharacteristics, double, READ_ONLY> DCPowerSwitchingMax;
        property <LibScannerSwitchChannelCharacteristics, double, READ_ONLY> DCVoltageMax;
        property <LibScannerSwitchChannelCharacteristics, double, READ_ONLY> SettlingTime;
        property <LibScannerSwitchChannelCharacteristics, int32_t, READ_ONLY> WireMode;

        //Methods
        virtual VTEXResult get_ACCurrentCarryMax(double *value) = 0;
        virtual VTEXResult get_ACCurrentSwitchingMax(double *value) = 0;
        virtual VTEXResult get_ACPowerCarryMax(double *value) = 0;
        virtual VTEXResult get_ACPowerSwitchingMax(double *value) = 0;
        virtual VTEXResult get_ACVoltageMax(double *value) = 0;
        virtual VTEXResult get_Bandwidth(double *value) = 0;
        virtual VTEXResult get_Impedance(double *value) = 0;
        virtual VTEXResult get_DCCurrentCarryMax(double *value) = 0;
        virtual VTEXResult get_DCCurrentSwitchingMax(double *value) = 0;
        virtual VTEXResult get_DCPowerCarryMax(double *value) = 0;
        virtual VTEXResult get_DCPowerSwitchingMax(double *value) = 0;
        virtual VTEXResult get_DCVoltageMax(double *value) = 0;
        virtual VTEXResult get_SettlingTime(double *value) = 0;
        virtual VTEXResult get_WireMode(int32_t *value) = 0;
};


class VTEX_API LibScannerSwitchChannel
{
    public:
        virtual ~LibScannerSwitchChannel() { };

        //Attributes
        LibScannerSwitchChannelCharacteristics* Characteristics;        

        property <LibScannerSwitchChannel, bool, READ_WRITE> IsConfigurationChannel;
        property <LibScannerSwitchChannel, bool, READ_WRITE> IsSourceChannel;

        //Methods
        virtual VTEXResult put_IsConfigurationChannel(bool value) = 0;
        virtual VTEXResult get_IsConfigurationChannel(bool* value) = 0;
        virtual VTEXResult put_IsSourceChannel(bool value) = 0;
        virtual VTEXResult get_IsSourceChannel(bool* value) = 0;
};


class VTEX_API LibScannerSwitchChannels
{
    public:
        virtual ~LibScannerSwitchChannels() { };

        //Attributes
        property <LibScannerSwitchChannels, int, READ_ONLY> Count;
        arrayizer <LibScannerSwitchChannels, LibScannerSwitchChannel*, const VTEXString&> Item;
        arrayizer <LibScannerSwitchChannels, VTEXString, int> Name;

        //Methods
        virtual LibScannerSwitchChannel* get_Item(const VTEXString& channelName) = 0;
        virtual VTEXString get_Name(int repCapIndex) = 0;
        virtual VTEXResult get_Count(int* count) = 0;
};


class VTEX_API LibScannerSwitch
{
    public:
        virtual ~LibScannerSwitch() { };
        
        LibScannerSwitchChannels* Channels;

        virtual VTEXResult ExternalConnection(const VTEXString& channel1, const VTEXString& channel2) = 0;
        virtual VTEXResult AddPathLevelExcludeList(const VTEXString& excludeList, const VTEXString& name) = 0;
        virtual VTEXResult RemovePathLevelExcludeList(const VTEXString& name) = 0;
};

#endif  //_LIB_SCANNER_SWITCH_H
