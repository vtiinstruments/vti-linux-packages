#include "exErrors.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#if defined(_WIN32) && !defined(_CVI_)
#define INLINE __inline
#else
#define INLINE inline
#endif

#ifdef __cplusplus
extern "C" {
#endif

 //!
 //! @file
 //!
 //! Scanner error codes.
 //!

#ifndef _ScannerErrors_H
#define _ScannerErrors_H

 //! IVI switch errors.
#define IVISCANNER_E_BASE 0x80070000

 //! IVI switch warnings.
#define IVISCANNER_W_BASE 0x70000

 // 
 // Do not edit IVI class compliant errors.  Add custom errors below.
 //

 //! Driver errors.
#define VTEXSCANNER_E_BASE 0x80074000

#define VTEXSCANNER_E_NOT_ALLOWED_IN_SETUP_PHASE 0x80074001
#define VTEXSCANNER_E_NOT_ALLOWED_IN_SWEEP_PHASE 0x80074002
#define VTEXSCANNER_E_USE_SYSTEM_DRIVER 0x80074003
#define VTEXSCANNER_E_INVALID_SOURCE 0x80074004
#define VTEXSCANNER_E_INCONSISTENT_STATE 0x80074005
#define VTEXSCANNER_E_SLOT_NOT_POPULATED 0x80074006
#define VTEXSCANNER_E_NO_CARDS 0x80074007
#define VTEXSCANNER_E_NO_TRIGGER_SOURCE_SET 0x80074008
#define VTEXSCANNER_E_NO_ARM_SOURCE_ENABLED 0x80074009
#define VTEXSCANNER_E_FORMAT 0x8007400a
#define VTEXSCANNER_E_SCAN_IN_PROGRESS 0x8007400b
#define VTEXSCANNER_E_NO_DMM_FOR_SWEEP_STEP 0x8007400c
#define VTEXSCANNER_E_INIT_NEED_RESET 0x8007400d
#define VTEXSCANNER_E_NO_SCAN_IN_PROGRESS 0x8007400e

 //! Driver warnings.
#define VTEXSCANNER_W_BASE 0x74000

 //! Device errors.
#define FWSCANNER_E_BASE 0x80078000

#define FWSCANNER_E_UNKNOWN 0x80078001
#define FWSCANNER_E_INTERNAL 0x80078002
#define FWSCANNER_E_BAD_FORMAT 0x80078003

 //! Device warnings.
#define FWSCANNER_W_BASE 0x78000


#endif /* ! _ScannerErrors_H */

#ifdef  __cplusplus
}
#endif

