#pragma once

#ifndef _WIN32
#define VTEX_STATIC
#endif

#ifdef VTEX_DLL
#define VTEX_EXPORT __declspec(dllexport)
#define EXPORT_TEMPLATE
#elif defined(VTEX_STATIC)
#define VTEX_EXPORT
#define EXPORT_TEMPLATE
#else
#define VTEX_EXPORT __declspec(dllimport)
#define EXPORT_TEMPLATE extern
#endif

#include <string>
#include <vector>

#ifndef VTEX_STATIC
EXPORT_TEMPLATE template class VTEX_EXPORT std::allocator<char>;
EXPORT_TEMPLATE template class VTEX_EXPORT std::allocator<int>;
EXPORT_TEMPLATE template class VTEX_EXPORT std::allocator<double>;
EXPORT_TEMPLATE template union VTEX_EXPORT std::_String_val<std::_Simple_types<char>>::_Bxty;
EXPORT_TEMPLATE template class VTEX_EXPORT std::_String_val<std::_Simple_types<char>>;
EXPORT_TEMPLATE template class VTEX_EXPORT std::_Compressed_pair<std::_Wrap_alloc<std::allocator<char>>, std::_String_val<std::_Simple_types<char>>, true>;
EXPORT_TEMPLATE template class VTEX_EXPORT std::_Vector_val<std::_Simple_types<double>>;
EXPORT_TEMPLATE template class VTEX_EXPORT std::_Compressed_pair<std::_Wrap_alloc<std::allocator<double>>, std::_Vector_val<std::_Simple_types<double>>, true>;
EXPORT_TEMPLATE template class VTEX_EXPORT std::basic_string<char, std::char_traits<char>, std::allocator<char>>;
EXPORT_TEMPLATE template class VTEX_EXPORT std::vector<double>;
#endif