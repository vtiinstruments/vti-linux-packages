
#ifndef VTEX_EXCEPTION_H
#define VTEX_EXCEPTION_H

/*******************
 * System header
 *******************/
#include <string>

/*******************
 * Library header
 *******************/


/*******************
 * Local header
 *******************/
#include "vtexapi.h"
#include "exTypes.h"

/***********************
 * Forward Declarations
 ***********************/

class errorOperands
{
    public:
	    std::string text1;
	    std::string text2;
	    std::string text3;
	    std::string text4;
	    std::string text5;
    	
	    void clear();
};


class VTEX_API VTEXException //: public std::exception
{
    public:
	    //Datamembers
	    VTEXResult errorCode;

		VTEXString errorMessage;
	    errorOperands operands;
    	
	    //Constructors
	    VTEXException();
	    VTEXException(VTEXResult error, const std::string& message);

	    // Methods - same names as the _com_error ones, for Linux <=> Windows portability
	    VTEXResult Error();
	    VTEXString Description();
};

#endif  //VTEX_EXCEPTION_H
