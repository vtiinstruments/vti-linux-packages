/******************************************************************************
*  .----------------------.
*  |==     ==  ======  == |    $Author$
*  | ==   ==   ======  == |    $Revision$
*  |  == ==      ==    == |    $Date$
*  |   ===       ==    == |    $HeadURL$
*  |    =        ==    == |
*  `----------------------'
*
* Copyright 2013 VTI Instruments Corp. as an unpublished work.
* All rights reserved. The information contained herein is confidential
* property of VTI Instruments Corp. Use, copy, transfer or disclosure
* of such information is prohibited except by express written agreement
* with VTI Instruments Corp.
*
* PURPOSE:
*   Declares VRT context packet requirements
*
******************************************************************************/
#ifndef _VRT_CONTEXT_H
#define _VRT_CONTEXT_H

#include <string>

// Common Definitions
#define timestamp_sec_str "timestamp_sec"
#define timestamp_frac_str "timestamp_frac"
#define default_str "Default"
#define unknown_str "Unknown"
#define none_str "None"
#define automatic_str "Automatic"
#define manual_str "Manual"

// Warnings
#define warning_str "WARNING"

#define wrong_context_packet_count_str "Missing or unexpected associated context packets"
#define expected_context_packets_str "Expected Associated Context Packet Count"
#define actual_context_packets_str "Received Associated Context Packet Count"

#define packets_out_of_order_str "VRT packets out of order"
#define channel_str "Channel"
#define packet_type_str "Packet Type"
#define expected_packet_count_str "Expected Packet Count"
#define actual_packet_count_str "Actual Packet Count"

// IF Context Definitions
#define bandwidth_str "Bandwidth"
#define reference_level_str "Reference Level"
#define overrange_count_str "Over-Range Count"
#define sample_rate_str "Sample Rate"
#define temperature_str "Temperature"
// Logical events
#define event_calibrated_time_str "Calibrated Time"
#define event_data_valid_str "Valid Data"
#define event_ref_lock_str "Reference Lock"
#define event_gain_str "Gain"
#define event_signal_detected_str "Signal Detected"
#define event_spectrum_inverted_str "Spectrum Inverted"
#define event_signal_overrange_str "Over-Range"
#define event_sample_loss_str "Sample Loss"
// User events
#define event_resampled_str "Data Resampled"
#define event_fifo_overflow_str "Fifo Overflow"
#define event_initial_str "" // TODO FIXME initial context packets require special handling
#define event_datastream_str "Associated Data Stream Enabled"
#define event_trigger_dropped_str "Trigger Dropped"

// Extension Context Definitions - Meas Info
#define filter_str "Filter"
#define filter_high_bandwidth_str "High-Bandwidth"
#define prescaler_str "Prescaler"
#define span_str "Span"
#define range_str "Range"
#define weighting_str "Weighting"
#define weighting_a_str "A"
#define weighting_c_str "C"
#define eu_type_str "EU"
#define eu_unit_scale_str "Unit Scale"
#define eu_gain_str "Gain"
#define eu_offset_str "Offset"
#define user_comment_str "User Comment"
#define trigger_timestamp_sec_str "Trigger Timestamp Seconds"
#define trigger_timestamp_frac_str "Trigger Timestamp Fraction"
#define ref_junction_str "Reference Junction"

// Extension Context Definitions - Tach Info
#define decimation_str "Decimation"
#define holdoff_str "Holdoff"

// Extension Context Definitions - Mfunc Info
#define mfunc_trigger_source_str "Trigger Source"
#define rpm_str "RPM"
#define dio_str "DIO"

#endif // _VRT_CONTEXT_H
