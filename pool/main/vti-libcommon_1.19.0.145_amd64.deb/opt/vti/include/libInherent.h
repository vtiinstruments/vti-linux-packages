
#ifndef _LIB_INHERENT_H
#define	_LIB_INHERENT_H


/*******************
 * System header
 *******************/
#include <string>

/*******************
 * Library header
 *******************/


/*******************
 * Local header
 *******************/
#include "vtexapi.h"
#include "property.h"
#include "array.h"

class VTEX_API LibInherent
{
    public:
		virtual ~LibInherent() {};

        virtual VTEXResult Close() = 0; 
        virtual VTEXResult Initialize(const VTEXString& resourceName, 
                                      bool idQuery, 
                                      bool reset, 
                                      const VTEXString& optionString) = 0; 

        virtual VTEXResult Initialize(const VTEXString& resourceName, 
                                      bool idQuery, 
                                      bool reset) = 0; 

        virtual VTEXResult get_Initialized (bool *val) = 0;

    protected:
};

class VTEX_API LibInherentCapabilityIdentity 
{ 
    public: 
        virtual ~LibInherentCapabilityIdentity() { }; 

        //Methods
        virtual VTEXResult get_Description(VTEXString *val) = 0; 
        virtual VTEXResult get_Revision(VTEXString *val) = 0; 
        virtual VTEXResult get_Vendor(VTEXString *val) = 0; 
        virtual VTEXResult get_GroupCapabilities(VTEXString *val) = 0; 
        virtual VTEXResult get_Identifier(VTEXString *val) = 0; 
        virtual VTEXResult get_InstrumentFirmwareRevision(VTEXString *val) = 0;
        virtual VTEXResult get_InstrumentManufacturer(VTEXString *val) = 0; 
        virtual VTEXResult get_InstrumentModel(VTEXString *val) = 0;
        virtual VTEXResult get_SpecificationMajorVersion(int32_t *val) = 0; 
        virtual VTEXResult get_SpecificationMinorVersion(int32_t *val) = 0; 
        virtual VTEXResult get_SupportedInstrumentModels(VTEXString *val) = 0;

        //Datamembers    
        property <LibInherentCapabilityIdentity, VTEXString, READ_ONLY> Description; 
        property <LibInherentCapabilityIdentity, VTEXString, READ_ONLY> Revision; 
        property <LibInherentCapabilityIdentity, VTEXString, READ_ONLY> Vendor; 
        property <LibInherentCapabilityIdentity, VTEXString, READ_ONLY> GroupCapabilities;
        property <LibInherentCapabilityIdentity, VTEXString, READ_ONLY> Identifier; 
        property <LibInherentCapabilityIdentity, VTEXString, READ_ONLY> InstrumentFirmwareRevision; 
        property <LibInherentCapabilityIdentity, VTEXString, READ_ONLY> InstrumentManufacturer; 
        property <LibInherentCapabilityIdentity, VTEXString, READ_ONLY> InstrumentModel; 
        property <LibInherentCapabilityIdentity, int32_t, READ_ONLY> SpecificationMajorVersion; 
        property <LibInherentCapabilityIdentity, int32_t, READ_ONLY> SpecificationMinorVersion; 
        property <LibInherentCapabilityIdentity, VTEXString, READ_ONLY> SupportedInstrumentModels; 
}; 

 
class VTEX_API LibInherentCapabilityDriverOperation 
{ 
    public: 
        virtual ~LibInherentCapabilityDriverOperation() { }; 

        //Methods
        virtual VTEXResult ClearInterchangeWarnings() = 0; 
        virtual VTEXResult GetNextCoercionRecord(VTEXString* val) = 0; 
        virtual VTEXResult GetNextInterchangeWarning(VTEXString* val) = 0; 
        virtual VTEXResult InvalidateAllAttributes() = 0; 
        virtual VTEXResult ResetInterchangeCheck() = 0; 

        virtual VTEXResult get_DriverSetup(VTEXString *val) = 0; 
        virtual VTEXResult get_IoResourceDescriptor(VTEXString *val) = 0; 
        virtual VTEXResult get_LogicalName(VTEXString *val) = 0; 
        virtual VTEXResult get_InterchangeCheck(bool *val) = 0; 
        virtual VTEXResult put_InterchangeCheck(bool val) = 0; 
        virtual VTEXResult get_Cache(bool *val) = 0; 
        virtual VTEXResult put_Cache(bool val) = 0; 
        virtual VTEXResult get_QueryInstrumentStatus(bool *val) = 0; 
        virtual VTEXResult put_QueryInstrumentStatus(bool val) = 0; 
        virtual VTEXResult get_RangeCheck(bool *val) = 0; 
        virtual VTEXResult put_RangeCheck(bool val) = 0; 
        virtual VTEXResult get_RecordCoercions(bool *val) = 0; 
        virtual VTEXResult put_RecordCoercions(bool val) = 0; 
        virtual VTEXResult get_Simulate(bool *val) = 0; 
        virtual VTEXResult put_Simulate(bool val) = 0; 


        //Datamembers
        property <LibInherentCapabilityDriverOperation, VTEXString, READ_ONLY> DriverSetup; 
        property <LibInherentCapabilityDriverOperation, VTEXString, READ_ONLY> IoResourceDescriptor; 
        property <LibInherentCapabilityDriverOperation, VTEXString, READ_ONLY> LogicalName; 
        property <LibInherentCapabilityDriverOperation, bool, READ_WRITE> InterchangeCheck; 
        property <LibInherentCapabilityDriverOperation, bool, READ_WRITE> Cache; 
        property <LibInherentCapabilityDriverOperation, bool, READ_WRITE> QueryInstrumentStatus; 
        property <LibInherentCapabilityDriverOperation, bool, READ_WRITE> RangeCheck; 
        property <LibInherentCapabilityDriverOperation, bool, READ_WRITE> RecordCoercions; 
        property <LibInherentCapabilityDriverOperation, bool, READ_WRITE> Simulate; 
}; 
 

class VTEX_API LibInherentCapabilityUtility 
{ 
    public: 
        virtual ~LibInherentCapabilityUtility() { }; 

        //Methods
        virtual VTEXResult Disable() = 0; 
        virtual VTEXResult ErrorQuery(int32_t *ErrorCode, VTEXString& ErrorMessage) = 0; 
        virtual VTEXResult LockObject() = 0; 
        virtual VTEXResult Reset() = 0; 
        virtual VTEXResult ResetWithDefaults() = 0; 

        virtual VTEXResult SelfTest(int32_t *TestResult, VTEXString& TestMessage) = 0; 

        virtual VTEXResult UnlockObject() = 0; 
}; 

#endif  //_LIB_INHERENT_H
