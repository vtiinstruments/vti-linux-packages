
/******************************************************************************
 *
 *  .----------------------.
 *  |==     ==  ======  == |    $Author$
 *  | ==   ==   ======  == |    $Revision$
 *  |  == ==      ==    == |    $Date$
 *  |   ===       ==    == |    $HeadURL$
 *  |    =        ==    == |
 *  `----------------------'
 *
 * Copyright 2006 VXI Technology Inc. as an unpublished work.
 * All rights reserved. The information contained herein is confidential
 * property of VXI Technology, Inc. Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement
 * with VXI Technology, Inc.
 *
 * PURPOSE:
 *   Interface class definition for IVI inherent capabilities
 *
 * First Written By: Gershon Shamay On Feb-2007
 ******************************************************************************/
#ifndef _VTEX_INHERENT_H
#define _VTEX_INHERENT_H

/*******************
 * System header
 *******************/
#include <string>
#include <vector>

/*******************
 * Library header
 *******************/


/*******************
 * Local header
 *******************/
#include "vtexExport.h"
#include "vtexTypes.h"
#include "vtexProperty.h"
#include "vtexArray.h"

#include "vtexCommonErrors.h"

class VTEX_EXPORT vtexInherent
{
public:
    vtexInherent() {};
    virtual ~vtexInherent() {};

    virtual VTEXResult Close() = 0;
    virtual VTEXResult Initialize(const std::string& resourceName,
                                  bool idQuery,
                                  bool reset,
                                  const std::string& optionString) = 0;

    virtual VTEXResult Initialize(const std::string& resourceName,
                                  bool idQuery,
                                  bool reset) = 0;

    virtual VTEXResult get_Initialized (bool &val) = 0;
};


class VTEX_EXPORT vtexInherentPlatform
{
public:
    vtexInherentPlatform() {};
    virtual ~vtexInherentPlatform() {};

    //Methods
    virtual VTEXResult get_InstrumentFirmwareRevision(std::string &val) = 0;
    virtual VTEXResult get_InstrumentHardwareRevision(std::string &val) = 0;
    virtual VTEXResult get_InstrumentManufacturer(std::string &val) = 0;
    virtual VTEXResult get_InstrumentModel(std::string &val) = 0;
    virtual VTEXResult get_SerialNumber(std::string &val) = 0;
    virtual VTEXResult get_Temperature(std::string &val) = 0;

    //Datamembers
    vtexProperty <vtexInherentPlatform, std::string, READ_ONLY> InstrumentFirmwareRevision;
    vtexProperty <vtexInherentPlatform, std::string, READ_ONLY> InstrumentHardwareRevision;
    vtexProperty <vtexInherentPlatform, std::string, READ_ONLY> InstrumentManufacturer;
    vtexProperty <vtexInherentPlatform, std::string, READ_ONLY> InstrumentModel;
    vtexProperty <vtexInherentPlatform, std::string, READ_ONLY> SerialNumber;
    vtexProperty <vtexInherentPlatform, std::string, READ_ONLY> Temperature;
};


class VTEX_EXPORT vtexInherentCapabilityIdentity
{
public:
    vtexInherentCapabilityIdentity() {};
    virtual ~vtexInherentCapabilityIdentity() {};

    //Methods
    virtual VTEXResult get_Description(std::string &val) = 0;
    virtual VTEXResult get_Revision(std::string &val) = 0;
    virtual VTEXResult get_Vendor(std::string &val) = 0;
    virtual VTEXResult get_GroupCapabilities(std::string &val) = 0;
    virtual VTEXResult get_Identifier(std::string &val) = 0;
    virtual VTEXResult get_InstrumentFirmwareRevision(std::string &val) = 0;
    virtual VTEXResult get_InstrumentManufacturer(std::string &val) = 0;
    virtual VTEXResult get_InstrumentModel(std::string &val) = 0;
    virtual VTEXResult get_SpecificationMajorVersion(int32_t &val) = 0;
    virtual VTEXResult get_SpecificationMinorVersion(int32_t &val) = 0;
    virtual VTEXResult get_SupportedInstrumentModels(std::string &val) = 0;

    //Datamembers
    vtexProperty <vtexInherentCapabilityIdentity, std::string, READ_ONLY> Description;
    vtexProperty <vtexInherentCapabilityIdentity, std::string, READ_ONLY> Revision;
    vtexProperty <vtexInherentCapabilityIdentity, std::string, READ_ONLY> Vendor;
    vtexProperty <vtexInherentCapabilityIdentity, std::string, READ_ONLY> GroupCapabilities;
    vtexProperty <vtexInherentCapabilityIdentity, std::string, READ_ONLY> Identifier;
    vtexProperty <vtexInherentCapabilityIdentity, std::string, READ_ONLY> InstrumentFirmwareRevision;
    vtexProperty <vtexInherentCapabilityIdentity, std::string, READ_ONLY> InstrumentManufacturer;
    vtexProperty <vtexInherentCapabilityIdentity, std::string, READ_ONLY> InstrumentModel;
    vtexProperty <vtexInherentCapabilityIdentity, int32_t, READ_ONLY> SpecificationMajorVersion;
    vtexProperty <vtexInherentCapabilityIdentity, int32_t, READ_ONLY> SpecificationMinorVersion;
    vtexProperty <vtexInherentCapabilityIdentity, std::string, READ_ONLY> SupportedInstrumentModels;
};


class VTEX_EXPORT vtexInherentCapabilityDriverOperation
{
public:
    vtexInherentCapabilityDriverOperation() {};
    virtual ~vtexInherentCapabilityDriverOperation() {};

    //Methods
    virtual VTEXResult ClearInterchangeWarnings() = 0;
    virtual VTEXResult GetNextCoercionRecord(std::string &val) = 0;
    virtual VTEXResult GetNextInterchangeWarning(std::string &val) = 0;
    virtual VTEXResult InvalidateAllAttributes() = 0;
    virtual VTEXResult ResetInterchangeCheck() = 0;

    virtual VTEXResult get_DriverSetup(std::string &val) = 0;
    virtual VTEXResult get_IoResourceDescriptor(std::string &val) = 0;
    virtual VTEXResult get_LogicalName(std::string &val) = 0;
    virtual VTEXResult get_InterchangeCheck(bool &val) = 0;
    virtual VTEXResult put_InterchangeCheck(bool val) = 0;
    virtual VTEXResult get_Cache(bool &val) = 0;
    virtual VTEXResult put_Cache(bool val) = 0;
    virtual VTEXResult get_QueryInstrumentStatus(bool &val) = 0;
    virtual VTEXResult put_QueryInstrumentStatus(bool val) = 0;
    virtual VTEXResult get_RangeCheck(bool &val) = 0;
    virtual VTEXResult put_RangeCheck(bool val) = 0;
    virtual VTEXResult get_RecordCoercions(bool &val) = 0;
    virtual VTEXResult put_RecordCoercions(bool val) = 0;
    virtual VTEXResult get_Simulate(bool &val) = 0;
    virtual VTEXResult put_Simulate(bool val) = 0;

    //Datamembers
    vtexProperty <vtexInherentCapabilityDriverOperation, std::string, READ_ONLY> DriverSetup;
    vtexProperty <vtexInherentCapabilityDriverOperation, std::string, READ_ONLY> IoResourceDescriptor;
    vtexProperty <vtexInherentCapabilityDriverOperation, std::string, READ_ONLY> LogicalName;
    vtexProperty <vtexInherentCapabilityDriverOperation, bool, READ_WRITE> InterchangeCheck;
    vtexProperty <vtexInherentCapabilityDriverOperation, bool, READ_WRITE> Cache;
    vtexProperty <vtexInherentCapabilityDriverOperation, bool, READ_WRITE> QueryInstrumentStatus;
    vtexProperty <vtexInherentCapabilityDriverOperation, bool, READ_WRITE> RangeCheck;
    vtexProperty <vtexInherentCapabilityDriverOperation, bool, READ_WRITE> RecordCoercions;
    vtexProperty <vtexInherentCapabilityDriverOperation, bool, READ_WRITE> Simulate;
};


class VTEX_EXPORT vtexInherentCapabilityUtility
{
public:
    vtexInherentCapabilityUtility() {};
    virtual ~vtexInherentCapabilityUtility() {};

    //Methods
    virtual VTEXResult Disable() = 0;
    virtual VTEXResult ErrorQuery(int32_t &ErrorCode, std::string& ErrorMessage) = 0;
    virtual VTEXResult LockObject() = 0;
    virtual VTEXResult Reset() = 0;
    virtual VTEXResult ResetWithDefaults() = 0;

    virtual VTEXResult SelfTest(int32_t &TestResult, std::string& TestMessage) = 0;

    virtual VTEXResult UnlockObject() = 0;
};

#endif  //_VTEX_INHERENT_H
