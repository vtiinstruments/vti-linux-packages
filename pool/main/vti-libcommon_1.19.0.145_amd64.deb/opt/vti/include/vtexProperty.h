/******************************************************************************
 *
 *  .----------------------.    
 *  |==     ==  ======  == |    $Author$
 *  | ==   ==   ======  == |    $Revision$ 
 *  |  == ==      ==    == |    $Date$ 
 *  |   ===       ==    == |    $HeadURL$
 *  |    =        ==    == |    
 *  `----------------------'
 *
 * Copyright 2006 VXI Technology Inc. as an unpublished work. 
 * All rights reserved. The information contained herein is confidential
 * property of VXI Technology, Inc. Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement 
 * with VXI Technology, Inc.
 *
 * PURPOSE: 
 *   Template class for various IVI properties
 *
 * First Written By: David Sigler On Jan-2007
 ******************************************************************************/

#ifndef _VTEXPROPERTY_TEMPLATE_
#define _VTEXPROPERTY_TEMPLATE_

#define READ_ONLY   1
#define WRITE_ONLY  2
#define READ_WRITE  3

#include "vtexInherent.h"

template<typename ValueType>
class VTEX_EXPORT vtexPropertyArg
{
    vtexPropertyArg() {};
public:
    typedef ValueType Type;
};

template<typename Container, typename ValueType, int access>
class VTEX_EXPORT vtexProperty
{
public:
    typedef ValueType value_type;

    vtexProperty()
    {
        m_container = nullptr;
        m_get = nullptr;
        m_set = nullptr;
    }

    void SetAttributes(Container *container,
        VTEXResult (Container::*get)(ValueType &value) = nullptr,
        VTEXResult (Container::*set)(typename vtexPropertyArg<ValueType>::Type value) = nullptr)
    {
        m_container = container;
        m_get = get;
        m_set = set;
    }

    operator ValueType()
    {
        // A getter that fails leaves this alone, and it is returned regardless.
        ValueType value = ValueType();

        (m_container->*m_get)(value);

        return value;
    }

    const ValueType &operator =(const ValueType &value)
    {
        (m_container->*m_set)(value);

        return value;
    }

private:
    Container *m_container;
    VTEXResult (Container::*m_get)(ValueType &value);
    VTEXResult (Container::*m_set)(typename vtexPropertyArg<ValueType>::Type value);
};

#endif //_VTEXPROPERTY_TEMPLATE_

