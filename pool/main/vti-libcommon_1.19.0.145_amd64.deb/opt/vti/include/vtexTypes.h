/**
*  .----------------------.
*  |==     ==  ======  == |    $Author$
*  | ==   ==   ======  == |    $Revision$
*  |  == ==      ==    == |    $Date$
*  |   ===       ==    == |    $HeadURL$
*  |    =        ==    == |
*  `----------------------'
*
* Copyright 2010 VTI Instruments Corp. as an unpublished work.
* All rights reserved. The information contained herein is confidential
* property of VTI Instruments Corp. Use, copy, transfer or disclosure
* of such information is prohibited except by express written agreement
* with VTI Instruments Corp.
*
* PURPOSE:
*   Declares the VTEX types
 */
#ifndef VTEX_TYPES_H
#define VTEX_TYPES_H

#pragma once

#ifdef _WIN32

typedef signed   __int8  int8_t;
typedef unsigned __int8  uint8_t;

typedef signed   __int16 int16_t;
typedef unsigned __int16 uint16_t;

typedef signed   __int32 int32_t;
typedef unsigned __int32 uint32_t;

typedef signed   __int64 int64_t;
typedef unsigned __int64 uint64_t;

#else
#include <stdint.h>

#endif

typedef int32_t VTEXResult;

#endif // VTEX_TYPES_H

