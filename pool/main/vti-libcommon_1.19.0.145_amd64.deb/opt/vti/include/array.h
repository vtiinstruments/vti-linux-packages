
#ifndef _ARRAY_TEMPLATE_
#define _ARRAY_TEMPLATE_

template <typename Container, typename ValueType, typename IndexType>
class VTEX_API arrayizer
{
public:
    arrayizer()
    {
        m_container = NULL;
        m_get = NULL;
    }
    
    void SetAttributes(Container *container,
      ValueType (Container::*get)(IndexType value))
    {
        m_container = container;
        m_get = get;
    }
    
    ValueType operator [](IndexType index)
    {
        return (m_container->*m_get)(index);
    }

private:
    Container *m_container;
    ValueType (Container::*m_get)(IndexType value);
};

#endif //_ARRAY_TEMPLATE_

