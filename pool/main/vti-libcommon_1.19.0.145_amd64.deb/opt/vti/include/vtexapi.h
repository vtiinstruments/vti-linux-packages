
#ifndef __INCLUDE_VTEX_API__
#define __INCLUDE_VTEX_API__

/*
 * All libVTEX APIs that are exported from Win32 DLL must be defined as VTEX_API.
 * Define DLL_EXPORTS to build libVTEX Win32 DLL.
 * Define VTEX_DLL to link with libVTEX DLL import libraries.
 */
#ifdef _WIN32

#ifdef DLL_EXPORTS
/* Win32 dynamic link library export */
#define VTEX_API __declspec(dllexport)
#else 
#ifdef VTEX_DLL
/* Win32 dynamic link library import */
#define VTEX_API __declspec(dllimport)

#else
/* Win32 static library */
#define VTEX_API

#endif
#endif

#else
/* Linux, Unix,...etc */

#if __GNUC__ >= 3 && !defined(VTEX_HIDDEN)
#define VTEX_API __attribute__ ((visibility("default")))
#else
#define VTEX_API
#endif

#endif

#endif
