
/******************************************************************************
 *
 *  .----------------------.
 *  |==     ==  ======  == |    $Author$
 *  | ==   ==   ======  == |    $Revision$
 *  |  == ==      ==    == |    $Date$
 *  |   ===       ==    == |    $HeadURL$
 *  |    =        ==    == |
 *  `----------------------'
 *
 * Copyright 2006 VXI Technology Inc. as an unpublished work.
 * All rights reserved. The information contained herein is confidential
 * property of VXI Technology, Inc. Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement
 * with VXI Technology, Inc.
 *
 * PURPOSE:
 *   Generic class for throwing an exception
 *
 * First Written By: David Sigler On Jan-2007
 ******************************************************************************/
#ifndef LIB_VTEX_EXCEPTION_H
#define LIB_VTEX_EXCEPTION_H

/*******************
 * System header
 *******************/
#include <string>

/*******************
 * Library header
 *******************/


/*******************
 * Local header
 *******************/
#include "vtexInherent.h"

/***********************
 * Forward Declarations
 ***********************/

#ifndef USE_LEGACY_EXCEPTIONS
namespace SentinelEX { class VTEXException; } // Forward declare so the using statement works
using SentinelEX::VTEXException;
#endif

namespace SentinelEX
{
    class VTEX_EXPORT VTEXException //: public std::exception
    {
    public:
        //Datamembers
        VTEXResult errorCode;
        std::string errorMessage;

        //Constructors
        VTEXException(VTEXResult error, const std::string& message) : errorCode(error), errorMessage(message) {};

        // Methods - same names as the _com_error ones, for Linux <=> Windows portability
        VTEXResult Error() { return errorCode; }
        std::string Description() { return errorMessage; }
    private:
        VTEXException() = delete;
    };
}



#endif  //LIB_VTEX_EXCEPTION_H
