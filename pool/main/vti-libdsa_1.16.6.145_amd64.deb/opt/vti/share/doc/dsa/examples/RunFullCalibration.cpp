#include <iostream>
#include "libDsa.h"
#include "json.h"
#include <fstream>
#include <ctype.h>

int main(int argc, char **argv)
{
    LibDsa *driver;
    try {
        // Create a new instance of the DSA driver
        driver = LibDsa::Create();
        try {

            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             */
            if (argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // Initialize the DSA driver
            driver->Initialize(resource_string, true, true);
            std::cout << "Initialized to " << resource_string << std::endl;

            Json::Value value;
            Json::Reader reader;

            reader.parse(driver->Platform->InstrumentModel, value);
            std::string slot = value.getMemberNames()[0];
            std::string model = value[slot].asString();
            reader.parse(driver->Platform->SerialNumber, value);
            std::string serial = value[slot].asString();

            char date[32];
            time_t t;
            time(&t);
            strftime(date, sizeof(date), "%Y-%m-%d_%H.%M.%S", localtime(&t));

            driver->Calibration->Full->Initiate();
            VTEXDsaCalibrationStatusEnum status;
            std::string message = "";
            std::string last_print = "Invalid";
            std::string response;
            bool done = false;
            char yn = 0;

            while (!done) {
              driver->Calibration->Full->GetStatus(status, message);
              reader.parse(message, value);
              message = value[slot].asString();
              if (message != last_print) {
                std::cout << message << std::endl;
                last_print = message;
              }
              switch (status) {
                case VTEXDsaCalibrationStatusRunning:
                  break;
                case VTEXDsaCalibrationStatusPrompt:
                  std::cout << "> ";
                  std::cin >> response;
                  driver->Calibration->Full->PromptResponse(response);
                  break;
                case VTEXDsaCalibrationStatusSuccess:
                  do {
                    std::cout << "Save new calibration adjustments in instrument flash? (Y/N)" << std::endl << "> ";
                    std::cin >> response;
                    if (response.size() > 0) {
                      yn = toupper(static_cast<unsigned char>(response[0]));
                    }
                  } while (yn != 'Y' && yn != 'N');
                  if (yn == 'Y') {
                    driver->Calibration->Full->SaveAdjustments();
                    do {
                      std::cout << "Use newly saved calibration adjustments by default, instead of factory adjustments? (Y/N)" << std::endl << "> ";
                      std::cin >> response;
                      if (response.size() > 0) {
                        yn = toupper(static_cast<unsigned char>(response[0]));
                      }
                    } while (yn != 'Y' && yn != 'N');
                    driver->Calibration->Full->LoadByDefault = yn == 'Y';
                  }
                  // fall through
                default:
                  done = true;
                  break;
              }
            }

            std::string fname = "full_cal_report_" + model + "_" + serial + "_" + date + ".csv";
            std::ofstream f(fname);
            reader.parse(driver->Calibration->Full->Report, value);
            f << value[slot].asString();
            f.close();
            std::cout << "Saved " << fname << std::endl;

            driver->Close(); // Make sure to close the driver session when you are finished
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(driver->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    driver->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(driver->Initialized)
            {
                driver->Close();
            }
        }
    }
    catch(...)
    {
        // Handle any non VTEX exceptions intelligently here
    }
}
