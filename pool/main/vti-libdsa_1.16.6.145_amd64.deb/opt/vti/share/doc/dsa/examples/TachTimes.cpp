#include "libDsa.h"
#include <iostream>

int main(int argc, char **argv)
{
    LibDsa *driver;
    try {
        // Create a new instance of the driver
        driver = LibDsa::Create();
        try{
            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             */
            if (argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // Initialize the driver
            driver->Initialize(resource_string, true, true);
            std::cout << "Initialized to " << resource_string << std::endl;

            // If the driver session contains digitizer card, configure it to acquire data continously, after single trigger.
            driver->Trigger->TriggerCount = 1;
            driver->Measurement->NumRecordsPerTrigger = 0;

            // Configure card to use IEEE1588 clock.
            driver->ReferenceOscillator->Source = VTEXDsaReferenceOscillatorSourceSystem;
            driver->ReferenceOscillator->TimestampSource = VTEXDsaReferenceOscillatorTimestampSourceSystem;

            // Configure EMX-1434 tach channel detection level, slope and hysteresis.
            std::string tach = driver->Tach->Channels->Name[1];
            driver->Tach->Channels->Item[tach]->Enabled = true;
            driver->Tach->Channels->Item[tach]->FIFO->StreamingEnabled = true;
            driver->Tach->Channels->Item[tach]->Level = 0.0;
            driver->Tach->Channels->Item[tach]->Hysteresis = 0.1;
            driver->Tach->Channels->Item[tach]->Slope = VTEXDsaTachSlopePositive;

            // Initiate measurement
            driver->Measurement->Initiate();

            int timeout_ms = 500; // Wait 500 mseconds for each tach timestamps read.

            // Each vector will contain seconds and fraction of seconds of timestamps.
            std::vector<double> tach_sec, tach_frac;

            int32_t numtachs = 0, total_tachs = 0;

            // Repeat until 1000 tachometer edges are detected.

            ////////////////////////////////////////////////////////////////////////////////////
            //  !!!WARNINGS!!!
            // The program can stay in this loop indefinitely unless tachometer pulses are connected
            // to TACH1 input and more than 1000 tach edges are detected at the specified, slope,
            // level, and hysteresis.
            ////////////////////////////////////////////////////////////////////////////////////
            while(total_tachs < 1000)
            {
                numtachs = 0;
                // Read tachometer timestamps into two safe arrays.
                int32_t fifo_count = driver->Tach->Channels->Item[tach]->FIFO->Count;
                if(fifo_count > 0)
                {
                    driver->Tach->Channels->Item[tach]->FIFO->Read(timeout_ms, fifo_count, numtachs, tach_sec, tach_frac);

                    // Tachometer timestamps are read into tach_sec and tach_frac arrays.
                    // Process them by users applicaiton, such as resampling.
                }
                total_tachs += numtachs;
            }

            driver->Measurement->Abort();
            driver->Close();
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(driver->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    driver->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(driver->Initialized)
            {
                driver->Measurement->Abort();
                driver->Close();
            }
        }

        //Clean up when we're done
        delete driver;
        driver = nullptr;
    }
    catch(...)
    {
        // Handle non VTEX errors in an intelligent manner
    }
}

