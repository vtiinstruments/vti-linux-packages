#include <iostream>
#include "libDsa.h"

int main(int argc, char **argv)
{
    LibDsa *driver;
    try {
        // Create a new instance of the Dsa driver
        driver = LibDsa::Create();
        try{
            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             */
            if (argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // Initialize the Dsa driver
            driver->Initialize(resource_string, true, true);
            std::cout << "Initialized to " << resource_string << std::endl;

            // Set up the measurement to use a LAN Event as the trigger source
            driver->Trigger->Sources->DisableAll();

            // We'll use LAN0 as the trigger source
            driver->Trigger->Sources->Item["LAN0"]->Enabled = true;

            // Initiate measurement
            driver->Measurement->Initiate();

            /*
             * After the measurement has been initiated, send a LAN Event to the instruement to trigger it.
             * By default, the Event ID for the LAN Event is the same as the trigger name. For example, here you would send an event with the ID: "LAN0"
             *
             * LAN Events allow triggering on both future and past timestamps. If using timestamped LAN Events, ensure that you are using PTP as the time source.
             * Sending an event with a timestamp of 0 will trigger as soon as it is recieved by the instrument.
             *
             * The Agilent Interactive LXI tool provides an easy to use, graphical way to send LAN events, however any tool that generates LXI compliant event messages should work.
             */

             std::cout << "Please send a LAN Event to the instrument now, or press Ctrl+C to abort." << std::endl;
             std::cout << "The LAN Event should be sent to the host specified first in the resource string. It should have an Event ID of LAN0, and the LXI Domain should be set to 0" << std::endl;

            // Wait for the measurement to complete
            driver->Measurement->WaitForMeasurementComplete(VTEXDsaTimeOutInfinite);

            // Read acquired Data
            int actual_recs;
            std::string channel;
            std::vector<double> data;
            std::vector<double> ts_sec;
            std::vector<double> ts_frac;
            std::string addl_data;
            driver->Measurement->Read(5000, -1, actual_recs, channel, data,
                    ts_sec, ts_frac, addl_data);

            // The channel string indicates how the data is arranged in the vector
            std::cout << "Channels: " << channel << std::endl;

            driver->Measurement->Abort();
            driver->Close();
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(driver->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    driver->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(driver->Initialized)
            {
                driver->Close();
            }
        }

        //Clean up when we're done
        delete driver;
        driver = nullptr;
    }
    catch(...)
    {
        // Handle non VTEX errors in an intelligent manner
    }
}

