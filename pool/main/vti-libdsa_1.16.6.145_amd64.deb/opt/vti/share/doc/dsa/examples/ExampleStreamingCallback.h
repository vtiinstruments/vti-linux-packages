#ifndef _EXAMPLE_STREAMING_CALLBACK_H
#define _EXAMPLE_STREAMING_CALLBACK_H

#include "libDsa.h"
class ExampleStreamingCallback : public LibDsaStreamingCallback
{
    public:
        virtual void StreamingCallback(int32_t num_records, std::string& channel, std::vector<double>& data,
          std::vector<double>& ts_sec, std::vector<double>& ts_frac, std::string& additional_data);
};

#endif
