#include "ExampleStreamingCallback.h"
#include <iostream>

// Implementation of the StreamingCallback function
void ExampleStreamingCallback::StreamingCallback(int32_t num_records, std::string& channel, std::vector<double>& data,
        std::vector<double>& ts_sec, std::vector<double>& ts_frac, std::string& additional_data)
{
    std::cout << "Callback received " << num_records << " records" << std::endl;
}


int main(int argc, char* argv[])
{
    // Create a VTEXDsa pointer
    LibDsa *driver;
    try
    {
        // Create a new instance of the driver
        driver = LibDsa::Create();
        try
        {
            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             */
            if(argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                std::cout << "Ex: " << argv[0] << "TCPIP::192.168.0.1::INSTR" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // Initialize the driver
            driver->Initialize(resource_string, false, true, "");

            // Enable all of the channels
            driver->Channels->Item["ALL"]->Enabled = true;

            // Create a new instance of your callback and register it
            ExampleStreamingCallback *callback = new ExampleStreamingCallback();
            driver->StreamingData->RegisterStreamingCallback(*callback, "");
            driver->StreamingData->EnableStreaming();

            // Initiate a measurement and let it run for 5 seconds
            driver->Measurement->Initiate();
            driver->Measurement->WaitForMeasurementComplete(5000);

            // Stop streaming and close the driver
            driver->StreamingData->DisableStreaming();
            driver->Close();
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(driver->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    driver->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(driver->Initialized)
            {
                driver->Close();
            }
        }
    }
    catch(...)
    {
    }
    return 0;
}
