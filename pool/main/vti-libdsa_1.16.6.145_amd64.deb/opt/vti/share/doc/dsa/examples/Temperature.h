#ifndef _TEMPERATURE_EXAMPLE_H
#define _TEMPERATURE_EXAMPLE_H

#include <stdio.h>
#include <iostream>
#include <unistd.h>

#include "libDsa.h"

#define NUM_FORWARD_COEFFS 11
double TypeE_ForwardCoeffs[NUM_FORWARD_COEFFS] = {
    0.0,
    0.00005866550871,
    4.5032275582e-8,
    2.8908407212e-11,
    -3.3056896652e-13,
    6.502440327e-16,
    -1.9197495504e-19,
    -1.2536600497e-21,
    2.1489217569e-24,
    -1.4388041782e-27,
    3.5960899481e-31
};

#define NUM_INVERSE_COEFFS 10
double TypeE_InverseCoeffs[NUM_INVERSE_COEFFS] = {
    0.0,
    17057.035,
    -233017.59,
    6543558.5,
    -73562749,
    -1789600100,
    84036165000,
    -1373587900000,
    10629823000000,
    -32447087000000
};

#endif
