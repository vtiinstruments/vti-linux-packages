#include <iostream>
#include "libDsa.h"

int main(int argc, char **argv)
{
    LibDsa *driver;
    try {
        // Create a new instance of the driver
        driver = LibDsa::Create();
        try{
            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             */
            if (argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // Initialize the driver
            driver->Initialize(resource_string, true, true);
            std::cout << "Initialized to " << resource_string << std::endl;

            // Look for the storage devices. Not all instruments support external storage devices.
            int32_t storage_device_count = driver->Storage->Devices->Count;
            std::cout << "Storage Devices: " << storage_device_count << std::endl;
            if(storage_device_count == 0)
            {
                std::cout << "No storage devices found. Cannot continue." << std::endl;

                driver->Close();
                return 0;
            }

            std::cout << "Storage Device Names:";
            for(int32_t i = 0; i < storage_device_count; i++)
            {
                std::cout << " " << driver->Storage->Devices->Name[i + 1];
            }
            std::cout << std::endl;

            // We'll use the first storage device.
            std::string name = driver->Storage->Devices->Name[1];
            std::cout << "Using " << name << std::endl;

            // How much free space do we have on the device?
            std::string dev_info = driver->Storage->Devices->Item[name]->Info;
            std::cout << "Storage Device Info: " << dev_info << std::endl;

            // Check the file name
            std::string filename = driver->Storage->Devices->Item[name]->Filename;
            std::cout << "Storage Device data filename: " << filename << std::endl;

            // The filename property supports strftime escape sequences (for the time the measurement was initiated),
            // as well as %@ for the slot name, %N for a count of Measurement.Initiate calls since boot, and %# for the file index within a single measurement.
            // Let's change the filename so the data gets stored in a subdirectory.
            filename = "data/%@_%Y-%m-%d_%H-%M-%S_%#.h5";
            driver->Storage->Devices->Item[name]->Filename = filename;
            std::cout << "New filename: " << filename << std::endl;

            // We don't want the data file to get too big. We'll set a limit for the maximum number of records.
            // But we'll leave the FileCount property set to zero so there's no limit to the number of files that are created.
            driver->Storage->Devices->Item[name]->FileMaxRecords = 10;

            // Add some custom attributes to describe the data in the files
            driver->Storage->Devices->Item[name]->SetCustomAttribute("Tester Name", "George");
            driver->Storage->Devices->Item[name]->SetCustomAttribute("Test Location", "Room 14");

            // Review the attributes we just set, before we start the acquisition
            std::string attrs;
            driver->Storage->Devices->Item[name]->GetCustomAttributes(attrs);
            std::cout << "Acquisition Attributes: " << attrs << std::endl;

            // Oops! We make a mistake in one of the attributes. Better fix that and review again.
            driver->Storage->Devices->Item[name]->SetCustomAttribute("Test Location", "Room 12");
            driver->Storage->Devices->Item[name]->GetCustomAttributes(attrs);
            std::cout << "Acquisition Attributes: " << attrs << std::endl;

            // Configure the acquisition
            double sample_rate = 1250;
            int64_t num_records_per_trigger = 10;
            int32_t trigger_count = 3;

            driver->Measurement->Sampling->SampleRate = sample_rate;
            driver->Measurement->NumRecordsPerTrigger = num_records_per_trigger;
            driver->Trigger->TriggerCount = trigger_count;

            // Enable the storage device
            driver->Storage->Devices->Item[name]->Enabled = true;

            // Save the configuration to the storage device
            driver->Configuration->SaveConfigurationToStorageDevice(name);

            driver->Close();

            std::cout << std::endl << "Configured Acquisition. Use instrument LCD to start acquisition." << std::endl;
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(driver->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    driver->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(driver->Initialized)
            {
                driver->Close();
            }
        }

        //Clean up when we're done
        delete driver;
        driver = nullptr;
    }
    catch(...)
    {
        // Handle non VTEX errors in an intelligent manner
    }
}
