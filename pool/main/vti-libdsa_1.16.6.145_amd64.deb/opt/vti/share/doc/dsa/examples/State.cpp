#include "libDsa.h"
#include <iostream>

int main(int argc, char **argv)
{
    LibDsa *driver;
    try {
        // Create a new instance of the driver
        driver = LibDsa::Create();
        try{

            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             */
            if (argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" <<std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // Initialize the driver
            driver->Initialize(resource_string, true, true);
            std::cout << "Initialized to " << resource_string << std::endl;

            // Set the digitizer to start the measurement on a signal sent from software
            driver->Start->Source = "Software";

            // Repeat arm loop 3 times.
            int numArms = 3;
            driver->Arm->ArmCount = numArms;

            // Enable software arm, disable all other arm sources.
            driver->Arm->Sources->DisableAll();
            driver->Arm->Sources->Item["Software"]->Enabled = true;

            // Enable software trigger, disable all other trigger sources.
            driver->Trigger->Sources->DisableAll();
            driver->Trigger->Sources->Item["Software"]->Enabled = true;

            // Current measurement state.
            VTEXDsaMeasurementStateEnum state = driver->Measurement->State;
            std::cout << "\tMeasurement state: " << state << std::endl;

            // Initiate measurement.
            driver->Measurement->Initiate();
            std::cout << "Measurement initiated." << std::endl;

            // Wait until filter settles and ready to send a start command.
            while (state != VTEXDsaMeasurementStateWaitingForStart)
            {
                state = driver->Measurement->State;
                std::cout << "\tMeasurement state: " << state << std::endl;
            }

            // Start data acquisition.
            std::cout << "Send start command." << std::endl;
            driver->Start->SendSoftwareStart();

            // Loop until the measurement complete.
            while (state != VTEXDsaMeasurementStateIdle)
            {
                if (state == VTEXDsaMeasurementStateWaitingForArm)
                {
                    std::cout << "Send arm command." << std::endl;
                    driver->Arm->SendSoftwareArm();
                }
                else if (state == VTEXDsaMeasurementStateWaitingForTrigger)
                {
                    std::cout << "Send trigger command." << std::endl;
                    driver->Trigger->SendSoftwareTrigger();
                }

                VTEXDsaMeasurementStateEnum newState = driver->Measurement->State;
                if (newState != state)
                {
                    state = newState;
                    std::cout << "\tMeasurement state: " << state << std::endl;
                    std::cout << "\tNumber of acquired records: " << driver->Measurement->NumAcquiredRecords << std::endl;
                }
            }

            std::cout << "\tMeasurement state: " << state << std::endl;
            std::cout << "Measurement complete" << std::endl;

            driver->Close(); // Make sure to close the driver session when you are finished with it
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(driver->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    driver->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(driver->Initialized)
            {
                driver->Close();
            }
        }

        //Clean up when we're done
        delete driver;
        driver = nullptr;
    }
    catch(...)
    {
        // Handle any non VTEX errors in an intelligent manner
    }
}
