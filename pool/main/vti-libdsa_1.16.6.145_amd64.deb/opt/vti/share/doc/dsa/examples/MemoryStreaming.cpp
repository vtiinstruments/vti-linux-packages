#include "libDsa.h"
#include <iostream>
#include <unistd.h>

int main(int argc, char **argv)
{
    LibDsa *driver;
    try {
        // Create a new instance of the driver
        driver = LibDsa::Create();
        try{
            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             */
            if (argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // Initialize the driver
            driver->Initialize(resource_string, true, true);
            std::cout << "Initialized to " << resource_string << std::endl;

            // Enable a software trigger.
            driver->Trigger->Sources->DisableAll();
            driver->Trigger->Sources->Item["Software"]->Enabled = true;
    
            // Enable streaming.
            driver->StreamingData->EnableStreaming();

            // Initiate measurement
            std::wcout << "Initiating measurement." << std::endl;
            driver->Measurement->Initiate();
            int timeout_ms = 5000;

            // Read acquired Data
            int actual_recs;
            std::string channel;
            std::vector<double> data;
            std::vector<double> ts_sec;
            std::vector<double> ts_frac;
            std::string addl_data;
            // This should return immediately with no memory read because measurement hasn't started.
            driver->StreamingData->MemoryRead(-1, actual_recs, channel, data,
                    ts_sec, ts_frac, addl_data);
            
            // These should all be 0 because no data has actually been read.
            std::wcout << "Acquired Records: " << driver->Measurement->NumAcquiredRecords;
            std::wcout << ", FIFO Records: " << driver->Measurement->NumFIFORecords;
            std::wcout << ", Streamed Records: " << driver->StreamingData->NumStreamedRecords;
            std::wcout << ", Memory Records: " << driver->StreamingData->NumMemoryRecords << std::endl;
            
            // Wait for the state to reach Waiting For Trigger
            VTEXDsaMeasurementStateEnum state = driver->Measurement->State;
            while (state != VTEXDsaMeasurementStateWaitingForTrigger)
            {
                usleep(10 * 1000);
                state = driver->Measurement->State;
            }

            // Now actually trigger measurement and wait for it to complete..
            std::wcout << "Sending software trigger." << std::endl;
            driver->Trigger->SendSoftwareTrigger();
            driver->Measurement->WaitForMeasurementComplete(timeout_ms);
            driver->StreamingData->MemoryRead(-1, actual_recs, channel, data,
                    ts_sec, ts_frac, addl_data);
                    
            std::wcout << "Acquired Records: " << driver->Measurement->NumAcquiredRecords;
            std::wcout << ", FIFO Records: " << driver->Measurement->NumFIFORecords;
            std::wcout << ", Streamed Records: " << driver->StreamingData->NumStreamedRecords;
            std::wcout << ", Memory Records: " << driver->StreamingData->NumMemoryRecords << std::endl;

            // The channel string indicates how the data is arranged in the vector
            std::cout << "Channels: " << channel << std::endl;
            
            driver->Measurement->Abort();
            driver->StreamingData->DisableStreaming();

            driver->Close();
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(driver->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    driver->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(driver->Initialized)
            {
                driver->Close();
            }
        }

        //Clean up when we're done
        delete driver;
        driver = nullptr;
    }
    catch(...)
    {
        // Handle non VTEX errors in an intelligent manner
    }
}

