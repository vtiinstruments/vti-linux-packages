#include <iostream>
#include "libDsa.h"

int main(int argc, char **argv)
{
    LibDsa *driver;
    try {
        // Create a new instance of the driver
        driver = LibDsa::Create();
        try{
            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             * The pipe character (|) is used to separate hostnames for multiple devices, e.g., hostname1|hostname2
             */
            if (argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // connect to both EMX-4250 and RX0124 devices - at least one of each
            driver->Initialize(resource_string, true, true, "");
            std::cout << "Initialized to " << resource_string << std::endl;

            std::string models = driver->Platform->InstrumentModel;
            std::cout << "Models: " << models << std::endl;

            // set the clock frequency to a value supported by all devices
            driver->Measurement->Sampling->ClockFrequency = 102400;

            // use the EMX-4250 channel group to set a sample rate of 102400 Hz and a record size of 4096 on all EMX-4250 devices
            // each record will take 40 milliseconds to acquire
            driver->Channels->Item["EMX-4250"]->Sampling->SampleRate = 102400;
            driver->Channels->Item["EMX-4250"]->Sampling->RecordSize = 4096;

            // use the RX0124 channel group to set a sample rate of 51200 Hz and a record size of 2048
            // each record will also take 40 milliseconds to acquire, but it will have half the samples as the records from EMX-4250
            driver->Channels->Item["RX0124"]->Sampling->SampleRate = 51200;
            driver->Channels->Item["RX0124"]->Sampling->RecordSize = 2048;

            // set up to use LAN coordination
            driver->ReferenceOscillator->Source = VTEXDsaReferenceOscillatorSourceSystem;
            driver->ReferenceOscillator->TimestampSource = VTEXDsaReferenceOscillatorTimestampSourceSystem;
            driver->Sync->CoordinationLine = "LAN,PXI0";
            driver->Sync->SendSoftwareSync();

            // Initiate measurement
            driver->Measurement->Initiate();

            // Wait for the measurement to complete
            driver->Measurement->WaitForMeasurementComplete(5000); // 5 seconds

            // Read acquired Data
            int actual_recs;
            std::string channel;
            std::vector<double> data;
            std::vector<double> ts_sec;
            std::vector<double> ts_frac;
            std::string addl_data;
            driver->Measurement->Read(5000, -1, actual_recs, channel, data,
                    ts_sec, ts_frac, addl_data);

            // The channel string indicates how the data is arranged in the vector
            // Remember, the number of samples for each channel will depend on the record size
            // That value can be queried for a specific channel via driver->Channels->Item[name]->Sampling->RecordSize
            std::cout << "Channels: " << channel << std::endl;

            driver->Measurement->Abort();
            driver->Close();
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(driver->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    driver->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(driver->Initialized)
            {
                driver->Close();
            }
        }
    }
    catch(...)
    {
        // Handle non VTEX errors in an intelligent manner
    }
}

