INTRODUCTION
The MicroLAN (MLAN) specification details five major functions that are the centerpiece of any operations involving TEDS devices. These five functions are:
- Read serial/URN from device (GET_URN)
- Write to volatile memory scratchpad (READ_SCRATCHPAD)
- Read from volatile memory scratchpad (WRITE_SCRATCHPAD)
- Copy volatile scratchpad to nonvolatile memory (COPY_SCRATCHPAD)
- Read from non-volatile memory (READ_MEMORY)

The GET_URN command is a vital precursor to any of the other four operations. If the URN of
the TEDS (1-Wire) device is not queried before the other operations are called, these operations
will fail.

In general, there can be multiple 1-Wire devices per 1-Wire bus master (MLAN repeater) and the
MLAN responder in the unit holds the state of the device being addressed. To interact with a 1-
Wire device, the URN of the device is used as an address, allowing a single device to be selected.
The EMX-4350 (and related cards) have a single 1-Wire bus master that can be used by any channel.
Under typical operation, only a single 1-Wire device will be connected to the active channel.

The GET_URN function is designed to identify a single 1-Wire TEDS device and return its unique
64-bit URN value. Sample code for how this function is implemented is provided. A variant of the
GET_URN function can be used to search through multiple devices in order to select a specific
device, but the example version of this function only supports one device per channel.

Once the 1-Wire device has been addressed, the MLAN responder will store its address, and it will
not need to be referenced again until it is necessary to change devices. Any of the other commands
can now be used to view or change data.

The READ_MEMORY function is probably the most commonly used MLAN command. It allows
the user to query the non-volatile memory of any 1-Wire device and read back its contents.
For some devices, notably the DS2431, the READ_MEMORY function may return multiple MLAN packets.

The "scratchpad" is a volatile buffer on a 1-Wire device where data is written before it is copied to
memory. In order to write data to the main memory, it must first be written to the scratchpad.
After writing to the scratchpad, the data can then be copied to the main memory.

WARNING
The scratchpad will be erased if you unplug your MLAN device, power off the instrument, or wait
a significant amount of time between commands. VTI Instruments recommends performing
scratchpad operations in a production environment using the "write_and_copy" atomic command
which is discussed in detail later.

The WRITE_SCRATCHPAD command can be used to write arbitrary data to the scratchpad of a
1-Wire device. Unlike the GET_URN function, WRITE_SCRATCHPAD (and all other MLAN)
functions are specific to the type of MLAN device being used. In the example code,
write_scratchpad_2430() and write_scratchpad_2431() functions are used to represent the
differences between the DS2430 and DS2431 devices. Be careful of the size differences between
various devices' scratchpad buffers. In the case of the DS2431, 8 bytes of data, aligned on an
8-byte address, must be written together � that is, all memory writes involve 8 bytes. To modify a
single byte of memory requires that the 8-byte block be read back from the device, the byte in
question modified, and the resulting 8 bytes written back. The datasheet for the 1-Wire component
in use should serve as the ultimate guide in programming the device.

The READ_SCRATCHPAD function can be used to read back a device's scratchpad. For
example, it is always a good idea to do this after a WRITE_SCRATCHPAD call and before a
COPY_SCRATCHPAD call to verify that the write was completed successfully and that the data
was entered correctly before permanently overwriting main memory. As previously noted, using
the individual functions for WRITE, READ, and COPY can cause data loss and the recommended
method is to use the WRITE_AND_COPY command and read main memory.

COPY_SCRATCHPAD allows the user to transfer the scratchpad buffer on the MLAN device to
the non-volatile memory of the device. This permanently overwrites the addressed non-volatile
memory, so care should be exercised when doing so.

PROGRAMMING MLAN
Below, we will discuss the example code for each function of the 2430 and 2431. First, however,
there are some constants which should be discussed.
These constants are all defined at the top of the TEDS_MLAN example code.

MLAN commands
These #defines are commands that are sent to the MLAN controller. They do not modify the data
on the device, but allow a device to be selected, tells the controller to return a buffer with the
result, or sets up a delay on the MLAN line. They will be explained when they are used in the
example code. These commands are defined by the MLAN specification. In general, these
commands are targeted at the MLAN repeater (1-Wire bus master) itself, not the 1-Wire, TEDS
devices.

Functions that modify TEDS data
These are the actual opcodes for four of the five functions we outlined above. They are 1-Wire bus
commands that are sent to the 1-Wire (TEDS) devices. The GET_URN function is not listed
because it is not a single opcode that modifies data on the device or returns data except for the
serial number/URN.

Before beginning with the listed functions, a short example will be examined and described in
detail.
int example_function(int channel)
{
    int sendLen, recLen = 0;
    sendLen = 1; // reserve first byte for length
    SendPkt[sendLen++] = CMD_RESET;
    SendPkt[sendLen++] = CMD_GETBUF;
    SendPkt[0] = sendLen - 1;
    MLanHostPacketSend(SendPkt, channel);
    recLen = MLanHostPacketReceive(RecPkt, channel, MLAN_PACKET_SIZE);
    return recLen;
}

This function performs an MLAN bus master reset, that is, it resets the MLAN repeater inside the
EMX-4250/EMX-4350/RX0124. As can be seen, the first byte of the packet is reserved for the length of the packet.
This not only defines a maximum size for an MLAN packet, but also tells the controller how much
space to allocate for it. This is done for every packet sent. The controller also uses the first byte as
the length of every packet received. Command and data bytes are appended to the byte array, with
a post-increment of the index (sendLen).

The first command sent is CMD_RESET, or 0x84. This is the command that performs the bus
master reset. The next command is CMD_GETBUF, or 0x85. This returns the response buffer
from the repeater.

Here is the program's output, given just this function:
    sent packet without errors
    Packet length: 3
    02 84 85
    got a packet without errors on receive
    Packet length: 3
    02 84 00
The first line indicates that the driver call used to send the data was successful. The second
indicates how long the packet sent was: 3 bytes, which is what was expected. The next line is the
printout of the packet. The first byte in the packet, as previously stated, is the length of the packet.
In this case, 2 bytes (this length does not include the length byte). The other bytes are the
CMD_RESET and CMD_GETBUF commands, in that order.

It is sometimes necessary to allocate space for a return buffer in the sent packet. All MLAN
commands will send back at least two bytes: the command performed and the response to that
command. Additional components may also be included, such as CRC bytes, data echo, or an error
message, but two bytes is the minimum.
In this instance, three bytes were returned: the length of the data, the command performed, and the
response to the command. As before, the length of the packet does not include the length byte. The
two bytes returned are "84" and "00", where "84" is from the sent packet, the CMD_RESET
command. This is the bus master echoing the command to confirm what was sent. The "00" byte
is the response to that command, in this case ML_SUCCESS. The CMD_GETBUF is not echoed
back in the response, nor is there an error code returned, as this information would be superfluous.
This indicates that the MLAN repeater received the bus master reset and that it was successful. If
an error was encountered during this process, it might look like this:
    sent packet without errors
    Packet length: 3
    02 84 85
    got a packet without errors on receive
    Packet length: 3
    03 84 86 02
This time, 3 bytes were received. The "84" for CMD_RESET, and then "86 02". From
IEEE 1451.4, Annex G, "86" is the code for CMD_ERROR. This buffer was not processed
successfully, and we have not reset the bus master. The "02" is also in Annex G, and means
"RET_BUSY, previous buffer has not been processed yet." It will be necessary to wait until the
last command completes before processing this one. Note that this error is purely hypothetical, but
illustrates the typical format for an MLAN error.
With some basic programming completed, the more complex functions required to access a
1-Wire device can be examined.

DS2430 COMMANDS

WRITE_SCRATCHPAD_2430
The function used in writing data to an MLAN device is the WRITE_SCRATCHPAD function. It
is important that the 1-Wire device be selected using the GET_URN function prior to using the
remaining functions. The CMD_ML_ACCESS command to the MLAN repeater uses the address
(URN) of the last selected device for all subsequent operations.

When the ASCII data format used in the example code is seen, the reason for the
(SCRATCHPAD_LEN * 2) + (SCRATCHPAD_LEN - 1) code segment becomes more
clear. For the DS2430, a data string for the example code might look like this:
    "01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F 10 11 12 13 14 15 16 17
    18 19 1A 1B 1C 1D 1F 20 21"
For each hex byte, there are two characters (LEN * 2), plus one space for all but the last one
(LEN-1). This example code uses this format for easy parsing.

Once again, the first byte is reserved for the length of the packet, and then two very common
MLAN commands are sent, CMD_ML_ACCESS and CMD_ML_DATA. The ML_ACCESS
command allows the user to access a 1-Wire device which was previously searched for and
discovered. ML_DATA tells the controller that data operations are going to begin on that device �
that is, 1-Wire bus transactions will be performed.

The next command, 3+DS2430_SCRATCHPAD_LEN, is actually the length of the command that
is being sent to the device. Since the entire scratchpad length is being written, that must be
included. Then, the data length block, the WRITE_SCRATCHPAD command itself, and the
"0", which is the address in memory that the scratchpad will write to, must be added. Since data
written to the scratchpad will ultimately end up in the non-volatile memory, the target address in
the non-volatile memory must be provided when writing the data to the scratchpad. This provides
a measure of error detection, when the address is later provided in the copy scratchpad operation,
as well as allowing the device to return an error if the target memory is write-protected. The
CMD_GETBUF is not part of this block, as it is a separate command.

Note that data length block is 2+DS2430_SCRATCHPAD_LEN. The reason for this is that, when
writing to the scratchpad, the controller sends back what was written so that it can be verified. For
any MLAN command, two must be added to the length of the data that is expected to be returned
(for the command sent and command result to be returned), and the scratchpad data is the only
data we expect to be returned.

On the DS2430, address 0 is always written to after the WRITE_SCRATCHPAD command, as
the DS2430 scratchpad is the same size as the memory. Therefore, by writing a single scratchpad,
the entire memory will be overwritten. This will not always be the case, and, in fact, is not on the
DS2431, which will be seen later.

The for loop that is next in the code translates the ASCII text string "data", which was passed in
(see the example data string above), into its hexadecimal equivalent to be sent to the controller.

The last command tells the controller to read back the result of the previous command. This is
invaluable, as it allows error codes to be viewed, if errors are returned. The last steps are to send
the completed packet and retrieve the response.

Here is how the output for a WRITE_SCRATCHPAD for the DS2430 looks when using the
example code:
    sent packet without errors
    Packet length: 40
    27 82 0A 23 22 0F 00 AA 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F 10
    11 12 13 14 15 16 17 18 19 1A 1B 1C 1D 1F 20 21 85
    got a packet without errors on receive
    Packet length: 39
    26 82 00 0A 22 0F 00 AA 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F 10
    11 12 13 14 15 16 17 18 19 1A 1B 1C 1D 1F 20 21
As can be seen, WRITE_SCRATCHPAD echoes the data written to it as well, which is why space
was allocated for it.

READ_SCRATCHPAD_2430
The READ_SCRATCHPAD command is nearly identical between the DS2430 and DS2431, but
some differences exist. The DS2430 will be covered first.

The first three commands are the same as the WRITE_SCRATCHPAD command. The device
must still be accessed and the controller must be put into data access mode. The block length, this
time, is only 3, because the expected buffer size, the READ_SCRATCHPAD command, and the
address to read from (always "0" for this example, but if less than the scratchpad length is read,
this could be incremented and read multiple times) is all that must be sent.

The expected data length is 2+SCRATCHPAD_LEN. See WRITE_SCRATCHPAD_2430 for why
this length is used.
Here is some example output from READ_SCRATCHPAD using the example code:
    sent packet without errors
    Packet length: 8
    07 82 0A 03 22 AA 00 85
    got a packet without errors on receive
    Packet length: 39
    26 82 00 0A 22 AA 00 AA 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F 10
    11 12 13 14
    15 16 17 18 19 1A 1B 1C 1D 1F 20 21
This is identical to what was written with the WRITE_SCRATCHPAD command, so the data was
written properly. Again, recall that the non-atomic operations cannot be guaranteed, as the 1-Wire
devices are powered down between MLAN commands, which erases the scratchpads.

COPY_SCRATCHPAD_2430
The COPY_SCRATCHPAD command is the only method for writing data to the memory of a
MLAN device; it copies the data in the scratchpad to the non-volatile memory. Like
READ_SCRATCHPAD, the command is fairly simple, as the data already exists and only needs
to be moved.

Once again, the first three bytes are the same as WRITE_SCRATCHPAD and
READ_SCRATCHPAD. Our block length is 3, as the expected response length, the
COPY_SCRATCHPAD command, and the "validation key" that ensures we are not writing to the
wrong device are sent. Each "family" of MLAN device has a different validation key. This will be
seen with the DS2431. Note that the expected response length is the minimum 2 bytes. Since the
COPY_SCRATCHPAD command does not actually return data to us, space does not have to be
allocated in the return buffer.

Once the copy command is sent, a delay is sent to the MLAN controller to allow time for the copy
to finish. The "1" sent after CMD_DATA is the length, in bytes, of the delay command which is
on the next line. A 'bitwise or' function is used to combine the units of delay with the delay length
� if a shorter or longer delay time is required, the 1-Wire specification defines several delay
lengths and several different time units which can be used.
Here is an example output from the COPY_SCRATCHPAD command using the example code:
    sent packet without errors
    Packet length: 11
    0A 82 0A 03 02 55 A5 0B 01 82 85
    got a packet without errors on receive
    Packet length: 7
    06 82 00 0A 02 55 A5
As there is no user data returned, the reply to this command is short.

READ_MEMORY_2430
Although the READ_MEMORY command is probably the most useful of the MLAN command, it
is discussed here as this is where the commands would logically appear in code.

Again, the first three are the same as those seen in previous examples. The block length is the
return buffer size, the READ_MEMORY command, and the address offset. Since the whole
address space can be read at once on the DS2430, the address offset is always zero. This in not
always the case for the DS2431's, as the DS2431 has a much larger memory space. See the
READ_MEMORY_2431 command for an example of this.

Note that the return buffer size does have to be big enough to hold the whole address space, so the
standard two bytes of MLAN data are added to the DS2430's address space size.

Here is an example output from the READ_MEMORY command using the example code:
    sent packet without errors
    Packet length: 8
    07 82 0A 03 22 F0 00 85
    got a packet without errors on receive
    Packet length: 39
    26 82 00 0A 22 F0 00 AA 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F 10
    11 12 13 14 15 16 17 18 19 1A 1B 1C 1D 1F 20 21
This is the same string that was in the WRITE_SCRATCHPAD, now has been transferred into
non-volatile memory.

WRITE_AND_COPY_SCRATCHPAD_2430
As noted above, the scratchpad is a volatile memory location. Between MLAN commands, the
1-Wire devices are powered down, and, hence, will lose all their scratchpad (volatile) data. In
example code below, the commands occur fast enough that power is not lost to the 1-Wire devices
and no data loss is experienced. This, however, is not recommended for a production environment.

As a consequence, the WRITE_AND_COPY command set is recommended. These commands are
atomic operations � they perform the write and the copy in a single MLAN command. Because the
read and write is accomplished in a single command, data integrity cannot be verified before it is
copied to memory (e.g. a READ_SCRATCHPAD command cannot be performed in the middle of
a WRITE_AND_COPY command set to verify the scratchpad write). However, the main memory
can still be checked after the write, in a separate series of MLAN operations to ensure that what
was written is correct.

If one looks closely, it becomes obvious that the WRITE_AND_COPY command is simply a
WRITE and a COPY command combined. There are multiple block length and data length bytes,
multiple commands, and all operations are performed that each of these commands did
individually. However, since they are issued in a single MLAN buffer, the device will not be
powered down and will not have a chance to lose its volatile data.

The example output of the WRITE_AND_COPY command is fairly long, but, like the code that
generates it, is very similar to an amalgamation of the WRITE_SCRATCHPAD and
COPY_SCRATCHPAD commands.
    sent packet without errors
    Packet length: 49
    30 82 0A 23 24 0F 00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F 10
    11 12 13 14
    15 16 17 18 19 1A 1B 1C 1D 1F 20 21 82 0A 03 02 55 A5 0B 01 82 85
    got a packet without errors on receive
    Packet length: 47
    2E 82 00 0A 24 0F 00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F 10
    11 12 13 14
    15 16 17 18 19 1A 1B 1C 1D 1F 20 21 FF FF 82 00 0A 02 55 A5

DS2431 COMMANDS

WRITE_SCRATCHPAD_2431
The DS2431 has the same command set as the DS2430, but some of the commands are different,
and some give more arguments to the MLAN controller. Some examples of these difference can
be seen in the WRITE_SCRATCHPAD command.

Notice first that, in comparison to the DS2430 scratchpad write, the length of the data string that is
checked is much smaller, although it uses the same formula. This is because the DS2431 has only
an 8-byte scratchpad, whereas the DS2430 has 32 bytes. The same format of data string is used to
submit data, however. Here is an example of a data string for the DS2431:
    "01 02 03 04 05 06 07 08"
Even on a different device, however, the basic format remains unchanged. The first byte received
is for length and the next two are CMD_ML_ACCESS and CMD_ML_DATA, just like in the
DS2430's command.

The block size is our first indicator that the DS2430 and DS2431, although similar, have slightly
different programming requirements. This block size is one byte larger than the DS2430's block
size, and the reason is readily apparent three commands down: there are two address registers
instead of one. The first address register, T1, is the beginning offset, and T2 is the address. As can
be seen in the example, T1 is used to offset the data within the main memory, allowing users to
write to any address between the bytes 0(hex) and 136e. From the 136th byte, users can write all the way
to the end of the memory.

The data length is also different. We add several bytes to the DS2430's command length, and two
of these are the CRC16 value that the DS2431 device returns to us. The CRC uses the entire
command, from WRITE_SCRATCHPAD all the way to the end of the data buffer, to generate its
CRC. Notice, too, that a CRC is run on the packet, passing in the offset of the
WRITE_SCRATCHPAD command in the packet and the length of the command plus the data.
This function is explained in the Additional Notes section.

NOTE If the CRC returned is not the same as the calculated CRC given by this program, the data write
was corrupted in transmission. Re-access the device and try the write again.

The same code is used as with the DS2430 to turn the data string into hexadecimal and to tell the
controller to send the response back with the CMD_GETBUF command.
The example output for the WRITE_SCRATCHPAD command for the DS2431 is very similar to
the WRITE_SCRATCHPAD for the DS2430, with the exception that the data is shorter:
    sent packet without errors
    Packet length: 17
    10 82 0A 0C 0D 0F 00 00 AA 02 03 04 05 06 07 08 85
    CRC16: 74E4
    got a packet without errors on receive
    Packet length: 18
    11 82 00 0A 0D 0F 00 00 AA 02 03 04 05 06 07 08 74 E4
This indicates that this write was successful, as the last two bytes returned are the same as the
calculated CRC.

READ_SCRATCHPAD_2431
Some differences from the DS2430 version are also seen here. Aside from using the
DS2431_SCRATCHPAD_LEN instead of the DS2430_SCRATCHPAD_LEN, a much larger
buffer is used for the data length. This is because the echo from the command being sent and a 2-
byte CRC calculated on the returned data stream are expected in addition to the data in the
scratchpad. It can also be seen that this is also passed into our the CRC calculating function so that
the CRC can be verified. See the note in the WRITE_SCRATCHPAD_2431 section for what to do
if the CRCs do not match.

Here is some example output from this command:
    sent packet without errors
    Packet length: 8
    07 82 0A 03 0E AA 00 85
    got a packet without errors on receive
    Packet length: 19
    12 82 00 0A 0E AA 00 00 07 AA 02 03 04 05 06 07 08 F9 19
    CRC16: F919
    The CRC again checks properly.

COPY_SCRATCHPAD_2431
The COPY_SCRATCHPAD command for the DS2431 is more complicated than the DS2430
command. Here, the scratchpad address must be passed in or the device will assume it is receiving
incorrect instructions and an error will occur. (The address should be the same address passed in to
WRITE_SCRATCHPAD). The ES register must also be passed in, which should be "07",
identical to its value in the READ_SCRATCHPAD command (if the original write was successful).
If this value is not "07" on the device, or if a number other than 07 is passed in, it is
assumed that the communication with this device was accidental and the copy will not occur.
Please refer to the DS2431 data sheet for more information on the ES register.

Here is some more example MLAN output:
    sent packet without errors
    Packet length: 12
    0B 82 0A 05 04 55 00 00 07 0B 01 82
    got a packet without errors on receive
    Packet length: 9
    08 82 00 0A 04 55 00 00 07

READ_MEMORY_2431
This command is almost exactly the same as the READ_MEMORY command for the DS2430,
other than specifying two bytes for the memory address to read.
There is significantly more output, because the DS2431 has nearly five times as much memory.
Once the end of the memory is reached, the device returns all "FF" bytes.

WRITE_AND_COPY_SCRATCHPAD_2431
Like all 1-Wire devices, the DS2431 chips are powered down between MLAN commands.
This can cause the volatile scratchpads to lose data, and, as such, the individual
WRITE_SCRATCHPAD and COPY_SCRATCHPAD commands are only recommended for
demonstration purposes.

The combined WRITE_AND_COPY command set issues a single MLAN buffer and has the
advantage if being an atomic operation, meaning the device will not lose data in the middle. The
disadvantage is that data verification is not possible until after the write has occurred.

This follows the same format as the DS2430's command as it is a concatenation of the
WRITE_SCRATCHPAD and COPY_SCRATCHPAD commands. The CRC16 is calculated on
the sent packet, and the returned result still contains the CRC bytes. However, as the results are
already written to memory, a bad write will only be evident after the fact.
Here is some example output from this command:
    sent packet without errors
    Packet length: 27
    1A 82 0A 0C 0D 0F 00 00 AA 02 03 04 05 06 07 08 82 0A 05 04 55 00 00
    07 0B 01 82
    CRC16: 74E4
    got a packet without errors on receive
    Packet length: 26
    19 82 00 0A 0D 0F 00 00 AA 02 03 04 05 06 07 08 74 E4 82 00 0A 04 55
    00 00 07
We can again see the CRC returned at the end of the WRITE_SCRATCHPAD portion of the
WRITE_AND_COPY command, and that it matches what was calculated, indicating a successful
write.

ADDITIONAL NOTES

Checksums
It should be noted that a "page" in the main memory of 1-Wire device consists of 32 bytes
according to the IEEE 1451.4 specification. Each page of memory is supposed to have a one-byte
checksum as the first bit, which when added to the other 31 bits in the page (dropping any carry)
makes the result 0. In the example code (and in the VTEXDigitizer driver used to implement it) there are
no checks made to ensure that the user inserts a checksum properly. If the user wishes to
implement checksums (and, therefore, be fully compliant with the IEEE 1451.4 standard), a proper
checksum should be written to the first page of memory, updated when memory is updated, and
the checksums should be calculated and verified on reads.

CRC Checking
The CRC check function is called to calculate a CRC16 for the written data and the read data on
the DS2431. See the implementation for a brief explanation.
