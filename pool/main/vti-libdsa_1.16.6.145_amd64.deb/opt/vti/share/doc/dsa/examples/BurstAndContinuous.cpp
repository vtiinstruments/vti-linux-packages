#include "libDsa.h"
#include <unistd.h>
#include <iostream>

int main(int argc, char* argv[])
{
    LibDsa* all_driver;
    LibDsa* inp_driver;
    LibDsa* src_driver;
    try
    {
        // Create a new instance of the VTEXDsa driver
        /* Note: We are using separate driver sessions for the EMX-1434 and the EMX-4xxx cards so that they can be coordinated independently.
         * When the DAC channels on the EMX-1434 are set to continuous mode and a measurement is initiated,
         * the measurement state will remain in VTEXDsaMeasurementStateMeasuring until Abort is called
         */
        all_driver= LibDsa::Create();
        inp_driver= LibDsa::Create();
        src_driver= LibDsa::Create();

        try
        {
            //
            // The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
            // where slot0_3 specifies a single card in the chassis
            //
            std::string src_resource_str("10.1.4.37::slot0_5");  // EMX-1434 at slot 5, list all EMX-1434 card slots.
            std::string inp_resource_str("10.1.4.37::slot0_4");  // EMX-4250 at slot 4, list all EMX-4250 card slots.
            std::string all_resource_str("10.1.4.37"); // All EMX cards in this chassis

            // Initialize a driver that includes both input and source cards.
            // Reset to default configuration.
            all_driver->Initialize(all_resource_str, true, true, "");
            std::cout << "Initialized to " << all_resource_str << std::endl;

            // Use PXI0 line to sync all EMX cards.
            all_driver->Sync->Line = "PXI0";
            all_driver->Sync->CoordinationLine = "PXI0";

            // Enable DAC channel 1 and set it to 1V, 30% duty cycle Burst Random.
            std::string dac1 = all_driver->Dac->Channels->Name[1];
            all_driver->Dac->Channels->Item[dac1]->Enabled = true;
            all_driver->Dac->Channels->Item[dac1]->OperationMode = VTEXDsaDacOperationModeBurst;
            all_driver->Dac->Channels->Item[dac1]->OutputMode = VTEXDsaDacOutputModeFunction;
            all_driver->Dac->Channels->Item[dac1]->BurstDutyCycle = 30.0;
            all_driver->Dac->Channels->Item[dac1]->StandardWaveform->Waveform = VTEXDsaWaveformRandom;
            all_driver->Dac->Channels->Item[dac1]->StandardWaveform->Random->Type = VTEXDsaRandomTypeWhiteNormal;
            all_driver->Dac->Channels->Item[dac1]->StandardWaveform->Amplitude= 1.0;

            // Configure sampling parameters.
            all_driver->Measurement->Sampling->ClockFrequency = 204800.0;
            all_driver->Measurement->Sampling->Span = 625.0;
            all_driver->Measurement->Sampling->RecordSize = 1024;

            // Configure to trigger from DAC for infinite times.
            all_driver->Trigger->TriggerCount = 0;
            all_driver->Trigger->Sources->DisableAll();
            all_driver->Trigger->Sources->Item[dac1]->Enabled = true;

            // Initiate measurement which starts, burst and data acqusition.
            all_driver->Measurement->Initiate();

            //
            // Read as many records of burst excition data as desired and process them here.
            //
            while(all_driver->Measurement->NumFIFORecords < 5)
            {
                 std::cout << "FIFO: " << all_driver->Measurement->NumFIFORecords << std::endl;
                 sleep(1);
            }

            // Abort measurement, stops burst output.
            all_driver->Measurement->Abort();

            all_driver->Close(); // Close a driver session for all cards.

            // Initialize input and source driver sessions preserving current configuration.
            inp_driver->Initialize(inp_resource_str, true, false, "");
            std::cout << "Initialized to " << inp_resource_str << std::endl;

            // Use PXI1 line to sync all EMX-1434 cards.
            inp_driver->Sync->Line = "PXI1";
            inp_driver->Sync->CoordinationLine = "PXI1";

            src_driver->Initialize(src_resource_str, true, false, "");
            std::cout << "Initialized to " << src_resource_str << std::endl;

            // Use PXI2 line to sync all EMX-4250 cards.
            inp_driver->Sync->Line = "PXI2";
            inp_driver->Sync->CoordinationLine = "PXI2";

            // Set src to continous random and start output.
            src_driver->Dac->Channels->Item[dac1]->OperationMode = VTEXDsaDacOperationModeContinuous;

            // Set source driver's trigger to Immediate
            src_driver->Trigger->Sources->DisableAll();
            src_driver->Trigger->Sources->Item["Immediate"]->Enabled = true;

            // Start random output
            src_driver->Measurement->Initiate();

            // Set input to Immediate triggter also.
            inp_driver->Trigger->Sources->DisableAll();
            inp_driver->Trigger->Sources->Item["Immediate"]->Enabled = true;

            // Set trigger holdoff to allow overlapped acquistion.
            inp_driver->Trigger->Holdoff = 0.2;  // Get new trigger after 0.2 sec from previous one.

            // Start data acqusition
            inp_driver->Measurement->Initiate();

            //
            // Read as many records of random excition data, overlapped here.
            //
            while(inp_driver->Measurement->NumFIFORecords < 20)
            {
                 std::cout << "FIFO: " << inp_driver->Measurement->NumFIFORecords << std::endl;
                 sleep(1);
            }

            // Abort measurement
            inp_driver->Measurement->Abort();

            // Stop source.
            src_driver->Measurement->Abort();

            inp_driver->Close(); // Close a driver session for digitizer cards.
            src_driver->Close(); // Close a driver session for EMX-1434 cards.

        }
        catch (VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                std::string error;
                int32_t error_code = 0;

                if(all_driver->Initialized)
                {
                    all_driver->Utility->ErrorQuery(error_code, error);
                    all_driver->Close();
                }
                else if(inp_driver->Initialized || src_driver->Initialized)
                {
                    if(inp_driver->Initialized)
                    {
                        inp_driver->Utility->ErrorQuery(error_code, error);
                        inp_driver->Close();
                    }
                    if(src_driver->Initialized)
                    {
                        if(error_code == 0) src_driver->Utility->ErrorQuery(error_code, error);
                        src_driver->Close();
                    }
                }
                std::cerr << "Error Code: " << error_code << std::endl;
                std::cerr << error << std::endl;
            }
            else
            {
                std::cerr << e.errorMessage << std::endl;
            }
         }
    }
    catch(...)
    {
        //Handle any non VTEX errors in an intelligent manner
    }
    return 0;
}
