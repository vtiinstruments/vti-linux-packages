#include "libDsa.h"
#include <iostream>

int main(int argc, char* argv[])
{
    LibDsa *driver;
    try
    {
        // Create a new instance of the driver
        driver = LibDsa::Create();
        try
        {
            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             */
            if(argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                std::cout << "Ex: " << argv[0] << "TCPIP::192.168.0.1::INSTR" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // Initialize the driver
            driver->Initialize(resource_string, false, true, "");

            // "ALL" is a channel group which allows you to modify all of the channels at once
            driver->Channels->Item["ALL"]->Enabled = true; // Enable the channels
            driver->Channels->Item["ALL"]->AutoRangeMode = VTEXDsaAutoRangeModeOff;
            driver->Channels->Item["ALL"]->Range = 10;
            driver->Channels->Item["ALL"]->Function = VTEXDsaChannelFunctionVoltage; // Set the channels to measure voltage

            // Setup sample rate, record size and number record per trigger on all channels
            driver->Measurement->Sampling->SampleRate = 4096;
            driver->Measurement->Sampling->RecordSize = 128;
            driver->Measurement->NumRecordsPerTrigger = 10;

            //Initiate the measurement
            driver->Measurement->Initiate();
            driver->Measurement->WaitForMeasurementComplete(5000); // Wait up to 5 seconds for the measurement to finish.

            int actual_records = 0;
            std::vector<double> data;
            std::vector<double> ts_sec;
            std::vector<double> ts_frac;
            std::string addl_data;
            std::string channels;

            int64_t count = driver->Measurement->NumFIFORecords;
            std::cout << "Count: " << count << std::endl;

            if(count > 0) // Make sure there is data in the FIFO
            {
                /* Read out all of the data from the FIFO with a timeout of 1000ms
                 * Set the number of records to read to -1, which indicates that all records should be read
                 */
                driver->Measurement->Read(1000, -1, actual_records, channels, data, ts_sec, ts_frac, addl_data);
                std::vector<double>::iterator it;
                for(it = data.begin(); it != data.end(); it++)
                {
                    std::cout << *it << std::endl; // Print out all of the data - Note, this can produce a lot of output
                }
            }
            driver->Close();
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(driver->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    driver->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(driver->Initialized)
            {
                driver->Close();
            }
        }
    }
    catch(...)
    {
        //Do something to intelligently deal with any other non-VTEX errors.
    }

    return 0;
}
