#include "libDsa.h"
#include <iostream>

int main(int argc, char **argv)
{
    LibDsa *driver;
    try {
        // Create a new instance of the driver
        driver = LibDsa::Create();
        try {

            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             */
            if (argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            // Initialize the driver
            driver->Initialize(resource_string, true, true);
            std::cout << "Initialized to " << resource_string << std::endl;

            // Query the instrument for different properties: Model Number, Serial Number, Channels, and Channel Groups

            std::string serial = driver->Platform->SerialNumber;
            std::cout << "Serial: " << serial << std::endl;

            std::string model = driver->Identity->InstrumentModel;
            std::cout << "Model: " << model << std::endl;

            model = driver->Platform->InstrumentModel;
            std::cout << "(Platform) Model: " << model << std::endl;

            std::string firmware_rev = driver->Identity->InstrumentFirmwareRevision;
            std::cout << "Firmware Revision: " << firmware_rev << std::endl;

            firmware_rev = driver->Platform->InstrumentFirmwareRevision;
            std::cout << "(Platform) Firmware Revision: " << firmware_rev << std::endl;

            std::string manufacturer = driver->Identity->InstrumentManufacturer;
            std::cout << "Manufacturer: " << manufacturer << std::endl;

            manufacturer = driver->Platform->InstrumentManufacturer;
            std::cout << "(Platform) Manufacturer: " << manufacturer << std::endl;

            std::cout << "Channels:" << std::endl;
            int channel;
            for (channel = 1; channel <= driver->Channels->NumChannels; channel++)
            {
                std::cout << "\t" << driver->Channels->Name[channel] << std::endl;
            }

            std::cout << "Channel Groups:" << std::endl;
            for (; channel <= driver->Channels->Count; channel++)
            {
                std::cout << "\t" << driver->Channels->Name[channel] << std::endl;
            }

            driver->Close(); // Make sure to close the driver session when you are finished
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(driver->Initialized)
                {
                    std::string error;
                    int32_t error_code;
                    driver->Utility->ErrorQuery(error_code, error);

                    std::cerr << "Error Code: " << error_code << std::endl;
                    std::cerr << error << std::endl;
                }
                else
                {
                    std::cerr << "Error Code: " << e.errorCode << std::endl;
                    std::cerr << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            if(driver->Initialized)
            {
                driver->Close();
            }
        }

        //Clean up when we're done
        delete driver;
        driver = nullptr;
    }
    catch(...)
    {
        // Handle any non VTEX exceptions intelligently here
    }
}
