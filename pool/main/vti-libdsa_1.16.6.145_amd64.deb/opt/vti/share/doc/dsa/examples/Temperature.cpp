
#include "Temperature.h"

int main(int argc, char **argv)
{
    LibDsa *driver;
    try {
        // Create a new instance of the Dsa driver
        driver = LibDsa::Create();
        try{
            /* The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
             * where slot0_3 specifies a single card in the chassis
             */
            if (argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                std::cout << "Ex: " << argv[0] << " TCPIP::192.168.0.1::INSTR" << std::endl;
                return -1;
            }
            std::string resource_str(argv[1]);

            // Initialize the driver session
            driver->Initialize(resource_str, false, true, "");
            std::cout << "Initialized to " << resource_str << std::endl;

            // This example program is written specifically for features supported by the EX1401 thermocouple instrument
            // It may need to be adapted for use with other instruments supported by the Dsa driver
            std::string model = driver->Identity->InstrumentModel;
            std::cout << "Model: " << model << std::endl;

            // Start by creating some channel groups that can be used to configure the acquisition settings
            driver->Channels->AddChannelGroup("Volts", "CH1,CH2,CH3,CH4");
            driver->Channels->AddChannelGroup("TC_T", "CH5,CH6,CH7,CH8");
            driver->Channels->AddChannelGroup("TC_K", "CH9,CH10,CH11,CH12");
            driver->Channels->AddChannelGroup("TC_Custom", "CH13,CH14,CH15,CH16");
            driver->Channels->AddChannelGroup("TC", "CH5,CH6,CH7,CH8,CH9,CH10,CH11,CH12,CH13,CH14,CH15,CH16");

            // Enable CJC reporting on all channels (including those that will be set to voltage)
            driver->Channels->Item["All"]->Temperature->Thermocouple->CJCReportingEnabled = true;

            // Configure the first 4 channels for voltage data
            driver->Channels->Item["Volts"]->Function = VTEXDsaChannelFunctionVoltage;
            driver->Channels->Item["Volts"]->Range = 1.0;

            // Configure all of the other channels for thermocouple data, using the internal (CJC) reference
            driver->Channels->Item["TC"]->Function = VTEXDsaChannelFunctionTemperature;
            driver->Channels->Item["TC"]->Temperature->TransducerType = VTEXDsaTemperatureTransducerTypeThermocouple;
            driver->Channels->Item["TC"]->Temperature->Thermocouple->RefJunctionType = VTEXDsaRefJunctionTypeInternal;

            // Type T thermocouples have good accuracy, but a narrow range (-200 to 400 degC)
            driver->Channels->Item["TC_T"]->Temperature->Thermocouple->Type = VTEXDsaThermocoupleTypeT;

            // Type K thermocouples are cheap and have a wider range than Type T (-200 to 1372 degC), but the accuracy suffers at higher temperatures
            driver->Channels->Item["TC_K"]->Temperature->Thermocouple->Type = VTEXDsaThermocoupleTypeT;

            // There are many types of thermocouple that aren't directly supported by the EX1401, but it's still possible to use them with the EX1401
            // We'll use the NIST coefficients for Type E thermocouples (specifically, the coefficients for 0 to 1000 degC),
            // but any exotic thermocouple or custom sensor could also be used
            driver->Channels->Item["TC_Custom"]->Temperature->Thermocouple->Type = VTEXDsaThermocoupleTypeCustom;

            // The forward conversion polynomial is used to convert a CJC temperature into a compensating voltage
            std::vector<double> forward_coeffs;
            for(int i = 0; i < NUM_FORWARD_COEFFS; i++)
            {
                forward_coeffs.push_back(TypeE_ForwardCoeffs[i]);
            }
            driver->Channels->Item["TC_Custom"]->Temperature->Thermocouple->SetCustomCJCConversion(forward_coeffs);

            // The inverse conversion polynomial is used to convert a compensated input voltage into temperature
            std::vector<double> inverse_coeffs;
            for(int i = 0; i < NUM_INVERSE_COEFFS; i++)
            {
                inverse_coeffs.push_back(TypeE_InverseCoeffs[i]);
            }
            driver->Channels->Item["TC_Custom"]->Transducer->SetConversion(inverse_coeffs);

            std::cout << "Configured channels" << std::endl;

            // If the instrument is set to use PTP on the time configuration web page, we can use that as the reference oscillator & timestamp source
            driver->ReferenceOscillator->Source = VTEXDsaReferenceOscillatorSourceSystem;
            driver->ReferenceOscillator->TimestampSource = VTEXDsaReferenceOscillatorTimestampSourceSystem;

            // Configure an alarm to fire at a half-second interval, repeating until the alarm is disabled
            // Setting the alarm time to 0 seconds and 0 nanoseconds means the alarm should fire "now", as soon as it's enabled,
            // so we won't enable the alarm until after the acquisition has been initiated
            std::string trig_alarm = "ALARM1";
            driver->Alarms->Item[trig_alarm]->Enabled = false;
            driver->Alarms->Item[trig_alarm]->RepeatCount = 0;
            driver->Alarms->Item[trig_alarm]->Period = 0.5;
            driver->Alarms->Item[trig_alarm]->TimeSeconds = 0;
            driver->Alarms->Item[trig_alarm]->TimeFraction = 0;
            std::cout << "Configured alarm" << std::endl;

            // Use the alarm as the trigger source
            driver->Trigger->TriggerCount = 10;
            driver->Trigger->Sources->DisableAll();
            driver->Trigger->Sources->Item[trig_alarm]->Enabled = true;
            std::cout << "Configured trigger: " << trig_alarm << std::endl;

            // Use the DIO lines as overload indicators
            // DIO0 will go high if any of the voltage channels are over-range (ADC overload)
            // DIO1/DIO2/DIO3 will go high if any of the thermocouple channels are outside 0 to 100 degC
            driver->Events->Item["DIO0"]->Slope = VTEXDsaSourceSlopeRise;
            driver->Events->Item["DIO0"]->DriveMode = VTEXDsaEventDriveModeDriven;
            driver->Events->Item["DIO0"]->Source = "Overload_CH1-4";
            driver->Channels->Item["Volts"]->Overload->EventEnabled = 0x10000;

            driver->Events->Item["DIO1"]->Slope = VTEXDsaSourceSlopeRise;
            driver->Events->Item["DIO1"]->DriveMode = VTEXDsaEventDriveModeDriven;
            driver->Events->Item["DIO1"]->Source = "Overload_CH5-8";
            driver->Channels->Item["TC_T"]->Overload->UserLowerLimit = 0.0;
            driver->Channels->Item["TC_T"]->Overload->UserUpperLimit = 100.0;
            driver->Channels->Item["TC_T"]->Overload->UserLimitEnabled = true;
            driver->Channels->Item["TC_T"]->Overload->EventEnabled = 0x18;

            driver->Events->Item["DIO2"]->Slope = VTEXDsaSourceSlopeRise;
            driver->Events->Item["DIO2"]->DriveMode = VTEXDsaEventDriveModeDriven;
            driver->Events->Item["DIO2"]->Source = "Overload_CH9-12";
            driver->Channels->Item["TC_K"]->Overload->UserLowerLimit = 0.0;
            driver->Channels->Item["TC_K"]->Overload->UserUpperLimit = 100.0;
            driver->Channels->Item["TC_K"]->Overload->UserLimitEnabled = true;
            driver->Channels->Item["TC_K"]->Overload->EventEnabled = 0x18;

            driver->Events->Item["DIO3"]->Slope = VTEXDsaSourceSlopeRise;
            driver->Events->Item["DIO3"]->DriveMode = VTEXDsaEventDriveModeDriven;
            driver->Events->Item["DIO3"]->Source = "Overload_CH13-16";
            driver->Channels->Item["TC_Custom"]->Overload->UserLowerLimit = 0.0;
            driver->Channels->Item["TC_Custom"]->Overload->UserUpperLimit = 100.0;
            driver->Channels->Item["TC_Custom"]->Overload->UserLimitEnabled = true;
            driver->Channels->Item["TC_Custom"]->Overload->EventEnabled = 0x18;

            // Open transducer detection isn't supported for voltage inputs, so it should be disabled
            driver->Channels->Item["Volts"]->Overload->OTDEnabled = false;

            // The temperature channels should all have open transducer detection enabled
            // In addition, it should be set to latching so that it stays high until cleared
            // The indicator LED should also turn on, so it's easy to see at a glance that there's a problem with the input connector
            driver->Channels->Item["TC"]->Overload->OTDEnabled = true;
            driver->Channels->Item["TC"]->Overload->LatchEnabled = 0x20;
            driver->Channels->Item["TC"]->Overload->Indicator = 0x20;

            std::cout << "Configured overload indicators" << std::endl;

            // Allow the driver to automatically configure the settings for sync & coordination
            driver->Sync->AutoConfigure();
            std::string sync_line = driver->Sync->Line;
            std::string coord_line = driver->Sync->CoordinationLine;
            std::cout << "Configured sync & coordination" << std::endl;
            std::cout << "Sync.Line: " << sync_line << std::endl;
            std::cout << "Sync.CoordinationLine: " << coord_line << std::endl;

            // Acquire data at 1 kHz with 256 samples in each record (~0.25 seconds of data per record)
            driver->Measurement->Sampling->SampleRate = 1000;
            driver->Measurement->Sampling->RecordSize = 256;

            // Synchronize & initiate the acquisition
            driver->Sync->SendSoftwareSync();
            driver->Measurement->Initiate();
            std::cout << "Initiated acquisition" << std::endl;

            // Wait for the measurement state to reach WaitingForTrigger, then enable the alarm
            VTEXDsaMeasurementStateEnum state = VTEXDsaMeasurementStateIdle;
            while(state != VTEXDsaMeasurementStateWaitingForTrigger)
            {
                usleep(10000);
                state = driver->Measurement->State;
            }
            driver->Alarms->Item[trig_alarm]->Enabled = true;

            // Wait up to 20 seconds for the acquisition to complete, then disable the alarm
            driver->Measurement->WaitForMeasurementComplete(20000);
            driver->Alarms->Item[trig_alarm]->Enabled = false;
            std::cout << "Acquisition complete" << std::endl;

            // Read/process data
            int actual_records = 0;
            std::vector<double> data;
            std::vector<double> ts_sec;
            std::vector<double> ts_frac;
            std::string addl_data;
            std::string channels;

            int64_t count = driver->Measurement->NumFIFORecords;
            std::cout << "NumFIFORecords: " << count << std::endl;
            if(count > 0) // Make sure there is data in the FIFO
            {
                // Read out all of the data from the FIFO with a timeout of 5 seconds
                // Set the number of records to read to -1, which indicates that all records should be read
                driver->Measurement->Read(5000, -1, actual_records, channels, data, ts_sec, ts_frac, addl_data);

                std::cout << "Measurement.Read channels: " << channels << std::endl;

                // Printing all of the data would produce a lot of output, so that code is disabled
#if 0
                for(auto it = data.begin(); it != data.end(); it++)
                {
                    std::cout << *it << std::endl;
                }
#endif
            }

            // Close the driver session
            driver->Close();
        }
        catch(VTEXException e)
        {
            // If the error is IVI_E_INSTRUMENT_STATUS or VTEX_E_ASYNC_ERROR, we need to check the error queue on the instrument
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS || e.Error() == (int)VTEX_E_ASYNC_ERROR)
            {
                if(driver->Initialized)
                {
                    int32_t error_code = -1;
                    std::string error_msg;
                    while(error_code != IVI_SUCCESS)
                    {
                        driver->Utility->ErrorQuery(error_code, error_msg);
                        std::cerr << "Error: 0x" << std::hex << error_code << " " << error_msg << std::endl;
                    }
                }
                else
                {
                    std::cerr << "Error: 0x" << std::hex << e.errorCode << " " << e.errorMessage << std::endl;
                }
            }
            else
            {
                std::cerr << "Error: 0x" << std::hex << e.errorCode << " " << e.errorMessage << std::endl;
            }
            if(driver->Initialized)
            {
                driver->Close();
            }
        }

        //Clean up when we're done
        delete driver;
        driver = nullptr;
    }
    catch(...)
    {
        // Handle non VTEX errors in an intelligent manner
    }
}

