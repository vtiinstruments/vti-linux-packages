/******************************************************************************
*
*  .----------------------.    File Name: libDsa.h
*  |==     ==  ======  == |    Project : EX Platform
*  | ==   ==   ======  == |    $Author$
*  |  == ==      ==    == |    $Revision$
*  |   ===       ==    == |    $Date$
*  |    =        ==    == | $HeadURL$
*  `----------------------'
*
* Copyright 2010 VTI Instruments Inc. as an unpublished work.
* All rights reserved. The information contained herein is confidential
* property of VTI Instruments, Inc. Use, copy, transfer or disclosure
* of such information is prohibited except by express written agreement
* with VTI Instruments, Inc.
*
* PURPOSE:
*   Main public interface file for the Dsa library.
*
* First Written By: James Vogel On Oct-2011
******************************************************************************/
#ifndef _libDsa_H
#define _libDsa_H

/**************************
 *       Includes         *
 **************************/
#include <string>
#include <vector>

#include "vtexInherent.h"
#include "libVtexException.h"

#include "libDsaErrors.h"
#include "libDsaEnums.h"

//=============================================================================

/**
 * Dsa.Channels.Item[].Sampling
 *
 */

class VTEX_EXPORT LibDsaSampling
{
public:
    virtual ~LibDsaSampling() {};

    virtual VTEXResult Configure(int64_t record_size, double sample_rate, bool oversample) = 0;

    virtual VTEXResult GetFilterCoefficients(std::vector<double> &coeffs) = 0;
    virtual VTEXResult SetFilterCoefficients(std::vector<double> coeffs) = 0;

    virtual VTEXResult get_ClockFrequency(double &val) = 0;
    virtual VTEXResult put_ClockFrequency(double val) = 0;
    virtual VTEXResult get_RecordSize(int64_t &val) = 0;
    virtual VTEXResult put_RecordSize(int64_t val) = 0;
    virtual VTEXResult get_SampleRate(double &val) = 0;
    virtual VTEXResult put_SampleRate(double val) = 0;
    virtual VTEXResult get_Span(double &val) = 0;
    virtual VTEXResult put_Span(double val) = 0;
    virtual VTEXResult get_Oversample(bool &val) = 0;
    virtual VTEXResult put_Oversample(bool val) = 0;
    virtual VTEXResult get_Prescaler(int32_t &val) = 0;
    virtual VTEXResult put_Prescaler(int32_t val) = 0;
    virtual VTEXResult get_Multipass(bool &val) = 0;
    virtual VTEXResult put_Multipass(bool val) = 0;
    virtual VTEXResult get_DownsamplingFactor(int32_t &val) = 0;
    virtual VTEXResult put_DownsamplingFactor(int32_t val) = 0;
    virtual VTEXResult get_FilterType(VTEXDsaDecimationFilterEnum &val) = 0;
    virtual VTEXResult put_FilterType(VTEXDsaDecimationFilterEnum val) = 0;
    virtual VTEXResult get_GroupDelay(double &val) = 0;
    virtual VTEXResult put_GroupDelay(double val) = 0;

    vtexProperty <LibDsaSampling, double, READ_WRITE> ClockFrequency;
    vtexProperty <LibDsaSampling, int64_t, READ_WRITE> RecordSize;
    vtexProperty <LibDsaSampling, double, READ_WRITE> SampleRate;
    vtexProperty <LibDsaSampling, double, READ_WRITE> Span;
    vtexProperty <LibDsaSampling, bool, READ_WRITE> Oversample;
    vtexProperty <LibDsaSampling, int32_t, READ_WRITE> Prescaler;
    vtexProperty <LibDsaSampling, bool, READ_WRITE> Multipass;
    vtexProperty <LibDsaSampling, int32_t, READ_WRITE> DownsamplingFactor;
    vtexProperty <LibDsaSampling, VTEXDsaDecimationFilterEnum, READ_WRITE> FilterType;
    vtexProperty <LibDsaSampling, double, READ_WRITE> GroupDelay;
};

//=============================================================================

/**
 * Dsa.Measurement.Sampling
 *
 */

class VTEX_EXPORT LibDsaMeasurementSampling
{
public:
    virtual ~LibDsaMeasurementSampling() {};

    virtual VTEXResult Configure(int64_t record_size, double sample_rate, bool oversample) = 0;

    virtual VTEXResult GetFilterCoefficients(std::vector<double> &coeffs) = 0;
    virtual VTEXResult SetFilterCoefficients(std::vector<double> coeffs) = 0;

    virtual VTEXResult get_ClockFrequency(double &val) = 0;
    virtual VTEXResult put_ClockFrequency(double val) = 0;
    virtual VTEXResult get_RecordSize(int64_t &val) = 0;
    virtual VTEXResult put_RecordSize(int64_t val) = 0;
    virtual VTEXResult get_SampleRate(double &val) = 0;
    virtual VTEXResult put_SampleRate(double val) = 0;
    virtual VTEXResult get_Span(double &val) = 0;
    virtual VTEXResult put_Span(double val) = 0;
    virtual VTEXResult get_Oversample(bool &val) = 0;
    virtual VTEXResult put_Oversample(bool val) = 0;
    virtual VTEXResult get_Prescaler(int32_t &val) = 0;
    virtual VTEXResult put_Prescaler(int32_t val) = 0;
    virtual VTEXResult get_Multipass(bool &val) = 0;
    virtual VTEXResult put_Multipass(bool val) = 0;
    virtual VTEXResult get_DownsamplingFactor(int32_t &val) = 0;
    virtual VTEXResult put_DownsamplingFactor(int32_t val) = 0;
    virtual VTEXResult get_FilterType(VTEXDsaDecimationFilterEnum &val) = 0;
    virtual VTEXResult put_FilterType(VTEXDsaDecimationFilterEnum val) = 0;
    virtual VTEXResult get_GroupDelay(double &val) = 0;
    virtual VTEXResult put_GroupDelay(double val) = 0;

    vtexProperty <LibDsaMeasurementSampling, double, READ_WRITE> ClockFrequency;
    vtexProperty <LibDsaMeasurementSampling, int64_t, READ_WRITE> RecordSize;
    vtexProperty <LibDsaMeasurementSampling, double, READ_WRITE> SampleRate;
    vtexProperty <LibDsaMeasurementSampling, double, READ_WRITE> Span;
    vtexProperty <LibDsaMeasurementSampling, bool, READ_WRITE> Oversample;
    vtexProperty <LibDsaMeasurementSampling, int32_t, READ_WRITE> Prescaler;
    vtexProperty <LibDsaMeasurementSampling, bool, READ_WRITE> Multipass;
    vtexProperty <LibDsaMeasurementSampling, int32_t, READ_WRITE> DownsamplingFactor;
    vtexProperty <LibDsaMeasurementSampling, VTEXDsaDecimationFilterEnum, READ_WRITE> FilterType;
    vtexProperty <LibDsaMeasurementSampling, double, READ_WRITE> GroupDelay;
};

//=============================================================================

/**
 * Dsa.Measurement
 *
 */

class VTEX_EXPORT LibDsaMeasurement
{
public:
    virtual ~LibDsaMeasurement() {};

    LibDsaMeasurementSampling* Sampling;

    virtual VTEXResult Abort() = 0;
    virtual VTEXResult Initiate() = 0;
    virtual VTEXResult Read(int32_t max_time_ms,
                            int32_t num_records, int32_t& actual_records,
                            std::string &channel, std::vector<double> &data,
                            std::vector<double> &ts_sec, std::vector<double> &ts_frac,
                            std::string &addl_data) = 0;
    virtual VTEXResult ReadWithCJC(int32_t max_time_ms,
        int32_t num_records, int32_t& actual_records,
        std::string &channel, std::vector<double> &data,
        std::vector<double> &ts_sec, std::vector<double> &ts_frac,
        std::string &addl_data,
        std::string &channel_cjc, std::vector<double> &data_cjc,
        std::vector<double> &ts_sec_cjc, std::vector<double> &ts_frac_cjc) = 0;
    virtual VTEXResult WaitForMeasurementComplete(int32_t max_time_milliseconds) = 0;

    virtual VTEXResult get_State(VTEXDsaMeasurementStateEnum &val) = 0;
    virtual VTEXResult get_NumFIFORecords(int64_t &val) = 0;
    virtual VTEXResult get_NumAcquiredRecords(int64_t &val) = 0;
    virtual VTEXResult get_NumRecordsPerTrigger(int64_t &val) = 0;
    virtual VTEXResult put_NumRecordsPerTrigger(int64_t val) = 0;
    virtual VTEXResult get_FIFOMode(VTEXDsaFifoModeEnum &val) = 0;
    virtual VTEXResult put_FIFOMode(VTEXDsaFifoModeEnum val) = 0;
    virtual VTEXResult get_DataFormat(VTEXDsaDataFormatEnum &val) = 0;
    virtual VTEXResult put_DataFormat(VTEXDsaDataFormatEnum val) = 0;

    vtexProperty <LibDsaMeasurement, VTEXDsaMeasurementStateEnum, READ_ONLY> State;
    vtexProperty <LibDsaMeasurement, int64_t, READ_ONLY> NumFIFORecords;
    vtexProperty <LibDsaMeasurement, int64_t, READ_ONLY> NumAcquiredRecords;
    vtexProperty <LibDsaMeasurement, int64_t, READ_WRITE> NumRecordsPerTrigger;
    vtexProperty <LibDsaMeasurement, VTEXDsaFifoModeEnum, READ_WRITE> FIFOMode;
    vtexProperty <LibDsaMeasurement, VTEXDsaDataFormatEnum, READ_WRITE> DataFormat;
};

//=============================================================================

/**
 * Dsa.Alarm
 *
 */

class VTEX_EXPORT LibDsaAlarm
{
public:
    virtual ~LibDsaAlarm() {};

    virtual VTEXResult Configure(bool enabled, double time_seconds, double time_fraction, double period, int32_t repeat_count) = 0;

    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Period(double &val) = 0;
    virtual VTEXResult put_Period(double val) = 0;
    virtual VTEXResult get_RepeatCount(int32_t &val) = 0;
    virtual VTEXResult put_RepeatCount(int32_t val) = 0;
    virtual VTEXResult get_TimeSeconds(double &val) = 0;
    virtual VTEXResult put_TimeSeconds(double val) = 0;
    virtual VTEXResult get_TimeFraction(double &val) = 0;
    virtual VTEXResult put_TimeFraction(double val) = 0;

    vtexProperty <LibDsaAlarm, bool, READ_WRITE> Enabled;
    vtexProperty <LibDsaAlarm, double, READ_WRITE> Period;
    vtexProperty <LibDsaAlarm, int32_t, READ_WRITE> RepeatCount;
    vtexProperty <LibDsaAlarm, double, READ_WRITE> TimeSeconds;
    vtexProperty <LibDsaAlarm, double, READ_WRITE> TimeFraction;
};

//=============================================================================

/**
* Dsa.Alarms
*
*/

class VTEX_EXPORT LibDsaAlarms
{
public:
    virtual ~LibDsaAlarms() {};

    virtual VTEXResult DisableAll() = 0;
    virtual LibDsaAlarm* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibDsaAlarms, int32_t, READ_ONLY> Count;
    arrayizer <LibDsaAlarms, LibDsaAlarm*, std::string> Item;
    arrayizer <LibDsaAlarms, std::string, int32_t> Name;
};

//=============================================================================

/**
 * Dsa.Arm.Sources.Item.Rpm
 *
 */

class VTEX_EXPORT LibDsaArmSourceRpm
{
public:
    virtual ~LibDsaArmSourceRpm() {};

    virtual VTEXResult get_Minimum(double &val) = 0;
    virtual VTEXResult put_Minimum(double val) = 0;
    virtual VTEXResult get_Maximum(double &val) = 0;
    virtual VTEXResult put_Maximum(double val) = 0;
    virtual VTEXResult get_Interval(double &val) = 0;
    virtual VTEXResult put_Interval(double val) = 0;

    vtexProperty <LibDsaArmSourceRpm, double, READ_WRITE> Minimum;
    vtexProperty <LibDsaArmSourceRpm, double, READ_WRITE> Maximum;
    vtexProperty <LibDsaArmSourceRpm, double, READ_WRITE> Interval;
};

//=============================================================================

/**
 * Dsa.Arm.Sources.Item
 *
 */

class VTEX_EXPORT LibDsaArmSource
{
public:
    virtual ~LibDsaArmSource() {};

    LibDsaArmSourceRpm* RPM;

    virtual VTEXResult Configure(bool enabled, VTEXDsaArmSourceDetectionEnum detection) = 0;

    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Detection(VTEXDsaArmSourceDetectionEnum &val) = 0;
    virtual VTEXResult put_Detection(VTEXDsaArmSourceDetectionEnum val) = 0;
    virtual VTEXResult get_Filter(std::string &val) = 0;
    virtual VTEXResult put_Filter(const std::string val) = 0;
    virtual VTEXResult get_EventId(std::string &val) = 0;
    virtual VTEXResult put_EventId(const std::string val) = 0;
    virtual VTEXResult get_Pattern(int32_t &val) = 0;
    virtual VTEXResult put_Pattern(int32_t val) = 0;

    vtexProperty <LibDsaArmSource, bool, READ_WRITE> Enabled;
    vtexProperty <LibDsaArmSource, VTEXDsaArmSourceDetectionEnum, READ_WRITE> Detection;
    vtexProperty <LibDsaArmSource, std::string, READ_WRITE> Filter;
    vtexProperty <LibDsaArmSource, std::string, READ_WRITE> EventId;
    vtexProperty <LibDsaArmSource, int32_t, READ_WRITE> Pattern;
};

//=============================================================================

/**
 * Dsa.Arm.Sources
 *
 */

class VTEX_EXPORT LibDsaArmSources
{
public:
    virtual ~LibDsaArmSources() {};

    virtual VTEXResult DisableAll() = 0;
    virtual LibDsaArmSource* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibDsaArmSources, int32_t, READ_ONLY> Count;
    arrayizer <LibDsaArmSources, LibDsaArmSource*, std::string> Item;
    arrayizer <LibDsaArmSources, std::string, int32_t> Name;
};

//=============================================================================

/**
 * Dsa.Arm
 *
 */

class VTEX_EXPORT LibDsaArm
{
public:
    virtual ~LibDsaArm() {};

    LibDsaArmSources* Sources;

    virtual VTEXResult SendSoftwareArm() = 0;

    virtual VTEXResult get_ArmCount(int32_t &val) = 0;
    virtual VTEXResult put_ArmCount(int32_t val) = 0;
    virtual VTEXResult get_Delay(double &val) = 0;
    virtual VTEXResult put_Delay(double val) = 0;
    virtual VTEXResult get_SourceOperator(VTEXDsaArmSourceOperatorEnum &val) = 0;
    virtual VTEXResult put_SourceOperator(VTEXDsaArmSourceOperatorEnum val) = 0;

    vtexProperty <LibDsaArm, int32_t, READ_WRITE> ArmCount;
    vtexProperty <LibDsaArm, double, READ_WRITE> Delay;
    vtexProperty <LibDsaArm, VTEXDsaArmSourceOperatorEnum, READ_WRITE> SourceOperator;
};

//=============================================================================

/**
 * Dsa.Channels.Item.Temperature.RTD
 *
 */

class VTEX_EXPORT LibDsaTemperatureRTD
{
public:
    virtual ~LibDsaTemperatureRTD() {};

    virtual VTEXResult Configure(double alpha, double resistance) = 0;

    virtual VTEXResult get_Alpha(double &val) = 0;
    virtual VTEXResult put_Alpha(double val) = 0;
    virtual VTEXResult get_Resistance(double &val) = 0;
    virtual VTEXResult put_Resistance(double val) = 0;

    vtexProperty <LibDsaTemperatureRTD, double, READ_WRITE> Alpha;
    vtexProperty <LibDsaTemperatureRTD, double, READ_WRITE> Resistance;
};

//=============================================================================

/**
 * Dsa.Channels.Item.Temperature.Thermocouple
 *
 */

class VTEX_EXPORT LibDsaTemperatureThermocouple
{
public:
    virtual ~LibDsaTemperatureThermocouple() {};

    virtual VTEXResult Configure(VTEXDsaThermocoupleTypeEnum thermocouple_type,
                                  double fixed_reference_junction,
                                  VTEXDsaRefJunctionTypeEnum reference_junction_type) = 0;

    virtual VTEXResult SetCustomCJCConversion(std::vector<double> conversion) = 0;
    virtual VTEXResult GetCustomCJCConversion(std::vector<double> &conversion) = 0;

    virtual VTEXResult get_FixedRefJunction(double &val) = 0;
    virtual VTEXResult put_FixedRefJunction(double val) = 0;
    virtual VTEXResult get_RefJunctionType(VTEXDsaRefJunctionTypeEnum &val) = 0;
    virtual VTEXResult put_RefJunctionType(VTEXDsaRefJunctionTypeEnum val) = 0;
    virtual VTEXResult get_Type(VTEXDsaThermocoupleTypeEnum &val) = 0;
    virtual VTEXResult put_Type(VTEXDsaThermocoupleTypeEnum val) = 0;
    virtual VTEXResult get_CJCReportingEnabled(bool &val) = 0;
    virtual VTEXResult put_CJCReportingEnabled(bool val) = 0;

    vtexProperty <LibDsaTemperatureThermocouple, double, READ_WRITE> FixedRefJunction;
    vtexProperty <LibDsaTemperatureThermocouple, VTEXDsaRefJunctionTypeEnum, READ_WRITE> RefJunctionType;
    vtexProperty <LibDsaTemperatureThermocouple, VTEXDsaThermocoupleTypeEnum, READ_WRITE> Type;
    vtexProperty <LibDsaTemperatureThermocouple, bool, READ_WRITE> CJCReportingEnabled;
};

//=============================================================================

/**
 * Dsa.Channels.Item.Temperature.Thermistor
 *
 */

class VTEX_EXPORT LibDsaTemperatureThermistor
{
public:
    virtual ~LibDsaTemperatureThermistor() {};

    virtual VTEXResult get_Resistance(double &val) = 0;
    virtual VTEXResult put_Resistance(double val) = 0;

    vtexProperty <LibDsaTemperatureThermistor, double, READ_WRITE> Resistance;
};

//=============================================================================

/**
 * Dsa.Channels.Item.Temperature
 *
 */

class VTEX_EXPORT LibDsaTemperature
{
public:
    virtual ~LibDsaTemperature() {};

    virtual VTEXResult get_TransducerType(VTEXDsaTemperatureTransducerTypeEnum &val) = 0;
    virtual VTEXResult put_TransducerType(VTEXDsaTemperatureTransducerTypeEnum val) = 0;
    virtual VTEXResult get_Units(VTEXDsaTemperatureUnitsEnum &val) = 0;
    virtual VTEXResult put_Units(VTEXDsaTemperatureUnitsEnum val) = 0;

    LibDsaTemperatureRTD* RTD;
    LibDsaTemperatureThermocouple* Thermocouple;
    LibDsaTemperatureThermistor* Thermistor;

    vtexProperty <LibDsaTemperature, VTEXDsaTemperatureTransducerTypeEnum, READ_WRITE> TransducerType;
    vtexProperty <LibDsaTemperature, VTEXDsaTemperatureUnitsEnum, READ_WRITE> Units;
};

//=============================================================================

/**
 * Dsa.Channels.Item.Strain
 *
 */

class VTEX_EXPORT LibDsaStrain
{
public:
    virtual ~LibDsaStrain() {};

    virtual VTEXResult MeasureLeadWireResistance(double &val) = 0;
    virtual VTEXResult MeasureExcitationLevel(double &val) = 0;
    virtual VTEXResult MeasureUnstrainedVoltage(double &val) = 0;
    virtual VTEXResult MeasureWiringResistance(double &val) = 0;
    virtual VTEXResult MeasureThermalEMFOffset(double &val) = 0;
    virtual VTEXResult MeasureShuntCalibrationGain(double &val) = 0;

    virtual VTEXResult Configure(VTEXDsaBridgeTypeEnum bridge_type,
                                 double gauge_factor,
                                 double poisson_ratio,
                                 VTEXDsaExcitationTypeEnum excitation_type,
                                 double excitation_level,
                                 double unstrained_voltage,
                                 double leadwire_desensitization,
                                 double leadwire_resistance) = 0;

    virtual VTEXResult get_BridgeType(VTEXDsaBridgeTypeEnum &val) = 0;
    virtual VTEXResult put_BridgeType(VTEXDsaBridgeTypeEnum val) = 0;
    virtual VTEXResult get_CompletionResistance(double &val) = 0;
    virtual VTEXResult put_CompletionResistance(double val) = 0;
    virtual VTEXResult get_CompletionResistor(VTEXDsaCompletionResistorEnum &val) = 0;
    virtual VTEXResult put_CompletionResistor(VTEXDsaCompletionResistorEnum val) = 0;
    virtual VTEXResult get_DynamicExcitationEnabled(bool &val) = 0;
    virtual VTEXResult put_DynamicExcitationEnabled(bool val) = 0;
    virtual VTEXResult get_ExcitationLevel(double &val) = 0;
    virtual VTEXResult put_ExcitationLevel(double val) = 0;
    virtual VTEXResult get_ExcitationPin(int32_t &val) = 0;
    virtual VTEXResult put_ExcitationPin(int32_t val) = 0;
    virtual VTEXResult get_ExcitationSlewRate(VTEXDsaExcitationSlewRateEnum &val) = 0;
    virtual VTEXResult put_ExcitationSlewRate(VTEXDsaExcitationSlewRateEnum val) = 0;
    virtual VTEXResult get_ExcitationType(VTEXDsaExcitationTypeEnum &val) = 0;
    virtual VTEXResult put_ExcitationType(VTEXDsaExcitationTypeEnum val) = 0;
    virtual VTEXResult get_GaugeFactor(double &val) = 0;
    virtual VTEXResult put_GaugeFactor(double val) = 0;
    virtual VTEXResult get_HalfBridgeLeadWireDesensitization(double &val) = 0;
    virtual VTEXResult put_HalfBridgeLeadWireDesensitization(double val) = 0;
    virtual VTEXResult get_LeadWireResistance(double &val) = 0;
    virtual VTEXResult put_LeadWireResistance(double val) = 0;
    virtual VTEXResult get_OhmGaugeResistance(double &val) = 0;
    virtual VTEXResult put_OhmGaugeResistance(double val) = 0;
    virtual VTEXResult get_PoissonRatio(double &val) = 0;
    virtual VTEXResult put_PoissonRatio(double val) = 0;
    virtual VTEXResult get_RemoteExcitationSenseEnabled(bool &val) = 0;
    virtual VTEXResult put_RemoteExcitationSenseEnabled(bool val) = 0;
    virtual VTEXResult get_RemoteShuntEnabled(bool &val) = 0;
    virtual VTEXResult put_RemoteShuntEnabled(bool val) = 0;
    virtual VTEXResult get_ShortCircuitTestEnabled(bool &val) = 0;
    virtual VTEXResult put_ShortCircuitTestEnabled(bool val) = 0;
    virtual VTEXResult get_ShuntCalibrationGain(double &val) = 0;
    virtual VTEXResult put_ShuntCalibrationGain(double val) = 0;
    virtual VTEXResult get_ShuntEnabled(bool &val) = 0;
    virtual VTEXResult put_ShuntEnabled(bool val) = 0;
    virtual VTEXResult get_ShuntResistance(double &val) = 0;
    virtual VTEXResult put_ShuntResistance(double val) = 0;
    virtual VTEXResult get_ShuntSource(VTEXDsaShuntSourceEnum &val) = 0;
    virtual VTEXResult put_ShuntSource(VTEXDsaShuntSourceEnum val) = 0;
    virtual VTEXResult get_ThermalEMFOffset(double &val) = 0;
    virtual VTEXResult put_ThermalEMFOffset(double val) = 0;
    virtual VTEXResult get_ThermalEMFOffsetMeasurementPeriod(double &val) = 0;
    virtual VTEXResult put_ThermalEMFOffsetMeasurementPeriod(double val) = 0;
    virtual VTEXResult get_UnstrainedVoltage(double &val) = 0;
    virtual VTEXResult put_UnstrainedVoltage(double val) = 0;
    virtual VTEXResult get_ACCalibrationEnabled(bool &val) = 0;
    virtual VTEXResult put_ACCalibrationEnabled(bool val) = 0;
    virtual VTEXResult get_ACCalibrationAmplitude(double &val) = 0;
    virtual VTEXResult put_ACCalibrationAmplitude(double val) = 0;
    virtual VTEXResult get_ACCalibrationFrequency(double &val) = 0;
    virtual VTEXResult put_ACCalibrationFrequency(double val) = 0;

    vtexProperty <LibDsaStrain, VTEXDsaBridgeTypeEnum, READ_WRITE> BridgeType;
    vtexProperty <LibDsaStrain, double, READ_WRITE> CompletionResistance;
    vtexProperty <LibDsaStrain, VTEXDsaCompletionResistorEnum, READ_WRITE> CompletionResistor;
    vtexProperty <LibDsaStrain, bool, READ_WRITE> DynamicExcitationEnabled;
    vtexProperty <LibDsaStrain, double, READ_WRITE> ExcitationLevel;
    vtexProperty <LibDsaStrain, VTEXDsaExcitationSlewRateEnum, READ_WRITE> ExcitationSlewRate;
    vtexProperty <LibDsaStrain, int32_t, READ_WRITE> ExcitationPin;
    vtexProperty <LibDsaStrain, VTEXDsaExcitationTypeEnum, READ_WRITE> ExcitationType;
    vtexProperty <LibDsaStrain, double, READ_WRITE> GaugeFactor;
    vtexProperty <LibDsaStrain, double, READ_WRITE> HalfBridgeLeadWireDesensitization;
    vtexProperty <LibDsaStrain, double, READ_WRITE> LeadWireResistance;
    vtexProperty <LibDsaStrain, double, READ_WRITE> OhmGaugeResistance;
    vtexProperty <LibDsaStrain, double, READ_WRITE> PoissonRatio;
    vtexProperty <LibDsaStrain, bool, READ_WRITE> RemoteExcitationSenseEnabled;
    vtexProperty <LibDsaStrain, bool, READ_WRITE> RemoteShuntEnabled;
    vtexProperty <LibDsaStrain, bool, READ_WRITE> ShortCircuitTestEnabled;
    vtexProperty <LibDsaStrain, double, READ_WRITE> ShuntCalibrationGain;
    vtexProperty <LibDsaStrain, bool, READ_WRITE> ShuntEnabled;
    vtexProperty <LibDsaStrain, double, READ_WRITE> ShuntResistance;
    vtexProperty <LibDsaStrain, VTEXDsaShuntSourceEnum, READ_WRITE> ShuntSource;
    vtexProperty <LibDsaStrain, double, READ_WRITE> ThermalEMFOffset;
    vtexProperty <LibDsaStrain, double, READ_WRITE> ThermalEMFOffsetMeasurementPeriod;
    vtexProperty <LibDsaStrain, double, READ_WRITE> UnstrainedVoltage;
    vtexProperty <LibDsaStrain, bool, READ_WRITE> ACCalibrationEnabled;
    vtexProperty <LibDsaStrain, double, READ_WRITE> ACCalibrationAmplitude;
    vtexProperty <LibDsaStrain, double, READ_WRITE> ACCalibrationFrequency;
};

//=============================================================================

/**
 * Dsa.Channels.Item.Overload
 *
 */

class VTEX_EXPORT LibDsaOverload
{
public:
    virtual ~LibDsaOverload() {};

    virtual VTEXResult Clear(int32_t mask) = 0;
    virtual VTEXResult Configure(int32_t latch_enabled, int32_t indicator, bool enabled, double lower_limit, double upper_limit) = 0;

    virtual VTEXResult get_Status(int32_t &val) = 0;
    virtual VTEXResult get_LatchEnabled(int32_t &val) = 0;
    virtual VTEXResult put_LatchEnabled(int32_t val) = 0;
    virtual VTEXResult get_Indicator(int32_t &val) = 0;
    virtual VTEXResult put_Indicator(int32_t val) = 0;
    virtual VTEXResult get_EventEnabled(int32_t &val) = 0;
    virtual VTEXResult put_EventEnabled(int32_t val) = 0;
    virtual VTEXResult get_UserLimitEnabled(bool &val) = 0;
    virtual VTEXResult put_UserLimitEnabled(bool val) = 0;
    virtual VTEXResult get_UserUpperLimit(double &val) = 0;
    virtual VTEXResult put_UserUpperLimit(double val) = 0;
    virtual VTEXResult get_UserLowerLimit(double &val) = 0;
    virtual VTEXResult put_UserLowerLimit(double val) = 0;
    virtual VTEXResult get_OTDEnabled(bool &val) = 0;
    virtual VTEXResult put_OTDEnabled(bool val) = 0;

    vtexProperty <LibDsaOverload, int32_t, READ_ONLY> Status;
    vtexProperty <LibDsaOverload, int32_t, READ_WRITE> LatchEnabled;
    vtexProperty <LibDsaOverload, int32_t, READ_WRITE> Indicator;
    vtexProperty <LibDsaOverload, int32_t, READ_WRITE> EventEnabled;
    vtexProperty <LibDsaOverload, bool, READ_WRITE> UserLimitEnabled;
    vtexProperty <LibDsaOverload, double, READ_WRITE> UserUpperLimit;
    vtexProperty <LibDsaOverload, double, READ_WRITE> UserLowerLimit;
    vtexProperty <LibDsaOverload, bool, READ_WRITE> OTDEnabled;
};

//=============================================================================

/**
 * Dsa.Channels.Item.Filter
 *
 */

class VTEX_EXPORT LibDsaFilter
{
public:
    virtual ~LibDsaFilter() {}

    virtual VTEXResult Configure(double min_frequency, double max_frequency) = 0;

    virtual VTEXResult get_Bypass(bool &val) = 0;
    virtual VTEXResult put_Bypass(bool val) = 0;
    virtual VTEXResult get_MaxFrequency(double &val) = 0;
    virtual VTEXResult put_MaxFrequency(double val) = 0;
    virtual VTEXResult get_MinFrequency(double &val) = 0;
    virtual VTEXResult put_MinFrequency(double val) = 0;
    virtual VTEXResult get_Type(VTEXDsaFilterEnum &val) = 0;
    virtual VTEXResult put_Type(VTEXDsaFilterEnum val) = 0;

    vtexProperty <LibDsaFilter, bool, READ_WRITE> Bypass;
    vtexProperty <LibDsaFilter, double, READ_WRITE> MaxFrequency;
    vtexProperty <LibDsaFilter, double, READ_WRITE> MinFrequency;
    vtexProperty <LibDsaFilter, VTEXDsaFilterEnum, READ_WRITE> Type;
};

//=============================================================================

/**
 * Dsa.Channels.Item.Measurement
 *
 */

class VTEX_EXPORT LibDsaChannelMeasurement
{
public:
    virtual ~LibDsaChannelMeasurement() {};

    virtual VTEXResult FetchWaveform(std::vector<double> waveform_array,
                              int64_t &actual_points, int64_t &first_valid_point, double &initial_x_offset,
                              double &initial_x_time_sec, double &initial_x_time_frac, double &x_increment) = 0;

    virtual VTEXResult ReadWaveform(int32_t max_time_millis, std::vector<double> waveform_array,
                             int64_t &actual_points, int64_t &first_valid_point, double &initial_x_offset,
                             double &initial_x_time_sec, double &initial_x_time_frac, double &x_increment) = 0;
};

//=============================================================================

/**
 * Dsa.Channels.Item.TEDS
 *
 */

class VTEX_EXPORT LibDsaTEDS
{
public:
    virtual ~LibDsaTEDS() {};

    virtual VTEXResult ReadURN(std::vector<int16_t> &urn) = 0;
    virtual VTEXResult ReadTEDS(std::vector<int16_t> &Teds) = 0;
    virtual VTEXResult WriteTEDS(std::vector<int16_t> Teds) = 0;

    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;

    vtexProperty <LibDsaTEDS, bool, READ_WRITE> Enabled;
};

//=============================================================================

/**
 * Dsa.Channels.Item.Transducer
 *
 */

class VTEX_EXPORT LibDsaTransducer
{
public:
    virtual ~LibDsaTransducer() {};

    virtual VTEXResult SetConversion(std::vector<double> conversion) = 0;
    virtual VTEXResult GetConversion(std::vector<double> &conversion) = 0;

    virtual VTEXResult get_UpperLimit(double &val) = 0;
    virtual VTEXResult put_UpperLimit(double val) = 0;
    virtual VTEXResult get_LowerLimit(double &val) = 0;
    virtual VTEXResult put_LowerLimit(double val) = 0;

    vtexProperty <LibDsaTransducer, double, READ_WRITE> UpperLimit;
    vtexProperty <LibDsaTransducer, double, READ_WRITE> LowerLimit;
};

//=============================================================================

/**
 * Dsa.Channels.Item
 *
 */

class VTEX_EXPORT LibDsaChannel
{
public:
    virtual ~LibDsaChannel() {};

    LibDsaTemperature*          Temperature;
    LibDsaStrain*               Strain;
    LibDsaOverload*             Overload;
    LibDsaFilter*               Filter;
    LibDsaChannelMeasurement*   Measurement;
    LibDsaTEDS*                 TEDS;
    LibDsaTransducer*           Transducer;
    LibDsaSampling*             Sampling;

    virtual VTEXResult Configure(bool enabled, VTEXDsaCouplingEnum coupling, double range,
                                 VTEXDsaChannelModeEnum mode, VTEXDsaChannelFunctionEnum function) = 0;
    virtual VTEXResult AutoRangeOnce() = 0;
    virtual VTEXResult AutoCal() = 0;
    virtual VTEXResult AutoZero() = 0;

    virtual VTEXResult get_Members(std::string &val) = 0;
    virtual VTEXResult get_Coupling(VTEXDsaCouplingEnum &val) = 0;
    virtual VTEXResult put_Coupling(VTEXDsaCouplingEnum val) = 0;
    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Impedance(double &val) = 0;
    virtual VTEXResult put_Impedance(double val) = 0;
    virtual VTEXResult get_Range(double &val) = 0;
    virtual VTEXResult put_Range(double val) = 0;
    virtual VTEXResult get_Weighting(VTEXDsaWeightingEnum &val) = 0;
    virtual VTEXResult put_Weighting(VTEXDsaWeightingEnum val) = 0;
    virtual VTEXResult get_Mode(VTEXDsaChannelModeEnum &val) = 0;
    virtual VTEXResult put_Mode(VTEXDsaChannelModeEnum val) = 0;
    virtual VTEXResult get_Function(VTEXDsaChannelFunctionEnum &val) = 0;
    virtual VTEXResult put_Function(VTEXDsaChannelFunctionEnum val) = 0;
    virtual VTEXResult get_IEPECurrent(double &val) = 0;
    virtual VTEXResult put_IEPECurrent(double val) = 0;
    virtual VTEXResult get_Offset(double &val) = 0;
    virtual VTEXResult put_Offset(double val) = 0;
    virtual VTEXResult get_AutoRangeMode(VTEXDsaAutoRangeModeEnum &val) = 0;
    virtual VTEXResult put_AutoRangeMode(VTEXDsaAutoRangeModeEnum val) = 0;
    virtual VTEXResult get_AutoRangeDirection(VTEXDsaAutoRangeDirectionEnum &val) = 0;
    virtual VTEXResult put_AutoRangeDirection(VTEXDsaAutoRangeDirectionEnum val) = 0;
    virtual VTEXResult get_AnalogFilterEnabled(bool &val) = 0;
    virtual VTEXResult put_AnalogFilterEnabled(bool val) = 0;
    virtual VTEXResult get_AnalogFilterCutoff(double &val) = 0;
    virtual VTEXResult put_AnalogFilterCutoff(double val) = 0;

    vtexProperty <LibDsaChannel, std::string, READ_ONLY> Members;
    vtexProperty <LibDsaChannel, VTEXDsaCouplingEnum, READ_WRITE> Coupling;
    vtexProperty <LibDsaChannel, bool, READ_WRITE> Enabled;
    vtexProperty <LibDsaChannel, double, READ_WRITE> Impedance;
    vtexProperty <LibDsaChannel, double, READ_WRITE> Range;
    vtexProperty <LibDsaChannel, VTEXDsaWeightingEnum, READ_WRITE> Weighting;
    vtexProperty <LibDsaChannel, VTEXDsaChannelModeEnum, READ_WRITE> Mode;
    vtexProperty <LibDsaChannel, VTEXDsaChannelFunctionEnum, READ_WRITE> Function;
    vtexProperty <LibDsaChannel, double, READ_WRITE> IEPECurrent;
    vtexProperty <LibDsaChannel, double, READ_WRITE> Offset;
    vtexProperty <LibDsaChannel, VTEXDsaAutoRangeModeEnum, READ_WRITE> AutoRangeMode;
    vtexProperty <LibDsaChannel, VTEXDsaAutoRangeDirectionEnum, READ_WRITE> AutoRangeDirection;
    vtexProperty <LibDsaChannel, bool, READ_WRITE> AnalogFilterEnabled;
    vtexProperty <LibDsaChannel, double, READ_WRITE> AnalogFilterCutoff;
};

//=============================================================================

/**
 * Dsa.Channels
 *
 */

class VTEX_EXPORT LibDsaChannels
{
public:
    virtual ~LibDsaChannels() {};

    virtual VTEXResult AddChannelGroup(std::string name, std::string channels) = 0;
    virtual VTEXResult RemoveChannelGroup(std::string name) = 0;
    virtual VTEXResult RemoveAllChannelGroups() = 0;

    virtual LibDsaChannel* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;
    virtual VTEXResult get_NumChannels(int32_t &val) = 0;

    vtexProperty <LibDsaChannels, int32_t, READ_ONLY> Count;
    vtexProperty <LibDsaChannels, int32_t, READ_ONLY> NumChannels;
    arrayizer <LibDsaChannels, LibDsaChannel*, std::string> Item;
    arrayizer <LibDsaChannels, std::string, int32_t> Name;
};

//=============================================================================

/**
 * Dsa.Events.Item
 *
 */

class VTEX_EXPORT LibDsaEvent
{
public:
    virtual ~LibDsaEvent() {};

    virtual VTEXResult Configure(VTEXDsaEventDriveModeEnum drive_mode,
                                 std::string source,
                                 std::string destination_path,
                                 VTEXDsaSourceSlopeEnum slope) = 0;

    virtual VTEXResult get_DestinationPath(std::string &val) = 0;
    virtual VTEXResult put_DestinationPath(std::string val) = 0;
    virtual VTEXResult get_DriveMode(VTEXDsaEventDriveModeEnum &val) = 0;
    virtual VTEXResult put_DriveMode(VTEXDsaEventDriveModeEnum val) = 0;
    virtual VTEXResult get_Source(std::string &val) = 0;
    virtual VTEXResult put_Source(std::string val) = 0;
    virtual VTEXResult get_Slope(VTEXDsaSourceSlopeEnum &val) = 0;
    virtual VTEXResult put_Slope(VTEXDsaSourceSlopeEnum val) = 0;

    vtexProperty <LibDsaEvent, std::string, READ_WRITE> DestinationPath;
    vtexProperty <LibDsaEvent, VTEXDsaEventDriveModeEnum, READ_WRITE> DriveMode;
    vtexProperty <LibDsaEvent, std::string, READ_WRITE> Source;
    vtexProperty <LibDsaEvent, VTEXDsaSourceSlopeEnum, READ_WRITE> Slope;
};

//=============================================================================

/**
 * Dsa.Events
 *
 */

class VTEX_EXPORT LibDsaEvents
{
public:
    virtual ~LibDsaEvents() {};

    virtual VTEXResult Add(std::string name) = 0;
    virtual VTEXResult Remove(std::string name) = 0;
    virtual VTEXResult DisableAll() = 0;
    virtual VTEXResult Pulse(std::string list_of_events) = 0;

    virtual LibDsaEvent* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    virtual VTEXResult get_WiredOrBiasMode(int32_t &val) = 0;
    virtual VTEXResult put_WiredOrBiasMode(int32_t val) = 0;
    virtual VTEXResult get_ListOfSources(std::string &val) = 0;

    vtexProperty <LibDsaEvents, int32_t, READ_ONLY> Count;
    vtexProperty <LibDsaEvents, int32_t, READ_WRITE> WiredOrBiasMode;
    vtexProperty <LibDsaEvents, std::string, READ_ONLY> ListOfSources;
    arrayizer <LibDsaEvents, LibDsaEvent*, std::string> Item;
    arrayizer <LibDsaEvents, std::string, int32_t> Name;
};

//=============================================================================

/**
 * Dsa.Trigger.Sources.Item
 *
 */

class VTEX_EXPORT LibDsaTriggerSource
{
public:
    virtual ~LibDsaTriggerSource() {};

    virtual VTEXResult Configure(bool enabled,
                                 VTEXDsaTriggerSourceDetectionEnum detection) = 0;
    virtual VTEXResult ConfigureAnalog(bool enabled,
                                 VTEXDsaTriggerSourceDetectionEnum detection,
                                 double level,
                                 double hysteresis) = 0;

    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Detection(VTEXDsaTriggerSourceDetectionEnum &val) = 0;
    virtual VTEXResult put_Detection(VTEXDsaTriggerSourceDetectionEnum val) = 0;
    virtual VTEXResult get_Filter(std::string &val) = 0;
    virtual VTEXResult put_Filter(const std::string val) = 0;
    virtual VTEXResult get_EventId(std::string &val) = 0;
    virtual VTEXResult put_EventId(const std::string val) = 0;
    virtual VTEXResult get_Hysteresis(double &val) = 0;
    virtual VTEXResult put_Hysteresis(double val) = 0;
    virtual VTEXResult get_Level(double &val) = 0;
    virtual VTEXResult put_Level(double val) = 0;

    vtexProperty <LibDsaTriggerSource, bool, READ_WRITE> Enabled;
    vtexProperty <LibDsaTriggerSource, VTEXDsaTriggerSourceDetectionEnum, READ_WRITE> Detection;
    vtexProperty <LibDsaTriggerSource, std::string, READ_WRITE> Filter;
    vtexProperty <LibDsaTriggerSource, std::string, READ_WRITE> EventId;
    vtexProperty <LibDsaTriggerSource, double, READ_WRITE> Hysteresis;
    vtexProperty <LibDsaTriggerSource, double, READ_WRITE> Level;
};

//=============================================================================

/**
 * Dsa.Trigger.Sources
 *
 */

class VTEX_EXPORT LibDsaTriggerSources
{
public:
    virtual ~LibDsaTriggerSources() {};

    virtual VTEXResult DisableAll() = 0;
    virtual LibDsaTriggerSource* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibDsaTriggerSources, int32_t, READ_ONLY> Count;
    arrayizer <LibDsaTriggerSources, LibDsaTriggerSource*, std::string> Item;
    arrayizer <LibDsaTriggerSources, std::string, int32_t> Name;
};

//=============================================================================

/**
 * Dsa.Trigger
 *
 */

class VTEX_EXPORT LibDsaTrigger
{
public:
    virtual ~LibDsaTrigger() {};

    virtual VTEXResult SendSoftwareTrigger() = 0;

    virtual VTEXResult get_TriggerCount(int32_t &val) = 0;
    virtual VTEXResult put_TriggerCount(int32_t val) = 0;
    virtual VTEXResult get_Delay(double &val) = 0;
    virtual VTEXResult put_Delay(double val) = 0;
    virtual VTEXResult get_Holdoff(double &val) = 0;
    virtual VTEXResult put_Holdoff(double val) = 0;
    virtual VTEXResult get_SourceOperator(VTEXDsaTriggerSourceOperatorEnum &val) = 0;
    virtual VTEXResult put_SourceOperator(VTEXDsaTriggerSourceOperatorEnum val) = 0;
    virtual VTEXResult get_MaxQueueSize(int32_t &val) = 0;
    virtual VTEXResult put_MaxQueueSize(int32_t val) = 0;
    virtual VTEXResult get_QueueEnabled(bool &val) = 0;
    virtual VTEXResult put_QueueEnabled(bool val) = 0;

    LibDsaTriggerSources* Sources;

    vtexProperty <LibDsaTrigger, int32_t, READ_WRITE> TriggerCount;
    vtexProperty <LibDsaTrigger, double, READ_WRITE> Delay;
    vtexProperty <LibDsaTrigger, double, READ_WRITE> Holdoff;
    vtexProperty <LibDsaTrigger, VTEXDsaTriggerSourceOperatorEnum, READ_WRITE> SourceOperator;
    vtexProperty <LibDsaTrigger, int32_t, READ_WRITE> MaxQueueSize;
    vtexProperty <LibDsaTrigger, bool, READ_WRITE> QueueEnabled;
};

//=============================================================================

/**
 * Dsa.Calibration.Self
 *
 */

class VTEX_EXPORT LibDsaCalibrationSelf
{
public:
    virtual ~LibDsaCalibrationSelf() {};

    virtual VTEXResult Initiate() = 0;
    virtual VTEXResult SaveAdjustments() = 0;
    virtual VTEXResult LoadAdjustments() = 0;
    virtual VTEXResult ClearSavedAdjustments() = 0;
    virtual VTEXResult GetStatus(VTEXDsaCalibrationStatusEnum &code, std::string &msg) = 0;

    virtual VTEXResult get_Date(std::string &val) = 0;
    virtual VTEXResult get_Adjustments(std::string &val) = 0;
    virtual VTEXResult get_Results(std::string &val) = 0;
    virtual VTEXResult get_Report(std::string &val) = 0;
    virtual VTEXResult get_Log(std::string &val) = 0;
    virtual VTEXResult get_IsSaved(bool &val) = 0;

    vtexProperty <LibDsaCalibrationSelf, std::string, READ_ONLY> Date;
    vtexProperty <LibDsaCalibrationSelf, std::string, READ_ONLY> Adjustments;
    vtexProperty <LibDsaCalibrationSelf, std::string, READ_ONLY> Results;
    vtexProperty <LibDsaCalibrationSelf, std::string, READ_ONLY> Report;
    vtexProperty <LibDsaCalibrationSelf, std::string, READ_ONLY> Log;
    vtexProperty <LibDsaCalibrationSelf, bool, READ_ONLY> IsSaved;
};

//=============================================================================

/**
 * Dsa.Calibration.Full
 *
 */

class VTEX_EXPORT LibDsaCalibrationFull
{
public:
    virtual ~LibDsaCalibrationFull() {};

    virtual VTEXResult SaveAdjustments() = 0;
    virtual VTEXResult LoadAdjustments() = 0;
    virtual VTEXResult ClearSavedAdjustments() = 0;
    virtual VTEXResult Initiate() = 0;
    virtual VTEXResult Abort() = 0;
    virtual VTEXResult GetStatus(VTEXDsaCalibrationStatusEnum &code, std::string &msg) = 0;
    virtual VTEXResult PromptResponse(std::string response) = 0;

    virtual VTEXResult get_Date(std::string &val) = 0;
    virtual VTEXResult get_Adjustments(std::string &val) = 0;
    virtual VTEXResult put_Adjustments(std::string val) = 0;
    virtual VTEXResult get_LoadByDefault(bool &val) = 0;
    virtual VTEXResult put_LoadByDefault(bool val) = 0;
    virtual VTEXResult get_SpecialOperations(std::string &val) = 0;
    virtual VTEXResult put_SpecialOperations(std::string val) = 0;
    virtual VTEXResult get_IsSaved(bool &val) = 0;
    virtual VTEXResult get_Report(std::string &val) = 0;
    virtual VTEXResult get_Log(std::string &val) = 0;

    vtexProperty <LibDsaCalibrationFull, std::string, READ_ONLY> Date;
    vtexProperty <LibDsaCalibrationFull, std::string, READ_WRITE> Adjustments;
    vtexProperty <LibDsaCalibrationFull, bool, READ_WRITE> LoadByDefault;
    vtexProperty <LibDsaCalibrationFull, std::string, READ_WRITE> SpecialOperations;
    vtexProperty <LibDsaCalibrationFull, bool, READ_ONLY> IsSaved;
    vtexProperty <LibDsaCalibrationFull, std::string, READ_ONLY> Report;
    vtexProperty <LibDsaCalibrationFull, std::string, READ_ONLY> Log;
};

//=============================================================================

/**
 * Dsa.Calibration.Factory
 *
 */

class VTEX_EXPORT LibDsaCalibrationFactory
{
public:
    virtual ~LibDsaCalibrationFactory() {};

    virtual VTEXResult Replace(std::string password) = 0;
    virtual VTEXResult Load() = 0;

    virtual VTEXResult get_Date(std::string &val) = 0;
    virtual VTEXResult get_Adjustments(std::string &val) = 0;

    vtexProperty <LibDsaCalibrationFactory, std::string, READ_ONLY> Date;
    vtexProperty <LibDsaCalibrationFactory, std::string, READ_ONLY> Adjustments;
};

//=============================================================================

/**
* Dsa.Calibration.InternalReferences.Item
*
*/

class VTEX_EXPORT LibDsaCalibrationInternalReference
{
public:
    virtual ~LibDsaCalibrationInternalReference() {};

    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_OutputEnabled(bool &val) = 0;
    virtual VTEXResult put_OutputEnabled(bool val) = 0;
    virtual VTEXResult get_Amplitude(double &val) = 0;
    virtual VTEXResult put_Amplitude(double val) = 0;
    virtual VTEXResult get_Frequency(double &val) = 0;
    virtual VTEXResult put_Frequency(double val) = 0;

    vtexProperty <LibDsaCalibrationInternalReference, bool, READ_WRITE> Enabled;
    vtexProperty <LibDsaCalibrationInternalReference, bool, READ_WRITE> OutputEnabled;
    vtexProperty <LibDsaCalibrationInternalReference, double, READ_WRITE> Amplitude;
    vtexProperty <LibDsaCalibrationInternalReference, double, READ_WRITE> Frequency;
};

//=============================================================================

/**
* Dsa.Calibration.InternalReferences
*
*/

class VTEX_EXPORT LibDsaCalibrationInternalReferences
{
public:
    virtual ~LibDsaCalibrationInternalReferences() {};

    virtual LibDsaCalibrationInternalReference* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibDsaCalibrationInternalReferences, int32_t, READ_ONLY> Count;
    arrayizer <LibDsaCalibrationInternalReferences, LibDsaCalibrationInternalReference*, std::string> Item;
    arrayizer <LibDsaCalibrationInternalReferences, std::string, int32_t> Name;
};

//=============================================================================

/**
 * Dsa.Calibration
 *
 */

class VTEX_EXPORT LibDsaCalibration
{
public:
    virtual ~LibDsaCalibration() {};

    LibDsaCalibrationSelf* Self;
    LibDsaCalibrationFull* Full;
    LibDsaCalibrationFactory* Factory;
    LibDsaCalibrationInternalReferences* InternalReferences;
};


//=============================================================================

/**
 * Dsa.Configuration
 *
 */

class VTEX_EXPORT LibDsaConfiguration
{
public:
    virtual ~LibDsaConfiguration() {};

    virtual VTEXResult SaveConfiguration() = 0;
    virtual VTEXResult LoadSavedConfiguration() = 0;
    virtual VTEXResult ClearSavedConfiguration() = 0;
    virtual VTEXResult get_CurrentConfigurationDigest(std::string &val) = 0;
    virtual VTEXResult get_SavedConfigurationDigest(std::string &val) = 0;

    virtual VTEXResult SaveConfigurationToStorageDevice(std::string device) = 0;
    virtual VTEXResult LoadConfigurationFromStorageDevice(std::string device) = 0;
    virtual VTEXResult ClearConfigurationFromStorageDevice(std::string device) = 0;
    virtual VTEXResult GetConfigurationDigestFromStorageDevice(std::string device, std::string &val) = 0;

    vtexProperty <LibDsaConfiguration, std::string, READ_ONLY> CurrentConfigurationDigest;
    vtexProperty <LibDsaConfiguration, std::string, READ_ONLY> SavedConfigurationDigest;
};

//=============================================================================

/**
 * Dsa.ReferenceOscillator
 *
 */

class VTEX_EXPORT LibDsaReferenceOscillator
{
public:
    virtual ~LibDsaReferenceOscillator() {};

    virtual VTEXResult Configure(VTEXDsaReferenceOscillatorSourceEnum source, double frequency) = 0;

    virtual VTEXResult get_ExternalFrequency(double &val) = 0;
    virtual VTEXResult put_ExternalFrequency(double val) = 0;
    virtual VTEXResult get_OutputEnabled(bool &val) = 0;
    virtual VTEXResult put_OutputEnabled(bool val) = 0;
    virtual VTEXResult get_Source(VTEXDsaReferenceOscillatorSourceEnum &val) = 0;
    virtual VTEXResult put_Source(VTEXDsaReferenceOscillatorSourceEnum val) = 0;
    virtual VTEXResult get_TimestampSource(VTEXDsaReferenceOscillatorTimestampSourceEnum &val) = 0;
    virtual VTEXResult put_TimestampSource(VTEXDsaReferenceOscillatorTimestampSourceEnum val) = 0;

    vtexProperty <LibDsaReferenceOscillator, double, READ_WRITE> ExternalFrequency;
    vtexProperty <LibDsaReferenceOscillator, bool, READ_WRITE> OutputEnabled;
    vtexProperty <LibDsaReferenceOscillator, VTEXDsaReferenceOscillatorSourceEnum, READ_WRITE> Source;
    vtexProperty <LibDsaReferenceOscillator, VTEXDsaReferenceOscillatorTimestampSourceEnum, READ_WRITE> TimestampSource;
};

//=============================================================================

/**
 * Dsa.Start
 *
 */

class VTEX_EXPORT LibDsaStart
{
public:
    virtual ~LibDsaStart() {};
    virtual VTEXResult SendSoftwareStart() = 0;

    virtual VTEXResult get_Source(std::string &val) = 0;
    virtual VTEXResult put_Source(std::string val) = 0;
    virtual VTEXResult get_ListOfSources(std::string &val) = 0;

    vtexProperty <LibDsaStart, std::string, READ_WRITE> Source;
    vtexProperty <LibDsaStart, std::string, READ_ONLY> ListOfSources;
};

//=============================================================================

/**
 * Dsa.Sync
 *
 */

class LibDsa;

class VTEX_EXPORT LibDsaSync
{
public:
    virtual ~LibDsaSync() {};

    virtual VTEXResult SendSoftwareSync() = 0;
    virtual VTEXResult SendSoftwareSyncAtTime(double seconds, double fraction) = 0;
    virtual VTEXResult AutoConfigure() = 0;
    virtual VTEXResult AutoConfigure(std::vector<LibDsa*> other_sessions) = 0;

    virtual VTEXResult get_CoordinationLine(std::string &val) = 0;
    virtual VTEXResult put_CoordinationLine(std::string val) = 0;
    virtual VTEXResult get_IsSynchronized(bool &val) = 0;
    virtual VTEXResult get_Line(std::string &val) = 0;
    virtual VTEXResult put_Line(std::string val) = 0;
    virtual VTEXResult get_Delay(double &val) = 0;
    virtual VTEXResult put_Delay(double val) = 0;
    virtual VTEXResult get_ListOfSources(std::string &val) = 0;

    vtexProperty <LibDsaSync, std::string, READ_WRITE> CoordinationLine;
    vtexProperty <LibDsaSync, bool, READ_ONLY> IsSynchronized;
    vtexProperty <LibDsaSync, std::string, READ_WRITE> Line;
    vtexProperty <LibDsaSync, double, READ_WRITE> Delay;
    vtexProperty <LibDsaSync, std::string, READ_ONLY> ListOfSources;
};

//=============================================================================

//User-overridable class implementing the callback
class VTEX_EXPORT LibDsaStreamingCallback
{
public:
    virtual ~LibDsaStreamingCallback() {};
    virtual void StreamingCallback(int32_t num_records,
        std::string& channel, std::vector<double>& data, std::vector<double>& ts_sec, std::vector<double>& ts_frac, std::string& additional_data) = 0;
};

//=============================================================================

/*
 * Dsa Streaming Interface
 */

class VTEX_EXPORT LibDsaStreamingData
{
public:
    virtual ~LibDsaStreamingData() {};

    virtual VTEXResult EnableStreaming() = 0;
    virtual VTEXResult DisableStreaming() = 0;

    virtual VTEXResult MemoryRead(int32_t num_records, int32_t& actual_records, std::string& channel, std::vector<double>& data,
        std::vector<double>& ts_sec, std::vector<double>& ts_frac, std::string& additional_data) = 0;
    virtual VTEXResult MemoryRead(int32_t num_records, long* actual_records, char* channels, std::size_t channels_size,
        double* data, std::size_t data_size, double* timestamp_sec, std::size_t timestamp_sec_size,
        double* timestamp_frac, std::size_t timestamp_frac_size, char* addl_data, std::size_t addl_data_size,
        long* data_actual_size, long* timestamp_sec_actual_size, long* timestamp_frac_actual_size) = 0;
    virtual VTEXResult MemoryReadWithCJC(int32_t num_records, int32_t& actual_records,
        std::string &channel, std::vector<double> &data, std::vector<double> &ts_sec, std::vector<double> &ts_frac, std::string &addl_data,
        std::string &channel_cjc, std::vector<double> &data_cjc, std::vector<double> &ts_sec_cjc, std::vector<double> &ts_frac_cjc) = 0;
    virtual VTEXResult MemoryReadWithCJC(int32_t num_records, long* actual_records, char* channels, std::size_t channels_size,
        double* data, std::size_t data_size, double* timestamp_sec, std::size_t timestamp_sec_size,
        double* timestamp_frac, std::size_t timestamp_frac_size, char* addl_data, std::size_t addl_data_size,
        char* channels_cjc, std::size_t channels_cjc_size, double* data_cjc, std::size_t data_cjc_size,
        double* timestamp_sec_cjc, std::size_t timestamp_sec_cjc_size, double* timestamp_frac_cjc, std::size_t timestamp_frac_cjc_size,
        long* data_actual_size, long* timestamp_sec_actual_size, long* timestamp_frac_actual_size,
        long* data_cjc_actual_size, long* timestamp_sec_cjc_actual_size, long* timestamp_frac_cjc_actual_size) = 0;

    virtual VTEXResult RegisterStreamingCallback(LibDsaStreamingCallback& callback, std::string channel_list) = 0;
    virtual VTEXResult UnregisterStreamingCallback(LibDsaStreamingCallback& callback) = 0;

    virtual VTEXResult SetCustomAttribute(std::string name, std::string value) = 0;
    virtual VTEXResult GetCustomAttributes(std::string& val) = 0;
    virtual VTEXResult RemoveCustomAttribute(std::string name) = 0;
    virtual VTEXResult RemoveAllCustomAttributes() = 0;

    virtual VTEXResult UpdateDataReader() = 0;

    //Property methods
    virtual VTEXResult get_NumStreamedRecords(int64_t &val) = 0;
    virtual VTEXResult get_NumMemoryRecords(int64_t &val) = 0;
    virtual VTEXResult get_MemoryChannelList(std::string& list) = 0;
    virtual VTEXResult put_MemoryChannelList(std::string list) = 0;
    virtual VTEXResult get_MemoryLimit(int32_t& limit) = 0;
    virtual VTEXResult put_MemoryLimit(int32_t limit) = 0;
    virtual VTEXResult get_MemoryLimitEx(int64_t& limit) = 0;
    virtual VTEXResult put_MemoryLimitEx(int64_t limit) = 0;
    virtual VTEXResult get_Filename(std::string& filename) = 0;
    virtual VTEXResult put_Filename(std::string filename) = 0;
    virtual VTEXResult get_FileCount(int32_t& filecount) = 0;
    virtual VTEXResult put_FileCount(int32_t filecount) = 0;
    virtual VTEXResult get_FileMaxSize(int32_t& maxsize) = 0;
    virtual VTEXResult put_FileMaxSize(int32_t maxsize) = 0;
    virtual VTEXResult get_FileRotate(bool& rotate) = 0;
    virtual VTEXResult put_FileRotate(bool rotate) = 0;

    vtexProperty <LibDsaStreamingData, int64_t, READ_ONLY> NumStreamedRecords;
    vtexProperty <LibDsaStreamingData, int64_t, READ_ONLY> NumMemoryRecords;
    vtexProperty <LibDsaStreamingData, std::string, READ_WRITE> MemoryChannelList;
    vtexProperty <LibDsaStreamingData, int32_t, READ_WRITE> MemoryLimit;
    vtexProperty <LibDsaStreamingData, int64_t, READ_WRITE> MemoryLimitEx;
    vtexProperty <LibDsaStreamingData, std::string, READ_WRITE> Filename;
    vtexProperty <LibDsaStreamingData, int32_t, READ_WRITE> FileCount;
    vtexProperty <LibDsaStreamingData, int32_t, READ_WRITE> FileMaxSize;
    vtexProperty <LibDsaStreamingData, bool, READ_WRITE> FileRotate;
};

//=============================================================================

/*
 * Board Temperature
 */
class VTEX_EXPORT LibDsaBoardTemperature
{
public:
    virtual ~LibDsaBoardTemperature() {};

    virtual VTEXResult get_BoardTemperature(double &val) = 0;
    virtual VTEXResult get_Units(VTEXDsaTemperatureUnitsEnum &val) = 0;
    virtual VTEXResult put_Units(VTEXDsaTemperatureUnitsEnum val) = 0;

    vtexProperty <LibDsaBoardTemperature, double, READ_ONLY> BoardTemperature;
    vtexProperty <LibDsaBoardTemperature, VTEXDsaTemperatureUnitsEnum, READ_WRITE> Units;
};

//=============================================================================

/*
 * Dsa Time
 */

class VTEX_EXPORT LibDsaTime
{
public:
    virtual ~LibDsaTime() {};

    virtual VTEXResult GetSystemTime(double &seconds, double &fraction) = 0;

    virtual VTEXResult get_IsMaster(bool &val) = 0;
    virtual VTEXResult get_IsSynchronized(bool &val) = 0;

    vtexProperty <LibDsaTime, bool, READ_ONLY> IsMaster;
    vtexProperty <LibDsaTime, bool, READ_ONLY> IsSynchronized;
};

//=============================================================================

/*
 * Dsa Self-Test Interface
 */

class VTEX_EXPORT LibDsaSelfTest
{
public:
    virtual ~LibDsaSelfTest() {};

    virtual VTEXResult Initiate() = 0;
    virtual VTEXResult GetStatus(int32_t &status, std::string &message) = 0;
    virtual VTEXResult get_Report(std::string &val) = 0;

    vtexProperty <LibDsaSelfTest, std::string, READ_ONLY> Report;
};

//=============================================================================

/**
* Dsa.Storage.Devices.Item
*
*/

class VTEX_EXPORT LibDsaStorageDevice
{
public:
    virtual ~LibDsaStorageDevice() {};

    virtual VTEXResult SetCustomAttribute(std::string name, std::string value) = 0;
    virtual VTEXResult GetCustomAttributes(std::string& val) = 0;
    virtual VTEXResult RemoveCustomAttribute(std::string name) = 0;
    virtual VTEXResult RemoveAllCustomAttributes() = 0;

    virtual VTEXResult get_Info(std::string& val) = 0;
    virtual VTEXResult get_NumSavedRecords(int64_t& val) = 0;

    virtual VTEXResult get_Enabled(bool& val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Filename(std::string& val) = 0;
    virtual VTEXResult put_Filename(std::string val) = 0;
    virtual VTEXResult get_FileCount(int32_t& val) = 0;
    virtual VTEXResult put_FileCount(int32_t val) = 0;
    virtual VTEXResult get_FileMaxRecords(int32_t& val) = 0;
    virtual VTEXResult put_FileMaxRecords(int32_t val) = 0;
    virtual VTEXResult get_FileRotate(bool& val) = 0;
    virtual VTEXResult put_FileRotate(bool val) = 0;
    virtual VTEXResult get_FileFormat(std::string& val) = 0;
    virtual VTEXResult put_FileFormat(std::string val) = 0;

    vtexProperty <LibDsaStorageDevice, int64_t, READ_ONLY> NumSavedRecords;
    vtexProperty <LibDsaStorageDevice, std::string, READ_ONLY> Info;
    vtexProperty <LibDsaStorageDevice, bool, READ_WRITE> Enabled;
    vtexProperty <LibDsaStorageDevice, std::string, READ_WRITE> Filename;
    vtexProperty <LibDsaStorageDevice, int32_t, READ_WRITE> FileCount;
    vtexProperty <LibDsaStorageDevice, int32_t, READ_WRITE> FileMaxRecords;
    vtexProperty <LibDsaStorageDevice, bool, READ_WRITE> FileRotate;
    vtexProperty <LibDsaStorageDevice, std::string, READ_WRITE> FileFormat;
};

//=============================================================================

/**
* Dsa.Storage.Devices
*
*/

class VTEX_EXPORT LibDsaStorageDevices
{
public:
    virtual ~LibDsaStorageDevices() {};

    virtual VTEXResult Update() = 0;

    virtual LibDsaStorageDevice* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibDsaStorageDevices, int32_t, READ_ONLY> Count;
    arrayizer <LibDsaStorageDevices, LibDsaStorageDevice*, std::string> Item;
    arrayizer <LibDsaStorageDevices, std::string, int32_t> Name;
};

//=============================================================================

/**
* Dsa.Storage
*
*/

class VTEX_EXPORT LibDsaStorage
{
public:
    virtual ~LibDsaStorage() {};

    LibDsaStorageDevices* Devices;
};

//=============================================================================

/**
 * Dsa.Dac.Arbitrary.Sequence
 *
 */

class VTEX_EXPORT LibDsaDacArbitrarySequence
{
public:
    virtual ~LibDsaDacArbitrarySequence() {};

    virtual VTEXResult Clear(int32_t handle) = 0;
    virtual VTEXResult Create(std::vector<int32_t> waveformHandle, std::vector<int32_t> loopCount, int32_t &handle) = 0;

    virtual VTEXResult get_LengthMax(int32_t &val) = 0;
    virtual VTEXResult get_LengthMin(int32_t &val) = 0;
    virtual VTEXResult get_LoopCountMax(int32_t &val) = 0;
    virtual VTEXResult get_NumberSequencesMax(int32_t &val) = 0;

    vtexProperty <LibDsaDacArbitrarySequence, int32_t, READ_ONLY> LengthMax;
    vtexProperty <LibDsaDacArbitrarySequence, int32_t, READ_ONLY> LengthMin;
    vtexProperty <LibDsaDacArbitrarySequence, int32_t, READ_ONLY> LoopCountMax;
    vtexProperty <LibDsaDacArbitrarySequence, int32_t, READ_ONLY> NumberSequencesMax;
};


//=============================================================================

/**
 * Dsa.Dac.Arbitrary.Waveform
 *
 */

class VTEX_EXPORT LibDsaDacArbitraryWaveform
{
public:
    virtual ~LibDsaDacArbitraryWaveform() {};

    virtual VTEXResult Clear(int32_t handle) = 0;
    virtual VTEXResult Create(std::vector<double> data, int32_t &handle) = 0;

    virtual VTEXResult get_NumberWaveformsMax(int32_t &val) = 0;
    virtual VTEXResult get_Quantum(int32_t &val) = 0;
    virtual VTEXResult get_SizeMax(int32_t &val) = 0;
    virtual VTEXResult get_SizeMin(int32_t &val) = 0;

    vtexProperty <LibDsaDacArbitraryWaveform, int32_t, READ_ONLY> NumberWaveformsMax;
    vtexProperty <LibDsaDacArbitraryWaveform, int32_t, READ_ONLY> Quantum;
    vtexProperty <LibDsaDacArbitraryWaveform, int32_t, READ_ONLY> SizeMax;
    vtexProperty <LibDsaDacArbitraryWaveform, int32_t, READ_ONLY> SizeMin;
};

//=============================================================================

/**
 * Dsa.Dac.Arbitrary
 *
 */

class VTEX_EXPORT LibDsaDacArbitrary
{
public:
    virtual ~LibDsaDacArbitrary() {};

    virtual VTEXResult ClearMemory() = 0;

    LibDsaDacArbitraryWaveform*    Waveform;
    LibDsaDacArbitrarySequence*    Sequence;
};

//=============================================================================

/**
 * Dsa.Dac.Channels.Item.Arbitrary
 *
 */

class VTEX_EXPORT LibDsaDacChannelArbitrary
{
public:
    virtual ~LibDsaDacChannelArbitrary() {};

    virtual VTEXResult Clear() = 0;
    virtual VTEXResult GetStatus(int32_t arb_status_mask, int32_t &status) = 0;
    virtual VTEXResult Write(int32_t max_time_millis, std::vector<double> data, int32_t &actual_samples) = 0;
    virtual VTEXResult ConfigureWaveform(int32_t Handle, double Gain, double Offset) = 0;
    virtual VTEXResult ConfigureSequence(int32_t Handle, double Gain, double Offset) = 0;

    virtual VTEXResult get_Gain(double &val) = 0;
    virtual VTEXResult put_Gain(double val) = 0;
    virtual VTEXResult get_Offset(double &val) = 0;
    virtual VTEXResult put_Offset(double val) = 0;
    virtual VTEXResult get_AsyncAdvanceSequence(bool &val) = 0;
    virtual VTEXResult put_AsyncAdvanceSequence(bool val) = 0;
    virtual VTEXResult get_WriteSize(int32_t &val) = 0;
    virtual VTEXResult put_WriteSize(int32_t val) = 0;

    vtexProperty <LibDsaDacChannelArbitrary, double, READ_WRITE> Gain;
    vtexProperty <LibDsaDacChannelArbitrary, double, READ_WRITE> Offset;
    vtexProperty <LibDsaDacChannelArbitrary, bool, READ_WRITE> AsyncAdvanceSequence;
    vtexProperty <LibDsaDacChannelArbitrary, int32_t, READ_WRITE> WriteSize;
};

//=============================================================================
/**
 * Dsa.Dac.Channels.Item.StandardWaveform.Random
 *
 */

class VTEX_EXPORT LibDsaDacChannelStandardWaveformRandom
{
public:
    virtual ~LibDsaDacChannelStandardWaveformRandom() {};

    virtual VTEXResult get_Seed(int32_t &val) = 0;
    virtual VTEXResult put_Seed(int32_t val) = 0;
    virtual VTEXResult get_Type(VTEXDsaRandomTypeEnum &val) = 0;
    virtual VTEXResult put_Type(VTEXDsaRandomTypeEnum val) = 0;
    virtual VTEXResult get_DownConversionEnabled(bool &val) = 0;
    virtual VTEXResult put_DownConversionEnabled(bool val) = 0;
    virtual VTEXResult get_CenterFrequency(double &val) = 0;
    virtual VTEXResult put_CenterFrequency(double val) = 0;

    vtexProperty <LibDsaDacChannelStandardWaveformRandom, int32_t, READ_WRITE> Seed;
    vtexProperty <LibDsaDacChannelStandardWaveformRandom, VTEXDsaRandomTypeEnum, READ_WRITE> Type;
    vtexProperty <LibDsaDacChannelStandardWaveformRandom, bool, READ_WRITE> DownConversionEnabled;
    vtexProperty <LibDsaDacChannelStandardWaveformRandom, double, READ_WRITE> CenterFrequency;
};

//=============================================================================
/**
 * Dsa.Dac.Channels.Item.StandardWaveform.Chirp
 *
 */

class VTEX_EXPORT LibDsaDacChannelStandardWaveformChirp
{
public:
    virtual ~LibDsaDacChannelStandardWaveformChirp() {};

    virtual VTEXResult get_MinFrequency(double &val) = 0;
    virtual VTEXResult put_MinFrequency(double val) = 0;
    virtual VTEXResult get_MaxFrequency(double &val) = 0;
    virtual VTEXResult put_MaxFrequency(double val) = 0;
    virtual VTEXResult get_Type(VTEXDsaChirpTypeEnum &val) = 0;
    virtual VTEXResult put_Type(VTEXDsaChirpTypeEnum val) = 0;
    virtual VTEXResult get_Direction(VTEXDsaChirpDirectionEnum &val) = 0;
    virtual VTEXResult put_Direction(VTEXDsaChirpDirectionEnum val) = 0;
    virtual VTEXResult get_Time(double &val) = 0;
    virtual VTEXResult put_Time(double val) = 0;
    virtual VTEXResult get_Mode(VTEXDsaChirpModeEnum &val) = 0;
    virtual VTEXResult put_Mode(VTEXDsaChirpModeEnum val) = 0;

    vtexProperty <LibDsaDacChannelStandardWaveformChirp, double, READ_WRITE> MinFrequency;
    vtexProperty <LibDsaDacChannelStandardWaveformChirp, double, READ_WRITE> MaxFrequency;
    vtexProperty <LibDsaDacChannelStandardWaveformChirp, VTEXDsaChirpTypeEnum, READ_WRITE> Type;
    vtexProperty <LibDsaDacChannelStandardWaveformChirp, VTEXDsaChirpDirectionEnum, READ_WRITE> Direction;
    vtexProperty <LibDsaDacChannelStandardWaveformChirp, double, READ_WRITE> Time;
    vtexProperty <LibDsaDacChannelStandardWaveformChirp, VTEXDsaChirpModeEnum, READ_WRITE> Mode;
};

//=============================================================================

/**
 * Dsa.Dac.Channels.Item.StandardWaveform
 *
 */

class VTEX_EXPORT LibDsaDacChannelStandardWaveform
{
public:
    virtual ~LibDsaDacChannelStandardWaveform() {};

    LibDsaDacChannelStandardWaveformRandom* Random;
    LibDsaDacChannelStandardWaveformChirp* Chirp;

    virtual VTEXResult Configure(VTEXDsaWaveformEnum waveform, double amplitude, double dc_offset,
        double frequency, double start_phase, VTEXDsaWaveformUpdateModeEnum update_mode) = 0;
    virtual VTEXResult SendSoftwareUpdate() = 0;

    virtual VTEXResult get_DutyCycleHigh(double &val) = 0;
    virtual VTEXResult put_DutyCycleHigh(double val) = 0;
    virtual VTEXResult get_Amplitude(double &val) = 0;
    virtual VTEXResult put_Amplitude(double val) = 0;
    virtual VTEXResult get_DCOffset(double &val) = 0;
    virtual VTEXResult put_DCOffset(double val) = 0;
    virtual VTEXResult get_Frequency(double &val) = 0;
    virtual VTEXResult put_Frequency(double val) = 0;
    virtual VTEXResult get_StartPhase(double &val) = 0;
    virtual VTEXResult put_StartPhase(double val) = 0;
    virtual VTEXResult get_Waveform(VTEXDsaWaveformEnum &val) = 0;
    virtual VTEXResult put_Waveform(VTEXDsaWaveformEnum val) = 0;
    virtual VTEXResult get_UpdateMode(VTEXDsaWaveformUpdateModeEnum &val) = 0;
    virtual VTEXResult put_UpdateMode(VTEXDsaWaveformUpdateModeEnum val) = 0;

    vtexProperty <LibDsaDacChannelStandardWaveform, double, READ_WRITE> DutyCycleHigh;
    vtexProperty <LibDsaDacChannelStandardWaveform, double, READ_WRITE> Amplitude;
    vtexProperty <LibDsaDacChannelStandardWaveform, double, READ_WRITE> DCOffset;
    vtexProperty <LibDsaDacChannelStandardWaveform, double, READ_WRITE> Frequency;
    vtexProperty <LibDsaDacChannelStandardWaveform, double, READ_WRITE> StartPhase;
    vtexProperty <LibDsaDacChannelStandardWaveform, VTEXDsaWaveformEnum, READ_WRITE> Waveform;
    vtexProperty <LibDsaDacChannelStandardWaveform, VTEXDsaWaveformUpdateModeEnum, READ_WRITE> UpdateMode;
};

//=============================================================================

/**
 * Dsa.Dac.Channels.Item.Sampling
 *
 */

class VTEX_EXPORT LibDsaDacChannelSampling
{
public:
    virtual ~LibDsaDacChannelSampling() {};

    virtual VTEXResult Configure(int64_t record_size, double sample_rate) = 0;
    
    virtual VTEXResult get_ClockFrequency(double &val) = 0;
    virtual VTEXResult put_ClockFrequency(double val) = 0;
    virtual VTEXResult get_RecordSize(int64_t &val) = 0;
    virtual VTEXResult put_RecordSize(int64_t val) = 0;
    virtual VTEXResult get_SampleRate(double &val) = 0;
    virtual VTEXResult put_SampleRate(double val) = 0;
    virtual VTEXResult get_Span(double &val) = 0;
    virtual VTEXResult put_Span(double val) = 0;
    virtual VTEXResult get_Prescaler(int32_t &val) = 0;
    virtual VTEXResult put_Prescaler(int32_t val) = 0;
    
    vtexProperty <LibDsaDacChannelSampling, double, READ_WRITE> ClockFrequency;
    vtexProperty <LibDsaDacChannelSampling, int64_t, READ_WRITE> RecordSize;
    vtexProperty <LibDsaDacChannelSampling, double, READ_WRITE> SampleRate;
    vtexProperty <LibDsaDacChannelSampling, double, READ_WRITE> Span;
    vtexProperty <LibDsaDacChannelSampling, int32_t, READ_WRITE> Prescaler;
};

//=============================================================================

/**
 * Dsa.Dacs.Item
 *
 */
class VTEX_EXPORT LibDsaDacChannel
{
public:
    virtual ~LibDsaDacChannel() {};

    LibDsaDacChannelSampling*          Sampling;
    LibDsaDacChannelStandardWaveform*  StandardWaveform;
    LibDsaDacChannelArbitrary*         Arbitrary;

    virtual VTEXResult Configure(bool Enabled, VTEXDsaDacOperationModeEnum OperationMode,
        VTEXDsaDacOutputModeEnum OutputMode, double BurstDutyCycle, double RampRate) = 0;
    virtual VTEXResult ClearShutdown() = 0;

    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Range(double &val) = 0;
    virtual VTEXResult put_Range(double val) = 0;
    virtual VTEXResult get_RampRate(double &val) = 0;
    virtual VTEXResult put_RampRate(double val) = 0;
    virtual VTEXResult get_Impedance(double &val) = 0;
    virtual VTEXResult get_OperationMode(VTEXDsaDacOperationModeEnum &val) = 0;
    virtual VTEXResult put_OperationMode(VTEXDsaDacOperationModeEnum val) = 0;
    virtual VTEXResult get_OutputMode(VTEXDsaDacOutputModeEnum &val) = 0;
    virtual VTEXResult put_OutputMode(VTEXDsaDacOutputModeEnum val) = 0;
    virtual VTEXResult get_SummerEnabled(bool &val) = 0;
    virtual VTEXResult put_SummerEnabled(bool val) = 0;
    virtual VTEXResult get_BurstDutyCycle(double &val) = 0;
    virtual VTEXResult put_BurstDutyCycle(double val) = 0;
    virtual VTEXResult get_State(VTEXDsaOutputStateEnum &val) = 0;
    virtual VTEXResult get_Status(int32_t &val) = 0;
    virtual VTEXResult get_ShutdownRampRate(VTEXDsaDacShutdownRampRateEnum &val) = 0;
    virtual VTEXResult put_ShutdownRampRate(VTEXDsaDacShutdownRampRateEnum val) = 0;
    virtual VTEXResult get_DriveMode(VTEXDsaDacDriveModeEnum &val) = 0;
    virtual VTEXResult put_DriveMode(VTEXDsaDacDriveModeEnum val) = 0;

    vtexProperty <LibDsaDacChannel, bool, READ_WRITE> Enabled;
    vtexProperty <LibDsaDacChannel, double, READ_WRITE> Range;
    vtexProperty <LibDsaDacChannel, double, READ_WRITE> RampRate;
    vtexProperty <LibDsaDacChannel, double, READ_ONLY> Impedance;
    vtexProperty <LibDsaDacChannel, VTEXDsaDacOperationModeEnum, READ_WRITE> OperationMode;
    vtexProperty <LibDsaDacChannel, VTEXDsaDacOutputModeEnum, READ_WRITE> OutputMode;
    vtexProperty <LibDsaDacChannel, bool, READ_WRITE> SummerEnabled;
    vtexProperty <LibDsaDacChannel, double, READ_WRITE> BurstDutyCycle;
    vtexProperty <LibDsaDacChannel, VTEXDsaOutputStateEnum, READ_ONLY> State;
    vtexProperty <LibDsaDacChannel, int32_t, READ_ONLY> Status;
    vtexProperty <LibDsaDacChannel, VTEXDsaDacShutdownRampRateEnum, READ_WRITE> ShutdownRampRate;
    vtexProperty <LibDsaDacChannel, VTEXDsaDacDriveModeEnum, READ_WRITE> DriveMode;
};

//=============================================================================

/**
 * Dsa.Dacs
 *
 */

class VTEX_EXPORT LibDsaDacChannels
{
public:
    virtual ~LibDsaDacChannels() {};

    virtual LibDsaDacChannel* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibDsaDacChannels, int32_t, READ_ONLY> Count;
    arrayizer <LibDsaDacChannels, LibDsaDacChannel*, std::string> Item;
    arrayizer <LibDsaDacChannels, std::string, int32_t> Name;
};

//=============================================================================

/**
 * Dsa.Dac
 *
 */

class VTEX_EXPORT LibDsaDac
{
public:
    virtual ~LibDsaDac() {};

    LibDsaDacChannels *Channels;
    LibDsaDacArbitrary *Arbitrary;
};

//=============================================================================

/**
 * Dsa.Tach.Channels.Item.Fifo
 *
 */
class VTEX_EXPORT LibDsaTachFifo
{
public:
    virtual ~LibDsaTachFifo() {};

    virtual VTEXResult Clear() = 0;
    virtual VTEXResult Read(int32_t max_time_milliseconds, int32_t num_counts, int32_t &actual_count,
        std::vector<double> &seconds, std::vector<double> &fractions) = 0;

    virtual VTEXResult get_Count(int32_t &val) = 0;
    virtual VTEXResult get_StreamingEnabled(bool &val) = 0;
    virtual VTEXResult put_StreamingEnabled(bool val) = 0;

    vtexProperty <LibDsaTachFifo, int32_t, READ_ONLY> Count;
    vtexProperty <LibDsaTachFifo, bool, READ_WRITE> StreamingEnabled;
};

//=============================================================================

/**
 * Dsa.Tach.Channels.Item.Pulses
 *
 */
class VTEX_EXPORT LibDsaTachPulses
{
public:
    virtual ~LibDsaTachPulses() {};

    virtual VTEXResult get_Multiplier(int32_t &val) = 0;
    virtual VTEXResult put_Multiplier(int32_t val) = 0;
    virtual VTEXResult get_Divider(int32_t &val) = 0;
    virtual VTEXResult put_Divider(int32_t val) = 0;

    vtexProperty <LibDsaTachPulses, int32_t, READ_WRITE> Multiplier;
    vtexProperty <LibDsaTachPulses, int32_t, READ_WRITE> Divider;
};

//=============================================================================

/**
 * Dsa.Tach.Channels.Item
 *
 */

class VTEX_EXPORT LibDsaTachChannel
{
public:
    virtual ~LibDsaTachChannel() {};

    LibDsaTachPulses* Pulses;
    LibDsaTachFifo* FIFO;

    virtual VTEXResult Configure(bool Enabled, double Range, VTEXDsaCouplingEnum Coupling, double Level,
        VTEXDsaTachSlopeEnum Slope, double Hysteresis, double MaxFrequency, double MinFrequency, double PulsesPerRevolution) = 0;

    virtual VTEXResult get_Coupling(VTEXDsaCouplingEnum &val) = 0;
    virtual VTEXResult put_Coupling(VTEXDsaCouplingEnum val) = 0;
    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Impedance(double &val) = 0;
    virtual VTEXResult get_Level(double &val) = 0;
    virtual VTEXResult put_Level(double val) = 0;
    virtual VTEXResult get_Hysteresis(double &val) = 0;
    virtual VTEXResult put_Hysteresis(double val) = 0;
    virtual VTEXResult get_Slope(VTEXDsaTachSlopeEnum &val) = 0;
    virtual VTEXResult put_Slope(VTEXDsaTachSlopeEnum val) = 0;
    virtual VTEXResult get_Range(double &val) = 0;
    virtual VTEXResult put_Range(double val) = 0;
    virtual VTEXResult get_MaxFrequency(double &val) = 0;
    virtual VTEXResult put_MaxFrequency(double val) = 0;
    virtual VTEXResult get_MinFrequency(double &val) = 0;
    virtual VTEXResult put_MinFrequency(double val) = 0;
    virtual VTEXResult get_PulsesPerRevolution(double &val) = 0;
    virtual VTEXResult put_PulsesPerRevolution(double val) = 0;
    virtual VTEXResult get_RPM(double &val) = 0;

    vtexProperty <LibDsaTachChannel, VTEXDsaCouplingEnum, READ_WRITE> Coupling;
    vtexProperty <LibDsaTachChannel, bool, READ_WRITE> Enabled;
    vtexProperty <LibDsaTachChannel, double, READ_ONLY> Impedance;
    vtexProperty <LibDsaTachChannel, double, READ_WRITE> Level;
    vtexProperty <LibDsaTachChannel, double, READ_WRITE> Hysteresis;
    vtexProperty <LibDsaTachChannel, VTEXDsaTachSlopeEnum, READ_WRITE> Slope;
    vtexProperty <LibDsaTachChannel, double, READ_WRITE> Range;
    vtexProperty <LibDsaTachChannel, double, READ_WRITE> MaxFrequency;
    vtexProperty <LibDsaTachChannel, double, READ_WRITE> MinFrequency;
    vtexProperty <LibDsaTachChannel, double, READ_WRITE> PulsesPerRevolution;
    vtexProperty <LibDsaTachChannel, double, READ_ONLY> RPM;
};

//=============================================================================

/**
 * Dsa.Tach.Channels
 *
 */

class VTEX_EXPORT LibDsaTachChannels
{
public:
    virtual ~LibDsaTachChannels() {};

    virtual LibDsaTachChannel* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibDsaTachChannels, int32_t, READ_ONLY> Count;
    arrayizer <LibDsaTachChannels, LibDsaTachChannel*, std::string> Item;
    arrayizer <LibDsaTachChannels, std::string, int32_t> Name;
};

//=============================================================================

/**
 * Dsa.Tach
 *
 */

class VTEX_EXPORT LibDsaTach
{
public:
    virtual ~LibDsaTach() {};

    LibDsaTachChannels *Channels;
};

//=============================================================================

/**
* Dsa Dio Channel Sampling
*/

class VTEX_EXPORT LibDsaDioChannelSampling
{
public:
    virtual ~LibDsaDioChannelSampling() {};

    virtual VTEXResult Configure(int64_t record_size, double sample_rate) = 0;

    virtual VTEXResult get_ClockFrequency(double &val) = 0;
    virtual VTEXResult put_ClockFrequency(double val) = 0;
    virtual VTEXResult get_RecordSize(int64_t &val) = 0;
    virtual VTEXResult put_RecordSize(int64_t val) = 0;
    virtual VTEXResult get_SampleRate(double &val) = 0;
    virtual VTEXResult put_SampleRate(double val) = 0;
    virtual VTEXResult get_Span(double &val) = 0;
    virtual VTEXResult put_Span(double val) = 0;
    virtual VTEXResult get_Prescaler(int32_t &val) = 0;
    virtual VTEXResult put_Prescaler(int32_t val) = 0;

    vtexProperty <LibDsaDioChannelSampling, double, READ_WRITE> ClockFrequency;
    vtexProperty <LibDsaDioChannelSampling, int64_t, READ_WRITE> RecordSize;
    vtexProperty <LibDsaDioChannelSampling, double, READ_WRITE> SampleRate;
    vtexProperty <LibDsaDioChannelSampling, double, READ_WRITE> Span;
    vtexProperty <LibDsaDioChannelSampling, int32_t, READ_WRITE> Prescaler;
};

//=============================================================================

/*
 * Dsa Dio Channel
 */

class VTEX_EXPORT LibDsaDioChannel
{
public:
    virtual ~LibDsaDioChannel() {};

    virtual VTEXResult Configure(int32_t output_mask, int32_t state) = 0;

    virtual VTEXResult get_OutputMask(int32_t &val) = 0;
    virtual VTEXResult put_OutputMask(int32_t val) = 0;
    virtual VTEXResult get_State(int32_t &val) = 0;
    virtual VTEXResult put_State(int32_t val) = 0;
    virtual VTEXResult get_Width(int32_t &val) = 0;
    virtual VTEXResult get_ReportingEnabled(bool &val) = 0;
    virtual VTEXResult put_ReportingEnabled(bool val) = 0;

    LibDsaDioChannelSampling* Sampling;

    vtexProperty <LibDsaDioChannel, int32_t, READ_WRITE> OutputMask;
    vtexProperty <LibDsaDioChannel, int32_t, READ_WRITE> State;
    vtexProperty <LibDsaDioChannel, int32_t, READ_ONLY> Width;
    vtexProperty <LibDsaDioChannel, bool, READ_WRITE> ReportingEnabled;
};

//=============================================================================

/*
 * Dsa Dio Channels
 */

class VTEX_EXPORT LibDsaDioChannels
{
public:
    virtual ~LibDsaDioChannels() {};

    virtual LibDsaDioChannel* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t &val) = 0;

    vtexProperty <LibDsaDioChannels, int32_t, READ_ONLY> Count;
    arrayizer <LibDsaDioChannels, LibDsaDioChannel*, std::string> Item;
    arrayizer <LibDsaDioChannels, std::string, int32_t> Name;
};

//=============================================================================

/*
 * Dsa Dio
 */

class VTEX_EXPORT LibDsaDio
{
public:
    virtual ~LibDsaDio() {};

    LibDsaDioChannels *Channels;
};

//=============================================================================


/**
 * Dsa base class
 *
 */

class VTEX_EXPORT LibDsa : public vtexInherent
{
public:
    static LibDsa* Create();
    virtual ~LibDsa() {};

    //Inherent capabilitites
    vtexInherentCapabilityIdentity* Identity;
    vtexInherentCapabilityUtility* Utility;
    vtexInherentCapabilityDriverOperation* DriverOperation;
    vtexInherentPlatform* Platform;

    LibDsaAlarms*               Alarms;
    LibDsaArm*                  Arm;
    LibDsaCalibration*          Calibration;
    LibDsaChannels*             Channels;
    LibDsaConfiguration*        Configuration;
    LibDsaDac*                  Dac;
    LibDsaDio*                  Dio;
    LibDsaEvents*               Events;
    LibDsaMeasurement*          Measurement;
    LibDsaReferenceOscillator*  ReferenceOscillator;
    LibDsaSelfTest*             SelfTest;
    LibDsaStart*                Start;
    LibDsaStorage*              Storage;
    LibDsaStreamingData*        StreamingData;
    LibDsaSync*                 Sync;
    LibDsaTach*                 Tach;
    LibDsaBoardTemperature*     Temperature;
    LibDsaTime*                 Time;
    LibDsaTrigger*              Trigger;

    vtexProperty <LibDsa, bool, READ_ONLY> Initialized;
};

#endif // _libDsa_H
