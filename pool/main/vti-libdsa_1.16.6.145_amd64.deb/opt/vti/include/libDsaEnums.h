#ifndef _DSA_ENUMS_
#define _DSA_ENUMS_

#ifndef ___VTEXDsa_h__

typedef enum
{
    VTEXDsaTimeOutImmediate = 0,
    VTEXDsaTimeOutInfinite = -1,
} VTEXDsaTimeOutEnum;

typedef enum
{
    VTEXDsaSelfTestStatusSuccess = 0,
    VTEXDsaSelfTestStatusFailed = 1,
    VTEXDsaSelfTestStatusRunning = 2,
    VTEXDsaSelfTestStatusNotStarted = 3,
    VTEXDsaSelfTestStatusWarning = 4,
} VTEXDsaSelfTestStatusEnum;

typedef enum
{
    VTEXDsaMeasurementStateIdle = 1000,
    VTEXDsaMeasurementStateSettling = 1001,
    VTEXDsaMeasurementStateWaitingForStart = 1002,
    VTEXDsaMeasurementStateWaitingForArm = 1003,
    VTEXDsaMeasurementStateWaitingForTrigger = 1004,
    VTEXDsaMeasurementStatePretriggerSamples = 1005,
    VTEXDsaMeasurementStateMeasuring = 1006,
    VTEXDsaMeasurementStateTriggerHoldoff = 1007,
    VTEXDsaMeasurementStateMixed = 1008,
} VTEXDsaMeasurementStateEnum;

typedef enum
{
    VTEXDsaFifoModeWait = 1000,
    VTEXDsaFifoModeOverwrite = 1001,
    VTEXDsaFifoModeStop = 1002,
} VTEXDsaFifoModeEnum;

typedef enum
{
    VTEXDsaDataFormatEUFixedPoint32 = 1000,
    VTEXDsaDataFormatEUReal64 = 1001,
    VTEXDsaDataFormatEUReal32 = 1002,
    VTEXDsaDataFormatRawInt32 = 1100,
    VTEXDsaDataFormatRawInt16 = 1101,
    VTEXDsaDataFormatVReal64 = 1102,
    VTEXDsaDataFormatVReal32 = 1103,
} VTEXDsaDataFormatEnum;

typedef enum
{
    VTEXDsaDecimationFilterNone = 1000,
    VTEXDsaDecimationFilterLowLatency = 1001,
    VTEXDsaDecimationFilterMedLatency = 1002,
    VTEXDsaDecimationFilterHighPerformance = 1003,
} VTEXDsaDecimationFilterEnum;

typedef enum
{
    VTEXDsaTriggerSourceDetectionRise = 0,
    VTEXDsaTriggerSourceDetectionFall = 1,
    VTEXDsaTriggerSourceDetectionHigh = 1000,
    VTEXDsaTriggerSourceDetectionLow = 1001,
} VTEXDsaTriggerSourceDetectionEnum;

typedef enum
{
    VTEXDsaTriggerSourceOperatorAND = 0,
    VTEXDsaTriggerSourceOperatorOR = 1,
} VTEXDsaTriggerSourceOperatorEnum;

typedef enum
{
    VTEXDsaArmSourceDetectionRise = 0,
    VTEXDsaArmSourceDetectionFall = 1,
    VTEXDsaArmSourceDetectionHigh = 2,
    VTEXDsaArmSourceDetectionLow = 3,
    VTEXDsaArmSourceDetectionRPMUp = 1000,
    VTEXDsaArmSourceDetectionRPMDown = 1001,
    VTEXDsaArmSourceDetectionRPMBoth = 1002,
} VTEXDsaArmSourceDetectionEnum;

typedef enum
{
    VTEXDsaArmSourceOperatorAND = 0,
    VTEXDsaArmSourceOperatorOR = 1,
} VTEXDsaArmSourceOperatorEnum;

typedef enum
{
    VTEXDsaSourceSlopeRise = 0,
    VTEXDsaSourceSlopeFall = 1,
} VTEXDsaSourceSlopeEnum;

typedef enum
{
    VTEXDsaEventDriveModeDriven = 0,
    VTEXDsaEventDriveModeOff = 1,
    VTEXDsaEventDriveModeWiredOr = 2,
} VTEXDsaEventDriveModeEnum;

typedef enum
{
    VTEXDsaReferenceOscillatorSourceInternal = 0,
    VTEXDsaReferenceOscillatorSourceExternal = 1,
    VTEXDsaReferenceOscillatorSourcePXIClk10 = 2,
    VTEXDsaReferenceOscillatorSourcePXIeClk100 = 3,
    VTEXDsaReferenceOscillatorSourcePXIeDSTARA = 1,
    VTEXDsaReferenceOscillatorSourceSystem = 1002,
} VTEXDsaReferenceOscillatorSourceEnum;

typedef enum
{
    VTEXDsaReferenceOscillatorTimestampSourceInternal = 0,
    VTEXDsaReferenceOscillatorTimestampSourceExternal = 1,
    VTEXDsaReferenceOscillatorTimestampSourcePXIClk10 = 2,
    VTEXDsaReferenceOscillatorTimestampSourcePXIeClk100 = 3,
    VTEXDsaReferenceOscillatorTimestampSourcePXIeDSTARA = 1,
    VTEXDsaReferenceOscillatorTimestampSourceSystem = 1002,
} VTEXDsaReferenceOscillatorTimestampSourceEnum;

typedef enum
{
    VTEXDsaTemperatureUnitsCelsius = 0,
    VTEXDsaTemperatureUnitsFahrenheit = 1,
    VTEXDsaTemperatureUnitsKelvin = 2,
} VTEXDsaTemperatureUnitsEnum;

typedef enum
{
    VTEXDsaCalibrationStatusNotStarted = 1000,
    VTEXDsaCalibrationStatusRunning = 1001,
    VTEXDsaCalibrationStatusSuccess = 1002,
    VTEXDsaCalibrationStatusFailed = 1003,
    VTEXDsaCalibrationStatusPrompt = 1004,
} VTEXDsaCalibrationStatusEnum;

typedef enum
{
    VTEXDsaChannelFunctionVoltage = 1000,
    VTEXDsaChannelFunctionIEPE = 1001,
    VTEXDsaChannelFunctionCharge = 1002,
    VTEXDsaChannelFunctionTemperature = 1003,
    VTEXDsaChannelFunctionStrain = 1004,
    VTEXDsaChannelFunctionMic = 1005,
    VTEXDsaChannelFunctionMic200 = 1006,
    VTEXDsaChannelFunctionCal = 1007,
    VTEXDsaChannelFunctionResistance = 1008,
} VTEXDsaChannelFunctionEnum;

typedef enum
{
    VTEXDsaCouplingAC = 0,
    VTEXDsaCouplingDC = 1,
    VTEXDsaCouplingGnd = 2,
} VTEXDsaCouplingEnum;

typedef enum
{
    VTEXDsaWeightingNone = 1000,
    VTEXDsaWeightingA = 1001,
    VTEXDsaWeightingB = 1002,
    VTEXDsaWeightingC = 1003,
    VTEXDsaWeightingIntegration = 1004,
} VTEXDsaWeightingEnum;

typedef enum
{
    VTEXDsaAutoRangeDirectionBoth = 1000,
    VTEXDsaAutoRangeDirectionUp = 1001,
    VTEXDsaAutoRangeDirectionDown = 1002,
} VTEXDsaAutoRangeDirectionEnum;

typedef enum
{
    VTEXDsaAutoRangeModeOn = 1000,
    VTEXDsaAutoRangeModeOff = 1001,
    VTEXDsaAutoRangeModeOnce = 1002,
} VTEXDsaAutoRangeModeEnum;

typedef enum
{
    VTEXDsaFilterFIR = 1000,
    VTEXDsaFilterEclipse = 1001,
    VTEXDsaFilterBessel = 1002,
    VTEXDsaFilterButterworth = 1003,
} VTEXDsaFilterEnum;

typedef enum
{
    VTEXDsaChannelModeDifferential = 1000,
    VTEXDsaChannelModeSingleEnded = 1001,
    VTEXDsaChannelModePseudoDifferential = 1002,
} VTEXDsaChannelModeEnum;

typedef enum
{
    VTEXDsaShuntSourceExternal = 1000,
    VTEXDsaShuntSourceInternal = 1001,
    VTEXDsaShuntSourceInternal47k = 1002,
    VTEXDsaShuntSourceInternal310k = 1003,
    VTEXDsaShuntSourceRemote = 1004,
    VTEXDsaShuntSourceInternalCustom1 = 1002,
    VTEXDsaShuntSourceInternalCustom2 = 1003,
} VTEXDsaShuntSourceEnum;

typedef enum
{
    VTEXDsaCompletionResistorUser = 1000,
    VTEXDsaCompletionResistor120Ohm = 1001,
    VTEXDsaCompletionResistor350Ohm = 1002,
    VTEXDsaCompletionResistor1000Ohm = 1003,
    VTEXDsaCompletionResistorCustom1 = 1001,
    VTEXDsaCompletionResistorCustom2 = 1002,
    VTEXDsaCompletionResistorCustom3 = 1003,
} VTEXDsaCompletionResistorEnum;

typedef enum
{
    VTEXDsaBridgeTypeQuarter120 = 1000,
    VTEXDsaBridgeTypeQuarter350 = 1001,
    VTEXDsaBridgeTypeQuarterUser = 1002,
    VTEXDsaBridgeTypeHalfBending = 1003,
    VTEXDsaBridgeTypeHalfPoisson = 1004,
    VTEXDsaBridgeTypeFullBending = 1005,
    VTEXDsaBridgeTypeFullPoisson = 1006,
    VTEXDsaBridgeTypeFullPoissonBending = 1007,
    VTEXDsaBridgeTypeQuarter1000 = 1008,
    VTEXDsaBridgeTypeTwoWireOhm = 1009,
    VTEXDsaBridgeTypeFourWireOhm = 1010,
    VTEXDsaBridgeTypeRatiometric = 1011,
    VTEXDsaBridgeTypeLinear = 1012,
    VTEXDsaBridgeTypeExcitationVoltage = 1013,
    VTEXDsaBridgeTypeWagnerVoltage = 1014,
    VTEXDsaBridgeTypeQuarterCustom1 = 1000,
    VTEXDsaBridgeTypeQuarterCustom2 = 1001,
    VTEXDsaBridgeTypeQuarterCustom3 = 1008,
}  VTEXDsaBridgeTypeEnum;

typedef enum
{
    VTEXDsaExcitationTypeVoltage = 1000,
    VTEXDsaExcitationTypeCurrent = 1001,
    VTEXDsaExcitationTypeNone = 1002,
    VTEXDsaExcitationTypeExternal = 1003,
} VTEXDsaExcitationTypeEnum;

typedef enum
{
    VTEXDsaExcitationSlewRateFast = 1000,
    VTEXDsaExcitationSlewRateSlow = 1001,
} VTEXDsaExcitationSlewRateEnum;

typedef enum
{
    VTEXDsaTemperatureTransducerTypeThermocouple = 0,
    VTEXDsaTemperatureTransducerTypeThermistor = 1,
    VTEXDsaTemperatureTransducerType2WireRTD = 2,
    VTEXDsaTemperatureTransducerType4WireRTD = 3,
    VTEXDsaTemperatureTransducerType3WireRTD = 1000,
} VTEXDsaTemperatureTransducerTypeEnum;

typedef enum
{
    VTEXDsaRefJunctionTypeInternal = 1000,
    VTEXDsaRefJunctionTypeFixed = 1001,
} VTEXDsaRefJunctionTypeEnum;

typedef enum
{
    VTEXDsaThermocoupleTypeB = 0,
    VTEXDsaThermocoupleTypeC = 1,
    VTEXDsaThermocoupleTypeD = 2,
    VTEXDsaThermocoupleTypeE = 3,
    VTEXDsaThermocoupleTypeG = 4,
    VTEXDsaThermocoupleTypeJ = 5,
    VTEXDsaThermocoupleTypeK = 6,
    VTEXDsaThermocoupleTypeN = 7,
    VTEXDsaThermocoupleTypeR = 8,
    VTEXDsaThermocoupleTypeS = 9,
    VTEXDsaThermocoupleTypeT = 10,
    VTEXDsaThermocoupleTypeU = 11,
    VTEXDsaThermocoupleTypeV = 12,
    VTEXDsaThermocoupleTypeCustom = 1000,
} VTEXDsaThermocoupleTypeEnum;

typedef enum
{
    VTEXDsaArbStatusReady = 1,
    VTEXDsaArbStatusOverread = 2,
    VTEXDsaArbStatusFull = 4,
    VTEXDsaArbStatusAll = -1,
} VTEXDsaArbStatusEnum;

typedef enum
{
    VTEXDsaChirpDirectionUp = 1000,
    VTEXDsaChirpDirectionDown = 1001,
} VTEXDsaChirpDirectionEnum;

typedef enum
{
    VTEXDsaChirpModeSingle = 1000,
    VTEXDsaChirpModeRoundtrip = 1002,
} VTEXDsaChirpModeEnum;

typedef enum
{
    VTEXDsaChirpTypeLinear = 1000,
    VTEXDsaChirpTypeLog = 1001,
} VTEXDsaChirpTypeEnum;

typedef enum
{
    VTEXDsaDacOperationModeContinuous = 1000,
    VTEXDsaDacOperationModeBurst = 1001,
    VTEXDsaDacOperationModeSequenced = 1002,
} VTEXDsaDacOperationModeEnum;

typedef enum
{
    VTEXDsaDacOutputModeFunction = 1000,
    VTEXDsaDacOutputModeArbitrary = 1001,
    VTEXDsaDacOutputModeSequence = 1002,
    VTEXDsaDacOutputModeStreaming = 1003,
    VTEXDsaDacOutputModeCOLA = 1004,
} VTEXDsaDacOutputModeEnum;

typedef enum
{
    VTEXDsaOutputStateIdle = 1000,
    VTEXDsaOutputStateRampingUp = 1001,
    VTEXDsaOutputStateRunning = 1002,
    VTEXDsaOutputStateRampingDown = 1003,
    VTEXDsaOutputStateShutdown = 1004,
} VTEXDsaOutputStateEnum;

typedef enum
{
    VTEXDsaRandomTypeWhiteNormal = 1000,
    VTEXDsaRandomTypeWhiteUniform = 1001,
    VTEXDsaRandomTypePinkNormal = 1002,
} VTEXDsaRandomTypeEnum;

typedef enum
{
    VTEXDsaTachSlopePositive = 1000,
    VTEXDsaTachSlopeNegative = 1001,
} VTEXDsaTachSlopeEnum;

typedef enum
{
    VTEXDsaWaveformSine = 1000,
    VTEXDsaWaveformSquare = 1001,
    VTEXDsaWaveformTriangle = 1002,
    VTEXDsaWaveformRampUp = 1003,
    VTEXDsaWaveformRampDown = 1004,
    VTEXDsaWaveformDC = 1005,
    VTEXDsaWaveformRandom = 1006,
    VTEXDsaWaveformChirp = 1007,
} VTEXDsaWaveformEnum;

typedef enum
{
    VTEXDsaWaveformUpdateModeImmediate = 1000,
    VTEXDsaWaveformUpdateModeSoftware = 1001,
    VTEXDsaWaveformUpdateModeZeroXing = 1002,
    VTEXDsaWaveformUpdateModeTrigger = 1003,
    VTEXDsaWaveformUpdateModeTriggerZeroXing = 1004,
} VTEXDsaWaveformUpdateModeEnum;

typedef enum
{
    VTEXDsaDacShutdownRampRateFast = 1000,
    VTEXDsaDacShutdownRampRateSlow = 1001,
} VTEXDsaDacShutdownRampRateEnum;

typedef enum
{
	VTEXDsaDacDriveModeVoltage = 1000,
	VTEXDsaDacDriveModeCurrent = 1001,
} VTEXDsaDacDriveModeEnum;

#endif //___VTEXDsa_h__
#endif //_DSA_ENUMS_
