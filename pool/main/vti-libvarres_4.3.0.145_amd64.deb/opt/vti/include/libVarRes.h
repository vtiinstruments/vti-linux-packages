
/******************************************************************************
 *
 *  .----------------------.
 *  |==     ==  ======  == |    $Author$
 *  | ==   ==   ======  == |    $Revision$
 *  |  == ==      ==    == |    $Date$
 *  |   ===       ==    == |    $HeadURL$
 *  |    =        ==    == |
 *  `----------------------'
 *
 * Copyright 2009 VTI Instruments Coorporation as an unpublished work.
 * All rights reserved. The information contained herein is confidential
 * property of VTI Instruments Coorporation Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement
 * with VTI Instruments Coorporation.
 *
 * PURPOSE:
 *   Class definition of the main LibVarRes class
 *
 * First Written By:
 ******************************************************************************/
#ifndef _LIB_VAR_RES_H
#define _LIB_VAR_RES_H

#include <string>
#include <vector>

#include "vtexInherent.h"
#include "libVtexException.h"
#include "libVarresEnums.h"
#include "libVarresErrors.h"

class LibVarResChannel
{
public:
    virtual ~LibVarResChannel() { };

    //Datamembers
    vtexProperty <LibVarResChannel, bool, READ_WRITE> Enabled;
    vtexProperty <LibVarResChannel, double, READ_WRITE> Output;
    vtexProperty <LibVarResChannel, bool, READ_ONLY> OverCurrent;
    vtexProperty <LibVarResChannel, bool, READ_ONLY> OverVoltage;
    vtexProperty <LibVarResChannel, VTEXVarResSwitchModeEnum, READ_WRITE> SwitchMode;
    vtexProperty <LibVarResChannel, bool, READ_WRITE> BusConnection;
    vtexProperty <LibVarResChannel, bool, READ_WRITE> SenseConnection;

    // Property methods
    virtual VTEXResult put_Enabled(bool value) = 0;
    virtual VTEXResult get_Enabled(bool& value) = 0;
    virtual VTEXResult put_Output(double value) = 0;
    virtual VTEXResult get_Output(double& value) = 0;
    virtual VTEXResult get_OverCurrent(bool& value) = 0;
    virtual VTEXResult get_OverVoltage(bool& value) = 0;
    virtual VTEXResult put_SwitchMode(VTEXVarResSwitchModeEnum value) = 0;
    virtual VTEXResult get_SwitchMode(VTEXVarResSwitchModeEnum& value) = 0;

    virtual VTEXResult put_BusConnection(bool value) = 0;
    virtual VTEXResult get_BusConnection(bool& value) = 0;
    virtual VTEXResult put_SenseConnection(bool value) = 0;
    virtual VTEXResult get_SenseConnection(bool& value) = 0;
};

class LibVarResChannels
{
public:
    virtual ~LibVarResChannels() { };

    //Properties
    vtexProperty <LibVarResChannels, int32_t, READ_ONLY> Count;
    arrayizer <LibVarResChannels, LibVarResChannel*, const std::string&> Item;
    arrayizer <LibVarResChannels, std::string, int32_t> Name;

    //Methods
    virtual VTEXResult get_Count(int32_t& count) = 0;
    virtual LibVarResChannel* get_Item(const std::string& channelName) = 0;
    virtual std::string get_Name(int32_t repCapIndex) = 0;
};

class LibVarResPlatform
{
public:
    virtual ~LibVarResPlatform() {};

    // Methods
    virtual VTEXResult CloseLogFile(void) = 0;
    virtual VTEXResult OpenLogFile(std::string FileName, std::string AccessMode) = 0;

    // Properties
    vtexProperty <LibVarResPlatform, std::string, READ_ONLY> SerialNumber;
    vtexProperty <LibVarResPlatform, std::string, READ_ONLY> InstrumentHardwareRevision;

    // Property methods
    virtual VTEXResult get_SerialNumber(std::string& value) = 0;
    virtual VTEXResult get_InstrumentHardwareRevision(std::string& val) = 0;
};

class LibVarResTrigger
{
public:
    virtual ~LibVarResTrigger() { };

    // Properties
    vtexProperty <LibVarResTrigger, VTEXVarResBackplaneTriggerEnum, READ_WRITE> BackplaneOutput;
    vtexProperty <LibVarResTrigger, VTEXVarResOutputSourceEnum, READ_WRITE > OutputSource;

    // Properties
    virtual VTEXResult put_BackplaneOutput(VTEXVarResBackplaneTriggerEnum value) = 0;
    virtual VTEXResult get_BackplaneOutput(VTEXVarResBackplaneTriggerEnum& value) = 0;
    virtual VTEXResult put_OutputSource(VTEXVarResOutputSourceEnum value) = 0;
    virtual VTEXResult get_OutputSource(VTEXVarResOutputSourceEnum& value) = 0;
};

class LibVarResBoardTemperature
{
public:
    virtual ~LibVarResBoardTemperature() {};

    virtual VTEXResult get_BoardTemperature(double &val) = 0;
    virtual VTEXResult get_Units(VTEXVarResTemperatureUnitsEnum &val) = 0;
    virtual VTEXResult put_Units(VTEXVarResTemperatureUnitsEnum val) = 0;

    vtexProperty <LibVarResBoardTemperature, double, READ_ONLY> BoardTemperature;
    vtexProperty <LibVarResBoardTemperature, VTEXVarResTemperatureUnitsEnum, READ_WRITE> Units;
};

class LibVarResSelfTest
{
public:
    virtual ~LibVarResSelfTest() {};

    virtual VTEXResult Initiate() = 0;
    virtual VTEXResult GetStatus(int32_t &status, std::string &message) = 0;
    virtual VTEXResult get_Report(std::string &val) = 0;

    vtexProperty <LibVarResSelfTest, std::string, READ_ONLY> Report;
};

class LibVarRes : public vtexInherent
{
public:
    static LibVarRes* Create();
    virtual ~LibVarRes() { };

    //Inherent capability
    vtexProperty <LibVarRes, bool, READ_ONLY> Initialized;
    vtexInherentCapabilityUtility* Utility;
    vtexInherentCapabilityDriverOperation* DriverOperation;
    vtexInherentCapabilityIdentity* Identity;

    // Properties
    vtexProperty <LibVarRes, bool, READ_ONLY> BackplaneFailsafe;
    vtexProperty <LibVarRes, int32_t, READ_ONLY> OverTemperature;

    LibVarResChannels* Channels;
    LibVarResTrigger* Trigger;
    LibVarResPlatform* Platform;
    LibVarResSelfTest* SelfTest;
    LibVarResBoardTemperature* Temperature;

    // Methods.
    virtual VTEXResult GetOdometers(const std::string &RelayList, std::vector<int32_t>& Count) = 0;

    // Property methods
    virtual VTEXResult get_BackplaneFailsafe(bool& value) = 0;
    virtual VTEXResult get_OverTemperature(int32_t& value) = 0;
};

#endif  //_LIB_VAR_RES_H
