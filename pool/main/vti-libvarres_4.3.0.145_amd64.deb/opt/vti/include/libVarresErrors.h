/*
* libVarresErrors.h
*
*  Created on: May 25, 2016
*      Author: Karthik
*/
#ifndef LIBVARRESERRORS_H_
#define LIBVARRESERRORS_H_

#include "vtexCommonErrors.h"

enum {
#ifndef _VarresErrors_H
    //! Device errors.
    FWVARRES_E_BASE = 0x80048000,
    FWVARRES_E_INTERNAL = 0x80048001,
    FWVARRES_E_BACKPLANE_FAILSAFE = 0x80048002,
    FWVARRES_E_NULL_POINTER_ARGUMENT = 0x80048003,
    FWVARRES_E_BUSY = 0x80048004,
    FWVARRES_E_FW_TOO_OLD = 0x80048005,
    FWVARRES_E_INVALID_CHANNEL = 0x80048006,
    FWVARRES_E_MEM_ALLOC_FAILED = 0x80048007,
    FWVARRES_E_CONFIG = 0x80048008,

    // TODO is this needed?
#ifndef _CommonErrors_H
    FWPLATFORM_E_TIMEOUT = 0x80008004,
#endif

    // TODO is this needed?
#ifndef _CommonErrors_H
    VTEX_E_WRONG_MODE = 0x80044420,
    VTEX_E_INTERNAL_NULL_POINTER = 0x80044421,
    VTEX_E_DCF_MALFORMED = 0x80044422,
    VTEX_E_DCF_AVAILABLE = 0x80044423,
    VTEX_E_SIMULATING_WITH_NO_SLOTS_SPECIFIED = 0x80044424,
    VTEX_E_SIMULATION_NO_ENVIRONMENT_VAR = 0x80044425,
    VTEX_E_UNKNOWN_MODULE_TYPE = 0x80044426,
#endif

#endif //_VarresErrors_H for the 1200 errors

    // EMX-specific errors (starting at 0x80044600 if needed)
};

#endif /* ! LIBVARRESERRORS_H_ */
