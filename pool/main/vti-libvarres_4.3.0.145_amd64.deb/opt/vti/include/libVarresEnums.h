/*
* libVarresEnums.h
*/

#ifndef _VarresConstants_H
#define _VarresConstants_H

#ifndef ___VTEXVarRes_h__

enum VTEXVarResBackplaneTriggerEnum
{
    VTEXVarResBackplaneTriggerNone = 0,
    VTEXVarResBackplaneTriggerBPL0 = 1000,
    VTEXVarResBackplaneTriggerBPL1 = 1001,
    VTEXVarResBackplaneTriggerBPL2 = 1002,
    VTEXVarResBackplaneTriggerBPL3 = 1003,
    VTEXVarResBackplaneTriggerBPL4 = 1004,
    VTEXVarResBackplaneTriggerBPL5 = 1005,
    VTEXVarResBackplaneTriggerBPL6 = 1006,
    VTEXVarResBackplaneTriggerBPL7 = 1007
};

enum VTEXVarResOutputSourceEnum
{
    VTEXVarResOutputSourceNone = 0,
    VTEXVarResOutputSourceOverVoltage = 1000,
    VTEXVarResOutputSourceOverCurrent = 1001,
    VTEXVarResOutputSourceOverTemperature = 1002,
    VTEXVarResOutputSourceBackplaneFailsafe = 1003,
    VTEXVarResOutputSourceAny = 1004
};

enum VTEXVarResSwitchModeEnum
{
    VTEXVarResSwitchModeNone = 1000,
    VTEXVarResSwitchModeBreakBeforeMake = 1001,
    VTEXVarResSwitchModeMakeBeforeBreak = 1002
};

typedef enum
{
    VTEXVarResTemperatureUnitsCelsius = 0,
    VTEXVarResTemperatureUnitsFahrenheit = 1,
    VTEXVarResTemperatureUnitsKelvin = 2,
} VTEXVarResTemperatureUnitsEnum;

typedef enum
{
    VTEXVarResSelfTestStatusSuccess = 0,
    VTEXVarResSelfTestStatusFailed = 1,
    VTEXVarResSelfTestStatusRunning = 2,
    VTEXVarResSelfTestStatusNotStarted = 3,
    VTEXVarResSelfTestStatusWarning = 4,
    VTEXVarResSelfTestStatusError = 5,
} VTEXVarResSelfTestStatusEnum;

#endif /* ___VTEXVarres_h__ */
#endif /* _VarresConstants_H */
