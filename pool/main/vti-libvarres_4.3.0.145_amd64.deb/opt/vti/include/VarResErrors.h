#include "exErrors.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#if defined(_WIN32) && !defined(_CVI_)
#define INLINE __inline
#else
#define INLINE inline
#endif

#ifdef __cplusplus
extern "C" {
#endif

 //!
 //! @file
 //!
 //! VarRes Error Codes
 //!

#ifndef _VarResErrors_H
#define _VarResErrors_H

 //! IVI Errors
#define IVIVARRES_E_BASE 0x80040000

 //! IVI Warnings
#define IVIVARRES_W_BASE 0x40000

 //! driver errors
#define VTEXVARRES_E_BASE 0x80044000

 //! driver warnings
#define VTEXVARRES_W_BASE 0x44000

 //! device errors
#define FWVARRES_E_BASE 0x80048000
#define FWVARRES_E_INTERNAL 0x80048001
#define FWVARRES_E_BACKPLANE_FAILSAFE 0x80048002
#define FWVARRES_E_NULL_POINTER_ARGUMENT 0x80048003
#define FWVARRES_E_BUSY 0x80048004
#define FWVARRES_E_FW_TOO_OLD 0x80048005
#define FWVARRES_E_INVALID_CHANNEL 0x80048006
#define FWVARRES_E_MEM_ALLOC_FAILED 0x80048007
#define FWVARRES_E_CONFIG 0x80048008

 //! device warnings
#define FWVARRES_W_BASE 0x48000
#endif /* ! _VarResErrors_H */

#ifdef  __cplusplus
}
#endif

