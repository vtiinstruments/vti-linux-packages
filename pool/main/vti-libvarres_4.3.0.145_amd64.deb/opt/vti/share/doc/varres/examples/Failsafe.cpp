#include "libVarRes.h"
#include <stdio.h>

int main()
{
	//Create a VTEXSwitch pointer
	LibVarRes *pVarRes;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	  properly if there is an error*/
	try {
		//Instantiate the created switch pointer
		pVarRes = LibVarRes::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		  doesn't run if we fail to initialize.*/

		try {
			/*We chose to give the driver an empty options string. You may want to 
			  give your driver options - check the manual to see the available settings.
			  Note that we also set the Reset bit so that we get a clean start to work 
			  from.*/
			pVarRes->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			/* backplanefailsafe is true if the failsafe trigger has fired since the last reset; this
			  prevents damage to the card by locking open all relays in unsafe conditions such as extreme temperature
			  or excess voltage */

			bool bpl_fail = pVarRes->BackplaneFailsafe;
			if (bpl_fail) {
				/* OverTemperature is a bitmask; each bit represents a temp sensor on the board and is
				  1 if that sensor has gone over temp since the last reset, 0 otherwise */
				int overtemp = pVarRes->OverTemperature;

				pVarRes->Utility->Reset();

				/* It is possible for BackplaneFailsafe to remain true through a reset if unsafe conditions persist. */
			}

			//Close the initialized session
			pVarRes->Close();
		} catch(VTEXException e) {
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	} catch(...) {
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
