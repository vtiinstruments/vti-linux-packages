#include "libVarRes.h"
#include <stdio.h>

int main()
{
	//Create a VTEXSwitch pointer
	LibVarRes *pVarRes;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	  properly if there is an error*/
	try {
		//Instantiate the created switch pointer
		pVarRes = LibVarRes::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		  doesn't run if we fail to initialize.*/

		try {
			/*We chose to give the driver an empty options string. You may want to 
			  give your driver options - check the manual to see the available settings.
			  Note that we also set the Reset bit so that we get a clean start to work 
			  from.*/
			pVarRes->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			// only channel on this device is "CH1"
			// setting an output will coerce it to the nearest possible value
			pVarRes->Channels->Item["CH1"]->Output = 3.0;
			pVarRes->Channels->Item["CH1"]->Enabled = true;

			// retrieving it will return its actual setting
			double actual_output;
			actual_output = pVarRes->Channels->Item["CH1"]->Output;

			//Close the initialized session
			pVarRes->Close();
		} catch(VTEXException e) {
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	} catch(...) {
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
