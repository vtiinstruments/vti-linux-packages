#include "libVarRes.h"
#include <stdio.h>

int main()
{
	//Create a VTEXSwitch pointer
	LibVarRes *pVarRes;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	  properly if there is an error*/
	try {
		//Instantiate the created switch pointer
		pVarRes = LibVarRes::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		  doesn't run if we fail to initialize.*/

		try {
			/*We chose to give the driver an empty options string. You may want to 
			  give your driver options - check the manual to see the available settings.
			  Note that we also set the Reset bit so that we get a clean start to work 
			  from.*/
			pVarRes->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			/* Over time the electromechanical relays wear out and become less reliable. GetOdometers
		 	 fills the first argument with a comma-separated list of relays and the second with the
			 corresponding switch counts over the card's lifetime. This can be used to estimate when relays
			 are approaching end of life.*/

			std::string relays;
			std::vector<int> odoms;
			pVarRes->GetOdometers(relays, odoms);

			//Close the initialized session
			pVarRes->Close();
		} catch(VTEXException e) {
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	} catch(...) {
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
