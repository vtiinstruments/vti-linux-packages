#include "libComparator.h"
#include <stdio.h>

int main()
{
	//Create a VTEXComparator pointer
	LibComparator *pComparator;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Comparator pointer
		pComparator = LibComparator::Create();
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pComparator->Initialize("TCPIP::10.1.4.36::INSTR",true,true, "");

      /*
       * This example will illustrate how to use the VTEXComparator driver to measure pulse width.
       */

      LibComparatorChannel *channel = pComparator->Channels->Item["CH1"];

      // We need to see both edges, so that we can measure the time between them
      channel->EventGenerationEdge = VTEXComparatorEventGenerationBoth;

      // We'll look for edges crossing 3.3V.
      channel->Range = 10;
      channel->Threshold = 3.3;

      // Finally, enable the channel.
      channel->EventGenerationEnabled = true;

      // Read 2 events from the log, waiting up to 10 seconds for them to occur
      std::vector<int32_t> p_events, p_channels, v_events, v_channels;
      std::vector<double> seconds, fractional;

      pComparator->EventLog->Read(2, 10000,
            p_events, p_channels,
            v_events, v_channels,
            seconds, fractional);

      // If bit 0 of p_channels is set, this means an edge occurred on channel 1
      if (((p_channels[0] & 1) == 1) && ((p_channels[1] & 1) == 1))
      {
        double width = (seconds[1] - seconds[0]) + (fractional[1] - fractional[0]);

        // a 1 in p_events indicates a rising edge; a 0 indicates a falling edge
        printf("Saw %s pulse on CH1, with width %f seconds\n", (((p_events[0] & 1) == 1) ? "high" : "low" ), width);
      }

			//Close the initialized session
			pComparator->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
