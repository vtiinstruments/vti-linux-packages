#include "libComparator.h"
#ifdef USE_DMM
#include "libDmm.h"
#endif
#include <stdio.h>

int main()
{
	//Create a VTEXComparator pointer
	LibComparator *pComparator;
#ifdef USE_DMM
	LibDmm *pDmm;
#endif

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Comparator pointer
		pComparator = LibComparator::Create();
#ifdef USE_DMM
		pDmm = LibDmm::Create();
#endif
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pComparator->Initialize("TCPIP::10.1.4.36::INSTR",true,true, "");
#ifdef USE_DMM
			pDmm->Initialize("TCPIP::10.1.4.36::INSTR",true,true, "");
#endif

			/*In this example, you are to use the EX1200 Dmm to measure the input signal
			from the comparator through the backplane.
			Steps:
			#1. Setup the comparator
			#2. Input a DC voltage signal (A signal generator is required)
			#3. Use the Dmm to measure the voltage through the backplane (A EX1200 Dmm is required)*/

			//CH1 is used in this example
			//Set the range of CH1
			pComparator->Channels->Item["CH1"]->Range = 10.0;

			//Set CH1 as the backplane connected channel
			pComparator->Channels->BackplaneConnectedChannel = "CH1";

			//Enable the backplane connection
			pComparator->Channels->BackplaneConnectionEnabled = true;

			//At this point, input a DC voltage signal below the range (10.0V) into CH1
			//Use the EX1200 Dmm to measure the signal through the backplane
			//#1. Set the Dmm function to DC Voltage
			//#2. Set the range of the Dmm (10.0V)
			//#3. Set the Dmm measurement input type to Internal
			//#4. Take a measurement*/
			double reading = 0;
#ifdef USE_DMM
			pDmm->Configure(VTEXDmmFunctionDCVolts, -1, 10.0);
			pDmm->Trigger->Configure(VTEXDmmTriggerSourceImmediate, -1);
			pDmm->Measurement->Input = VTEXDmmInputSelectInternal;
			pDmm->Measurement->Read(10000, &reading);
#endif

			printf("Read %f V from DMM.\n", reading);

			//Query the calibration constants of the selected channel and range to adjust the dmm reading
			double gain = 0, offset = 0;
			pComparator->Calibration->Read("CH1", VTEXComparatorCalibrationConstantInputGain, 10.0, &gain);
			pComparator->Calibration->Read("CH1", VTEXComparatorCalibrationConstantInputOffset, 10.0, &offset);
			reading = (reading / gain) + offset;

			printf("User input voltage is %f V.", reading);
			
			//Close the initialized session
			pComparator->Close();
#ifdef USE_DMM
      pDmm->Close();
#endif
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
