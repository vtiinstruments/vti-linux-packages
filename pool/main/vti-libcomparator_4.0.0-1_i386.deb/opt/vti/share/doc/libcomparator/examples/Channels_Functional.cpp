#include "libComparator.h"
#include <stdio.h>

int main()
{
	//Create a VTEXComparator pointer
	LibComparator *pComparator;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Comparator pointer
		pComparator = LibComparator::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pComparator->Initialize("TCPIP::10.1.4.25::INSTR",true,true, "");

			//In this examples, you are to input a DC voltage signal into CH1 and CH2.
			//You will see that the raw data of CH1 and CH2 will be 0 when the voltage
			//is under the threshold voltage and become 1 when the input signal is above
			//the threshold voltage

			//Set the range of CH1 and CH2
			pComparator->Channels->Item["CH1"]->Range = 10.0;
			pComparator->Channels->Item["CH2"]->Range = 100.0;

			//Set the threshold voltage of CH1 and CH2
			pComparator->Channels->Item["CH1"]->Threshold = 5.0;
			pComparator->Channels->Item["CH2"]->Threshold = 50.0;

			//Check the raw data
			int rawData = pComparator->Channels->RawData;
			//At this point, the raw data for CH1 and CH2 should be 0

			//Input a DC voltage signal that is higher than 5V to CH1
			//Input a DC voltage signal that is higher than 50V to CH2

			//Check the raw data
			rawData = pComparator->Channels->RawData;
			//At this point, the raw data for CH1 and CH2 should be 1

			//EventGenerationEdge and EventGenerationEnabled allow you to have specific raw data transitions logged
			pComparator->Channels->Item["CH3"]->Range = 10.0;
			pComparator->Channels->Item["CH3"]->Threshold = 5.0;

			pComparator->Channels->Item["CH1"]->EventGenerationEdge = VTEXComparatorEventGenerationNormal;
			pComparator->Channels->Item["CH2"]->EventGenerationEdge = VTEXComparatorEventGenerationInvert;
			pComparator->Channels->Item["CH3"]->EventGenerationEdge = VTEXComparatorEventGenerationBoth;

			//Set CH1 input to < 5V
			//Set CH2 input to <50V
			//Set CH3 input to < 5V
			pComparator->EventLog->Clear();
			int count;
			std::vector<int> physMask;
			std::vector<int> physData;
			std::vector<int> virtMask;
			std::vector<int> virtData;
			std::vector<double> seconds;
			std::vector<double> fractional;

			pComparator->Channels->Item["CH1"]->EventGenerationEnabled = true;
			pComparator->Channels->Item["CH2"]->EventGenerationEnabled = true;
			pComparator->Channels->Item["CH3"]->EventGenerationEnabled = true;

			//Set CH1 input to > 5V
			//Query the event log count to see that a new event has occured
			count = pComparator->EventLog->Count; // should be 1
			//Read back the new event log entry
			pComparator->EventLog->Read(1, 1000, physData, physMask, virtData, virtMask, seconds, fractional);

			//Set CH1 input back to < 5V
			//Query the event log count, and see that no new event has occured, because 
			//EventGenerationEdge = Normal only rising edges are recorded
			count = pComparator->EventLog->Count; // should be 0

			//Set CH2 input to > 50V
			//Query the event log count, and see that no new event has occurred, because
			//EventGenerationEdge = Invert only falling edges are recorded
			count = pComparator->EventLog->Count; // should be 0

			//Set CH2 input back to < 50V
			//Query the event log count to see that a new event has occurred
			count = pComparator->EventLog->Count; // should be 1
			//Read back the new event log entry
			pComparator->EventLog->Read(1, 1000, physData, physMask, virtData, virtMask, seconds, fractional);

			//Set CH3 input to > 5V
			//Query the event log count to see that a new event has occurred
			//(both rising and falling edges cause events when EventGenerationEdge = Both)
			count = pComparator->EventLog->Count; // should be 1
			//Read back the new event log entry
			pComparator->EventLog->Read(1, 1000, physData, physMask, virtData, virtMask, seconds, fractional);

			//Set CH3 input back to < 5V
			//Query the event log count to see that a new event has occurred 
			//(both rising and falling edges cause events when EventGenerationEdge = Both)
			count = pComparator->EventLog->Count; // should be 1
			//Read back the new event log entry
			pComparator->EventLog->Read(1, 1000, physData, physMask, virtData, virtMask, seconds, fractional);

			//Close the initialized session
			pComparator->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
