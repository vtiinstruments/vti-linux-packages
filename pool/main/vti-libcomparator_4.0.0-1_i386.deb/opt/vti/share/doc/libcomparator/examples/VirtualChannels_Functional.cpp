#include "libComparator.h"
#include <stdio.h>

int main()
{
	//Create a VTEXComparator pointer
	LibComparator *pComparator;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Comparator pointer
		pComparator = LibComparator::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pComparator->Initialize("TCPIP::10.1.4.36::INSTR",true,true, "");

			//In this example, you are to exercise with virtual channels.
			//You will be able to see how the raw data will be changed
			//when the raw data of their source channels change

			//We now set the range and threshold on the channels that we are going to use
			pComparator->Channels->Item["CH1"]->Range = 10.0;
			pComparator->Channels->Item["CH1"]->Threshold = 5.0;
			pComparator->Channels->Item["CH2"]->Range = 10.0;
			pComparator->Channels->Item["CH2"]->Threshold = 5.0;
			pComparator->Channels->Item["CH3"]->Range = 100.0;
			pComparator->Channels->Item["CH3"]->Threshold = 50.0;
			pComparator->Channels->Item["CH4"]->Range = 100.0;
			pComparator->Channels->Item["CH4"]->Threshold = 50.0;

			//VCH1 and VCH9 are used in this example.
			//CH1 and CH3 are used as the source channels of VCH1
			//CH2 and CH4 are used as the source channels of VCH9
			pComparator->VirtualChannels->Item["VCH1"]->SourceChannels = "CH1,CH3";
			pComparator->VirtualChannels->Item["VCH9"]->SourceChannels = "CH2,CH4";

			//When OrEnabled is disabled, all the raw data of the source channels
			//need to be 1 in order for the raw data of the virtual channel
			//to become 1. If OrEnabled is enabled, the raw data of either one of the
			//source channels becomes 1, the raw data of the virtual channel will
			//become 1 as well
			pComparator->VirtualChannels->Item["VCH1"]->OrEnabled = false;
			pComparator->VirtualChannels->Item["VCH9"]->OrEnabled = true;

			//The raw data for the virtual channels should be 0 since
			//the raw data of the physical channels is 0
			double rawData = pComparator->VirtualChannels->RawData;

			//Now, input a DC voltage signal which is higher than 5V into CH1.
			//Check the raw data again. Since only the raw data of CH1 
			//is 1, the raw data of VCH1 is still 0
			rawData = pComparator->VirtualChannels->RawData;

			//Now, input a DC voltage signal which is higher than 50V into CH3.
			//Check the raw data again. Since the raw data of both CH1 and
			//CH3 is 1, the raw data of VCH1 should become 1 now
			rawData = pComparator->VirtualChannels->RawData;

			//Now, input a DC voltage signal which is higher than 5V into CH2.
			//Check the raw data again. Since the OrEnabled property is set
			//to ture on VCH9 and the raw data of CH2 becomes 1,
			//the raw data of VCH9 should become 1 as well.
			rawData = pComparator->VirtualChannels->RawData;

			//Now, disable the DC voltage signal on CH2 and input a DC voltage
			//signal which is higher than 50V into CH4. Check the raw data again.
			//Since the OrEnabled property is set to true and the raw data of CH4
			//becomes 1, the raw data of VCH9 should become 1 as well
			rawData = pComparator->VirtualChannels->RawData;

			//Now we will use the PairedInput feature of the physical channels with a virtual channel to create
			//a "window" that a single input generates an event by going out of or into.
			pComparator->Channels->Item["CH1"]->Range = 10.0;
			pComparator->Channels->Item["CH1"]->PairedInput = true;
			pComparator->Channels->Item["CH1"]->Threshold = 0.5;
			//setting EventGenerationEdge=Invert allows the physical channel to act as a minimum limit instead of a maximum
			pComparator->Channels->Item["CH1"]->EventGenerationEdge = VTEXComparatorEventGenerationInvert;
			pComparator->Channels->Item["CH2"]->Threshold = 4.5;
			pComparator->Channels->Item["CH2"]->EventGenerationEdge = VTEXComparatorEventGenerationNormal;

			pComparator->Channels->Item["CH3"]->Range = 10.0;
			pComparator->Channels->Item["CH3"]->PairedInput = true;
			pComparator->Channels->Item["CH3"]->Threshold = 0.5;
			pComparator->Channels->Item["CH3"]->EventGenerationEdge = VTEXComparatorEventGenerationInvert;
			pComparator->Channels->Item["CH4"]->Threshold = 4.5;
			pComparator->Channels->Item["CH4"]->EventGenerationEdge = VTEXComparatorEventGenerationNormal;

			pComparator->VirtualChannels->Item["VCH1"]->SourceChannels = "CH1,CH2";
			pComparator->VirtualChannels->Item["VCH2"]->SourceChannels = "CH3,CH4";
			pComparator->VirtualChannels->Item["VCH3"]->SourceChannels = "VCH1,VCH2";

			//with EventGenerationEdge=Normal, the virtual channel's raw data will be 0 when the data is 
			//within the window, and an event will occur when leaving the window if EventGenerationEnabled=True
			pComparator->VirtualChannels->Item["VCH1"]->EventGenerationEdge = VTEXComparatorEventGenerationNormal;
			//with EventGenerationEdge=invert, the virtual channels's raw data will be 0 when the data is
			//outside of the window, and an event will occur when entering the window if EventGenerationEnabled=True
			pComparator->VirtualChannels->Item["VCH2"]->EventGenerationEdge = VTEXComparatorEventGenerationInvert;
			pComparator->VirtualChannels->Item["VCH3"]->EventGenerationEdge = VTEXComparatorEventGenerationNormal;

			pComparator->VirtualChannels->Item["VCH1"]->OrEnabled = true;
			pComparator->VirtualChannels->Item["VCH2"]->OrEnabled = true;
			pComparator->VirtualChannels->Item["VCH3"]->OrEnabled = false;

			pComparator->VirtualChannels->Item["VCH1"]->EventGenerationEnabled = true;
			pComparator->VirtualChannels->Item["VCH2"]->EventGenerationEnabled = true;
			pComparator->VirtualChannels->Item["VCH3"]->EventGenerationEnabled = true;

			//Now, input 2.5V into CH1 -- because PairedInput is set to True, this will also go to CH2.
			//Also input 5V into CH3. Again, PairedInput = True will cause this signal to go to CH4 as well.
			//Querying the raw data now should again show both VCH1 and VCH2 at 0. Since VCH3=VCH1&VCH2, it should be 0 as well;
			rawData = pComparator->VirtualChannels->RawData;

			//Set CH1's input to 5V and notice that its raw data becomes 1:
			rawData = pComparator->VirtualChannels->RawData;

			//Set CH1's input back to 2.5V and it should go back to 0:
			rawData = pComparator->VirtualChannels->RawData;

			//Set CH1's input to 0V and it will become 1 again:
			rawData = pComparator->VirtualChannels->RawData;

			//Set CH3's input to 2.5V and its raw data will become 1. Since VCH1 is 1 VCH3 will become 1 as well:
			rawData = pComparator->VirtualChannels->RawData;

			//Set CH3's input to 0V and both it and VCH3 will become 0 again:
			rawData = pComparator->VirtualChannels->RawData;

			//Close the initialized session
			pComparator->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
