#include "libComparator.h"
#include <stdio.h>

int main()
{
	//Create a VTEXComparator pointer
	LibComparator *pComparator;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Comparator pointer
		pComparator = LibComparator::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pComparator->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			/*The identity class contains properties that return general information of the instrument.
			You can get the information of the instrument simply by getting the value of the
			properties.*/
			std::string description = pComparator->Identity->Description;
			std::string groupCapabilities = pComparator->Identity->GroupCapabilities;
			std::string identifier = pComparator->Identity->Identifier;
			std::string firmwareRevision = pComparator->Identity->InstrumentFirmwareRevision;
			std::string manufacturer = pComparator->Identity->InstrumentManufacturer;
			std::string model = pComparator->Identity->InstrumentModel;
			std::string revision = pComparator->Identity->Revision;
			std::string supportedModels = pComparator->Identity->SupportedInstrumentModels;
			std::string vendor = pComparator->Identity->Vendor;

			//You can also get the serial number of the instrument
			std::string serialNumber = pComparator->Platform->SerialNumber;
			
			//Close the initialized session
			pComparator->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
