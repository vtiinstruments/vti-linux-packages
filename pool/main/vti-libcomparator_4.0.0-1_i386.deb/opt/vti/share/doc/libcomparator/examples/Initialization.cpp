#include "libComparator.h"
#include <stdio.h>

int main()
{
	//Create a VTEXComparator pointer
	LibComparator *pComparator;
	LibComparator *pComparator2;
	LibComparator *pComparator3;
	LibComparator *pComparator4;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Comparator pointer
		pComparator = LibComparator::Create();
		pComparator2 = LibComparator::Create();
		pComparator3 = LibComparator::Create();
		pComparator4 = LibComparator::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pComparator->Initialize("TCPIP::10.1.4.36::INSTR",true,true, "");

			//Initialize multiple comparators in one mainframe

			//Use any comparator card in slot 1, and don't perform an identification check
			pComparator2->Initialize("TCPIP::10.1.4.36::INSTR",false,true,"DriverSetup=Slots=(1)");

			//Use the card in slot 3, only if it is model ex1200-7416
			pComparator3->Initialize("TCPIP::10.1.4.36::INSTR",true,true,"DriverSetup=Slots=(3=ex1200-7416)");

			//Use any comparator card in slot 5, and do not reset it
			pComparator4->Initialize("TCPIP::10.1.4.36::INSTR",false,false,"DriverSetup=Slots=(5)");

			//Close the initialized session
			pComparator->Close();
			pComparator2->Close();
			pComparator3->Close();
			pComparator4->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
