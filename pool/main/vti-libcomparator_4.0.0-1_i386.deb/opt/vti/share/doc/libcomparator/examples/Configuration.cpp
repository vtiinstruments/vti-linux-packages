#include "libComparator.h"
#include <stdio.h>

int main()
{
	//Create a VTEXComparator pointer
	LibComparator *pComparator;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Comparator pointer
		pComparator = LibComparator::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pComparator->Initialize("TCPIP::10.1.4.55::INSTR",true,true,"");

			/*The comparator driver provides function for you to save and load configurations.
			Given a configuration name, you can save and load a configuration
			easily so that you can reuse the setting without setting the attributes
			again.*/
			
			//In this example, we are to save the setting on CH1 and VCH1,
			//where CH1 is a physical channel and VCH1 is a virtual channel.
			pComparator->Channels->Item["CH1"]->Range = 10.0;
			pComparator->Channels->Item["CH1"]->Threshold = 0;
			pComparator->Channels->Item["CH1"]->DebounceTime = 0.0001;
			pComparator->Channels->Item["CH1"]->PairedInput = false;
			pComparator->Channels->Item["CH1"]->TriggerOutput = VTEXComparatorChannelTriggerOutputNone;
			pComparator->Channels->Item["CH1"]->EventGenerationEnabled = false;
			pComparator->Channels->Item["CH1"]->EventGenerationEdge = VTEXComparatorEventGenerationNormal;
			pComparator->Channels->Item["CH1"]->EventAutoDisableMode = VTEXComparatorAutoDisableNone;
			pComparator->VirtualChannels->Item["VCH1"]->SourceChannels = "CH1,CH2,CH3";
			pComparator->VirtualChannels->Item["VCH1"]->OrEnabled = false;
			pComparator->VirtualChannels->Item["VCH1"]->TriggerOutput = VTEXComparatorChannelTriggerOutputNone;
			pComparator->VirtualChannels->Item["VCH1"]->EventGenerationEnabled = false;
			pComparator->VirtualChannels->Item["VCH1"]->EventGenerationEdge = VTEXComparatorEventGenerationNormal;
			pComparator->VirtualChannels->Item["VCH1"]->EventAutoDisableMode = VTEXComparatorAutoDisableNone;

			//You can also save the overflow mode for the event log
			pComparator->EventLog->OverflowMode = VTEXComparatorEventLogOverflowOverwrite;

			//Save the setting as a configuration
			pComparator->Configuration->Save("Config0");

			//Check how many configuration there in the device
			int count = pComparator->Configuration->Count;

			//Check if the configuration is in the configuration list
			std::string list = pComparator->Configuration->List;

			//Another way to check if a configuration exists
			bool exist = pComparator->Configuration->Exists("Config0");

			//To load the configuration in the future, call the Load function
			pComparator->Configuration->Load("Config0");

			//Delete the configuration
			pComparator->Configuration->Delete("Config0");

			//If there are too many configurations and you like to delete all of them at once
			//you can call DeleteAll function to delete all the configurations
			pComparator->Configuration->DeleteAll();
			
			//Close the initialized session
			pComparator->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
