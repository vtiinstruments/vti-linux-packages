#include "libComparator.h"
#include <stdio.h>

int main()
{
	//Create a VTEXComparator pointer
	LibComparator *pComparator;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Comparator pointer
		pComparator = LibComparator::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pComparator->Initialize("TCPIP::10.1.4.36::INSTR",true,true, "");

			//Get the name of all available channels
			for (int i=0; i<pComparator->Channels->Count; i++)
				printf("%s\n", pComparator->Channels->Name[i+1].c_str());
			//Note that the index is 1-based

			//Set a specified channel to connect to backplane
			pComparator->Channels->BackplaneConnectedChannel = "CH1";

			//To enable the backplane connection, set Enabled to true
			pComparator->Channels->BackplaneConnectionEnabled = true;
			//Once it is enabled, you can use the Dmm to measure the output value on the
			//channel through the backplane, for more information about Dmm, please
			//read the user manual

			//Check the raw data on all the channels
			int rawData = pComparator->Channels->RawData;
			printf("Raw Data for all channels: %x\n", rawData);
			//The least significant bit of the raw data is the raw data of CH1
            //The most significant bit of the raw data is the raw data of the highest number channel
            //For examples: 1100 0011 1010 0101 indicates that the raw data of CH1,CH3,CH6,CH8,CH9,CH10,CH15,CH16
            //is 1 and the raw data of CH2,CH4,CH5,CH7,CH11,CH12,CH13,CH14 is 0
			for (int i=1; i<= pComparator->Channels->Count; i++)
				printf("Raw Data for %s: %d\n", (char *)pComparator->Channels->Name[i].c_str(), (rawData >> (i-1) & 0x1));

			//Set the debounce time of a specified channel
			pComparator->Channels->Item["CH1"]->DebounceTime = 0.0001;

			//Set the event auto disable mode to determine how the event will be disabled on a specified channel
			pComparator->Channels->Item["CH1"]->EventAutoDisableMode = VTEXComparatorAutoDisableNone;

			//Set the event generation edge to determine how the event will be generated on a specified channel
			pComparator->Channels->Item["CH1"]->EventGenerationEdge = VTEXComparatorEventGenerationNormal;

			//Enable or disable the event generation on a specified channel
			pComparator->Channels->Item["CH1"]->EventGenerationEnabled  = false;

			//Get the hysteresis value on a specified channel
			double hysteresis = pComparator->Channels->Item["CH1"]->Hysteresis;
			//Note that for some of the comparator models, it is not allowed to set the hysteresis value
			//Please refer to the user manual for more information about hysteresis

			//Enable or disable paired input on a specified channel
			pComparator->Channels->Item["CH1"]->PairedInput = false;

			//Set the range of a specified channel
			pComparator->Channels->Item["CH1"]->Range = 10.0;

			//Set the threshold value of a specified channel
			pComparator->Channels->Item["CH1"]->Threshold = 0;

			//Set the trigger output of a specified channel
			pComparator->Channels->Item["CH1"]->TriggerOutput = VTEXComparatorChannelTriggerOutputNone;

			//The driver also provides a function to set all the attributes at once
			pComparator->Channels->Item["CH1"]->Configure(false, 10.0, 0, 0.0001, false, 
				VTEXComparatorChannelTriggerOutputNone,
				VTEXComparatorEventGenerationNormal,
				VTEXComparatorAutoDisableNone);
			
			//Close the initialized session
			pComparator->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
