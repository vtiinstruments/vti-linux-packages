#include "libComparator.h"
#include <stdio.h>

int main()
{
	//Create a VTEXComparator pointer
	LibComparator *pComparator;

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Comparator pointer
		pComparator = LibComparator::Create();
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pComparator->Initialize("TCPIP::10.1.4.25::INSTR",true,true, "");

			//Print out all the available virtual channel names
			for(int i=1; i<=pComparator->VirtualChannels->Count; i++)
				printf("%s\n",(char *)pComparator->VirtualChannels->Name[i].c_str());
			//Note that the index is 1-based.

			//Check the raw data of all the virtual channels
			int rawData = pComparator->VirtualChannels->RawData;
			printf("Raw Data for all virtual channels: %x\n",rawData);
			//The least significant bit of the raw data is the raw data of VCH1
            //The most significant bit of the raw data is the raw data of the highest number virtual channel
            //For examples: 1100 0011 1010 0101 indicates that the raw data of VCH1,VCH3,VCH6,VCH8,VCH9,VCH10,VCH15,VCH16
            //is 1 and the raw data of VCH2,VCH4,VCH5,VCH7,VCH11,VCH12,VCH13,VCH14 is 0
			for (int i=1; i<=pComparator->VirtualChannels->Count; i++)
				printf("Raw Data for %s: %x\n", (char *)pComparator->VirtualChannels->Name[i].c_str(), (rawData >> (i-1) & 0x1));

			//Set the event auto disable mode to determine how the event will be disabled on a specified virtual channel
			pComparator->VirtualChannels->Item["VCH1"]->EventAutoDisableMode = VTEXComparatorAutoDisableNone;

			//Set the event generation edge to determine how the event will be generated on a specified virtual channel
			pComparator->VirtualChannels->Item["VCH1"]->EventGenerationEdge = VTEXComparatorEventGenerationNormal;

			//Enable or disable the event generation on a specified virtual channel
			pComparator->VirtualChannels->Item["VCH1"]->EventGenerationEnabled = false;

			//Set the source channel property to specify which physical channels or virtual channels
			//are the source channels for a specified virtual channel
			pComparator->VirtualChannels->Item["VCH1"]->SourceChannels = "CH1,CH2,CH3";
			//Note that in order to set a virtual channel as a source channel, the number of the 
			//source virtual channel needs to be lower than the number of the virtual channel
			//that is being set.
			//For example, VCH2 can be a source channel of VCH3-16 but not VCH1
			//VCH6 can be a source cahnnel of VCH7-16 but not VCH1-5
			//For that reason, VCH1 cannot have any virtual channel as a source channel

			//Enable or disable the OrEnabled property of the specified virtual channel
			pComparator->VirtualChannels->Item["VCH1"]->OrEnabled = false;
			//In this example, if OrEnabled is set to true, the raw data of either one of CH1, CH2 and CH3
			//changes to 1, the raw data of VCH1 will also change to 1.
			//If OrEnabled is set to false, the raw datta of all CH1, CH2, and CH3 needs to be 1 in order
			//for the raw data of VCH1 to become 1
			
			//Set the trigger output of a specified virtual channel
			pComparator->VirtualChannels->Item["VCH1"]->TriggerOutput = VTEXComparatorChannelTriggerOutputNone;

			//The driver also provides a function to set all the attributes at once
			pComparator->VirtualChannels->Item["VCH1"]->Configure(false,"CH1,CH2,CH3",false,
				VTEXComparatorChannelTriggerOutputNone,
				VTEXComparatorEventGenerationNormal,
				VTEXComparatorAutoDisableNone);

			//Close the initialized session
			pComparator->Close();
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
