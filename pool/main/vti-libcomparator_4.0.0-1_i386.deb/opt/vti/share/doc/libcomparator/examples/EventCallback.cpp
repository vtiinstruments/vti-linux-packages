#include <stdio.h>
#ifndef _WIN32
#include <unistd.h>
#endif
#ifdef _WIN32
#include <windows.h>
#define SLEEP(x)	Sleep(x*1000)
#else
#define SLEEP(x)	sleep(x)
#endif

#include "libComparator.h"

//
// Implement callback class to be called at the event.
//
class AllEventsCallback : public LibComparatorEventCallback
{
  private:
	int32_t m_lPhysicalMask;
	int32_t m_lVirtualMask;

  public:
    AllEventsCallback() 
    {
      m_lPhysicalMask = 0xffff;
      m_lVirtualMask = 0xffff;
    }

	virtual VTEXResult put_PhysicalMask(int32_t value) { m_lPhysicalMask = value; return IVI_SUCCESS; }
	virtual VTEXResult get_PhysicalMask(int32_t *value) { *value = m_lPhysicalMask; return IVI_SUCCESS; }

	virtual VTEXResult put_VirtualMask(int32_t value) { m_lVirtualMask = value; return IVI_SUCCESS; }
	virtual VTEXResult get_VirtualMask(int32_t *value) { *value = m_lVirtualMask; return IVI_SUCCESS; }

    // EventOccurred function is called when events are detected at any
    // physical or virtual channels specified in the channel mask.
    virtual void EventOccurred(int32_t PhysicalMask, int32_t VirtualMask) 
    {
      // PhysicalMask and VirtualMask indicates which channels caused 
      // this event.
      printf("Event occurred: physical channels: %#x, virtual channels: %#x\n",
             PhysicalMask, VirtualMask);
    }
};


int main (int argc, char *argv[]) 
{
    // Declare a libComparator object pointer.
    LibComparator* pComparator = 0;

    try
    {
        // Instantiate libComprator object.
        pComparator = LibComparator::Create();

        // Connect to an instrument and initilaize a session.
        pComparator->Initialize("TCPIP::10.8.1.21::INSTR", 
                                                       true, true, "");

        // Unlike real application, this example program forces an event
        // to occurr at channel 1 by changing threshold level from -99V to
        // to 99V.   This virtually guarantee an event regardless of actual
        // voltate at channel 1.
        // In actual application, signal level change causes an event, rather
        // than threshold level change.
        pComparator->Channels->Item["CH1"]->Range = 100;
        pComparator->Channels->Item["CH1"]->Threshold = -99;

        // Enable event generation at both rising and falling edges.
        pComparator->Channels->Item["CH1"]->EventGenerationEnabled = true;
        pComparator->Channels->Item["CH1"]->EventGenerationEdge 
                                      = VTEXComparatorEventGenerationBoth;

        // Instantiate a callback object.
        AllEventsCallback *cb = new AllEventsCallback();

        // Register the callback object and keep the handle returned.
        // The returned handle will be used to unregister the callback.
        int32_t cb_handle;
        pComparator->RegisterEventCallback(cb, &cb_handle);

        printf("Callback registered.\n");

        // Force an event at channel 1 by flipping threshold level.
        printf("Causing event...\n");
        pComparator->Channels->Item["CH1"]->Threshold = 99;
        printf("Sleeping...\n");
        SLEEP(8);

        // Force an event again at channel 1 by flipping threshold level.
        printf("Causing event...\n");
        pComparator->Channels->Item["CH1"]->Threshold = -99;
        printf("Sleeping...\n");
        SLEEP(8);


        // Unregister the callback.
        pComparator->UnregisterEventCallback(cb_handle);
        printf("Callback unregistered.\n");

        // Delete the callback object.
        delete cb;

        // Close the session and delete object.
        pComparator->Close();
        delete(pComparator);

    }
    catch(VTEXException e)
    {
        printf("Error code: %d\n", (unsigned int)e.errorCode);
        printf("Error message: %s\n", e.errorMessage.c_str());

        delete(pComparator);
    }


}



