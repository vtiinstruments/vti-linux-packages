#include "libComparator.h"
#ifdef USE_SYSTEM
#include "libSystem.h"
#endif
#include <stdio.h>

int main()
{
	//Create a VTEXComparator pointer
	LibComparator *pComparator;
#ifdef USE_SYSTEM
	LibSystem *pSystem;
#endif

	/*We want to instantiate a pointer to the driver in a try/catch block so that we fail
	properly if there is an error*/
	try
	{
		//Instantiate the created Comparator pointer
		pComparator = LibComparator::Create();
#ifdef USE_SYSTEM
		pSystem = LibSystem::Create();
#endif
		/*We want to do the initialization in a try/catch block so that our test code 
		doesn't run if we fail to initialize.*/
		
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pComparator->Initialize("TCPIP::10.1.4.36::INSTR",true,true, "");
#ifdef USE_SYSTEM
			pSystem->Initialize("TCPIP::10.1.4.36::INSTR",true,true, "");
#endif

      /*
       * This example will illustrate how to use the triggering properties of the VTEXComparator driver.
       */

      // Any channel can, when an event occurs, assert a backplane trigger, the front panel triggers, both, or none.
      pComparator->Channels->Item["CH1"]->TriggerOutput = VTEXComparatorChannelTriggerOutputBackplane;
      pComparator->Channels->Item["CH2"]->TriggerOutput = VTEXComparatorChannelTriggerOutputFrontPanel;
      pComparator->Channels->Item["CH3"]->TriggerOutput = VTEXComparatorChannelTriggerOutputBoth;
      pComparator->Channels->Item["CH4"]->TriggerOutput = VTEXComparatorChannelTriggerOutputNone;

      // There are two front panel trigger lines. They are fed by the same logic, but one latches until cleared manually,
      if (pComparator->Trigger->FrontPanel->LatchedTriggerAsserted)
        pComparator->Trigger->FrontPanel->ClearLatch();
      // while other will always emit a momentary pulse for every event.
      bool asserted = pComparator->Trigger->FrontPanel->UnlatchedTriggerAsserted;

      // Each ex1200 card can use only one backplane trigger line as an output at a time.
      pComparator->Trigger->Backplane->OutputTrigger = VTEXComparatorBackplaneTriggerBPL5;
      // The backplane trigger can either latch when asserted until cleared by the user.
      pComparator->Trigger->Backplane->LatchEnable = true;
      pComparator->Trigger->Backplane->ClearLatch();
      // Or, it can emit only momentary pulses for every event.
      pComparator->Trigger->Backplane->LatchEnable = false;
#ifdef USE_SYSTEM
      // The system driver can be used to check the state of the backplane lines.
      // Comparator trigger outputs are normally high, asserted low.
      asserted = ((system->InstrumentSpecific->IOPorts->Item["BPL"]->InputState & (1 << 5)) == 0);
      // The system driver can also be used to route the backplane line to an external trigger.
      system->Events->Item["LXI5"]->Configure(
          VTEXSystemEventDriveModeDriven,
          "BPL5", "",
          VTEXSystemSourceSlopeRise);
#endif
			
			//Close the initialized session
			pComparator->Close();
#ifdef USE_SYSTEM
      pSystem->Close();
#endif
		}	
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}
