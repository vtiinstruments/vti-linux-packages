#include "libComparator.h"
#include <stdio.h>
#include <ctime>
#ifndef _WIN32
#include <unistd.h>
#endif

void printEvent(LibComparator *compartor, int PhysicalEvents, int PhysicalChannels, int VirtualEvents, int VirtualChannels, double timeSeconds, double timeFractional);

int main()
{
	//Create a VTEXComparator pointer
	LibComparator *pComparator;
	
	try
	{
		//Instantiate the created Comparator pointer
		pComparator = LibComparator::Create();

		/*We want to do the Initialization in a try/catch block so that our test code
		doesn't run if we fail to initialize.*/
		try
		{
			/*We chose to give the driver an empty options string. You may want to 
			give your driver options - check the manual to see the available settings.
			Note that we also set the Reset bit so that we get a clean start to work 
			from.*/
			pComparator->Initialize("TCPIP::10.1.4.25::INSTR",true,true, "");

			//Comparator cards have an internal FIFO of logged events that can be 
			//controlled and read via the EventLog interface.

			//Use the EventGenerationEnabled property of Channel and VirtualChannel objects to enable
			//the logging of events from that channel
			pComparator->Channels->Item["CH1"]->EventGenerationEnabled = true;
			pComparator->VirtualChannels->Item["VCH1"]->EventGenerationEnabled = true;

			//Use the EventgenerationEdge property to control whether rising, falling, or both
			//edges cause events to be logged
			pComparator->Channels->Item["CH1"]->EventGenerationEdge = VTEXComparatorEventGenerationBoth;
			pComparator->Channels->Item["CH2"]->EventGenerationEdge = VTEXComparatorEventGenerationNormal;
			pComparator->VirtualChannels->Item["VCH1"]->EventGenerationEdge = VTEXComparatorEventGenerationInvert;

			//Set the OverflowMode property to control what happens when too many events occur
			//delete the oldest entry in the log and replace it with the new event
			pComparator->EventLog->OverflowMode = VTEXComparatorEventLogOverflowOverwrite;
			//stop recording new events
			pComparator->EventLog->OverflowMode = VTEXComparatorEventLogOverflowStop;

			//It's often useful at the beginning of a test to clear the event log of any previous events.
			pComparator->EventLog->Clear();

			//You can check to see how many events have occurred so far by querying the 
			//number of events currenty stored in the event log:
			int num_events = pComparator->EventLog->Count;

			//flip the threshold of CH1 back and forth a few times to force events to occur...
			pComparator->Channels->Item["CH1"]->Range = 100.0;
			pComparator->Channels->Item["CH1"]->Threshold = 99.0;
			pComparator->EventLog->Clear();
			for (int i=0; i<10; i++)
			{
				usleep(200000);
				pComparator->Channels->Item["CH1"]->Threshold = -pComparator->Channels->Item["CH1"]->Threshold;
				num_events = pComparator->EventLog->Count;
				printf("%d events in log\n", num_events);
			}

			//Use ReadLastEvent() to read back just the last event to occur without touching the FIFO.
			int PhysicalEvents = 0, PhysicalChannels = 0, VirtualEvents = 0, VirtualChannels = 0;
			double timeSeconds = 0, timeFractional = 0;
			pComparator->EventLog->ReadLastEvent(
				&PhysicalEvents, &PhysicalChannels,
				&VirtualEvents, &VirtualChannels,
				&timeSeconds, &timeFractional);

			printf("\nLast event was:\n");
			printEvent(pComparator, PhysicalEvents, PhysicalChannels, VirtualEvents, VirtualChannels, timeSeconds, timeFractional);
			
			//Read back num_events events from the event log, waiting up to 1000ms for the events to be available.
			std::vector<int> a_PhysicalEvents;
			std::vector<int> a_PhysicalChannels;
			std::vector<int> a_VirtualEvents;
			std::vector<int> a_VirtualChannels;
			std::vector<double> a_timeSeconds;
			std::vector<double> a_timeFractional;
			
			pComparator->EventLog->Read(num_events, 1000,
				a_PhysicalEvents, a_PhysicalChannels, 
				a_VirtualEvents, a_VirtualChannels,
				a_timeSeconds, a_timeFractional);

			printf("Entire Contents of Event Log:\n");
			for(int i=0; i<num_events; i++)
			{
				printEvent(pComparator, 
					a_PhysicalEvents[i], a_PhysicalChannels[i],
					a_VirtualEvents[i], a_VirtualChannels[i],
					a_timeSeconds[i], a_timeFractional[i]);					
			}
			
			//Close the initialized session
			pComparator->Close();
		}
		catch(VTEXException e)
		{
			printf("Error code: %d", e.errorCode);
			printf("Error Message: %s", e.errorMessage.c_str());
		}
	}
	catch(...)
	{
		/*We put this here to catch any error the program generates.*/
		//Do something to intelligently deal with errors
	}
}

void printEvent(LibComparator *pComparator, int PhysicalEvents, int PhysicalChannels, int VirtualEvents, int VirtualChannels, double timeSeconds, double timeFractional)
{
	//all timestamps are IEEE1588-based and as such are offsets from 1/1/1970 00:00:00 UTC	
	time_t rawtime;
	struct tm * timeinfo;
	char buf[80];
	
	rawtime = (time_t)timeSeconds;
	timeinfo = localtime (&rawtime);	
	strftime(buf, sizeof(buf), "%a %Y-%m-%d %H:%M:%S",timeinfo);	
	sprintf(buf,"%s, %f ms",buf,timeFractional*1000);	
	printf("Event occured at %s\n",buf);

	//PhysicalChannels indicates which physical channels events occurred on
	//PhysicalEvents indicates the new physical raw data after the events occurred
	for(int i=1; i<= pComparator->Channels->Count; i++)
	{
		int mask = (1<<(i-1));
		if((PhysicalChannels & mask) != 0)		
			printf("%s: %s\n",(char *)pComparator->Channels->Name[i].c_str(),((PhysicalEvents & mask) == 0)? "falling" : "rising");		
	}

	//VirtualChannels indicates which virtual channels events occurred on
	//VirtualEvents indicates the new virtual raw data after the events occurred
	for(int i=1; i<=pComparator->VirtualChannels->Count; i++)
	{
		int mask = (1<<(i-1));
		if((VirtualChannels & mask) != 0)		
			printf("%s: %s edge\n",(char *)pComparator->VirtualChannels->Name[i].c_str(),((VirtualEvents & mask) == 0) ? "falling" : "rising");		
	}
	printf("\n");
}
