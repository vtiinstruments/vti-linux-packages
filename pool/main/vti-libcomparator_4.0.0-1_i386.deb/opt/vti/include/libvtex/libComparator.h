
/******************************************************************************
 *
 *  .----------------------.	
 *  |==     ==  ======  == |	$Author$
 *  | ==   ==   ======  == |	$Revision$ 
 *  |  == ==      ==    == |	$Date$ 
 *  |   ===       ==    == |	$HeadURL$
 *  |    =        ==    == |	
 *  `----------------------'
 *
 * Copyright 2009 VTI Instruments Coorporation as an unpublished work. 
 * All rights reserved. The information contained herein is confidential
 * property of VTI Instruments Coorporation Use, copy, transfer or disclosure
 * of such information is prohibited except by express written agreement 
 * with VTI Instruments Coorporation.
 *
 * PURPOSE: 
 *   Class definition of the main LibComparator class
 *
 * First Written By:
 ******************************************************************************/
#ifndef _LIB_COMPARATOR_H
#define _LIB_COMPARATOR_H


/*******************
 * System header
 *******************/
#include <vector>

/*******************
 * Library header
 *******************/

/*******************
 * Local header
 *******************/
#include "vtexapi.h"
#ifndef _ATL_ATTRIBUTES
  #include "ComparatorConstants.h"
#endif

#include "vtexException.h"
#include "CommonErrors.h"
#include "ComparatorErrors.h"

#include "libInherent.h"


 
class VTEX_API LibComparatorChannel
{
    public:
        virtual ~LibComparatorChannel() { };

		//Datamembers
		property <LibComparatorChannel, double, READ_WRITE> DebounceTime;
		property <LibComparatorChannel, bool, READ_WRITE> EventGenerationEnabled;
		property <LibComparatorChannel, VTEXComparatorAutoDisableEnum, READ_WRITE> EventAutoDisableMode;
		property <LibComparatorChannel, VTEXComparatorEventGenerationEnum, READ_WRITE> EventGenerationEdge;
		property <LibComparatorChannel, double, READ_WRITE> Hysteresis;
		property <LibComparatorChannel, double, READ_WRITE> Range;
		property <LibComparatorChannel, double, READ_WRITE> Threshold;
		property <LibComparatorChannel, VTEXComparatorChannelTriggerOutputEnum, READ_WRITE> TriggerOutput;
		property <LibComparatorChannel, bool, READ_WRITE> PairedInput;

		//Methods
		virtual VTEXResult Configure(bool EventGenerationEnabled, double Range, double Threshold, double DebunceTime, 
			bool PairedInput,
			VTEXComparatorChannelTriggerOutputEnum TriggerOutput,
			VTEXComparatorEventGenerationEnum EventGenerationEdge, 
			VTEXComparatorAutoDisableEnum EventAutoDisableMode) = 0;

		// Property methods
		virtual VTEXResult put_DebounceTime(double value) = 0;
		virtual VTEXResult get_DebounceTime(double* value) = 0;
		virtual VTEXResult put_EventGenerationEnabled(bool value) = 0;
		virtual VTEXResult get_EventGenerationEnabled(bool* value) = 0;
		virtual VTEXResult put_EventAutoDisableMode(VTEXComparatorAutoDisableEnum value) = 0;
		virtual VTEXResult get_EventAutoDisableMode(VTEXComparatorAutoDisableEnum* value) = 0;
		virtual VTEXResult put_EventGenerationEdge(VTEXComparatorEventGenerationEnum value) = 0;
		virtual VTEXResult get_EventGenerationEdge(VTEXComparatorEventGenerationEnum* value) = 0;
		virtual VTEXResult put_Hysteresis(double value) = 0;
		virtual VTEXResult get_Hysteresis(double* value) = 0;
		virtual VTEXResult put_Range(double value) = 0;
		virtual VTEXResult get_Range(double* value) = 0;
		virtual VTEXResult put_Threshold(double value) = 0;
		virtual VTEXResult get_Threshold(double* value) = 0;
		virtual VTEXResult put_TriggerOutput(VTEXComparatorChannelTriggerOutputEnum value) = 0;
		virtual VTEXResult get_TriggerOutput(VTEXComparatorChannelTriggerOutputEnum* value) = 0;
		virtual VTEXResult put_PairedInput(bool value) = 0;
		virtual VTEXResult get_PairedInput(bool* value) = 0;
};


class VTEX_API LibComparatorChannels
{
	public:
		virtual ~LibComparatorChannels() { };

		//Properties
		property <LibComparatorChannels, VTEXString, READ_WRITE> BackplaneConnectedChannel;
		property <LibComparatorChannels, bool, READ_WRITE> BackplaneConnectionEnabled;
        property <LibComparatorChannels, int32_t, READ_ONLY> Count;
        arrayizer <LibComparatorChannels, LibComparatorChannel*, const VTEXString&> Item;
        arrayizer <LibComparatorChannels, VTEXString, int32_t> Name;
		property <LibComparatorChannels, int32_t, READ_ONLY> RawData;

        //Methods
		virtual VTEXResult put_BackplaneConnectedChannel(const VTEXString &name) = 0;
		virtual VTEXResult get_BackplaneConnectedChannel(VTEXString *name) = 0;
 		virtual VTEXResult put_BackplaneConnectionEnabled(bool value) = 0;
 		virtual VTEXResult get_BackplaneConnectionEnabled(bool *value) = 0;
        virtual VTEXResult get_Count(int32_t* count) = 0;
        virtual LibComparatorChannel* get_Item(const VTEXString& channelName) = 0;
        virtual VTEXString get_Name(int32_t repCapIndex) = 0;
		virtual VTEXResult get_RawData(int32_t* value) = 0;
};

class VTEX_API LibComparatorVirtualChannel
{
    public:
        virtual ~LibComparatorVirtualChannel() { };

        //Properties
		property <LibComparatorVirtualChannel, bool, READ_WRITE> EventGenerationEnabled;
		property <LibComparatorVirtualChannel, VTEXComparatorAutoDisableEnum, READ_WRITE> EventAutoDisableMode;
		property <LibComparatorVirtualChannel, VTEXComparatorEventGenerationEnum, READ_WRITE> EventGenerationEdge;
		property <LibComparatorVirtualChannel, bool, READ_WRITE> OrEnabled;
		property <LibComparatorVirtualChannel, VTEXString, READ_WRITE> SourceChannels;
		property <LibComparatorVirtualChannel,VTEXComparatorChannelTriggerOutputEnum, READ_WRITE> TriggerOutput;

        //Methods
		virtual VTEXResult Configure(bool EventGenerationEnabled, 
			VTEXString SourceChannels, 
			bool OrEnabled,
			VTEXComparatorChannelTriggerOutputEnum TriggerOutput,
			VTEXComparatorEventGenerationEnum EventGenerationEdge,
			VTEXComparatorAutoDisableEnum EventAutoDisableMode) = 0;

		// Property methods
		virtual VTEXResult put_EventGenerationEnabled(bool value) = 0;
		virtual VTEXResult get_EventGenerationEnabled(bool* value) = 0;
		virtual VTEXResult put_EventAutoDisableMode(VTEXComparatorAutoDisableEnum value) = 0;
		virtual VTEXResult get_EventAutoDisableMode(VTEXComparatorAutoDisableEnum* value) = 0;
		virtual VTEXResult put_EventGenerationEdge(VTEXComparatorEventGenerationEnum value) = 0;
		virtual VTEXResult get_EventGenerationEdge(VTEXComparatorEventGenerationEnum* value) = 0;
		virtual VTEXResult put_SourceChannels(const VTEXString &value) = 0;
		virtual VTEXResult get_SourceChannels(VTEXString* value) = 0;
		virtual VTEXResult put_OrEnabled(bool value) = 0;
		virtual VTEXResult get_OrEnabled(bool* value) = 0;
		virtual VTEXResult put_TriggerOutput(VTEXComparatorChannelTriggerOutputEnum value) = 0;
		virtual VTEXResult get_TriggerOutput(VTEXComparatorChannelTriggerOutputEnum* value) = 0;
};


class VTEX_API LibComparatorVirtualChannels
{
    public:
		virtual ~LibComparatorVirtualChannels() { };

		//Attributes
        property <LibComparatorVirtualChannels, int32_t, READ_ONLY> Count;
        arrayizer <LibComparatorVirtualChannels, LibComparatorVirtualChannel*, const VTEXString&> Item;
        arrayizer <LibComparatorVirtualChannels, VTEXString, int32_t> Name;
		property <LibComparatorVirtualChannels, int32_t, READ_ONLY> RawData;


        //Methods
        virtual LibComparatorVirtualChannel* get_Item(const VTEXString& channelName) = 0;
        virtual VTEXString get_Name(int32_t repCapIndex) = 0;
        virtual VTEXResult get_Count(int32_t* count) = 0;
		virtual VTEXResult get_RawData(int32_t* value) = 0;
};


class VTEX_API LibComparatorEventLog
{
    public:
        virtual ~LibComparatorEventLog() { };

        //Properties
		property <LibComparatorEventLog, int32_t, READ_ONLY> Count;
		property <LibComparatorEventLog, VTEXComparatorEventLogOverflowEnum, READ_WRITE> OverflowMode;

        //Methods
		virtual VTEXResult Clear(void) = 0;
		virtual VTEXResult ReadLastEvent(int32_t* PhysicalEvents, int32_t* PhysicalChannels,
										int32_t* VirtualEvents, int32_t* VirtualChannels,
										double* TimeSeconds, double* TimeFraction) = 0;
		virtual VTEXResult Read(int32_t Count, int32_t MaxTimeMilliseconds ,
			std::vector <int32_t>& PhysicalEvents, std::vector <int32_t>& PhysicalChannels,
			std::vector <int32_t>& VirtualEvents, std::vector <int32_t>& VirtualChannels,
			std::vector <double>& TimeSeconds, std::vector<double>& TimeFraction ) = 0;

		// Property methods
		virtual VTEXResult get_Count(int32_t* value) = 0;
		virtual VTEXResult put_OverflowMode(VTEXComparatorEventLogOverflowEnum  value) = 0;
		virtual VTEXResult get_OverflowMode(VTEXComparatorEventLogOverflowEnum *value) = 0;
};

class VTEX_API LibComparatorPlatform
{
    public:
        virtual ~LibComparatorPlatform() {};

		// Methods
		virtual VTEXResult CloseLogFile(void) = 0;
		virtual VTEXResult OpenLogFile(VTEXString FileName, VTEXString AccessMode) = 0;

		// Properties
		property <LibComparatorPlatform, VTEXString, READ_ONLY> SerialNumber;

		// Property methods
		virtual VTEXResult get_SerialNumber(VTEXString *value) = 0;
};

class VTEX_API LibComparatorTriggerFrontPanel
{
    public:
        virtual ~LibComparatorTriggerFrontPanel() { };

		// Methods
		virtual VTEXResult ClearLatch(void) = 0;

		// Properties
		property <LibComparatorTriggerFrontPanel, bool, READ_ONLY > LatchedTriggerAsserted;
		property <LibComparatorTriggerFrontPanel, VTEXComparatorTriggerOutputLevelEnum, READ_WRITE > LatchedTriggerLevel;
		property <LibComparatorTriggerFrontPanel, bool, READ_ONLY > UnlatchedTriggerAsserted;
		property <LibComparatorTriggerFrontPanel, VTEXComparatorTriggerOutputLevelEnum, READ_WRITE > UnlatchedTriggerLevel;

		// Property methods
		virtual VTEXResult get_LatchedTriggerAsserted(bool *value) = 0;
		virtual VTEXResult put_LatchedTriggerLevel(VTEXComparatorTriggerOutputLevelEnum value) = 0;
		virtual VTEXResult get_LatchedTriggerLevel(VTEXComparatorTriggerOutputLevelEnum *value) = 0;
		virtual VTEXResult get_UnlatchedTriggerAsserted(bool *value) = 0;
		virtual VTEXResult put_UnlatchedTriggerLevel(VTEXComparatorTriggerOutputLevelEnum value) = 0;
		virtual VTEXResult get_UnlatchedTriggerLevel(VTEXComparatorTriggerOutputLevelEnum *value) = 0;
};

class VTEX_API LibComparatorTriggerBackplane
{
    public:
        virtual ~LibComparatorTriggerBackplane() { };

		// Methods
		virtual VTEXResult ClearLatch(void) = 0;

		// Properties
		property <LibComparatorTriggerBackplane, VTEXComparatorBackplaneTriggerEnum , READ_WRITE> OutputTrigger;
		property <LibComparatorTriggerBackplane, bool, READ_WRITE > LatchEnable;
		property <LibComparatorTriggerBackplane, VTEXComparatorTriggerOutputLevelEnum, READ_WRITE > TriggerLevel;

		// Property methods
		virtual VTEXResult put_OutputTrigger(VTEXComparatorBackplaneTriggerEnum value) = 0;
		virtual VTEXResult get_OutputTrigger(VTEXComparatorBackplaneTriggerEnum*value) = 0;
		virtual VTEXResult put_LatchEnable(bool value) = 0;
		virtual VTEXResult get_LatchEnable(bool *value) = 0;
		virtual VTEXResult put_TriggerLevel(VTEXComparatorTriggerOutputLevelEnum value) = 0;
		virtual VTEXResult get_TriggerLevel(VTEXComparatorTriggerOutputLevelEnum *value) = 0;
};

class VTEX_API LibComparatorTrigger
{
	public:
        virtual ~LibComparatorTrigger() { };

		// Properties
		LibComparatorTriggerFrontPanel *FrontPanel;
		LibComparatorTriggerBackplane  *Backplane;
};


class VTEX_API LibComparatorConfiguration
{
    public:
        virtual ~LibComparatorConfiguration() { };

		// Methods
		virtual VTEXResult Delete(VTEXString ConfigurationName) = 0;
		virtual VTEXResult DeleteAll(void) = 0;
		virtual VTEXResult Load(VTEXString ConfigurationName) = 0;
		virtual VTEXResult Save(VTEXString ConfigurationName) = 0;

		// Properties
		property <LibComparatorConfiguration, int32_t, READ_ONLY> Count;
		property <LibComparatorConfiguration, VTEXString, READ_ONLY> List;

		// Property methods
		virtual bool Exists(VTEXString ConfigurationName) = 0;
//		virtual VTEXResult get_Exists(VTEXString ConfigurationName, bool *value) = 0;
		virtual VTEXResult get_Count(int32_t *value) = 0;
		virtual VTEXResult get_List(VTEXString *value) = 0;
};

class VTEX_API LibComparatorCalibration
{
    public:
        virtual ~LibComparatorCalibration() { };

		// Methods
		virtual VTEXResult Load(int32_t CalibrationSet) = 0;
		virtual VTEXResult Read(VTEXString ChannelName, VTEXComparatorCalibrationConstantEnum Type, double Range, double *Value) = 0;
		virtual VTEXResult ReadFile(int32_t CalibrationSet, VTEXString &String) = 0;
		virtual VTEXResult Save(int32_t CalibrationSet, int32_t Password) = 0;
		virtual VTEXResult Write(VTEXString ChannelName, VTEXComparatorCalibrationConstantEnum Type, double Range, double Value) = 0;
		virtual VTEXResult WriteFile(int32_t CalibrationSet, int32_t Password, VTEXString &Data) = 0;

		// properties
		property <LibComparatorCalibration, bool, READ_WRITE> Mode;

		// property methods
		virtual VTEXResult put_Mode(bool value) = 0;
		virtual VTEXResult get_Mode(bool *value) = 0;

		virtual VTEXResult put_RawDac(VTEXString ChannelName, int32_t value) = 0;
		virtual VTEXResult get_RawDac(VTEXString ChannelName, int32_t *value) = 0;
};

// Callback class definition.
class LibComparatorEventCallback
{
public:
    virtual ~LibComparatorEventCallback() { };

public:
    virtual VTEXResult get_PhysicalMask(int32_t *value) = 0;
    virtual VTEXResult put_PhysicalMask(int32_t value) = 0;
    virtual VTEXResult get_VirtualMask(int32_t *value) = 0;
    virtual VTEXResult put_VirtualMask(int32_t value) = 0;

	virtual void EventOccurred(int32_t PhysicalMask, int32_t VirtualMask) = 0;
};

class VTEX_API LibComparator : public LibInherent
{
    public:
        static LibComparator* Create();
        virtual ~LibComparator() { };
        
        //Inherent capability
        property <LibComparator, bool, READ_ONLY> Initialized;
        LibInherentCapabilityUtility* Utility;
        LibInherentCapabilityDriverOperation* DriverOperation;
        LibInherentCapabilityIdentity* Identity;

		// Properties
	    LibComparatorChannels* Channels;
	    LibComparatorVirtualChannels* VirtualChannels;
		LibComparatorTrigger* Trigger;
		LibComparatorEventLog* EventLog;
		LibComparatorConfiguration* Configuration;
		LibComparatorCalibration* Calibration;
		LibComparatorPlatform* Platform;

		// Methods.
		virtual VTEXResult WaitForEvent(int32_t MaxTimeMiliseconds, int32_t *PhysicalMask, int32_t *VirtualMask) = 0;

		virtual VTEXResult RegisterEventCallback(LibComparatorEventCallback *Callback, int32_t *Handle) = 0;
		virtual VTEXResult UnregisterEventCallback(int32_t Handle) = 0;
};

#endif  //_LIB_COMPARATOR_H
