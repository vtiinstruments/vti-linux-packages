#include "exErrors.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#if defined(_WIN32) && !defined(_CVI_)
#define INLINE __inline
#else
#define INLINE inline
#endif

#ifdef __cplusplus
extern "C" {
#endif

 //!
 //! @file
 //!
 //! Comparator constants.
 //!

#ifndef _ComparatorConstants_H
#define _ComparatorConstants_H

#define COMPARATOR_MAX_SAMPLES_PER_READ 1000
#define COMPARATOR_MAX_TIMEOUT_SECS 20
#define COMPARATOR_CHANNEL_BASE 1

 //
 // There are no IVI class-compliant constants for this Comparator card
 //

 //
 // Instrument-specific constants
 //
enum VTEXComparatorEventGenerationEnum
{
  VTEXComparatorEventGenerationNone = 1000,
  VTEXComparatorEventGenerationNormal = 1001,
  VTEXComparatorEventGenerationInvert = 1002,
  VTEXComparatorEventGenerationBoth = 1003
};

enum VTEXComparatorBackplaneTriggerEnum
{
  VTEXComparatorBackplaneTriggerNone = 0,
  VTEXComparatorBackplaneTriggerBPL0 = 1000,
  VTEXComparatorBackplaneTriggerBPL1 = 1001,
  VTEXComparatorBackplaneTriggerBPL2 = 1002,
  VTEXComparatorBackplaneTriggerBPL3 = 1003,
  VTEXComparatorBackplaneTriggerBPL4 = 1004,
  VTEXComparatorBackplaneTriggerBPL5 = 1005,
  VTEXComparatorBackplaneTriggerBPL6 = 1006,
  VTEXComparatorBackplaneTriggerBPL7 = 1007
};

enum VTEXComparatorChannelTriggerOutputEnum
{
  VTEXComparatorChannelTriggerOutputNone = 1000,
  VTEXComparatorChannelTriggerOutputBackplane = 1001,
  VTEXComparatorChannelTriggerOutputFrontPanel = 1002,
  VTEXComparatorChannelTriggerOutputBoth = 1003
};

enum VTEXComparatorAutoDisableEnum
{
  VTEXComparatorAutoDisableNone = 1000,
  VTEXComparatorAutoDisableDisableOnly = 1001,
  VTEXComparatorAutoDisableDisableAndReEnable = 1002
};

enum VTEXComparatorEventLogOverflowEnum
{
  VTEXComparatorEventLogOverflowStop = 1000,
  VTEXComparatorEventLogOverflowOverwrite = 1001
};

enum VTEXComparatorCalibrationConstantEnum
{
  VTEXComparatorCalibrationConstantDate = 1000,
  VTEXComparatorCalibrationConstantDueDate = 1001,
  VTEXComparatorCalibrationConstantInputGain = 1002,
  VTEXComparatorCalibrationConstantInputOffset = 1003,
  VTEXComparatorCalibrationConstantDacGain = 1004,
  VTEXComparatorCalibrationConstantDacOffset = 1005
};

enum VTEXComparatorCalibrationSlotEnum
{
  VTEXComparatorCalibrationSlotNominal = -1,
  VTEXComparatorCalibrationSlotFactory = 0,
  VTEXComparatorCalibrationSlotUser1 = 1,
  VTEXComparatorCalibrationSlotUser2 = 2,
  VTEXComparatorCalibrationSlotUser3 = 3,
  VTEXComparatorCalibrationSlotUser4 = 4,
  VTEXComparatorCalibrationSlotUser5 = 5,
  VTEXComparatorCalibrationSlotUser6 = 6,
  VTEXComparatorCalibrationSlotUser7 = 7,
  VTEXComparatorCalibrationSlotUser8 = 8
};

enum VTEXComparatorTriggerOutputLevelEnum
{
  VTEXComparatorTriggerOutputLevelActiveLow = 1000,
  VTEXComparatorTriggerOutputLevelActiveHigh = 1001
};

#endif /* ! _ComparatorConstants_H */

#ifdef  __cplusplus
}
#endif

