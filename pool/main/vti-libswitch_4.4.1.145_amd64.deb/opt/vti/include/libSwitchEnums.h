/*
* libSwitchEnums.h
*/

#ifndef _SwitchConstants_H
#define _SwitchConstants_H

#ifndef ___VTEXSwitch_h__

typedef enum
{
    VTEXSwitchSelfTestRelayContactResUndef = 0,
    VTEXSwitchSelfTestRelayContactResPass = 1,
    VTEXSwitchSelfTestRelayContactResHigh = 2,
    VTEXSwitchSelfTestRelayContactResNoDet = 3,
} VTEXSwitchSelfTestRelayContactResEnum;

typedef enum
{
    VTEXSwitchSelfTestRelayStatusUndef = 0,
    VTEXSwitchSelfTestRelayStatusPass = 1,
    VTEXSwitchSelfTestRelayStatusShort = 2,
    VTEXSwitchSelfTestRelayStatusOpen = 3,
    VTEXSwitchSelfTestRelayStatusNoDet = 4,
} VTEXSwitchSelfTestRelayStatusEnum;

typedef enum
{
    VTEXSwitchSelfTestStatusSuccess = 0,
    VTEXSwitchSelfTestStatusFailed = 1,
    VTEXSwitchSelfTestStatusRunning = 2,
    VTEXSwitchSelfTestStatusNotStarted = 3,
    VTEXSwitchSelfTestStatusWarning = 4,
    VTEXSwitchSelfTestStatusError = 5,
} VTEXSwitchSelfTestStatusEnum;

typedef enum
{
    VTEXSwitchPathAvailable = 100,
    VTEXSwitchPathExists = 101,
    VTEXSwitchPathUnsupported = 102,
    VTEXSwitchPathRsrcInUse = 103,
    VTEXSwitchPathSourceConflict = 104,
    VTEXSwitchPathChannelNotAvailable = 105,
    VTEXSwitchPathChannelOneUnknown = 106,
    VTEXSwitchPathChannelTwoUnknown = 107,
    VTEXSwitchPathCannotConnectToItself = 108,
    VTEXSwitchPathWireModeMismatch = 109,
} VTEXSwitchPathCapabilityEnum;

typedef enum
{
    VTEXSwitchScanModeBreakBeforeMake = 0,
    VTEXSwitchScanModeBreakAfterMake = 1,
    VTEXSwitchScanModeNone = 2,
} VTEXSwitchScanModeEnum;

typedef enum
{
    VTEXSwitchAdvancedOutputNone = 0,
    VTEXSwitchAdvancedOutputExternal = 2,
    VTEXSwitchAdvancedOutputPXIStar = 125,
    VTEXSwitchAdvancedOutputBPL0 = 1000,
    VTEXSwitchAdvancedOutputBPL1 = 1001,
    VTEXSwitchAdvancedOutputBPL2 = 1002,
    VTEXSwitchAdvancedOutputBPL3 = 1003,
    VTEXSwitchAdvancedOutputBPL4 = 1004,
    VTEXSwitchAdvancedOutputBPL5 = 1005,
    VTEXSwitchAdvancedOutputBPL6 = 1006,
    VTEXSwitchAdvancedOutputBPL7 = 1007,
    VTEXSwitchAdvancedOutputPXI0 = 1100,
    VTEXSwitchAdvancedOutputPXI1 = 1101,
    VTEXSwitchAdvancedOutputPXI2 = 1102,
    VTEXSwitchAdvancedOutputPXI3 = 1103,
    VTEXSwitchAdvancedOutputPXI4 = 1104,
    VTEXSwitchAdvancedOutputPXI5 = 1105,
    VTEXSwitchAdvancedOutputPXI6 = 1106,
    VTEXSwitchAdvancedOutputPXI7 = 1107,
    VTEXSwitchAdvancedOutputPXIe_DSTARC = 1121,
    VTEXSwitchAdvancedOutputLXISync = 1200,
} VTEXSwitchAdvancedOutputEnum;

typedef enum
{
    VTEXSwitchTriggerInputImmediate = 1,
    VTEXSwitchTriggerInputExternal = 2,
    VTEXSwitchTriggerInputSwTrigFunc = 3,
    VTEXSwitchTriggerInputPXIStar = 125,
    VTEXSwitchTriggerInputBPL0 = 1000,
    VTEXSwitchTriggerInputBPL1 = 1001,
    VTEXSwitchTriggerInputBPL2 = 1002,
    VTEXSwitchTriggerInputBPL3 = 1003,
    VTEXSwitchTriggerInputBPL4 = 1004,
    VTEXSwitchTriggerInputBPL5 = 1005,
    VTEXSwitchTriggerInputBPL6 = 1006,
    VTEXSwitchTriggerInputBPL7 = 1007,
    VTEXSwitchTriggerInputPXI0 = 1100,
    VTEXSwitchTriggerInputPXI1 = 1101,
    VTEXSwitchTriggerInputPXI2 = 1102,
    VTEXSwitchTriggerInputPXI3 = 1103,
    VTEXSwitchTriggerInputPXI4 = 1104,
    VTEXSwitchTriggerInputPXI5 = 1105,
    VTEXSwitchTriggerInputPXI6 = 1106,
    VTEXSwitchTriggerInputPXI7 = 1107,
    VTEXSwitchTriggerInputPXIe_DSTARB = 1120,
    VTEXSwitchTriggerInputLXISync = 1200,
} VTEXSwitchTriggerInputEnum;

typedef enum
{
    VTEXSwitchExternalConnectionConnect = 1000,
    VTEXSwitchExternalConnectionDisconnect = 1001,
} VTEXSwitchExternalConnectionEnum;

typedef enum
{
    VTEXSwitchRelayStateOpen = 600,
    VTEXSwitchRelayStateClosed = 601,
    VTEXSwitchRelayStateCommandedOpen = 602,
    VTEXSwitchRelayStateCommandedClosed = 603,
    VTEXSwitchRelayStateIndeterminate = 1004,
} VTEXSwitchRelayStateEnum;

typedef enum
{
	VTEXSwitchDetectionRise = 1000,
	VTEXSwitchDetectionFall = 1001,
	VTEXSwitchDetectionHigh = 1002,
	VTEXSwitchDetectionLow  = 1003,
}VTEXSwitchDetectionEnum;

#endif /* ___VTEXSwitch_h__ */
#endif /* _SwitchConstants_H */
