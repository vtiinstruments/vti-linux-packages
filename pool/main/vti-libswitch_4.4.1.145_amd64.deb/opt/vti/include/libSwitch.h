/******************************************************************************
*
*  .----------------------.    File Name: libSwitch.h
*  |==     ==  ======  == |    Project : SMX Platform
*  | ==   ==   ======  == |    $Author$
*  |  == ==      ==    == |    $Revision$
*  |   ===       ==    == |    $Date$
*  |    =        ==    == | $HeadURL$
*  `----------------------'
*
* Copyright 2010 VTI Instruments Inc. as an unpublished work.
* All rights reserved. The information contained herein is confidential
* vtexProperty of VTI Instruments, Inc. Use, copy, transfer or disclosure
* of such information is prohibited except by express written agreement
* with VTI Instruments, Inc.
*
* PURPOSE:
*   Main public interface file for the Switch library.
*
* First Written By: Praveen On Oct-2011
******************************************************************************/

#ifndef _LIB_SWITCH_H
#define _LIB_SWITCH_H

/**************************
 *       Includes         *
 **************************/
#include <string>
#include <vector>

#include "vtexInherent.h"
#include "libVtexException.h"

#include "libSwitchEnums.h"
#include "libSwitchErrors.h"

/*************************
 *      Classes          *
 *************************/

class LibSwitchAttenuator
{
public:
    virtual ~LibSwitchAttenuator() {};

    //Attributes
    vtexProperty <LibSwitchAttenuator, double, READ_WRITE> Setting;

    //Methods
    virtual VTEXResult get_Setting(double& val) = 0;
    virtual VTEXResult put_Setting(double val) = 0;
};

class LibSwitchAttenuators
{
public:
    virtual ~LibSwitchAttenuators() {};

    //Attributes
    vtexProperty <LibSwitchAttenuators, int32_t, READ_ONLY> Count;
    arrayizer <LibSwitchAttenuators, LibSwitchAttenuator*, std::string> Item;
    arrayizer <LibSwitchAttenuators, std::string, int32_t> Name;

    //Methods
    virtual LibSwitchAttenuator* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t& count) = 0;
};

class LibSwitchChannelCharacteristics
{
public:
    virtual ~LibSwitchChannelCharacteristics() {};

    //Attributes
    vtexProperty <LibSwitchChannelCharacteristics, double, READ_ONLY> ACCurrentCarryMax;
    vtexProperty <LibSwitchChannelCharacteristics, double, READ_ONLY> ACCurrentSwitchingMax;
    vtexProperty <LibSwitchChannelCharacteristics, double, READ_ONLY> ACPowerCarryMax;
    vtexProperty <LibSwitchChannelCharacteristics, double, READ_ONLY> ACPowerSwitchingMax;
    vtexProperty <LibSwitchChannelCharacteristics, double, READ_ONLY> ACVoltageMax;
    vtexProperty <LibSwitchChannelCharacteristics, double, READ_ONLY> Bandwidth;
    vtexProperty <LibSwitchChannelCharacteristics, double, READ_ONLY> Impedance;
    vtexProperty <LibSwitchChannelCharacteristics, double, READ_ONLY> DCCurrentCarryMax;
    vtexProperty <LibSwitchChannelCharacteristics, double, READ_ONLY> DCCurrentSwitchingMax;
    vtexProperty <LibSwitchChannelCharacteristics, double, READ_ONLY> DCPowerCarryMax;
    vtexProperty <LibSwitchChannelCharacteristics, double, READ_ONLY> DCPowerSwitchingMax;
    vtexProperty <LibSwitchChannelCharacteristics, double, READ_ONLY> DCVoltageMax;
    vtexProperty <LibSwitchChannelCharacteristics, double, READ_ONLY> SettlingTime;
    vtexProperty <LibSwitchChannelCharacteristics, int32_t, READ_ONLY> WireMode;

    //Methods
    virtual VTEXResult get_ACCurrentCarryMax(double &value) = 0;
    virtual VTEXResult get_ACCurrentSwitchingMax(double &value) = 0;
    virtual VTEXResult get_ACPowerCarryMax(double &value) = 0;
    virtual VTEXResult get_ACPowerSwitchingMax(double &value) = 0;
    virtual VTEXResult get_ACVoltageMax(double &value) = 0;
    virtual VTEXResult get_Bandwidth(double &value) = 0;
    virtual VTEXResult get_Impedance(double &value) = 0;
    virtual VTEXResult get_DCCurrentCarryMax(double &value) = 0;
    virtual VTEXResult get_DCCurrentSwitchingMax(double &value) = 0;
    virtual VTEXResult get_DCPowerCarryMax(double &value) = 0;
    virtual VTEXResult get_DCPowerSwitchingMax(double &value) = 0;
    virtual VTEXResult get_DCVoltageMax(double &value) = 0;
    virtual VTEXResult get_SettlingTime(double &value) = 0;
    virtual VTEXResult get_WireMode(int32_t &value) = 0;
};

class LibSwitchChannel
{
public:
    virtual ~LibSwitchChannel() {};

    //Attributes
    LibSwitchChannelCharacteristics* Characteristics;
    vtexProperty <LibSwitchChannel, bool, READ_WRITE> IsConfigurationChannel;
    vtexProperty <LibSwitchChannel, bool, READ_WRITE> IsSourceChannel;

    //Methods
    virtual VTEXResult get_IsConfigurationChannel(bool& value) = 0;
    virtual VTEXResult put_IsConfigurationChannel(bool value) = 0;
    virtual VTEXResult get_IsSourceChannel(bool& value) = 0;
    virtual VTEXResult put_IsSourceChannel(bool value) = 0;
};

class LibSwitchChannels
{
public:
    virtual ~LibSwitchChannels() {};

    //Attributes
    vtexProperty <LibSwitchChannels, int32_t, READ_ONLY> Count;
    arrayizer <LibSwitchChannels, LibSwitchChannel*, std::string> Item;
    arrayizer <LibSwitchChannels, std::string, int32_t> Name;

    //Methods
    virtual LibSwitchChannel* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t& count) = 0;
};

class LibSwitchParallelIO
{
public:
    virtual ~LibSwitchParallelIO() {};

    //Attributes
    vtexProperty <LibSwitchParallelIO, int32_t, READ_WRITE> Data;
    vtexProperty <LibSwitchParallelIO, int32_t, READ_WRITE> OutputEnableMask;

    //Methods
    virtual VTEXResult get_OutputEnableMask(int32_t& val) = 0;
    virtual VTEXResult put_OutputEnableMask(int32_t val) = 0;
    virtual VTEXResult get_Data(int32_t& val) = 0;
    virtual VTEXResult put_Data(int32_t val) = 0;
};

class LibSwitchParallelIOs
{
public:
    virtual ~LibSwitchParallelIOs() {};

    //Attributes
    vtexProperty <LibSwitchParallelIOs, int32_t, READ_ONLY> Count;
    arrayizer <LibSwitchParallelIOs, LibSwitchParallelIO*, std::string> Item;
    arrayizer <LibSwitchParallelIOs, std::string, int32_t> Name;

    //Methods
    virtual LibSwitchParallelIO* get_Item(std::string name) = 0;
    virtual std::string get_Name(int32_t index) = 0;
    virtual VTEXResult get_Count(int32_t& count) = 0;
};

class LibSwitchPath
{
public:
    virtual ~LibSwitchPath() {};

    //Attributes
    vtexProperty <LibSwitchPath, bool, READ_ONLY> IsDebounced;

    //Methods
    virtual VTEXSwitchPathCapabilityEnum CanConnect(std::string channel1, std::string channel2) = 0;
    virtual VTEXResult Connect(std::string channel1, std::string channel2) = 0;
    virtual VTEXResult Disconnect(std::string channel1, std::string channel2) = 0;
    virtual VTEXResult DisconnectAll() = 0;
    virtual std::string GetPath(std::string channel1, std::string channel2) = 0;
    virtual VTEXResult SetPath(std::string pathString) = 0;
    virtual VTEXResult WaitForDebounce(int32_t maxTimeMilliSeconds) = 0;

    virtual VTEXResult get_IsDebounced(bool& val) = 0;
};

class LibSwitchScan
{
public:
    virtual ~LibSwitchScan() {};

    //Attributes
    vtexProperty <LibSwitchScan, bool, READ_WRITE> Continuous;
    vtexProperty <LibSwitchScan, double, READ_WRITE> Delay;
    vtexProperty <LibSwitchScan, bool, READ_ONLY> IsScanning;
    vtexProperty <LibSwitchScan, std::string, READ_WRITE> List;
    vtexProperty <LibSwitchScan, VTEXSwitchScanModeEnum, READ_WRITE> Mode;
    vtexProperty <LibSwitchScan, int32_t, READ_ONLY> NumberOfColumns;
    vtexProperty <LibSwitchScan, int32_t, READ_ONLY> NumberOfRows;
    vtexProperty <LibSwitchScan, int32_t, READ_WRITE> Repeat;

    vtexProperty <LibSwitchScan, VTEXSwitchTriggerInputEnum, READ_WRITE> Input;
    vtexProperty <LibSwitchScan, VTEXSwitchAdvancedOutputEnum, READ_WRITE> AdvancedOutput;

    //Methods
    virtual VTEXResult Abort() = 0;
    virtual VTEXResult ConfigureList(std::string List, VTEXSwitchScanModeEnum mode) = 0;
    virtual VTEXResult Initiate() = 0;
    virtual VTEXResult SendSoftwareTrigger() = 0;
    virtual VTEXResult WaitForScanComplete(int32_t MaxTimeMilliseconds) = 0;
    virtual VTEXResult ConfigureTrigger(double ScanDelay, VTEXSwitchTriggerInputEnum TriggerInput, VTEXSwitchAdvancedOutputEnum AdvancedOutput) = 0;

    virtual VTEXResult get_Continuous(bool &val) = 0;
    virtual VTEXResult put_Continuous(bool val) = 0;
    virtual VTEXResult get_Delay(double &val) = 0;
    virtual VTEXResult put_Delay(double val) = 0;
    virtual VTEXResult get_IsScanning(bool &val) = 0;
    virtual VTEXResult get_List(std::string &val) = 0;
    virtual VTEXResult put_List(std::string val) = 0;
    virtual VTEXResult get_Mode(VTEXSwitchScanModeEnum& val) = 0;
    virtual VTEXResult put_Mode(VTEXSwitchScanModeEnum val) = 0;
    virtual VTEXResult get_NumberOfColumns(int32_t &val) = 0;
    virtual VTEXResult get_NumberOfRows(int32_t &val) = 0;
    virtual VTEXResult get_Repeat(int32_t &val) = 0;
    virtual VTEXResult put_Repeat(int32_t val) = 0;

    virtual VTEXResult get_Input(VTEXSwitchTriggerInputEnum& val) = 0;
    virtual VTEXResult put_Input(VTEXSwitchTriggerInputEnum val) = 0;
    virtual VTEXResult get_AdvancedOutput(VTEXSwitchAdvancedOutputEnum& val) = 0;
    virtual VTEXResult put_AdvancedOutput(VTEXSwitchAdvancedOutputEnum val) = 0;
};

class LibSwitchSelfTest
{
public:
    virtual ~LibSwitchSelfTest() {};

    virtual VTEXResult Initiate() = 0;
    virtual VTEXResult GetStatus(int32_t &status, std::string &message) = 0;
    virtual VTEXResult get_Report(std::string &val) = 0;

    vtexProperty <LibSwitchSelfTest, std::string, READ_ONLY> Report;
};

class LibSwitchFpOpen
{
public:
    virtual ~LibSwitchFpOpen() {};

    virtual VTEXResult ResetLatchedStatus() = 0;
    virtual VTEXResult get_Enabled(bool &val) = 0;
    virtual VTEXResult put_Enabled(bool val) = 0;
    virtual VTEXResult get_Detection(VTEXSwitchDetectionEnum &val) = 0;
    virtual VTEXResult put_Detection(VTEXSwitchDetectionEnum val) = 0;
    virtual VTEXResult get_CurrentStatus(int32_t &val) = 0;
    virtual VTEXResult get_LatchedStatus(int32_t &val) = 0;

    vtexProperty <LibSwitchFpOpen, bool, READ_WRITE> Enabled;
    vtexProperty <LibSwitchFpOpen, VTEXSwitchDetectionEnum, READ_WRITE> Detection;
    vtexProperty <LibSwitchFpOpen, int32_t, READ_ONLY> CurrentStatus;
    vtexProperty <LibSwitchFpOpen, int32_t, READ_ONLY> LatchedStatus;
};

class LibSwitchInstrumentSpecific
{
public:
    virtual ~LibSwitchInstrumentSpecific() {};

    LibSwitchAttenuators* Attenuators;
    LibSwitchParallelIOs* ParallelIOs;
    LibSwitchSelfTest* SelfTest;
    LibSwitchFpOpen* FPOpen;

    //Attributes
    vtexProperty <LibSwitchInstrumentSpecific, std::string, READ_ONLY> ListOfAttenuators;
    vtexProperty <LibSwitchInstrumentSpecific, std::string, READ_ONLY> ListOfChannels;
    vtexProperty <LibSwitchInstrumentSpecific, std::string, READ_ONLY> ListOfParallelIOs;
    vtexProperty <LibSwitchInstrumentSpecific, std::string, READ_ONLY> ListOfRelays;
    vtexProperty <LibSwitchInstrumentSpecific, std::string, READ_ONLY> SerialNumber;
    vtexProperty <LibSwitchInstrumentSpecific, std::string, READ_ONLY> InstrumentHardwareRevision;
    vtexProperty <LibSwitchInstrumentSpecific, bool, READ_WRITE> VerifyRelayState;

    //Relay-level interfaces
    virtual VTEXResult CloseRelays(std::string relayList) = 0;
    virtual VTEXResult OpenRelays(std::string relayList) = 0;
    virtual VTEXSwitchRelayStateEnum GetRelayState(std::string relayName) = 0;
    virtual VTEXResult GetRelayStates(std::string relayList, std::vector<VTEXSwitchRelayStateEnum>& states) = 0;
    virtual VTEXResult GetOdometers(std::string relayList, std::vector<int32_t>& odometers) = 0;
    virtual VTEXResult AddRelayLevelExcludeList(std::string excludeList, std::string name) = 0;
    virtual VTEXResult RemoveRelayLevelExcludeList(std::string name) = 0;

    virtual VTEXResult LoadState(int32_t id) = 0;
    virtual VTEXResult OpenLogFile(std::string fileName, std::string accessMode) = 0;
    virtual VTEXResult CloseLogFile() = 0;

    virtual VTEXResult AddPathLevelExcludeList(std::string excludeList, std::string name) = 0;
    virtual VTEXResult RemovePathLevelExcludeList(std::string name) = 0;
    virtual VTEXResult ExternalConnection(std::string channel1, std::string channel2) = 0;

    virtual VTEXResult get_ListOfAttenuators(std::string& val) = 0;
    virtual VTEXResult get_ListOfChannels(std::string& val) = 0;
    virtual VTEXResult get_ListOfParallelIOs(std::string& val) = 0;
    virtual VTEXResult get_ListOfRelays(std::string& val) = 0;
    virtual VTEXResult get_SerialNumber(std::string& val) = 0;
    virtual VTEXResult get_InstrumentHardwareRevision(std::string& val) = 0;
    virtual VTEXResult get_VerifyRelayState(bool& verify) = 0;
    virtual VTEXResult put_VerifyRelayState(bool verify) = 0;
};

class LibSwitch : public vtexInherent
{
public:
    static LibSwitch* Create();
    virtual ~LibSwitch() {};

    vtexInherentCapabilityUtility* Utility;
    vtexInherentCapabilityDriverOperation* DriverOperation;
    vtexInherentCapabilityIdentity* Identity;

    LibSwitchChannels* Channels;
    LibSwitchPath* Path;
    LibSwitchScan* Scan;
    LibSwitchInstrumentSpecific* InstrumentSpecific;

    vtexProperty <LibSwitch, bool, READ_ONLY> Initialized;
};

#endif  //_LIB_SWITCH_H
