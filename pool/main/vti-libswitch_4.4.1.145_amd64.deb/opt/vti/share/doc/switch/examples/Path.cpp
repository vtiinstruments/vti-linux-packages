#include "libSwitch.h"
#include <stdio.h>

int main()
{
    //Create a VTEXSwitch pointer
    LibSwitch *pSwitch;

    /*We want to instantiate a pointer to the driver in a try/catch block so that we fail
    properly if there is an error*/
    try
    {
        //Instantiate the created switch pointer
        pSwitch = LibSwitch::Create();
        /*We want to do the initialization in a try/catch block so that our test code
        doesn't run if we fail to initialize.*/

        try
        {
            /*We chose to give the driver an empty options string. You may want to
            give your driver options - check the manual to see the available settings.
            Note that we also set the Reset bit so that we get a clean start to work
            from.*/
            pSwitch->Initialize("TCPIP::10.1.4.55::INSTR", true, true, "");

            //Assume that you have a EX1200_3048 switch card in slot 1 of your system
            //By default, the common channels in EX1200_3048 are not configuration channels.
            //In order for channels to be connected through the common channels, the common
            //channels need to be set to configuration channels.
            pSwitch->Channels->Item["1!CH1_COM"]->IsConfigurationChannel = true;
            pSwitch->Channels->Item["1!CH2_COM"]->IsConfigurationChannel = true;

            /*To check if two channels can be connected, you can use CanConnect
            function to check.*/
            VTEXSwitchPathCapabilityEnum status = pSwitch->Path->CanConnect("1!CH1_1H", "1!CH1_2H");
            /*In this case, you are checking the path capability of CH1_1H in slot 1
            and CH1_2H in slot 1. Note that "1!" means slot 1. There are more than
            one type of path capability, please read the user manual for more information*/

            /*In EX1200_3048, CH1_1H should be able to connect to CH1_2H, we are now to
            connect these two channels.*/
            pSwitch->Path->Connect("1!CH1_1H", "1!CH1_2H");
            /*At this point, they should be connected. You can always use the SFP
            to check the connection. For more information about how to use the SFP,
            please read the user manual.*/

            /*After you have connected the channels, you can always check the path
            which the switch driver connects the channels.*/
            std::string path = pSwitch->Path->GetPath("1!CH1_1H", "1!CH1_2H");

            /*You can always disconnect the channels you have connected. Note that if you
            try to disconnect channels that are not connected, an exception will be generated.*/
            pSwitch->Path->Disconnect("1!CH1_1H", "1!CH1_2H");
            /*At this point, they should be disconnected. You use the SFP to check the connection.*/

            /*There is another way to connect two channels. By calling SetPath function,
            you can specify the path that you like to connect two channels. Note that
            there are syntax for the path for the SetPath function. Please read the
            user manual for more information about SetPath function.*/
            /*Since we get the path before, we can reuse it. But remember that you can
            always specify a valid path you like to connect two channels.*/
            pSwitch->Path->SetPath(path.c_str());

            /*There is another way to disconnect channels as well. By calling DisconnectAll
            function, you can disconnect all the connected channels without specifying
            which channels you are to disconnect.*/
            pSwitch->Path->DisconnectAll();

            //Close the initialized session
            pSwitch->Close();
        }
        catch(VTEXException e)
        {
            printf("Error code: %d\n", e.errorCode);
            printf("Error Message: %s\n", e.errorMessage.c_str());
        }

        //Clean up when we're done
        if(pSwitch->Initialized)
        {
            pSwitch->Close();
        }
        delete pSwitch;
        pSwitch = nullptr;
    }
    catch(...)
    {
        /*We put this here to catch any error the program generates.*/
        //Do something to intelligently deal with errors
    }
}
