#include "libSwitch.h"
#include <stdio.h>

int main()
{
    //Create a VTEXSwitch pointer
    LibSwitch *pSwitch;

    /*We want to instantiate a pointer to the driver in a try/catch block so that we fail
    properly if there is an error*/
    try
    {
        //Instantiate the created switch pointer
        pSwitch = LibSwitch::Create();
        /*We want to do the initialization in a try/catch block so that our test code
        doesn't run if we fail to initialize.*/

        try
        {
            /*We chose to give the driver an empty options string. You may want to
            give your driver options - check the manual to see the available settings.
            Note that we also set the Reset bit so that we get a clean start to work
            from.*/
            pSwitch->Initialize("TCPIP::10.1.4.55::INSTR", true, true, "");

            /*Different model of switch card has its own set of channel names. To get all
            the channel name for your specific switch caard, there are two ways you
            can do that.*/
            //The first way is to get the channel names one by one
            //Get the total number of channels
            int count = pSwitch->Channels->Count;
            //Print out the channel names one by one in a for loop
            for(int i=0; i<count; i++)
                printf("%s ", pSwitch->Channels->Name[i+1].c_str());
            /*Note that Name is not 0-based. It is 1-based, so the first channel is
            at index 1.*/

            //The second way is to get all the channel names at once
            std::string channelList = pSwitch->InstrumentSpecific->ListOfChannels;
            printf("%s\n", channelList.c_str()); //Print out the channel List

            /*Once you know the name of the channel you want to use, you can also set
            the property of that particular channel, such as setting it to a
            configuration channel or source channel. Please read the user manual
            for more information about configuration channel and source channel.*/
            //Set the first channel to be a configuration channel
            pSwitch->Channels->Item[pSwitch->Channels->Name[1]]->IsConfigurationChannel = true;

            //Set the second channel to be a source channel
            pSwitch->Channels->Item[pSwitch->Channels->Name[2]]->IsSourceChannel = true;
            /*This is just an example. You should know the configuration of your switch
            card before setting any channel to configuration channel or source channel.*/

            //Close the initialized session
            pSwitch->Close();
        }
        catch(VTEXException e)
        {
            printf("Error code: %d\n", e.errorCode);
            printf("Error Message: %s\n", e.errorMessage.c_str());
        }

        //Clean up when we're done
        if(pSwitch->Initialized)
        {
            pSwitch->Close();
        }
        delete pSwitch;
        pSwitch = nullptr;
    }
    catch(...)
    {
        /*We put this here to catch any error the program generates.*/
        //Do something to intelligently deal with errors
    }
}
