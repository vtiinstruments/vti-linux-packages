#include "libSwitch.h"
#include <stdio.h>

int main()
{
    //Create a VTEXSwitch pointer
    LibSwitch *pSwitch;
    bool isScanning;

    /*We want to instantiate a pointer to the driver in a try/catch block so that we fail
    properly if there is an error*/
    try
    {
        //Instantiate the created switch pointer
        pSwitch = LibSwitch::Create();
        /*We want to do the initialization in a try/catch block so that our test code
        doesn't run if we fail to initialize.*/

        try
        {
            /*We chose to give the driver an empty options string. You may want to
            give your driver options - check the manual to see the available settings.
            Note that we also set the Reset bit so that we get a clean start to work
            from.*/
            pSwitch->Initialize("TCPIP::10.1.4.55::INSTR", true, true, "");

            //Setup the scanlist and scan mode
            //"1!" means "Slot 1". Make sure that you have your card in slot one before you run this program.
            //Also, a EX1200_3048 switch card is used in this example
            pSwitch->Scan->ConfigureList("1!CH1_1H->1!CH1_2H;1!CH1_3H->1!CH1_4H;1!CH2_1H->1!CH2_2H;1!CH2_3H->1!CH2_4H;",
                                        VTEXSwitchScanModeBreakBeforeMake);
            /*By setting the scan mode to "BreakBeforeMake", the Switch driver will first break
            the previous connection before making the next one.*/

            //Setup the delay, trigger input and output
            pSwitch->Scan->ConfigureTrigger(0, VTEXSwitchTriggerInputSwTrigFunc, VTEXSwitchAdvancedOutputBPL0);

            /*In this case, the sequence of the scan would be:
            Step #1: Connect 1!CH1_1H and 1!CH1_2H
            Step #2: Route a signal on BPL0
            Step #3: Wait for software trigger
            Step #4: Disconnect 1!CH1_1H and 1!CH1_2H (after receiving a software trigger)
            Step #5: Connect 1!CH1_3H and 1!CH1_4H
            Step #6: Route a signal on BPL0
            Step #7: Wait for software trigger
            Step #8: Disconnect 1!CH1_3H and 1!CH1_4H (after receiving a software trigger)
            Step #9: Connect 1!CH2_1H and 1!CH2_2H
            Step #10: Route a signal on BPL0
            Step #11: Wait for software trigger
            Step #12: Disconnect 1!CH2_1H and 1!CH2_2H (after receiving a software trigger)
            Step #13: Connect 1!CH2_3H and 1!CH2_4H*/

            //Set Continuous to false
            pSwitch->Scan->Continuous = false;

            /*By default, the common channels are set to be non-configuration channels. A non-configuration
            channel can only be used in the beginning or the end of a scanlist as a terminated channel.
            Therefore, in order for the scanlist to be initiated without errors, they need to be set to
            configuration channels. For more information about configuration channel, please read the user manual.*/
            pSwitch->Channels->Item["1!CH1_COM"]->IsConfigurationChannel = true;
            pSwitch->Channels->Item["1!CH2_COM"]->IsConfigurationChannel = true;

            //Initiate a scan
            pSwitch->Scan->Initiate();

            /*After the scan is initiated , the first step is always operated without
            waiting for any trigger. At this point, 1!CH1_1H should be already connected
            to 1!CH1_2H. To verify that, you can open the Switch SFP to check their
            connection.*/

            /*The first step is done but we have 4 steps in the scanlist, so we need to
            send 3 more software trigger to finish the whole scanlist.*/
            for(int i=0; i<3; i++)
            {
                isScanning = pSwitch->Scan->IsScanning; /*In this for loop, isScanning
                is always true, because the scan isn't finished yet.*/
                pSwitch->Scan->SendSoftwareTrigger();
            }

            /*In this case, in the first loop after the software trigger is sent, you
            can see 1!CH1_1H is disconnected from 1!CH1_2H and 1!CH1_3H is connected to 1!CH1_4H.
            In the second loop after the software trigger is sent, you
            can see 1!CH1_3H is disconnected from 1!CH1_4H and 1!CH2_1H is connected
            to 1!CH2_2H. In the third loop after the software trigger is sent, you
            can see 1!CH2_1H is disconnected from 1!CH2_2H and 1!CH2_3H is connected
            to 1!CH2_4H.*/

            /*After 3 software trigger are sent, the scan process finally finishes.
            isScanning should be false now.*/
            isScanning = pSwitch->Scan->IsScanning;

            //Close the initialized session
            pSwitch->Close();
        }
        catch(VTEXException e)
        {
            printf("Error code: %d\n", e.errorCode);
            printf("Error Message: %s\n", e.errorMessage.c_str());
        }

        //Clean up when we're done
        if(pSwitch->Initialized)
        {
            pSwitch->Close();
        }
        delete pSwitch;
        pSwitch = nullptr;
    }
    catch(...)
    {
        /*We put this here to catch any error the program generates.*/
        //Do something to intelligently deal with errors
    }
}
