#include "libSwitch.h"
#include <iostream>
#include <sstream>
#include <string>

inline std::string toString(std::vector<int> vec) {
    std::ostringstream ss;
    if(vec.size() > 0) {
        ss << "[";
    }
    for (size_t i = 0; i < vec.size(); i++) {
        ss << vec[i] << ((i < vec.size()-1) ? ", " : "]");
    }
    return ss.str();
}

int main(int argc, char **argv)
{
    //Create a VTEXSwitch pointer
    LibSwitch *pSwitch;

    /*We want to instantiate a pointer to the driver in a try/catch block so that we fail
    properly if there is an error*/
    try
    {
        //Instantiate the created switch pointer
        pSwitch = LibSwitch::Create();
        /*We want to do the initialization in a try/catch block so that our test code
        doesn't run if we fail to initialize.*/

        try
        {
            /*
            The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
            where slot0_3 specifies a single card in the chassis.
            In this example, we need to deal with relays instead of channels and paths,
            so we need to set the IndividualRelayMode to true in DriverSetup in the
            Initialize function. Please read the user manual for more information about
            the DriverSetup.
            */
            if (argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);
            pSwitch->Initialize(resource_string, true, true, "DriverSetup=IndividualRelayMode=true");
            std::cout << "Initialized to " << resource_string << std::endl;
            
            std::string relay_list, first_relay;
            std::vector<int> odometer_values;
            
            //Get the list of all relays in the system
            relay_list = pSwitch->InstrumentSpecific->ListOfRelays;
            std::cout << "Relay List:" << std::endl;
            std::cout << relay_list << std::endl;
            
            size_t comma = relay_list.find(',');
            first_relay = relay_list.substr(0, comma);
            std::cout << "First relay: " << first_relay << std::endl;

            //You can check how many times a relay has ever closed in its life time
            pSwitch->InstrumentSpecific->GetOdometers(first_relay, odometer_values);
            std::cout << "Odometer count: " << first_relay << " " << odometer_values[0] << std::endl;

            //You can check more than one relay at once
            pSwitch->InstrumentSpecific->GetOdometers(relay_list, odometer_values);
            std::cout << "All odometers:" << std::endl;
            std::cout << toString(odometer_values) << std::endl;

            //Calling CloseRelays function, you can close any relay in the switch card
            pSwitch->InstrumentSpecific->CloseRelays(relay_list);

            //After closing the relays, you can see that the count of each relay increments by 1.
            pSwitch->InstrumentSpecific->GetOdometers(relay_list, odometer_values);
            std::cout << "All odometers (after closing):" << std::endl;
            std::cout << toString(odometer_values) << std::endl;

            //Calling OpenRelays function, you can open any relay that has been closed
            pSwitch->InstrumentSpecific->OpenRelays(relay_list);
            
            //Opening a relay does not increase the odometer count
            pSwitch->InstrumentSpecific->GetOdometers(relay_list, odometer_values);
            std::cout << "All odometers (after opening):" << std::endl;
            std::cout << toString(odometer_values) << std::endl;

            //Close the initialized session
            pSwitch->Close();
        }
        catch(VTEXException e)
        {
            printf("Error code: %d\n", e.errorCode);
            printf("Error Message: %s\n", e.errorMessage.c_str());
        }

        //Clean up when we're done
        if(pSwitch->Initialized)
        {
            pSwitch->Close();
        }
        delete pSwitch;
        pSwitch = nullptr;
    }
    catch(...)
    {
        /*We put this here to catch any error the program generates.*/
        //Do something to intelligently deal with errors
    }
}
