#include "libSwitch.h"
#include <stdio.h>

int main()
{
    //Create a VTEXSwitch pointer
    LibSwitch *pSwitch;

    /*We want to instantiate a pointer to the driver in a try/catch block so that we fail
    properly if there is an error*/
    try
    {
        //Instantiate the created switch pointer
        pSwitch = LibSwitch::Create();
        /*We want to do the initialization in a try/catch block so that our test code
        doesn't run if we fail to initialize.*/

        try
        {
            /*We chose to give the driver an empty options string. You may want to
            give your driver options - check the manual to see the available settings.
            Note that we also set the Reset bit so that we get a clean start to work
            from.*/
            pSwitch->Initialize("TCPIP::10.1.4.55::INSTR", true, true, "");

            //First configure the scanlist and the scan mode
            /*Note that there is syntax in the scanlist configuration, please read the user manual
            for more information. Also, the Switch driver provides 3 scan modes o scan the channels
            in the scanlist differently, please read the user manual for information.*/
            pSwitch->Scan->ConfigureList("1!CH1_1H->1!CH1_2H;1!CH2_1H->1!CH2_2H", VTEXSwitchScanModeNone);

            //Then, set the trigger properties.
            /*Please read the user manual for more information about the trigger source and
            trigger input.*/
            pSwitch->Scan->ConfigureTrigger(0,VTEXSwitchTriggerInputImmediate,VTEXSwitchAdvancedOutputNone);
            /*In this case, we set the scan delay to 0, trigger input to Immediate and trigger output to None.
            It means, the Switch driver is to scan the channels in the scanlist immediately without any delay
            and output after a scan is initiated.*/

            /*You can set the Continuous property to true to command the Switch driver repeat scanning
            the same scanlist until you call the Abort function to stop it. But in this case, we
            set it to false. That means, the Switch driver only scan the scanlist once.*/
            pSwitch->Scan->Continuous = false;

            //The IsScanning property helps you to determine if any scan is in progress
            bool isScanning = pSwitch->Scan->IsScanning;

            /*By default, the common channels are set to be non-configuration channels. A non-configuration
            channel can only be used in the beginning or the end of a scanlist as a terminated channel.
            Therefore, in order for the scanlist to be initiated without errors, they need to be set to
            configuration channels. For more information about configuration channel, please read the user manual.*/
            pSwitch->Channels->Item["1!CH1_COM"]->IsConfigurationChannel = true;
            pSwitch->Channels->Item["1!CH2_COM"]->IsConfigurationChannel = true;

            //Initiate the scan
            if (!isScanning)
                pSwitch->Scan->Initiate();
            //You can open the SFP and see the scanning process.

            //Close the initialized session
            pSwitch->Close();
        }
        catch(VTEXException e)
        {
            printf("Error code: %d\n", e.errorCode);
            printf("Error Message: %s\n", e.errorMessage.c_str());
        }

        //Clean up when we're done
        if(pSwitch->Initialized)
        {
            pSwitch->Close();
        }
        delete pSwitch;
        pSwitch = nullptr;
    }
    catch(...)
    {
        /*We put this here to catch any error the program generates.*/
        //Do something to intelligently deal with errors
    }
}
