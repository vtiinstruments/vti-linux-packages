#include <iostream>
#include "libSwitch.h"

int main(int argc, char **argv)
{
    //Create a VTEXSwitch pointer
    LibSwitch *pSwitch;

    /*We want to instantiate a pointer to the driver in a try/catch block so that we fail
    properly if there is an error*/
    try
    {
        //Instantiate the created switch pointer
        pSwitch = LibSwitch::Create();
        /*We want to do the initialization in a try/catch block so that our test code
        doesn't run if we fail to initialize.*/

        try
        {
            // The resource string should be in the form of TCPIP::192.168.0.1::INSTR or TCPIP::hostname::slot0_3::INSTR
            if (argc != 2)
            {
                std::cout << "Usage: " << argv[0] << " <resource_string>" << std::endl;
                return -1;
            }
            std::string resource_string(argv[1]);

            /*We chose to give the driver an empty options string. You may want to
            give your driver options - check the manual to see the available settings.
            Note that we also set the Reset bit so that we get a clean start to work
            from.*/
            pSwitch->Initialize(resource_string, true, true, "");

            /*The identity class contains properties that return general information of the instrument.
            You can get the information of the instrument simply by getting the value of the
            properties.*/
            std::string description = pSwitch->Identity->Description;
            std::string groupCapabilities = pSwitch->Identity->GroupCapabilities;
            std::string identifier = pSwitch->Identity->Identifier;
            std::string revision = pSwitch->Identity->Revision;
            std::string supportedInstrumentModels = pSwitch->Identity->SupportedInstrumentModels;
            std::string vendor = pSwitch->Identity->Vendor;

            std::string model = pSwitch->Identity->InstrumentModel;
            std::cout << "Model: " << model << std::endl;

            std::string firmware_rev = pSwitch->Identity->InstrumentFirmwareRevision;
            std::cout << "Firmware Revision: " << firmware_rev << std::endl;

            std::string manufacturer = pSwitch->Identity->InstrumentManufacturer;
            std::cout << "Manufacturer: " << manufacturer << std::endl;

            //You can also get the serial number
            std::string serial = pSwitch->InstrumentSpecific->SerialNumber;
            std::cout << "Serial: " << serial << std::endl;

            //Close the initialized session
            pSwitch->Close();
        }
        catch(VTEXException e)
        {
            if(e.Error() == (int)IVI_E_INSTRUMENT_STATUS) // If the error is IVI_E_INSTRUMENT_STATUS, we need to check the error queue
            {
                std::string error;
                int32_t error_code;
                pSwitch->Utility->ErrorQuery(error_code, error);

                std::cerr << "Error Code: " << error_code << std::endl;
                std::cerr << error << std::endl;
            }
            else
            {
                std::cerr << "Error Code: " << e.errorCode << std::endl;
                std::cerr << e.errorMessage << std::endl;
            }
            pSwitch->Close(); // If an exception occurs, try to close the driver session gracefully if possible
        }

        //Clean up when we're done
        delete pSwitch;
        pSwitch = nullptr;
    }
    catch(...)
    {
        // Handle any non VTEX exceptions here
    }
}
