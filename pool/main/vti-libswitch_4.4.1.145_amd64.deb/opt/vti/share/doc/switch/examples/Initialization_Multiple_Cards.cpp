#include "libSwitch.h"
#include <stdio.h>

int main()
{
    //Create a VTEXSwitch pointer
    LibSwitch *pSwitch;

    /*We want to instantiate a pointer to the driver in a try/catch block so that we fail
    properly if there is an error*/
    try
    {
        //Instantiate the created switch pointer
        pSwitch = LibSwitch::Create();
        /*We want to do the initialization in a try/catch block so that our test code
        doesn't run if we fail to initialize.*/

        try
        {
            //Initialize a new session with connecting multiple switch cards
            //In this example, you are to connect to cards in slot 1-3 on instrument at IP address 10.1.0.87,
            //in slot 1-3 on instrument at IP address 10.1.0.88, and
            //in slot 5-10 on instrument at IP address 10.1.0.100

            //Specify all the instrument logical addresses in ResourceName
            //Specify the slot in the driver setup section in OptionString
            pSwitch->Initialize("TCPIP::10.1.0.87::INSTR, TCPIP::10.1.0.88::INSTR, TCPIP::10.1.0.100::INSTR",
                                true,
                                true,
                                "DriverSetup= Slots=(1-3, 101-103, 205-210)");
            //1-3 in the driver setup means slot 1-3 in 10.1.0.87
            //101-103 in the driver setup means slot 1-3 in 10.1.0.88
            //205-210 in the driver setup means slot 5-10 in 10.1.0.100

            //If there is a fourth instrument, the slot should begin from 300.
            //So, 301 will be slot 1 in the fourth instrument and 302 will be slot 2 and so on.
            //Test code goes here

            //Close the initialized session
            pSwitch->Close();
        }
        catch(VTEXException e)
        {
            printf("Error code: %d\n", e.errorCode);
            printf("Error Message: %s\n", e.errorMessage.c_str());
        }

        //Clean up when we're done
        if(pSwitch->Initialized)
        {
            pSwitch->Close();
        }
        delete pSwitch;
        pSwitch = nullptr;
    }
    catch(...)
    {
        /*We put this here to catch any error the program generates.*/
        //Do something to intelligently deal with errors
    }
}
