#include "libSwitch.h"
#include <stdio.h>

int main()
{
    //Create a VTEXSwitch pointer
    LibSwitch *pSwitch;

    /*We want to instantiate a pointer to the driver in a try/catch block so that we fail
    properly if there is an error*/
    try
    {
        //Instantiate the created switch pointer
        pSwitch = LibSwitch::Create();
        /*We want to do the initialization in a try/catch block so that our test code
        doesn't run if we fail to initialize.*/

        std::vector<int> count;

        try
        {
            /*In this example, we need to deal with relays instead of channels and paths,
            so we need to set the IndividualRelayMode to true in DriverSetup in the
            Initialize function. Please read the user manual for more information about
            the DriverSetup.*/
            pSwitch->Initialize("TCPIP::10.1.4.55::INSTR", true, true, "DriverSetup=IndividualRelayMode=true");

            //You can check how many times a relay has ever closed in its life time
            //Assume that you have a EX1200_3048 in slot 1 of your system
            pSwitch->InstrumentSpecific->GetOdometers("1!K1", count);

            //You can check more than one relay at once
            pSwitch->InstrumentSpecific->GetOdometers("1!K1,1!K2", count);

            //Calling CloseRelays function, you can close any relay in the switch card
            pSwitch->InstrumentSpecific->CloseRelays("1!K1");

            //You can also close more than one relay at once
            pSwitch->InstrumentSpecific->CloseRelays("1!K1,1!K2");

            /*After closing and opening K1 and K2, you can see that the count of each
            relay increments by 1.*/
            pSwitch->InstrumentSpecific->GetOdometers("1!K1,1!K2", count);

            /*You can call GetRelayState to check the state of any relay. In this case,
            if we check the state of K1 and K2, the state should be "Closed".*/
            VTEXSwitchRelayStateEnum state = pSwitch->InstrumentSpecific->GetRelayState("1!K1");
            state = pSwitch->InstrumentSpecific->GetRelayState("1!K2");
            /*Note that there are more than one relay state, please read the user
            manual for more information about the relay state.*/

            //Calling OpenRelays function, you can open any relay that has been closed
            pSwitch->InstrumentSpecific->OpenRelays("1!K1");

            //You can also open more than one relay at once
            pSwitch->InstrumentSpecific->OpenRelays("1!K1,1!K2");

            /*After you have opened the relay K1 and K2, the relay state should become
            "Open".*/
            state = pSwitch->InstrumentSpecific->GetRelayState("1!K1");
            state = pSwitch->InstrumentSpecific->GetRelayState("1!K2");

            //Close the initialized session
            pSwitch->Close();
        }
        catch(VTEXException e)
        {
            printf("Error code: %d\n", e.errorCode);
            printf("Error Message: %s\n", e.errorMessage.c_str());
        }

        //Clean up when we're done
        if(pSwitch->Initialized)
        {
            pSwitch->Close();
        }
        delete pSwitch;
        pSwitch = nullptr;
    }
    catch(...)
    {
        /*We put this here to catch any error the program generates.*/
        //Do something to intelligently deal with errors
    }
}
